﻿/**
 * 
 */
angular.module('PruForce.controllers')

    .controller('LoginCtrl', function ($scope, $state, $cordovaSQLite, $translate, $ionicHistory, $filter, $rootScope, $ionicLoading, LoginService, DetailProfileService, $localStorage, $ionicPopup, CheckScoreRecExamService, GetAplicationPackService, GetCountRecExamService,
        GetSupportDocService, GetCountAgentJourneyAppPackService, CollectPackStatusDataService, FormulirPerekrutanService, CheckingRetakerAAJIService, GetAMLScoreService, GetCountRegistrationAAJIService, GetCountRetakerAAJIService, Idle, SecurityQuestionService, GetListDeviceService, RegisterDeviceService, PushNotificationService, SubscribeNotificationService) {
        $scope.user = {};
        $scope.login = function () {
            if ($scope.user.username == undefined || $scope.user.password == undefined || $scope.user.username == "" || $scope.user.password == "") {
                $rootScope.AlertDialog($filter('translate')('PRU_06'));
                clearInputedFormLogin();
            } else {

                AnalyticsLog.logPage("login.app");
                $rootScope.username = $filter('lowercase')($scope.user.username);
                $rootScope.agent.code = $filter('lowercase')($scope.user.username);
                $ionicLoading.show();
                LoginService.invoke($scope.user.username, $scope.user.password, "agen").then(function (res) {
                    getTokenSuccess(res);
                });
                $ionicHistory.nextViewOptions({
                    disableAnimate: true,
                    disableBack: true
                });

            }
        }

        $scope.ForgetPassword = function () {
            $ionicLoading.show();
            SecurityQuestionService.invoke().then(function (result) {
                if (result.invocationResult.statusCode == 200) {
                    if (result.invocationResult.array != null) {
                        for (var i = 0; i < result.invocationResult.array.length; i++) {
                            var dataSQ = {};
                            dataSQ.aobdescriptionind = result.invocationResult.array[i].aobdescriptionind;
                            dataSQ.aobsystemcodeid = result.invocationResult.array[i].aobsystemcodeid;
                            dataSQ.aobitem = result.invocationResult.array[i].aobitem;
                            $rootScope.listQuestions[i] = dataSQ;
                        }
                        $state.go('lupa-pass');
                    } else {
                        AppsLog.log("no data found");
                    }

                } else {
                    AppsLog.log("result errror");
                }
            });
        }

        /* when create tag repository ,please comment this code*/
        
        function getServerUrl() {
            var ServerUrl = '';
            WL.App.getServerUrl(function (getServerURLSuccess) {
                console.log(getServerURLSuccess);
                ServerUrl = getServerURLSuccess;
            }), function (getServerURLFailure) {
                console.log(getServerURLFailure);
            };
            return ServerUrl;
        }

        function setServerUrl(serverURL) {
            console.log(serverURL);
            WL.App.setServerUrl(serverURL, setServerURLSuccess, setServerURLFailure);
        }

        function setServerURLSuccess() {
            getServerUrl();
        }

        function setServerURLFailure(error) {
            console.log('setServerURLFailure');
            console.log(error);
        }

        $scope.ChangeServer = function () {
            runtimeServer == $rootScope.DevServer + '/api' ? setServerUrl($rootScope.SITServer) : setServerUrl($rootScope.DevServer);
        }

        function clearInputedFormLogin() {
            $scope.user.username = '';
            $scope.user.password = '';
        }

        $rootScope.widgetList = {
            WIDGET_PERSISTENCY: false,
            WIDGET_POLICY_STATUS: false,
            WIDGET_PRODUCTION: false,
            WIDGET_PROPOSAL_STATUS: false,
            WIDGET_NEWS_UPDATE: false,
            WIDGET_COMMISSION_ESTIMATION: false,
            WIDGET_CONTEST: false,
            WIDGET_BONUS: false
        };

        $rootScope.MenuList = {
            LIST_RECRUITMENT: false,
            AAJIAGENT: false,
            NEWSQS: false,
            HOME: false,
            NEWS_UPDATE: false,
            ACHIEVEMENT: false,
            INQUIRY: false,
            HELP: false,
            CONTEST: false,
            CONTACTSUPPORT: false,
            AGENTPROFILE: true
        };

        function setWidget(value) {
            switch (value) {
                case "WIDGET_PERSISTENCY":
                    $rootScope.widgetList.WIDGET_PERSISTENCY = true;
                    break;
                case "WIDGET_POLICY_STATUS":
                    $rootScope.widgetList.WIDGET_POLICY_STATUS = true;
                    break;
                case "WIDGET_PRODUCTION":
                    $rootScope.widgetList.WIDGET_PRODUCTION = true;
                    break;
                case "WIDGET_PROPOSAL_STATUS":
                    $rootScope.widgetList.WIDGET_PROPOSAL_STATUS = true;
                    break;
                case "WIDGET_NEWS_UPDATE":
                    $rootScope.widgetList.WIDGET_NEWS_UPDATE = true;
                    break;
                case "WIDGET_COMMISSION_ESTIMATION":
                    $rootScope.widgetList.WIDGET_COMMISSION_ESTIMATION = true;
                    break;
                case "WIDGET_CONTEST":
                    $rootScope.widgetList.WIDGET_CONTEST = true;
                    break;
                case "WIDGET_TO_DO":
                    $rootScope.widgetList.WIDGET_TO_DO = true;
                    break;

                case "SIDEBAR_HOME":
                    $rootScope.MenuList.HOME = true;
                    break;
                // aaji set from service getDetailProfile
                // case "SIDEBAR_AAJI":
                // 	$rootScope.MenuList.AAJIAGENT = true;
                // 	break;
                case "SIDEBAR_ACV":
                    $rootScope.MenuList.ACHIEVEMENT = true;
                    break;
                case "SIDEBAR_HELP":
                    $rootScope.MenuList.HELP = true;
                    break;
                case "SIDEBAR_CONTEST":
                    $rootScope.MenuList.CONTEST = true;
                    break;
                case "SIDEBAR_INQUIRIES":
                    $rootScope.MenuList.INQUIRY = true;
                    break;
                case "SIDEBAR_NEWS_UPDATE":
                    $rootScope.MenuList.NEWS_UPDATE = true;
                    break;
                case "SIDEBAR_NEW_SQS":
                    $rootScope.MenuList.NEWSQS = true;
                    break;
                case "SIDEBAR_LIST_RECRUITMENT":
                    $rootScope.MenuList.LIST_RECRUITMENT = true;
                    break;
                case "SIDEBAR_CS":
                    $rootScope.MenuList.CONTACTSUPPORT = true;
                    break;
                // case "BONUS":
                // 	$rootScope.widgetList.WIDGET_BONUS = true;
                // 	break; 
            }
        }

        function getTokenSuccess(res) {
            if (res.invocationResult.statusCode == 200) {
                if (res.invocationResult.access_token != undefined || res.invocationResult.access_token == !null) {
                    AnalyticsLog.logPage("Get.Token");
                    $localStorage.access_token = res.invocationResult.access_token;
                    if (res.invocationResult.mobileMenu != undefined || res.invocationResult.mobileMenu != null || res.invocationResult.mobileMenu == '') {
                        $localStorage.menuWidgetList = res.invocationResult.mobileMenu.menu;
                    }
                    $rootScope.flagtoken = true;
                    try {
                        DetailProfileService.invoke($localStorage.access_token).then(function (res) {
                            getDetailProfileServiceSuccess(res);
                        });
                    } catch (error) {
                        AppsLog.log("error :" + error);
                    }
                    if (angular.isDefined(res.invocationResult.mobileMenu) && res.invocationResult.mobileMenu != null) {
                        if (res.invocationResult.mobileMenu.length > 0) {
                            for (var i = 0; i < res.invocationResult.mobileMenu.length; i++) {
                                if (res.invocationResult.mobileMenu[i].active) {
                                    setWidget(res.invocationResult.mobileMenu[i].name);
                                }
                            }
                        }
                    }

                    //Agent Hierarchy -- Regie 09 Mei 2017
                    if (res.invocationResult.agent_scope != null) {
                        $rootScope.agent_agentTypeId = res.invocationResult.agent_agentTypeId;
                        $rootScope.agent_scope = res.invocationResult.agent_scope.toLowerCase();
                        $rootScope.agent_isLeader = res.invocationResult.agent_isLeader;
                        $rootScope.GroupByAgentType = ($rootScope.agent_scope.indexOf("group") > -1) ? true : false;
                        $rootScope.UnitByAgentType = ($rootScope.agent_scope.indexOf("unit") > -1) ? true : false;
                        $rootScope.IndividualByAgentType = ($rootScope.agent_scope.indexOf("individual") > -1) ? true : false;
                    }

                    if (res.invocationResult.agent_channelType != null) {
                        $rootScope.agent_channelType = res.invocationResult.agent_channelType;
                    } else {
                        $rootScope.agent_channelType = $rootScope.channelType.agency;
                    }

                    //note: response channelType PD from service = 2
                    $rootScope.pd = ($rootScope.agent_channelType == 2) ? true : false;

                } else {
                    $ionicLoading.hide();
                    if (res.invocationResult.isLoginExpired === undefined) {
                        $rootScope.AlertDialog($filter('translate')('PRU_17'));
                    } else if (!res.invocationResult.isLoginExpired) {
                        $rootScope.AlertDialog($filter('translate')('PRU_17'));
                    } else if (res.invocationResult.isLoginExpired) {
                        $rootScope.AlertDialog($filter('translate')('LOGIN_EXPIRED'));
                    } else {
                        $rootScope.AlertDialog($filter('translate')('PRU_26'));
                    }
                }
            } else if (res.invocationResult.statusCode == 500) {
                $ionicLoading.hide();
                if (res.invocationResult.errorCode == "000149") {
                    $rootScope.AlertDialog($filter('translate')('PRU_17'));
                } else if (res.invocationResult.errorCode == '000249') {
                    $rootScope.temp.expiredPassword = true;
                    $state.go('ganti-password');
                } else {
                    $rootScope.AlertDialog($filter('translate')('ERROR_CONNECTION'));
                }
            }
        }

        function getDetailProfileServiceSuccess(res) {

            if (res.responseCode == null) {
                var res = res.invocationResult;
                if (res.agentNumber == null || res.agentNumber == undefined || res.agentNumber == "") {
                    $ionicLoading.hide();
                    $rootScope.AlertDialog($filter('translate')('PRU_98'));
                } else {
                    Idle.watch();
                    $rootScope.flagSession = 1;
                    //$rootScope.agent.userType = res.agentType;
                    $rootScope.agent.userType = res.userType;
                    if ($rootScope.agent.userType == "candidate") {
                        AnalyticsLog.logPage("Login.Candidate");
                        $rootScope.candidate.npa = res.agentNumber;
                        $rootScope.agent.code = res.agentNumber;
                        $rootScope.MenuList.CONTACTSUPPORT = true;
                        CheckAMLScore($rootScope.candidate.npa);
                        CheckCountAG($rootScope.candidate.npa);
                        CheckAgentJourney($rootScope.candidate.npa);
                        CheckCountRecExamCA($rootScope.candidate.npa);
                        CheckCandidate($rootScope.candidate.npa);
                        CheckScoreRecExamCA($rootScope.candidate.npa);
                    } else {
                        AnalyticsLog.logPage("Login.Agent");
                        var statusAgent = res.activeStatus;


                        //TAMBAHAN NEWSQS
                        $rootScope.agent.channelType = 'AG';

                        if (statusAgent != 'ACTIVE') {
                            $ionicLoading.hide();
                            $rootScope.AlertDialog($filter('translate')('PRU_101'));
                        } else {
                            //$rootScope.agent.agentType = res.designationId[0].description;
                            $rootScope.agent.agentType = res.agentType;
                            $rootScope.userLoginName = res.clientName;
                            $rootScope.agent.code = res.agentNumber;
                            $rootScope.agent.agentOfficeCode = res.officeCode;
                            $rootScope.agent.email = res.agentEmailAddress;
                            $rootScope.agent.phone = res.agentMobilephone1;
                            $rootScope.agent.licenseType = res.licenseNumber;
                            $rootScope.agent.flagLicenseCodeReTaker = checkingLicenseTypeAAJIReTaker(res.licenseNumber);
                            DoGetCountReTakerAAJI($rootScope.agent.code);
                            if ($rootScope.agent.agentType != 'AG' && $rootScope.agent.agentType != 'MA') {
                                $rootScope.agent.leaderagentcode = res.agentNumber;
                                $rootScope.agent.leaderName = res.clientName;
                                $rootScope.agent.leaderOfficeCode = res.officeCode;
                            } else {
                                $rootScope.agent.leaderagentcode = res.leaderNumber;
                                $rootScope.agent.leaderName = res.leaderName;
                                $rootScope.agent.leaderOfficeCode = res.leaderOfficeCode;
                            }
                            initDevice();
                        }

                    }
                }

            } else if (res.invocationResult.errorCode == '000249') {
                $rootScope.temp.expiredPassword = true;
                $state.go('ganti-password');
            } else {
                $ionicLoading.hide();
                $rootScope.AlertDialog($filter('translate')('PRU_98'));
            }
        }

        function CheckAMLScore(npa) {
            try {
                GetAMLScoreService.invoke(npa).then(function (res) {
                    if (res.invocationResult.respCode == 200) {
                        $rootScope.candidate.amlScore = res.invocationResult.result.score;
                        if (res.invocationResult.result.score > 59) {
                            $rootScope.candidate.UjianKodeEtikFlag = true;
                            localStorage['AML' + $rootScope.candidate.npa] = true;
                        }
                    }
                });
            } catch (error) {
                AppsLog.log("error :" + error);
            }

        }

        // this is used for candidate checking
        //----------------------------------
        function CheckScoreRecExamCA(npa) {
            try {
                var params = {
                    agentId: $rootScope.agent.code,
                    npa: npa
                }
                var RecExamScoreLocal;
                FormulirPerekrutanService.getRecExamResult(params).then(function (res) {
                    if (res.length != 0) {
                        RecExamScoreLocal = res.content[17].answer;
                    } else {
                        RecExamScoreLocal = 0;
                    }
                });
                CheckScoreRecExamService.invoke(npa).then(function (res) {
                    try {
                        if (res.invocationResult.array.length == 0 && RecExamScoreLocal == 0) {
                            $rootScope.candidate.RecExamScoreLocal = 0;
                        } else if (res.invocationResult[0].resultform != 0 && RecExamScoreLocal == 0) {
                            $rootScope.candidate.RecExamScoreLocal = res.invocationResult.array[0].resultform;
                        } else {
                            $rootScope.candidate.RecExamScoreLocal = RecExamScoreLocal;
                        }
                    } catch (error) {
                        AppsLog.log("catch value score: " + error);
                    }

                });

            } catch (error) {
                AppsLog.log("error :" + error);
            }

        }

        function CheckCountAG(npa) {
            GetCountAgentJourneyAppPackService.invoke(npa).then(function (res) {
                try {
                    $rootScope.candidate.countagentjourney = res.invocationResult.array[0].count;
                } catch (error) {
                    AppsLog.log("error :" + error);
                }
            });


        }

        function CheckAgentJourney(npa) {
            try {
                CollectPackStatusDataService.invoke(npa).then(function (res) {
                    $rootScope.candidate.agentjourney = res;
                });
            } catch (error) {
                AppsLog.log("error :" + error);
            }

        }
        function CheckCountRecExamCA(npa) {
            try {
                GetCountRecExamService.invoke(npa).then(function (res) {
                    if (res.invocationResult.isSuccessful) {
                        AppsLog.log("hasil CheckCountRecExamCA" + JSON.stringify(res));
                    }
                });
            } catch (error) {
                AppsLog.log("error :" + error);
            }

        }
        function CheckCandidate(npa) {
            $scope.dataCandidateParam = {
                agentId: $rootScope.agent.code,
                npa: npa
            }
            try {
                GetAplicationPackService.getDataCandidatePack($scope.dataCandidateParam).then(function (res) {
                    var candidateDataResponse = res.json;
                    $rootScope.userLoginName = candidateDataResponse.dataPribadi.name;
                    $rootScope.candidate.signature = candidateDataResponse.candidatesignature;
                    if (candidateDataResponse.activeCandidate == 'EXPIRED') {
                        $ionicLoading.hide();
                        $rootScope.AlertDialog($filter('translate')('PRU_28'));
                    } else if (candidateDataResponse.rejectStatus == 'REJECTED') {
                        var msgReject = $filter('translate')('PRU_30');
                        if (candidateDataResponse.rejectStatus != null && candidateDataResponse.rejectStatus.indexOf('Recruiter') > 0) {
                            msgReject = $filter('translate')('PRU_31');
                        }
                        $rootScope.AlertDialog(msgReject);
                    } else {
                        initDevice();
                    }
                });
            } catch (error) {
                AppsLog.log("error :" + error);
            }


        }

        // this is end of candidate checking
        //----------------------------------


        function checkingLicenseTypeAAJIReTaker(licenseType) {
            var check = false;
            var subs1 = licenseType.substring(0, 1);
            var subs2 = licenseType.substring(1, 2);
            var subs3 = checkingNumericLicenseCode(subs2);
            if (subs1 == 'F') {
                if (subs3) {
                    check = true;
                } else {
                    check = false;
                }
            } else if (subs1 != 'F') {
                check = false;
            }
            return check;

        }
        function checkingNumericLicenseCode(dt) {
            var isNumeric = false;
            if (dt >= '0' && dt <= '9') {
                isNumeric = true;
            } else {
                isNumeric = false;
            }
            return isNumeric;
        }

        function DoGetCountReTakerAAJI(agentCode) {
            try {
                GetCountRetakerAAJIService.invoke(agentCode).then(function (res) {
                    if (res.invocationResult.array.length != 0) {
                        $rootScope.agent.statusRetaker = false;
                    } else {
                        $rootScope.agent.statusRetaker = true;
                        getCountAAJIRegistration(agentCode);
                    }
                });

            } catch (error) {
                AppsLog.log("error :" + error);
            }

        }

        function getCountAAJIRegistration(agentCode) {
            try {
                GetCountRegistrationAAJIService.invoke(agentCode).then(function (res) {
                    if (res.invocationResult.array.length != 0) {
                        $rootScope.MenuList.AAJIAGENT = true;
                    } else {
                        if ($rootScope.agent.licenseType == null || $rootScope.agent.licenseType == undefined || $rootScope.agent.licenseType == '') {
                            $rootScope.MenuList.AAJIAGENT = true;
                        } else if ((!$rootScope.agent.flagLicenseCodeReTaker)) {
                            $rootScope.MenuList.AAJIAGENT = true;
                        }
                    }

                });
            } catch (error) {
                AppsLog.log("error :" + error);
            }

        }

        // this is end of agent checking
        //----------------------------------

        // this is end of checking inbox message
        //--------------------------------------

        function initDevice() {

            try {
                if ($rootScope.platForm == 'iphone' || $rootScope.platForm == 'ipad') {
                    $rootScope.dbImage = $cordovaSQLite.openDB({ name: "image.db", location: "default" }); //device
                } else {
                    $rootScope.dbImage = window.openDatabase("image.db", '1', 'my', 1024 * 1024 * 10000); // browser
                }
                $cordovaSQLite.execute($rootScope.dbImage, "CREATE TABLE IF NOT EXISTS tblImage (agentId, npa, type, label, imgBase64, statusImage)");
                $cordovaSQLite.execute($rootScope.dbImage, "CREATE TABLE IF NOT EXISTS tblPendingDoc (agentId, npa, docName, docType)");
            } catch (error) {
                AppsLog.log("error create table" + error);
            }

            $rootScope.directToHome();
            // GetListDeviceService.invoke($rootScope.username).then(function (res) {
            // console.log(res);
            //     if (res.invocationResult.statusCode == 200) {
            //         if (res.invocationResult.allowNotification) {
            //             $rootScope.directToHome();
            //         } else {
            //             if ($rootScope.platForm == 'preview') {
            //                 $rootScope.directToHome();
            //             } else {
            //                 $rootScope.DialogWithCancel($filter('translate')('PRU_123'), ['registerDeviceNotification','directToHome']);
            //             }
            //         }
            //     }
            // });
        }

        var countRetry = 0;
        $rootScope.registerDeviceNotification = function () {
            $ionicLoading.show();
            var platForm = $filter('lowercase')($rootScope.platForm) == 'android' ? 'android' : 'ios';
            var subscribeModule = "RECRUITMENT;NEWS_UPDATE;COMMISSION;PRODUCTION;PERSISTENCY;PROPOSAL;POLICY;BONUS;CONTEST";
            var subscribeNotif = true;
            if (pushNotifToken != undefined) {
                RegisterDeviceService.invoke($rootScope.username, $rootScope.model, pushNotifToken, $rootScope.uuid, platForm).then(function (res) {
                    if (res.invocationResult.statusCode == 200) {
                        SubscribeNotificationService.invoke($rootScope.username, subscribeNotif, subscribeModule).then(function (res) {
                            console.log(res);
                            if (res.invocationResult.statusCode == 200) {
                                console.log("success subscribe");
                            } else {
                                console.log("failed subscribe");
                            }
                        });
                        $rootScope.directToHome();
                    } else {
                        $rootScope.directToHome();
                    }
                });
            } else {
                countRetry++;
                registerDevice();
                countRetry == 3 ? $rootScope.directToHome() : $rootScope.registerDeviceNotification();
            }

        }

        $rootScope.directToHome = function () {
            $ionicLoading.hide();
            clearInputedFormLogin();
            if ($rootScope.directNotif) {
                $rootScope.directNotif = false;
                PushNotificationService.proccess($rootScope.notificationData, true).then(function (res) {
                    console.log(res);
                });
            } else {
                if ($rootScope.agent.userType == "candidate") {
                    if ($rootScope.candidate.RecExamScoreLocal < 60) {
                        $state.go("formulir-perekrutan");
                    } else {
                        $state.go("home-menu.candidate");
                    }
                } else {
                    $state.go("home-menu.agent");
                }
            }

        }

    })