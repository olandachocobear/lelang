﻿angular.module('PruForce.services')

	.service('CancelSupportingDocService', function (AOBResources, $q) {

		function invoke(docId, docName, docType, npa) {

			var req = {
				adapter: "HTTPAdapterAuth",
				procedure: "cancelSupportingDoc",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + docId + "','" + docName + "','" + docType + "','" + npa + "']" }
			};

			var deferred = $q.defer();

			AOBResources.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invoke: invoke
		}
	});

