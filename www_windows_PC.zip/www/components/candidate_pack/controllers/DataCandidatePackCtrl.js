﻿
var pruforce = angular.module('PruForce');

pruforce.controller('DataCandidatePackCtrl', function ($q, $state, $jrCrop, $scope, $translate, getImageCandidatePackList, $ionicScrollDelegate, $ionicLoading, $ionicPopup, $ionicModal, GetAplicationPackService, $filter, $mdToast, $rootScope, MasterDataService, GetAMLScoreService, GetAAJIScheduleService, CancelSupportingDocService) {

    function init() {
        $scope.statusTab = false;
        $scope.formValidasi = {
            pribadi: false,
            rekening: false,
            pajak: false
        }
        $scope.formValidasi.documentType = [];

        for (var i = 0; i < $(".tab-item").length; i++) {
            var tabItem = $($(".tab-item")[i]);
            if (tabItem.attr("data-position-left") == undefined) {
                tabItem.attr("data-position-left", ($($(".tab-item")[i]).position().left - 20));
            }
        }
    }

    $scope.ngMessageStyle = { 'color': 'red', 'opacity': '1', 'margin-top': '0px' };

    $scope.setFormScope = function (form) {
        $scope.form = form;
    }

    if ($rootScope.flagReadOnly) {
        $scope.statusTab = true;
    }


    // $scope.statusTab = true;
    $scope.isExpanded = false;
    $scope.flagMovingTab = true;
    $scope.graduationYearData = [];

    listImageCandidate(getImageCandidatePackList);
    function listImageCandidate(result) {
        $scope.imageCandidatePack = {};
        $scope.imageCandidatePack.dataPribadi = {};
        $scope.imageCandidatePack.dataRekening = {};
        $scope.imageCandidatePack.dataPajak = {};
        $scope.imageCandidatePack.dataDokumen = [];
        $scope.imageCandidatePack.allImage = [];
        if (result !== 'empty') {
            $scope.imageCandidatePack = result;
        }
    }

    $scope.showCropper = function (image, uploadTo, widthCropper, heightCropper) {
        var dataModel = uploadTo.split(".");
        $jrCrop.crop({
            url: image,
            width: widthCropper,
            height: heightCropper,
            cancelText: $filter('translate')('CANCEL'),
            chooseText: $filter('translate')('CROP'),
            allowRotation: true,
            buttonLocation: 'footer',
        }).then(function (canvas) {
            if (dataModel[1] == 'dataDokumen') {
                $scope[dataModel[0]][dataModel[1]][dataModel[2]][dataModel[3]] = canvas.toDataURL();
                $scope.saveImage();
            } else {
                $scope[dataModel[0]][dataModel[1]][dataModel[2]] = canvas.toDataURL();
                $scope.saveImage();
            }
        });
    };

    $scope.saveImage = function () {
        $scope.imageCandidatePack.agentId = $scope.agent.code;
        $scope.imageCandidatePack.npa = $rootScope.candidate.npa;
        GetAplicationPackService.saveImageCandidate($scope.imageCandidatePack, true).then(
            function (result) {
            },
            function (error) {
                AppsLog.log(error);
            }
        );
    }

    $scope.removeImage = function (imgType) {
        $rootScope.dbImage.transaction(function (tx) {
            var query = "DELETE FROM tblImage WHERE agentId = ? and npa = ? and type =?";
            var params = [$rootScope.agent.code, $rootScope.candidate.npa, imgType];
            tx.executeSql(query, params, function (tx, res) {
                AppsLog.log('DELETE succcess');
            }, function (tx, error) {
                AppsLog.log('DELETE error: ' + error.message);
            });
        });
    }

    $scope.change = false;
    $scope.selectedItem = {};
    $scope.requiredChange = function (valid) {
        if (valid) {
            return $scope.change = true;
        } else if (valid == false || valid == undefined || valid == " " || valid == "" || valid.length < 3) {
            return $scope.change = false;
        }
    };

    var provincePromise;
    $scope.getDataProvince = function () {
        provincePromise = MasterDataService.getDataProvince().then(
            function (result) {
                $scope.dataProvince = result;
            },
            function (error) {

            }
        );
    };

    $scope.getDataProvince();

    var bankNamePromise;
    $scope.getBankName = function () {
        bankNamePromise = MasterDataService.getBankAccount().then(
            function (result) {
                $scope.bankName = result;
                $rootScope.$broadcast('finish-load-bankName');
            },
            function (error) {

            }
        );
    };

    $scope.getBankName();

    var dataOfficePromise;
    $scope.getDataOffice = function () {
        dataOfficePromise = MasterDataService.getDataOffice().then(
            function (result) {
                $scope.dataOffice = result;
            },
            function (error) {
            }
        );
    };

    $scope.getDataOffice();

    $scope.dataCandidateParam = {
        agentId: $rootScope.agent.code,
        npa: $rootScope.candidate.npa
    }

    $scope.candidatePack = {};
    $scope.selected = true;

    $scope.getDataNPWPStatus = function () {
        MasterDataService.getDataNPWPStatus().then(
            function (result) {
                $scope.dataNPWPStatus = result;
            },
            function (error) {
            }
        );
    };

    $scope.getDataNPWPStatus();

    $scope.getDataMaritalStatus = function () {
        MasterDataService.getDataMaritalStatus().then(
            function (result) {
                $scope.dataMaritalStatus = result;
            },
            function (error) {
            }
        );
    };

    $scope.getDataMaritalStatus();

    $scope.getDataEducation = function () {
        MasterDataService.getDataEducation().then(
            function (result) {
                $scope.dataEducation = result;
            },
            function (error) {
            }
        );
    };

    $scope.getDataEducation();

    $scope.getDataGender = function () {
        MasterDataService.getDataGender().then(
            function (result) {
                $scope.dataGender = result;
            },
            function (error) {
            }
        );
    };

    $scope.getDataGender();

    $scope.getDataReligion = function () {
        MasterDataService.getDataReligion().then(
            function (result) {
                $scope.dataReligion = result;
            },
            function (error) {
            }
        );
    };

    $scope.getDataReligion();

    $scope.getFastStartType = function () {
        GetAplicationPackService.getFastStartType().then(
            function (result) {
                $scope.fastStartType = result;
            },
            function (error) {
                AppsLog.log(error);
            }
        )
    }

    $scope.getFastStartType();

    $scope.getFastStartSchedule = function (city) {
        GetAplicationPackService.getfastStartSchedule(city).then(
            function (result) {
                $scope.fastStartSchedule = result;
            },
            function (error) {
                AppsLog.log(error);
            }
        )
    }

    $scope.getFastStartLocation = function () {
        if (!$scope.flagReadOnly) {
            GetAplicationPackService.getFastStartLocation().then(
                function (result) {
                    $scope.fastStartLocation = result;
                },
                function (error) {
                    AppsLog.log(error);
                }
            )
        }
    }


    $scope.changeFastStartType = function () {
        if ($scope.candidatePack.dataFastStart.trainingType === 1) {
            $scope.getFastStartLocation();
        } else {
            delete $scope.candidatePack.dataFastStart.trainingLocation;
            delete $scope.candidatePack.dataFastStart.choosedTrainingId;
        }
        $scope.save();
    }

    $scope.changeFastStartLocation = function () {
        if ($scope.candidatePack.dataFastStart.choosed != undefined && $scope.candidatePack.dataFastStart.choosed != null && $scope.candidatePack.dataFastStart.choosed != '' && $scope.candidatePack.dataFastStart.choosed != "undefined") {
            $scope["choosing" + $scope.candidatePack.dataFastStart.choosed.id] = false;
            delete $scope.candidatePack.dataFastStart.choosedTrainingId;
            delete $scope.candidatePack.dataFastStart.choosed;
        } else {
            $scope.candidatePack.dataFastStart.choosedTrainingId;
            $scope.candidatePack.dataFastStart.choosed;
        }
        $scope.getFastStartSchedule($scope.candidatePack.dataFastStart.trainingLocation);
        $scope.save();
    }

    $scope.getLocation = function () {
        if (!$scope.flagReadOnly) {
            GetAplicationPackService.getLocation().then(
                function (result) {
                    $scope.Location = result;
                },
                function (error) {
                    AppsLog.log(error);
                }
            );
        }

    }

    $scope.getLocation();

    $scope.getScheduleAAJI = function (city) {
        AnalyticsLog.logPage("Get.Schedule.AAJI");
        GetAAJIScheduleService.invoke(city).then(
            function (result) {
                $scope.aajiSchedule = result;
            },
            function (error) {
                AppsLog.log(error);
            }
        );
    }

    $scope.changeAAJILocation = function () {
        if ($scope.candidatePack.dataUjian.choosedLocation == "0") {
            delete $scope.candidatePack.dataUjian.choosedLocation;
        } else {
            if ($scope.candidatePack.dataUjian != null && $scope.candidatePack.dataUjian != undefined && $scope.candidatePack.dataUjian != null && $scope.candidatePack.dataUjian != 'undefined') {
                $scope["choosingAaji" + $scope.candidatePack.dataUjian.choosedId] = false;
                delete $scope.candidatePack.dataUjian.choosedId;
            }
            $scope.getScheduleAAJI($scope.candidatePack.dataUjian.choosedLocation);
        }
        $scope.save();
    }

    $scope.getDataCandidatePack = function () {

        $scope.candidatePack.dataPribadi = {};
        $scope.candidatePack.dataRekening = {};
        $scope.candidatePack.dataPajak = {};
        $scope.candidatePack.dataKeluarga = {};
        $scope.candidatePack.dataKeagenan = {};
        $scope.candidatePack.dataJejaring = {};
        $scope.candidatePack.dataDokumen = [];
        $scope.candidatePack.dataFastStart = {};
        $scope.candidatePack.dataUjian = {};

        GetAplicationPackService.getDataCandidatePack($scope.dataCandidateParam).then(
            function (result) {
                if (result !== 'empty') {
                    $scope.candidatePack = result.json;
                    $rootScope.agent.recruiteragentcode = $scope.candidatePack.dataKeagenan.recruitersCode;
                    $q.all([provincePromise]).then(function () {
                        if ($scope.candidatePack.dataPribadi.province !== '') {
                            var selectedProvince = $filter('filter')($scope.dataProvince, { value: $scope.candidatePack.dataPribadi.province })[0];
                            $scope.selectedItem.province = selectedProvince;
                        }
                        if ($scope.candidatePack.dataPajak.province !== '') {
                            var selectedNPWPProvince = $filter('filter')($scope.dataProvince, { value: $scope.candidatePack.dataPajak.province })[0];
                            $scope.selectedItem.NPWPProvince = selectedNPWPProvince;
                        }
                    });

                    $q.all([bankNamePromise]).then(function () {
                        if ($scope.candidatePack.dataRekening.bankName != '') {
                            var selectedbankName = $filter('filter')($scope.bankName, { value: $scope.candidatePack.dataRekening.bankName })[0];
                            $scope.selectedItem.bankNameSelected = selectedbankName;
                        }
                    });

                    $q.all([dataOfficePromise]).then(function () {
                        if ($scope.candidatePack.dataKeagenan.candidateOfficeMarketing != '') {
                            var selectedCandidateOffice = $filter('filter')($scope.dataOffice, { value: $scope.candidatePack.dataKeagenan.candidateOfficeMarketing })[0];
                            $scope.selectedItem.officeCandidateSelected = selectedCandidateOffice;
                        }
                    });


                    if ($scope.candidatePack.dataKeluarga.wifeBirthOfDate !== undefined) {
                        $scope.candidatePack.dataKeluarga.wifeBirthOfDate = new Date($scope.candidatePack.dataKeluarga.wifeBirthOfDate);
                    }
                    var idCardExpDate = $filter('date')(new Date($scope.candidatePack.dataPribadi.idCardExpDate), 'dd/MM/yyyy');
                    if (idCardExpDate !== undefined && idCardExpDate != "01/01/1970" && idCardExpDate != "12/12/2999") {
                        $scope.candidatePack.dataPribadi.idCardExpDate = new Date($scope.candidatePack.dataPribadi.idCardExpDate);
                    } else if ($scope.candidatePack.dataPribadi.isIdCardUnExpired) {
                        $scope.candidatePack.dataPribadi.idCardExpDate = '';
                    }


                    var idSpouseDOB = $filter('date')(new Date($scope.candidatePack.dataKeluarga.spouseDateOfBirth), 'dd/MM/yyyy');
                    if (idSpouseDOB !== undefined && idSpouseDOB != "01/01/1970" && idSpouseDOB !== "undefined" && idSpouseDOB !== null) {
                        $scope.candidatePack.dataKeluarga.spouseDateOfBirth = new Date($scope.candidatePack.dataKeluarga.spouseDateOfBirth);
                    } else {
                        $scope.candidatePack.dataKeluarga.spouseDateOfBirth = '';
                    }

                    if ($scope.candidatePack.dataPribadi.cellPhone !== undefined) {
                        if ($scope.candidatePack.dataPribadi.cellPhone.length <= 1) {
                            $scope.pribadiCelularPhones = [{ id: '1', modelName: 'celular_phone_1' }];
                        } else {
                            $scope.pribadiCelularPhones = [];
                            var phoneCount = 1;
                            if (!angular.isUndefined($scope.candidatePack.dataPribadi.cellPhone.phone3)) {
                                phoneCount = 3;
                            } else if (!angular.isUndefined($scope.candidatePack.dataPribadi.cellPhone.phone2)) {
                                phoneCount = 2;
                            }
                            for (var i = 1; i <= phoneCount; i++) {
                                $scope.pribadiCelularPhones.push({ id: i, modelName: 'celular_phone_' + i });
                            }
                        }
                    } else {
                        $scope.pribadiCelularPhones = [{ id: '1', modelName: 'celular_phone_1' }];
                    }

                    if ($scope.flagReadOnly) {
                        $rootScope.trainingTypeFastStart = ($rootScope.trainingTypeFastStart == undefined) ? 2 : $rootScope.trainingTypeFastStart;

                        if ($rootScope.trainingTypeFastStart == 1) {
                            $scope.candidatePack.dataFastStart.trainingLocation = $rootScope.candidate.fastStartSchedule[0].loc;
                            $scope.fastStartLocation = [];
                            $scope.fastStartLocation.push({ value: $rootScope.candidate.fastStartSchedule[0].loc, label: $rootScope.candidate.fastStartSchedule[0].loc });
                            $scope.fastStartSchedule = $rootScope.candidate.fastStartSchedule;
                        } else if ($rootScope.trainingTypeFastStart == 2) {
                            $scope.candidatePack.dataFastStart.trainingType = 2;
                        }
                    } else {
                        if ($scope.candidatePack.dataFastStart.trainingType !== undefined) {
                            if ($scope.candidatePack.dataFastStart.trainingType === 1) {
                                $scope.getFastStartLocation();
                            }
                        }

                        if ($rootScope.flagPending) {
                            $scope.candidatePack.dataFastStart.choosed = {};
                            if ($scope.candidatePack.dataFastStart.trainingType !== undefined && $scope.candidatePack.dataFastStart.trainingType === 1) {
                                $scope.candidatePack.dataFastStart.choosed.id = $scope.candidatePack.dataFastStart.id;
                                $scope.candidatePack.dataFastStart.choosed.faststartscheduleid = $scope.candidatePack.dataFastStart.faststartscheduleid;
                                $scope.candidatePack.dataFastStart.choosed.courseCode = $scope.candidatePack.dataFastStart.faststartcoursecode;
                                $scope.candidatePack.dataFastStart.choosed.faststartdate = $scope.candidatePack.dataFastStart.faststartdate;
                                $scope.candidatePack.dataFastStart.choosed.faststartcourse = $scope.candidatePack.dataFastStart.faststartcourse;
                            } else {
                                $scope.candidatePack.dataFastStart.trainingType = 2;
                            }
                        }


                        if ($scope.candidatePack.dataFastStart.trainingLocation !== undefined) {
                            AnalyticsLog.logPage("Get.Schedule.FastStart");
                            GetAplicationPackService.getfastStartSchedule($scope.candidatePack.dataFastStart.trainingLocation).then(
                                function (result) {
                                    $scope.fastStartSchedule = result;

                                    if ($scope.candidatePack.dataFastStart.choosed.id !== undefined) {
                                        for (var i = 0; i < $scope.fastStartSchedule.length; i++) {
                                            var schId = $scope.fastStartSchedule[i].id;
                                            $scope["choosing" + schId] = false;
                                        }
                                        $scope["choosing" + $scope.candidatePack.dataFastStart.choosed.id] = true;
                                    }
                                },
                                function (error) {
                                    AppsLog.log(error);
                                }
                            );
                        }
                    }

                    var dateNow = moment().get('year');
                    var graduationYearStart = dateNow;
                    var graduationYearEnd = dateNow - 50;
                    for (var i = graduationYearStart; i >= graduationYearEnd; i--) {
                        $scope.graduationYearData.push({ value: '' + i, label: '' + i });
                    }

                    if ($scope.candidatePack.dataPribadi.graduationYear != undefined) {
                        var selectedGraduationYear = $filter('filter')($scope.graduationYearData, { value: $scope.candidatePack.dataPribadi.graduationYear })[0];
                        $scope.selectedItem.graduationYear = selectedGraduationYear;
                    }

                    if ($scope.candidatePack.dataUjian.choosedLocation !== undefined) {
                        AnalyticsLog.logPage("Get.Schedule.AAJI");
                        if ($scope.flagReadOnly) {
                            $scope.Location = [];
                            $scope.isExpanded = true;
                            $scope.Location.push({ value: $scope.candidatePack.dataUjian.choosedLocation, label: $scope.candidatePack.dataUjian.choosedLocation });
                            $scope.aajiSchedule = $rootScope.candidate.aajiSchedule;
                        } else {
                            GetAAJIScheduleService.invoke($scope.candidatePack.dataUjian.choosedLocation).then(
                                function (result) {
                                    $scope.aajiSchedule = result;
                                    if ($scope.candidatePack.dataUjian.choosedId !== undefined) {
                                        var choosedSch = document.getElementsByClassName("choosed").length;
                                        if (choosedSch <= 0) {
                                            $scope["choosingAaji" + $scope.candidatePack.dataUjian.choosedId] = true;
                                        } else {
                                            $scope["choosingAaji" + id] = false;
                                            delete $scope.candidatePack.dataUjian.choosedId;
                                        }
                                    }
                                },
                                function (error) {
                                    AppsLog.log(error);
                                }
                            );
                        }

                    }

                    $ionicLoading.hide();
                    $scope.save();
                } else {
                    $scope.pribadiCelularPhones = [{ id: '1', modelName: 'celular_phone_1' }];
                }
            },
            function (error) {
                AppsLog.log(error);
            }
        );
    }

    $scope.getDataCandidatePack();


    $scope.menuTabs = [
        { id: 1, name: "Pribadi", class: "dkp-tab-pribadi", url: "components/candidate_pack/pribadi.html", status: $scope.statusTab },
        { id: 2, name: "Rekening", class: "dkp-tab-rekening", url: "components/candidate_pack/rekening.html", status: $scope.statusTab },
        { id: 3, name: "Pajak", class: "dkp-tab-pajak", url: "components/candidate_pack/pajak.html", status: $scope.statusTab },
        { id: 4, name: "Keluarga", class: "dkp-tab-keluarga", url: "components/candidate_pack/keluarga.html", status: $scope.statusTab },
        { id: 5, name: "Keagenan", class: "dkp-tab-keagenan", url: "components/candidate_pack/keagenan.html", status: $scope.statusTab },
        { id: 6, name: "Jejaring Sosial", class: "dkp-tab-jejaring-social", url: "components/candidate_pack/jejaring_social.html", status: $scope.statusTab },
        { id: 7, name: "Dokumen", class: "dkp-tab-dokumen", url: "components/candidate_pack/dokumen.html", status: $scope.statusTab },
        { id: 8, name: "<strong>PRU</strong><em>fast start</em>", class: "dkp-tab-fast-start", url: "components/candidate_pack/prufast-start.html", status: $scope.statusTab },
        { id: 9, name: "Ujian AAJI", class: "dkp-tab-ujian-aaji", url: "components/candidate_pack/ujian-aaji.html", status: $scope.statusTab }
    ]

    $scope.currentMenuTab = $scope.menuTabs[0];

    $scope.isActiveTab = function (menuTabUrl) {
        return $scope.currentMenuTab.url === menuTabUrl;
    };

    $scope.fastStart = false;
    $scope.chooseSchedule = function (e, id, faststart) {
        for (var i = 0; i < $scope.fastStartSchedule.length; i++) {
            var schId = $scope.fastStartSchedule[i].id;
            if (schId != id) {
                $scope["choosing" + schId] = false;
            }
        }

        if ($scope["choosing" + id] !== undefined) {
            if ($scope["choosing" + id] === true) {
                $scope["choosing" + id] = false;
                delete $scope.candidatePack.dataFastStart.choosed;
            } else {
                $scope["choosing" + id] = true;
                $scope.candidatePack.dataFastStart.choosed = faststart;
            }
        } else {
            $scope["choosing" + id] = true;
            $scope.candidatePack.dataFastStart.choosed = faststart;
        }

        $scope.save();
    }

    $scope.chooseAajiSchedule = function (e, id, date, dateDefault) {
        var choosedSch = document.getElementsByClassName("choosed").length;
        if (choosedSch <= 0) {
            $scope["choosingAaji" + id] = true;
            $scope.candidatePack.dataUjian.choosedId = id;
            $scope.candidatePack.dataUjian.choosedDate = date;
            $scope.candidatePack.dataUjian.choosedDateDefault = dateDefault;
            $scope.save();
        } else {
            if (!$scope["choosingAaji" + id]) {
                $scope.showConfirm(id, date, dateDefault);
            } else {
                $scope["choosingAaji" + id] = false;
                delete $scope.candidatePack.dataUjian.choosedId;
                $scope.save();
            }
        }
    }

    $scope.showConfirm = function (id, date, dateDefault) {
        var confirmPopup = $ionicPopup.confirm({
            title: "<strong>PRU</strong><em>force</em>",
            template: $filter('translate')('PRU_88'),
            cssClass: 'pru-white-alert without-header popup-large pru-logo-text button-side-duo',
            buttons: [{
                text: $filter('translate')('NO'),
                type: 'button-dark-gray',
                onTap: function (e) { }
            },
            {
                text: $filter('translate')('YES'),
                type: 'button-assertive',
                onTap: function () {
                    for (var i = 0; i < $scope.aajiSchedule.length; i++) {
                        for (var j = 0; j < $scope.aajiSchedule[i].sch.length; j++) {
                            var schId = $scope.aajiSchedule[i].sch[j].id;
                            if (schId != id) {
                                $scope["choosingAaji" + schId] = false;
                            }
                        }
                    }
                    $scope["choosingAaji" + id] = true;
                    $scope.candidatePack.dataUjian.choosedId = id;
                    $scope.candidatePack.dataUjian.choosedDate = date;
                    $scope.candidatePack.dataUjian.choosedDateDefault = dateDefault;
                    $scope.save();
                }
            }]
        });
    };

    $scope.showSimpleToast = function (msgText) {
        $mdToast.show(
            $mdToast.simple()
                .textContent(msgText)
                .position('bottom right')
                .hideDelay(3000)
        );
    };

    $scope.chekingGraduationYear = function () {
        if (parseInt($scope.candidatePack.dataPribadi.graduationYear) - moment(new Date($scope.candidatePack.dataPribadi.candidateDobDefault)).get('year') < 17) {
            if ($scope.candidatePack.dataPribadi.graduationYear != undefined && $scope.candidatePack.dataPribadi.graduationYear != 'undefined' && $scope.candidatePack.dataPribadi.graduationYear != '' && $scope.candidatePack.dataPribadi.graduationYear != null) {
                $scope.validGraduationYear = false;
            }
        } else {
            $scope.validGraduationYear = true;
        }
    }

    $scope.checkingImagePribadi = function (e, menuTab, status) {
        if (($scope.imageCandidatePack.dataPribadi.ktpImage != null && $scope.imageCandidatePack.dataPribadi.ktpImage != undefined && $scope.imageCandidatePack.dataPribadi.ktpImage != "undefined" && $scope.imageCandidatePack.dataPribadi.ktpImage != '') && ($scope.imageCandidatePack.dataPribadi.profileImage != null && $scope.imageCandidatePack.dataPribadi.profileImage != undefined && $scope.imageCandidatePack.dataPribadi.profileImage != "undefined" && $scope.imageCandidatePack.dataPribadi.profileImage != '') && ($scope.candidatePack.dataPribadi.education != 'A' && $scope.candidatePack.dataPribadi.education != 'B') && $scope.validGraduationYear) {
            $scope.nextTab(e, menuTab, status);
        }
    }

    $scope.checkingImageRekening = function (e, menuTab, status) {
        if ($scope.imageCandidatePack.dataRekening.foto != null && $scope.imageCandidatePack.dataRekening.foto != '' && $scope.imageCandidatePack.dataRekening.foto != undefined && $scope.imageCandidatePack.dataRekening.foto != "undefined") {
            $scope.nextTab(e, menuTab, status);
        }
    }

    $scope.checkingImagePajak = function (e, menuTab, status) {
        if ($scope.candidatePack.dataPajak.npwpStatus != 'no' && $scope.imageCandidatePack.dataPajak.npwpImage != null && $scope.imageCandidatePack.dataPajak.npwpImage != '' && $scope.imageCandidatePack.dataPajak.npwpImage != undefined && $scope.imageCandidatePack.dataPajak.npwpImage != "undefined") {
            $scope.nextTab(e, menuTab, status);
        } else if ($scope.candidatePack.dataPajak.npwpStatus == 'no') {
            $scope.nextTab(e, menuTab, status);
        }
    }

    $scope.checkingImageDoc = function (e, menuTab, status) {
        if ($scope.nextTabAccces) {
            $scope.nextTab(e, menuTab, status);
        }
    }

    $scope.saveNpwpStatus = function (form) {

        $scope.formValidasi.pajak = false;
        $scope.imageCandidatePack.dataPajak.npwpImage = undefined;
        $scope.candidatePack.dataPajak.npwpNumber = '';
        $scope.candidatePack.dataPajak.npwpName = '';
        $scope.candidatePack.dataPajak.province = '';
        $scope.candidatePack.dataPajak.address1 = '';
        $scope.candidatePack.dataPajak.address2 = '';
        $scope.candidatePack.dataPajak.address3 = '';
        $scope.candidatePack.dataPajak.city = '';
        $scope.candidatePack.zipCode = '';

        if ($scope.candidatePack.dataPajak.npwpStatus == 'no') {
            $scope.candidatePack.dataPajak.npwpName = '';
            $scope.candidatePack.dataPajak.zipCode = '';
            form.$setUntouched();
        }

        if ($scope.candidatePack.dataPajak.province == '' || $scope.candidatePack.dataPajak.province == undefined) {
            $scope.candidatePack.dataPajak.province = '';
        }

        var imgType = "11010404";
        $scope.removeImage(imgType);
        $scope.save();
    }

    $scope.save = function () {

        try {
            $scope.candidatePack.agentId = $scope.dataCandidateParam.agentId;
            $scope.candidatePack.npa = $scope.dataCandidateParam.npa;
            if ($scope.candidatePack.dataPribadi.maritalStatus == 'S') {
                $scope.candidatePack.dataKeluarga = {};
                $scope.candidatePack.dataPribadi.maritalStatus == 'S';
            }

            if (!moment($scope.candidatePack.dataPribadi.idCardExpDate).isValid()) {
                $scope.candidatePack.dataPribadi.idCardExpDate = null;
            }
            if (!moment($scope.candidatePack.dataKeluarga.spouseDateOfBirth).isValid()) {
                $scope.candidatePack.dataKeluarga.spouseDateOfBirth = null;
            }

            GetAplicationPackService.saveDataCandidate($scope.candidatePack).then(
                function (result) {
                    if ($scope.candidatePack.dataPribadi.idCardExpDate == null) {
                        $scope.candidatePack.dataPribadi.idCardExpDate = '';
                    }

                    if ($scope.candidatePack.dataKeluarga.spouseDateOfBirth == null) {
                        $scope.candidatePack.dataKeluarga.spouseDateOfBirth = '';
                    }
                },
                function (error) {
                    AppsLog.log(error);
                }
            );

        } catch (error) {
            AppsLog.log(error);
        }
    }

    $scope.checkedExpiredID = function () {
        try {
            if ($scope.candidatePack.dataPribadi.isIdCardUnExpired) {
                $scope.candidatePack.dataPribadi.idCardExpDate = '';
            }
        } catch (error) {
            AppsLog.log(error);
        }

        $scope.save();
    }

    $scope.changeWorkInsurance = function () {
        try {
            if ($scope.candidatePack.dataKeagenan.workInInsuranceCompany == 'Y') {
                var suratResignExist = $filter('filter')($scope.imageCandidatePack.dataDokumen, { type: 30020109 })[0];
                if (suratResignExist == undefined || suratResignExist == "undefined" || suratResignExist == null || suratResignExist == '') {
                    var newDocument = generateUUID();
                    var countDocument = $scope.imageCandidatePack.dataDokumen.length;
                    $scope.imageCandidatePack.dataDokumen.push({ 'id': newDocument, 'imageModelName': 'imageCandidatePack.dataDokumen.' + countDocument + '.file', 'type': '30020109' });
                    $scope.saveDoc(30020109, newDocument, countDocument, 'keagenan');
                }
            } else if ($scope.candidatePack.dataKeagenan.workInInsuranceCompany == 'N') {
                var suratResign = $filter('filter')($scope.imageCandidatePack.dataDokumen, { type: 30020109 })[0];
                var index = $scope.imageCandidatePack.dataDokumen.indexOf(suratResign);
                $scope.imageCandidatePack.dataDokumen.splice(index, 1);
                var imgType = "30020109";
                $scope.removeImage(imgType);
                $scope.imageCandidatePack.dataDokumen.forEach(function (dokumen, i) {
                    dokumen.imageModelName = "imageCandidatePack.dataDokumen." + i + ".file"
                }, this);
                $scope.save();
            }
        } catch (error) {
            AppsLog.log(error);
        }
    }

    $scope.removeDocument = function (indexDokumen, imgType) {
        $scope.imageCandidatePack.dataDokumen.splice(indexDokumen, 1);
        $scope.removeImage(imgType);
        $scope.imageCandidatePack.dataDokumen.forEach(function (dokumen, i) {
            dokumen.imageModelName = "imageCandidatePack.dataDokumen." + i + ".file"
        }, this);
    }

    $scope.checkingFastStartSchedule = function (e, menuTab, status) {
        if ($scope.candidatePack.dataFastStart.trainingType == 1) {
            if ($scope.candidatePack.dataFastStart.choosed == '' || $scope.candidatePack.dataFastStart.choosed == undefined) {
                $rootScope.AlertDialog($filter('translate')('PRU_66'));
            } else {
                $scope.nextTab(e, menuTab, status);
            }
        } else {
            $scope.nextTab(e, menuTab, status);
        }

    }

    $scope.nextTab = function (e, menuTab, status) {
        if (status) {
            menuTab.status = true;
            e.preventDefault();
            $scope.currentMenuTab = menuTab;
            var self = $("." + menuTab.class);
            var tabContentTitle = self.attr("href");
            $(".tab-scrolling").animate({ scrollLeft: self.attr("data-position-left") }, 300);
            self.parent().find("a").removeClass("active");
            self.addClass("active");
            $(tabContentTitle).addClass("active");
            $ionicScrollDelegate.scrollTop();
            $rootScope.showScrollTopButton = false;
        }
        if (!$scope.flagReadOnly) {
            if ($rootScope.agent.userType != 'candidate' && $rootScope.agent.agentType != undefined) {
                if ($rootScope.agent_isLeader && $scope.imageCandidatePack.dataDokumen.length == 0) {
                    var newDocument = generateUUID();
                    var countDocument = $scope.imageCandidatePack.dataDokumen.length;
                    $scope.imageCandidatePack.dataDokumen.push({ 'id': newDocument, 'imageModelName': 'imageCandidatePack.dataDokumen.' + countDocument + '.file', 'type': '30010109' });
                    $scope.saveDoc(30010109, newDocument, countDocument, 0);
                } else if (!$rootScope.agent_isLeader && $scope.imageCandidatePack.dataDokumen.length == 0) {
                    var newDocument = generateUUID();
                    $scope.imageCandidatePack.dataDokumen.push({ 'id': newDocument, 'imageModelName': 'imageCandidatePack.dataDokumen.' + $scope.imageCandidatePack.dataDokumen.length + '.file', 'type': '30010108' });
                    $scope.saveDoc(30010108, newDocument, countDocument, 0);
                }
            }
        }

        if ($scope.candidatePack.dataPajak.npwpStatus == 'no' && $scope.imageCandidatePack.dataPajak.npwpImage != undefined && $scope.imageCandidatePack.dataPajak.npwpImage != '' && $scope.imageCandidatePack.dataPajak.npwpImage != null && $scope.imageCandidatePack.dataPajak.npwpImage != "undefined") {
            var imgType = "11010404";
            $scope.removeImage(imgType);
        }
    }

    $scope.addNewCelularPhone = function () {
        if ($scope.pribadiCelularPhones.length < 3) {
            var newCelular = $scope.pribadiCelularPhones.length + 1;
            $scope.pribadiCelularPhones.push({ 'id': newCelular, modelName: 'celular_phone_' + newCelular });
        } else {
            $scope.showSimpleToast($filter('translate')('MAX_PHONE_NUMBER'));
        }
    }

    function generateUUID() {
        var d = new Date().getTime();
        if (window.performance && typeof window.performance.now === "function") {
            d += performance.now();
        }
        var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
        return uuid;
    }

    $scope.docType = [];
    $scope.docType.push({ type: 11010203, label: 'Akte Lahir' });
    $scope.docType.push({ type: 30020107, label: 'Akte Kelahiran Anak' });
    $scope.docType.push({ type: 30020104, label: 'Akte Kematian' });
    $scope.docType.push({ type: 11010207, label: 'Kartu Keluarga / ID WNI Kartu Keluarga' });
    $scope.docType.push({ type: 11010210, label: 'Surat Nikah' });
    $scope.docType.push({ type: 30010103, label: 'Surat Pernyataan Calon Agen' });
    $scope.docType.push({ type: 30010104, label: 'Surat Keterangan Kelurahan' });
    $scope.docType.push({ type: 30010105, label: 'Surat Resi KTP Kelurahan' });
    $scope.docType.push({ type: 30010106, label: 'Surat Pernyataan Beda Nama Rekening' });
    $scope.docType.push({ type: 30020101, label: 'Surat Pernyataan NPWP (if NPWP is own by Father/Husband)' });
    $scope.docType.push({ type: 30020102, label: 'Surat Pernyataan Beda Nama NPWP' });
    $scope.docType.push({ type: 30020103, label: 'Surat Pernyataan PTKP' });
    $scope.docType.push({ type: 30020105, label: 'Surat Perceraian' });
    $scope.docType.push({ type: 30020106, label: 'Surat Pengasuhan Anak' });
    $scope.docType.push({ type: 30020109, label: 'Surat Resign' });
    $scope.docType.push({ type: 30010109, label: 'KTP Manajer Keagenan' });
    $scope.docType.push({ type: 30010108, label: 'KTP Perekrut' });
    $scope.docType.push({ type: 80000002, label: 'Others' });

    $scope.additionalDocuments = [{ id: generateUUID(), typeModelName: "additional_document_text_1", modelName: 'additional_document_1' }]

    $scope.addAdditionalDocuments = function (event, form) {
        if ($scope.additionalDocuments.length < $scope.docType.length) {
            var newDocument = generateUUID();
            $scope.imageCandidatePack.dataDokumen.push({ 'id': newDocument, 'imageModelName': 'imageCandidatePack.dataDokumen.' + $scope.imageCandidatePack.dataDokumen.length + '.file' });
        } else {
            $scope.showSimpleToast($filter('translate')('MAX_ADD_DOCS'))
        }
    }
    $scope.showMessage = function (form) {
        $scope.nextTabAccces = true;
        $scope.imageCandidatePack.dataDokumen.forEach(function (element, index) {
            if ($scope.imageCandidatePack.dataDokumen[index].file === undefined) {
                $scope.nextTabAccces = false;
                $scope.formValidasi.documentType[index] = false;
            } else {
                $scope.formValidasi.documentType[index] = true;
            }
        }, this);
    }

    $scope.getDocLabel = function (value) {
        var doctype = $filter('filter')($scope.docType, { type: value })[0];
        return doctype.label;
    }

    $scope.saveDoc = function (type, id, position, origin) {
        var docCollection = $scope.imageCandidatePack.dataDokumen.filter(function (p) { return p.type === type }).filter(function (p) { return p.id !== id });
        if (docCollection.length > 0) {
            var currentDoc = $filter('filter')($scope.imageCandidatePack.dataDokumen, { id: id })[0];
            delete currentDoc.type;
            if (origin !== undefined) {
                if (origin === 'keagenan') {
                    var index = $scope.imageCandidatePack.dataDokumen.indexOf(currentDoc);
                    $scope.imageCandidatePack.dataDokumen.splice(index, 1);
                }
            }
            alert($filter('translate')('DOCUMENT') + $scope.getDocLabel(type) + $filter('translate')('UPLOADED'));
            return false;
        } else {
            $scope.imageCandidatePack.dataDokumen[position].label = $scope.getDocLabel(type);
            $scope.save();
            return true;
        }
    }

    $scope.goMainAgreement = function () {
        if ($scope.candidatePack.dataUjian.choosedId == undefined || $scope.candidatePack.dataUjian.choosedId == '') {
            $rootScope.AlertDialog($filter('translate')('PRU_66'));
        } else {
            if ($rootScope.candidate.amlScore > 59) {
                $state.go("syarat-dan-ketentuan-keagenan-checked");
            } else {
                if ($rootScope.agent.userType == 'candidate') {
                    $rootScope.DialogEvents($filter('translate')('PRU_72'), 'home-menu.candidate');
                } else {
                    $rootScope.DialogEvents($filter('translate')('PRU_72'), 'home-menu.agent');
                }
            }
        }

    }

    $scope.goBackState = function () {
        if ($rootScope.previousState == 'home-menu.candidate') {
            $state.go('home-menu.candidate');
        } else {
            $rootScope.goBack();
        }
    }

    angular.element(document).ready(function () {
        setTimeout(init, 500);
    });
});