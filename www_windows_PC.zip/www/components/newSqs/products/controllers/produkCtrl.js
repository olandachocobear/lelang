﻿var pruforce = angular.module('PruForce');

pruforce.controller('produkCtrl', function($q, $scope, $rootScope, $ionicScrollDelegate, /*$element,*/ $ionicPopup, $mdDialog , $ionicLoading ,PublishGlobalService, QuotationStorageService) {
  console.log('Quotation ID :' + $rootScope.QuotationId);
  console.log('Level        :' + $rootScope.Level);
  // var PUBLISH_DATA = JSON.parse(localStorage.getItem("publishLocalStorage"));
  console.log($rootScope.agent.channelType);
  var jenisChannelList = $rootScope.agent.channelType;
  var custList = {};
  var DATA_PRODUCT = {};
  var tempDataProd = {};
  $scope.dataALokasiDana = {};
  $scope.jenisProdukList = [];
  // var PUBLISH_DATA = {};
  var ProductList = {};
  var FundListz = {};
  var QuotationStorage = {};
  $scope.tempProdukCurrency = [];
  $scope.tempProdukPaymentFrequency = [];
  var fundList = [];
  var coverageList = [];
  var prodChoosed;
  var curChoosed;
  var prodCat;
  var adminFee;
  var objProdCat = {};
  var objProdCatCode;
  $scope.tempProdukCurrency = [];
  $scope.popupAlokasiDana = [];
  var DATA_PRODUCT;
  var DATA_FUND;

  $scope.dataALokasiDana.pilihTemplate = false;

  $scope.jenisProdukList = $rootScope.CHANNEL[jenisChannelList].PRODUCT_CATEGORY;

  QuotationStorageService.getQuotationStorageByKey($q, $rootScope.QuotationId).then(function(res){
    $rootScope.Level = res.Level;
    DATA_PRODUCT = res.Product;
    console.log(DATA_PRODUCT);

    prodChoosed = DATA_PRODUCT ? DATA_PRODUCT.ProductCode : '';
    curChoosed = DATA_PRODUCT ? DATA_PRODUCT.ProductCurrency : '';
    var prodCategory = DATA_PRODUCT ? DATA_PRODUCT.ProductCategory : '';

    var tempProdcodeCurr = DATA_PRODUCT ? DATA_PRODUCT.ProductCode+'|'+DATA_PRODUCT.ProductCurrency : '';
    $scope.dataALokasiDana = DATA_PRODUCT;
    if ($scope.dataALokasiDana) {
        $scope.dataALokasiDana.ProductCode = tempProdcodeCurr;        
    }

    if(DATA_PRODUCT){
      var tempFundList = [];
      var tmpFund = DATA_PRODUCT;
      var tempLoadProd = loadProduct(prodCategory);
      loadFrekuensiPembayaran(prodCategory, tempProdcodeCurr);
      
        for(var j = 0; j < tempLoadProd.length; j++){
            var vv = tempLoadProd[j];
            if (vv.code === tempProdcodeCurr) {
                tempFundList = vv.fund;
                $scope.popupAlokasiDana = generateFundByProduct(tempFundList);
              if(tmpFund.FundList){
                for (var k = 0; k < $scope.popupAlokasiDana.length; k++){                  
                    for(var i = 0; i < tmpFund.FundList.length; i++){
                    var fundListChossed = tmpFund.FundList[i];
                    var fundListChossedCd = tmpFund.FundList[i].code;
                        if($scope.popupAlokasiDana[k].code === fundListChossedCd){
                          $scope.popupAlokasiDana[k].checked = true;
                          $scope.popupAlokasiDana[k].taken = true;
                            for(m = 0 ; m < fundListChossed.itemInput.length; m++){
                                var ii1 = fundListChossed.itemInput[m];
                                for(l = 0 ; l < $scope.popupAlokasiDana[k].itemInput.length; l++){
                                    var ii2 = $scope.popupAlokasiDana[k].itemInput[l];
                                    if(ii1.code == ii2.code && ii1.key == ii2.key){
                                        $scope.popupAlokasiDana[k].itemInput[l].inputValue = ii1.inputValue;
                                        $scope.popupAlokasiDana[k].itemInput[l].value = ii1.value;
                                    }
                                }
                            }
                        }
                    }
                }
              }
            }
        }
    }else{
      DATA_PRODUCT = {};
    }

    custList = res.CustomerList;

    $scope.tempProdukCurrency = !DATA_PRODUCT ?  [] : loadProduct(DATA_PRODUCT.ProductCategory); 

    $ionicLoading.hide();

    
  function loadFrekuensiPembayaran(productCategoryCode, productCode) {
    var tempList = [];
    $scope.tempProdukPaymentFrequency = [];

    for (var j = 0; j < $scope.jenisProdukList.length; j++) {
      var w = $scope.jenisProdukList[j];
      if (w.code === productCategoryCode) {
        objProdCat = w;

        for (var i=0; i < objProdCat.PRODUCT.length; i++) {
          var x = objProdCat.PRODUCT[i];
          var productCodeSplit = productCode.split('|')[0];
          if(x.code === productCodeSplit){
             for (var l=0; l < x.CURRENCY.length; l++) {
            var z = x.CURRENCY[l];
            var tempListProduk = {
              productCurr : z.code,
              code : x.code + '|' + z.code,
              label : x.longName + ' (' + z.code + ')',
              fund : x.CURRENCY[l].FUND,
              coverage : x.CURRENCY[l].COVERAGE,
              adminFee : z.adminFee
            }
            tempList.push(tempListProduk);

          }
           $scope.tempProdukPaymentFrequency = x.PAYMENT_FREQUENCY;
          }
        }
      }
    } 
    return tempList;
  }

  function loadProduct(productCategoryCode) {
    var tempList = [];


    for (var j = 0; j < $scope.jenisProdukList.length; j++) {
      var w = $scope.jenisProdukList[j];
      if (w.code === productCategoryCode) {
        objProdCat = w;

        for (var i=0; i < objProdCat.PRODUCT.length; i++) {
          var x = objProdCat.PRODUCT[i];
          for (var l=0; l < x.CURRENCY.length; l++) {
            var z = x.CURRENCY[l];
            var tempListProduk = {
              productCurr : z.code,
              code : x.code + '|' + z.code,
              label : x.longName + ' (' + z.code + ')',
              fund : x.CURRENCY[l].FUND,
              coverage : x.CURRENCY[l].COVERAGE,
              adminFee : z.adminFee
            }
            tempList.push(tempListProduk);

          }

 //         $scope.tempProdukPaymentFrequency = x.PAYMENT_FREQUENCY;
        }
      }
    } 
    return tempList;
  }


      $scope.keyPress = function(name, value){
        //$scope.dataALokasiDana.pilihTemplate = value.pilihTemplate;
        console.log('ADA KEYPRESS');

        if (name === 'jenisProduk' ) {
          $scope.tempProdukCurrency = [];
          $scope.dataALokasiDana.ProductCategory = value.ProductCategory;
          $scope.tempProdukCurrency = loadProduct($scope.dataALokasiDana.ProductCategory);
          $scope.dataALokasiDana.ProductCode = null;
          $scope.dataALokasiDana.PaymentFrequency = null;
        }

        if (name === 'produkNama') {
             $scope.tempProdukPaymentFrequency = [];       
          $scope.tempProdukCurrencyByProdukCode = loadFrekuensiPembayaran($scope.dataALokasiDana.ProductCategory, value.ProductCode);
          $scope.dataALokasiDana.ProductCode = value.ProductCode;

          for (var j = 0; j < $scope.tempProdukCurrencyByProdukCode.length; j++) { 
            var v = $scope.tempProdukCurrencyByProdukCode[j];
            if (v.code === value.ProductCode) {
              var objProdCod = v;
              var prodCd = v.code.split('|');
              prodChoosed = prodCd[0];
              curChoosed = v.productCurr;
              adminFee = v.adminFee;
              fundList = v.fund;
              coverageList = v.coverage;
            }
          }
          //generateFundByProduct(fundList);
          $scope.popupAlokasiDana = generateFundByProduct(fundList);   
        }

        QuotationStorage.ProductList = {};

          var tempQuot = {
            QuotationId : $rootScope.QuotationId,
            QuotationDate : res.QuotationDate,
            OutputId :  res.OutputId,
            CustomerList : custList,
            Level : 3
          };

        tempQuot.Product = {};
            var tempFundList = [];
              if (name === 'itemInput') {
                for (var t = 0; t < $scope.popupAlokasiDana.length; t++){
                  var z = $scope.popupAlokasiDana[t];
                  if(z.checked == true){
                    for (var y = 0; y < z.itemInput.length; y++){
                      var a = z.itemInput[y].key;
                      var b = z.itemInput[y].inputValue;
                      var c = $scope.popupAlokasiDana[t].code;
                      tempFundList.push($scope.popupAlokasiDana[t]);
                      tempQuot.Product.FundList = tempFundList;
                    }
                  }
                }
              }

        if (name === 'frequensi') {
          $scope.dataALokasiDana.PaymentFrequency = value.PaymentFrequency;
          // var paymentFrequency = value.PaymentFrequency;
        }
        
        tempQuot.Product.ProductCategory = objProdCat.code;
        tempQuot.Product.ProductCode = prodChoosed;
        tempQuot.Product.ProductCurrency = curChoosed;
        tempQuot.Product.AdminFee = adminFee;
        tempQuot.Product.PaymentFrequency = $scope.dataALokasiDana.PaymentFrequency;
        tempQuot.Product.SPAJNo = $scope.dataALokasiDana.noSpaja;
      
        QuotationStorageService.addQuotationStorage($q, $rootScope.QuotationId, tempQuot);      
        
      }

  });

  $scope.searchProductName;

  $scope.clearProductName = function() {
    $scope.searchProductName = '';
  };


  

  $scope.btnAlokasiDana = function(e) {
    
    var myPopup = $ionicPopup.show({
      title: "Pilih investasi yang ingin ditambahkan",
      templateUrl: "components/newSqs/products/list-investation.html",
      cssClass: 'pru-alert white-header pru-logo-text button-side-duo',
      parent: angular.element(document.body),
      targetEvent : e,
      scope: $scope,
      buttons: [
      {
        text: 'Batal',
        type: 'button-dark-gray',
        onTap: function(e) {
           for (var t = 0; t < $scope.popupAlokasiDana.length; t++){
              if($scope.popupAlokasiDana[t].checked == true){
                $scope.popupAlokasiDana[t].taken = true;
              }else{
                $scope.popupAlokasiDana[t].taken = false;
              }
              $scope.popupAlokasiDana[t].flagSearch = true
            }
        }
      },
      {
        text: 'Simpan',
        type: 'button-assertive',
        onTap: function(e) {
          for (var t = 0; t < $scope.popupAlokasiDana.length; t++){
            if($scope.popupAlokasiDana[t].taken == true){
              $scope.popupAlokasiDana[t].checked = true;
            }else{
              $scope.popupAlokasiDana[t].checked = false;
            }
            $scope.popupAlokasiDana[t].flagSearch = true
          }
        }
      }
      ]
    });
  };

  function generateFundByProduct(res) {
    var alokasiDanaList = [];
    for (var i=0; i < res.length; i++) {
      var tempFund = $rootScope.FUND[res[i]];

      /*/////style font garamont 
      var xxx = tempFund.descriptionEng;
      console.log(xxx);
      var PRU = xxx.slice(0, 3);
      var sisa = xxx.slice(3, xxx.length);
      PRU = "<b class='PRUletter'>"+ PRU +"</b>";
      console.log(PRU + sisa);
      tempFund.descriptionEng = PRU + sisa;*/
      var itemInputList = [];
      for (var j =0; j < tempFund.ITEM_INPUT.length; j++) {
        var y = tempFund.ITEM_INPUT[j];
        var x = $rootScope.INPUT[y];
        var tempInputItem = {};
        tempInputItem.code = x.code;
        tempInputItem.description = x.description;
        tempInputItem.type = x.type;
        tempInputItem.value = x.value;
        tempInputItem.key = x.key;

        itemInputList.push(tempInputItem);
      }

      alokasiDanaList.push({
        code : res[i],
        name : tempFund.descriptionEng,
        checked : false,
        taken : false,
        flagSearch : true,
        itemInput : itemInputList,
        type : 'FUND'
      });
    }
    return alokasiDanaList;
  }

  $scope.filter = function(searchText){
    for (var i=0; i < $scope.popupAlokasiDana.length; i++) {
      if ($scope.popupAlokasiDana[i].name.toLowerCase().indexOf(searchText.toLowerCase()) !== -1) {
        $scope.popupAlokasiDana[i].flagSearch = true;
      } else {
        $scope.popupAlokasiDana[i].flagSearch = false;
      }
    }
  }
  
});
