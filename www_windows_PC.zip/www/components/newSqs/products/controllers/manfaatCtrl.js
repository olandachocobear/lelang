﻿var pruforce = angular.module('PruForce');

pruforce.controller('manfaatCtrl', function(PublishGlobalService, $q, $timeout, $scope, $state, $ionicScrollDelegate, $rootScope, $ionicLoading, $ionicPopup, $mdDialog, CustomerStorageService, QuotationStorageService, OutputStorageService, RateStorageService, MathExpressionService) {
  var deferred = $q.defer();
  var channelCode = $rootScope.agent.channelType;
  var quotationId = $rootScope.QuotationId;
  console.log(channelCode);
  console.log(quotationId);
  
  $scope.calcHide = false;

  var outputId;
  $scope.manfaatTopup = [];
  $scope.manfaatPenarikan = [];
  
  $scope.manfaat = {};  
  $scope.manfaat.premiUnapplied = 0;
  $scope.manfaat.minimumUangPertanggungan = 0;
  $scope.manfaat.maksimumUangPertanggungan = 0;
  $scope.manfaat.premi = 0;
  $scope.manfaat.totalPremi = '0';
  $scope.manfaat.rencanaPembayaran = 0;
  
  
  $scope.manfaat.alternatifRencanaPembayaran = 2;
  // $scope.manfaat.halamanRingkasanTahun1 = 1;
  // $scope.manfaat.halamanRingkasanTahun2 = 36;
  // $scope.manfaat.halamanRingkasanTahun3 = 46;
  var getRuleTypeName = {};
  var CUSTOMER_STORAGE = [];
  var QUOTATION_STORAGE = {};
  var OUTPUT_STORAGE = {};
  var mapRule;
  var anbTmp;
  $scope.blockingFlag = true;

  var setDefaultHalamanRingkasan = false;

  QuotationStorageService.getQuotationStorageByKey($q, quotationId).then(function(resQuot){
      QUOTATION_STORAGE = resQuot;
      console.log('Isi QUOTATION STIRAGE : ', QUOTATION_STORAGE);

      CustomerStorageService.getCustomerStorageByCustMap($q, QUOTATION_STORAGE.CustomerList).then(function(resCust){
          CUSTOMER_STORAGE = resCust;
          console.log(CUSTOMER_STORAGE);

         


          //DETAIL FROM QUOTATION STORAGE
          var prodCatCd = QUOTATION_STORAGE.Product.ProductCategory;
          var prodCd = QUOTATION_STORAGE.Product.ProductCode;
          var currCd = QUOTATION_STORAGE.Product.ProductCurrency;
          var fundList = QUOTATION_STORAGE.Product.FundList;
          var adminFee = QUOTATION_STORAGE.Product.AdminFee;

          $scope.currencyProduct = currCd;
          console.log('$scope.currencyProduct : '+ $scope.currencyProduct);

          var product = getProduct(channelCode, prodCatCd, prodCd);
          $scope.manfaat.productName = product.shortName;
          var coverageList = getCoverageList(product, currCd);

          console.log('Product Category Code : '+ prodCatCd);
          console.log('Product Code : '+ prodCd);
          console.log('Currency Code : '+ currCd);
          console.log('Data Produk : ', product);

          $scope.benefitLists = generateCoverageByProduct(coverageList, CUSTOMER_STORAGE);
          $scope.benefitListsTemp = cloneBenefit($scope.benefitLists);
          console.log('RIDER PER PRODUCT : ', $scope.benefitLists);
          
          function mergingBenefitSelected(benefitAvailable, newBenefit){
              var tmpNewBenefitList = [];
              for(var k = 0; k < benefitAvailable.length; k++){
                  var tmpBenefitAvailable = benefitAvailable[k];
                  for(var l = 0; l < newBenefit.length; l++){
                      var tmpNewBenefit = newBenefit[l];
                      if(tmpBenefitAvailable.code == tmpNewBenefit.code){

                          var newCustList = [];
                          for(var m = 0; m < tmpBenefitAvailable.custList.length; m++){
                              var tmpCustAvailbale = tmpBenefitAvailable.custList[m];
                              for(var n = 0; n < tmpNewBenefit.custList.length; n++){
                                  var tmpCustNewBenefit = tmpNewBenefit.custList[n];

                                  if(tmpCustAvailbale.customerId == tmpCustNewBenefit.customerId){
                                      var tmpCustBnft = {};
                                      tmpCustBnft.customerId = tmpCustNewBenefit.customerId;
                                      tmpCustBnft.name = tmpCustNewBenefit.name;
                                      tmpCustBnft.anb = tmpCustNewBenefit.anb;
                                      tmpCustBnft.key = tmpCustNewBenefit.key;
                                      tmpCustBnft.loadList = tmpCustNewBenefit.loadList;
                                      tmpCustBnft.itemInput = tmpCustAvailbale.itemInput;
                                      tmpCustBnft.annualPremi = tmpCustAvailbale.annualPremi;
                                      tmpCustBnft.code = tmpCustAvailbale.code;
                                      tmpCustBnft.biayaBulanan = tmpCustAvailbale.biayaBulanan;

                                      newCustList.push(tmpCustBnft);
                                  }
                              }
                          }

                          tmpBenefitAvailable.custList = newCustList;
                          tmpNewBenefitList.push(tmpBenefitAvailable);


                          break;
                      }
                  }
              }

              return tmpNewBenefitList;
          }

          if(QUOTATION_STORAGE.Manfaat){
              var tmpManfaat = QUOTATION_STORAGE.Manfaat;
              $scope.manfaat.premi = tmpManfaat.premi;
              $scope.manfaat.totalPremi = tmpManfaat.totalPremi;
              $scope.manfaat.rencanaPembayaran = tmpManfaat.rencanaPembayaran;
              $scope.manfaat.alternatifRencanaPembayaran = tmpManfaat.alternatifRencanaPembayaran;
              $scope.manfaat.halamanRingkasanTahun1 = tmpManfaat.halamanRingkasanTahun1;
              $scope.manfaat.halamanRingkasanTahun2 = tmpManfaat.halamanRingkasanTahun2;
              $scope.manfaat.halamanRingkasanTahun3 = tmpManfaat.halamanRingkasanTahun3;
              $scope.benefitListSelected = mergingBenefitSelected(tmpManfaat.manfaatList, $scope.benefitLists);
              $scope.benefitListsSelectedTemp = cloneBenefit($scope.benefitListSelected);
              
              var manfaatTopupfrm = replaceMoneyFormatTopupWidraw(tmpManfaat.manfaatTopup);
              var manfaatPenarikanFrm = replaceMoneyFormatTopupWidraw(tmpManfaat.manfaatPenarikan);

              $scope.manfaatTopup = manfaatTopupfrm;
              $scope.manfaatPenarikan = manfaatPenarikanFrm;

              setDefaultHalamanRingkasan = false;
          }else{
              QUOTATION_STORAGE.Manfaat = {};
              $scope.benefitListSelected = getDefaultCoverage($scope.benefitLists);
              $scope.benefitListsSelectedTemp = cloneBenefit($scope.benefitListSelected);
              setDefaultHalamanRingkasan = true;
          }

          if(QUOTATION_STORAGE.OutputId){
              outputId = QUOTATION_STORAGE.OutputId;
              OutputStorageService.getOutputStorageByKey($q, outputId).then(function(resOut){
                  OUTPUT_STORAGE = resOut;
                  if(OUTPUT_STORAGE){
                      $scope.manfaat.premiUnapplied = OUTPUT_STORAGE.premiUnapplied;
                      console.log('premmi unapplied dari OUTPUT_STORAGE', OUTPUT_STORAGE.premiUnapplied);
                      $scope.manfaat.minimumUangPertanggungan = OUTPUT_STORAGE.minimumUangPertanggungan;
                      $scope.manfaat.maksimumUangPertanggungan = OUTPUT_STORAGE.maksimumUangPertanggungan;
                  }
              });          
          }


          //----------------------------------------------------------POPUP--------------------------------------------------------------------------
          $scope.searchKey = null;


          
          $scope.addBenefitModal = function(e) {
            var myPopup = $ionicPopup.show({
              title: "Pilih Manfaat yang ingin Ditambahkan",
              templateUrl: "components/newSqs/products/list-manfaat.tmpl.html",
              cssClass: 'pru-alert popup-large white-header button-side-duo',
              scope: $scope,
              buttons: [
                {
                  text: 'Batal',
                  type: 'button-dark-gray',
                  onTap: function(e) {
                    $scope.benefitListsSelectedTemp = cloneBenefit($scope.benefitListSelected);
                    $scope.benefitListsTemp = cloneBenefit($scope.benefitLists);
                    $scope.keypress('');
                  }
                },
                {
                  text: 'Simpan',
                  type: 'button-assertive',
                  onTap: function(e) {
                    $scope.benefitListSelected = cloneBenefit($scope.benefitListsSelectedTemp);
                    console.log('isi dari add $scope.benefitListsSelectedTemp =============, ',$scope.benefitListsSelectedTemp);
                    $scope.benefitListsTemp = cloneBenefit($scope.benefitLists);
                    $scope.keypress('');
                  }
                }
              ]
            });
          };

          $scope.toggle = function (item, list) {
              var idx = getIndex(item, list);
              if (idx > -1) {
                  list.splice(idx, 1);
              }
              else {
                  var itemTmp = clearItem(item);
                  list.push(itemTmp);
              }
          };

          $scope.exists = function (item, list) {
              return getIndex(item, list) == -1 ? false : true;
          };

          function getIndex(item, list){
              var idx = -1;
              for(var i = 0; i < list.length; i++){
                  if(item.code == list[i].code){
                      idx = i;
                  }
              }
              return idx;
          }

          $scope.searchBenefit = function(searchKey){
              if(searchKey){
                  $scope.benefitLists = [];
                  for(var i = 0 ; i < $scope.benefitListsTemp.length; i++){
                      if(($scope.benefitListsTemp[i].name).toLowerCase().indexOf((searchKey).toLowerCase()) !== -1 ){
                          $scope.benefitLists.push($scope.benefitListsTemp[i]);
                      }
                  }                
              }else{
                  $scope.benefitLists = cloneBenefit($scope.benefitListsTemp);
              }
          }


          function generateCoverageByProduct(coverageList, CUSTOMER_STORAGE){
                
              var tmpBenefitList = [];
              for(var i = 0; i < coverageList.length; i++){
                  var tmpCoverage = $rootScope.COVERAGE[coverageList[i].coverageCd];
                  
                  var tmpCustList = [];
                  //if(tmpCoverage.type.toLowerCase() == 'topup' || coverageList[i].lifeAssureCd == '02,03' || coverageList[i].lifeAssureCd == '02' || coverageList[i].coverageCd == 'C1KR' || coverageList[i].coverageCd == 'U1ZR'){
                      var additionalLifeList = coverageList[i].lifeAssureCd.split(',');
                      var additionalLen = additionalLifeList.length;
                      
                      for(var y = 0; y < additionalLen; y++){
                          var tmp = (parseInt(additionalLifeList[y].substring(1, additionalLifeList[y].length)) + 1);
                          var tmpTertanggung = getDataTertanggung('0'+tmp, QUOTATION_STORAGE.CustomerList, CUSTOMER_STORAGE);
                          
                          if(tmpTertanggung){
                              var tertanggung = {};
                              tertanggung.customerId = tmpTertanggung.customerId;
                              tertanggung.name = tmpTertanggung.name;
                              tertanggung.anb = tmpTertanggung.anb;
                              anbTmp = tmpTertanggung.anb;;
                              tertanggung.key = tmpTertanggung.key;
                              tertanggung.loadList = tmpTertanggung.loadList;
                              var itemInputList = [];
                              for(var j = 0; j < tmpCoverage.ITEM_INPUT.length; j++){
                                  var tmpInputItemCd = tmpCoverage.ITEM_INPUT[j];
                                  var x = $rootScope.INPUT[tmpInputItemCd];
                                  var tmpItemInput = {};

                                  tmpItemInput.code = x.code;
                                  tmpItemInput.description = x.description;
                                  tmpItemInput.type = x.type;
                                  tmpItemInput.value = x.value;
                                  tmpItemInput.inputValue = 0;
                                  tmpItemInput.key = x.key;
                                  tmpItemInput.annualPremi = 0;
                                    
                                  itemInputList.push(tmpItemInput);
                              }

                              if(tmpCoverage.TERM.length > 0){
                                  var stringTerm = '';
                                  for(var d = 0; d < tmpCoverage.TERM.length; d++){
                                      if(d == (tmpCoverage.TERM.length -1)){
                                          stringTerm += tmpCoverage.TERM[d];
                                      }else{
                                          stringTerm += tmpCoverage.TERM[d] + '|';
                                      }
                                  }
                                  var tmpTerm = {};
                                  
                                  tmpTerm.code = 'TERMOPTION';
                                  tmpTerm.description = 'Masa Pertanggungan(Sampai Usia)';
                                  tmpTerm.type = 'option';
                                  tmpTerm.value = stringTerm;
                                  tmpTerm.inputValue = 0;
                                  tmpTerm.key = 'PDTERM';
                                    
                                  itemInputList.push(tmpTerm);                    
                              }  
                            
                              
                              tertanggung.itemInput = itemInputList;
                              tertanggung.annualPremi = 0;
                              tmpCustList.push(tertanggung);
                                                       
                          }
                      }

                      var tmpBenefit = {};
                      tmpBenefit.code = coverageList[i].coverageCd;
                      tmpBenefit.name = tmpCoverage.shortDescription;
                      tmpBenefit.disabled = tmpCoverage.type == 'main' ? true : false;
                      tmpBenefit.coverageType = tmpCoverage.type;
                      tmpBenefit.type = 'COVERAGE';
                      tmpBenefit.lifeAssureCd = coverageList[i].lifeAssureCd;
                      tmpBenefit.custList = tmpCustList;

                      tmpBenefitList.push(tmpBenefit);                      
                  //}
              }
              return tmpBenefitList;
          }
          


          function getDefaultCoverage(coverageList){
              var tmpCoverageList = [];
              for(var i = 0; i < coverageList.length; i++){
                  if(coverageList[i].coverageType != 'rider'){
                      tmpCoverageList.push(coverageList[i]);
                  }
              }
              return tmpCoverageList;
          }
          //-------------------------------- TOPUP -------------------------------------------------
            
          //$scope.manfaatTopup = [{id: '1', yearStart: 'yearStart_1', yearEnd: 'yearEnd_1', amount: "amount_1"}]
          $scope.addNewTopup = function(){
            var newTopup = $scope.manfaatTopup.length+1;
            $scope.manfaatTopup.push({id: newTopup,
                                      yearStart: '',
                                      yearEnd: '', 
                                      amount: '0'});
            $scope.keypress('');
          }


          //------------------------------PENARIKAN --------------------------------------------------
          //$scope.manfaatPenarikan = [{id: '1', yearStart: 'yearStart_1', yearEnd: 'yearEnd_1', amount: "amount_1"}]
          $scope.addNewPenarikan = function(){
            var newPenarikan = $scope.manfaatPenarikan.length+1;
            $scope.manfaatPenarikan.push({id: newPenarikan,
                                      yearStart: '',
                                      yearEnd: '',
                                      amount: '0'});
            $scope.keypress('');
          }

          $scope.confirmRemovePopup = function(type, model){
            var msgPopup = null;
            if(type == "topup"){
              msgPopup = "Apakah anda ingin menghapus <br> TOP UP " + model.id +" ?"
            }else if(type == "penarikan"){
              msgPopup = "Apakah anda ingin menghapus <br> Penarikan " + model.id +" ?"
            }

            var confirmPopup = $ionicPopup.confirm({
              title: "",
              template: msgPopup,
              cssClass: 'pru-white-alert without-header popup-large pru-logo-text button-side-duo',
              scope: $scope,
              buttons: [
              {
                text: 'TIDAK',
                type: 'button-dark-gray',
                onTap: function(e) {
                }
              },
              {
                text: 'YA',
                type: 'button-assertive',
                onTap: function(e) {
                  $scope.removedPopup(type, model);
                }
              }
              ]
            });
          }

          $scope.removedPopup = function(type, model){
            // $scope.removeIlustrasi.close();
            var idx = -1;
            var msgPopup = null;
            if(type == "topup"){
              idx = $scope.manfaatTopup.indexOf(model);
              msgPopup = "TOP UP " + model.id +" telah dihapus"
              $scope.manfaatTopup.splice(idx, 1);
            }else if(type == "penarikan"){
              idx = $scope.manfaatPenarikan.indexOf(model);
              msgPopup = "Penarikan " + model.id +" telah dihapus"
              $scope.manfaatPenarikan.splice(idx, 1);
            }

            $timeout(function(){
              var alertPopup = $ionicPopup.alert({
                title: "",
                template: msgPopup,
                cssClass: 'pru-white-alert without-header popup-large pru-logo-text button-side-duo',
                scope: $scope,
                buttons: [
                {
                  text: 'SELESAI',
                  type: 'button-assertive',
                  onTap: function(e) {
                    alertPopup.close();
                    $scope.keypress('');
                  }
                }
                ]
              }, 5);
            })
          }


          function getValueTopup(){
            var inputValue = 0;
              for(var i = 0; i < $scope.benefitListSelected.length; i++){
                  if($scope.benefitListSelected[i].coverageType == 'topup'){
                      for(var j = 0; j < $scope.benefitListSelected[i].custList.length; j++){
                          var custList = $scope.benefitListSelected[i].custList[j];
                          for(var k = 0; k < custList.itemInput.length; k++){
                              if(custList.itemInput[k].inputValue){
                                 inputValue += custList.itemInput[k].inputValue
                              }    
                          }
                      }                      
                  }
              }
              return inputValue;
          }

          
          
          $scope.keypress = function(key){
            $rootScope.Level = 4;
            QUOTATION_STORAGE.Level = 4;
            $scope.manfaat.topupBerkala = getValueTopup();
            if(key === 'premi'){
              $scope.manfaat.totalPremi = getTotalPremi($scope.manfaat.premi, $scope.manfaat.topupBerkala);
            }else if(key === 'topupBerkala'){
              $scope.manfaat.totalPremi = getTotalPremi($scope.manfaat.premi, $scope.manfaat.topupBerkala);
            }


            QUOTATION_STORAGE.Manfaat.premiUnapplied = $scope.manfaat.premiUnapplied;
            QUOTATION_STORAGE.Manfaat.minimumUangPertanggungan = $scope.manfaat.minimumUangPertanggungan
            QUOTATION_STORAGE.Manfaat.maksimumUangPertanggungan = $scope.manfaat.maksimumUangPertanggungan;
            QUOTATION_STORAGE.Manfaat.premi = replaceMoneyFormat($scope.manfaat.premi);
            QUOTATION_STORAGE.Manfaat.topupBerkala = replaceMoneyFormat($scope.manfaat.topupBerkala);
            QUOTATION_STORAGE.Manfaat.totalPremi = replaceMoneyFormat($scope.manfaat.totalPremi);
            QUOTATION_STORAGE.Manfaat.rencanaPembayaran = $scope.manfaat.rencanaPembayaran;
            QUOTATION_STORAGE.Manfaat.alternatifRencanaPembayaran = $scope.manfaat.alternatifRencanaPembayaran;
            QUOTATION_STORAGE.Manfaat.halamanRingkasanTahun1 = $scope.manfaat.halamanRingkasanTahun1;
            QUOTATION_STORAGE.Manfaat.halamanRingkasanTahun2 = $scope.manfaat.halamanRingkasanTahun2;
            QUOTATION_STORAGE.Manfaat.halamanRingkasanTahun3 = $scope.manfaat.halamanRingkasanTahun3;
            QUOTATION_STORAGE.Manfaat.manfaatList = $scope.benefitListSelected;
            QUOTATION_STORAGE.Manfaat.manfaatListFormat = $scope.benefitListSelected;
            QUOTATION_STORAGE.Manfaat.manfaatTopup = replaceMoneyFormatTopupWidraw($scope.manfaatTopup);
            QUOTATION_STORAGE.Manfaat.manfaatPenarikan = replaceMoneyFormatTopupWidraw($scope.manfaatPenarikan);

            QuotationStorageService.addQuotationStorage($q, $rootScope.QuotationId, QUOTATION_STORAGE);

            console.log('isi dari data collection QUOTATION_STORAGE ================= ',QUOTATION_STORAGE);

          }

          function messageAlert(rule){   
            console.log(rule);
            var ruleMap = {};
            if(rule && rule.length > 0){
              for(var i = 0; i < rule.length; i++){
                var tempRule = rule[i];
                ruleMap.flag = tempRule.comparisson;
                ruleMap.type = tempRule.errorType;
                ruleMap.errorMsg = tempRule.errorMessageInd;
              }
            } 

            return ruleMap;
          }



          //GET DATA TERTANGGUNG UTAMA FROM PARAMETER UTAMA FROM CUSTOMER STORAGE
          var tertanggungUtama = getDataTertanggung('02', QUOTATION_STORAGE.CustomerList, CUSTOMER_STORAGE);
          var age = tertanggungUtama.anb;
          var custAgeDay = tertanggungUtama.custAgeDay;
          var custAgeMonth = tertanggungUtama.custAgeMonth;
          var clazz = tertanggungUtama.Occupation.clazz;
          var jk = (tertanggungUtama.jenisKelaminPerokok).split('|');
          var gender = jk[0];
          var smokerStatus = jk[1];



          var custIncome = tertanggungUtama.Income;
          var tmpAltAge = ((40+parseInt(age))-1);
          console.log('------------------------' + tmpAltAge);
          $scope.ageList = [{code : '1', label :(tmpAltAge > 99 ? 99 : tmpAltAge)}, {code : '2', label : 99}];
          if(setDefaultHalamanRingkasan){
              setHalamanRingkasanTahun(age);            
          }


          $scope.calculate = function(){

            if(!outputId){
                outputId = 'OUT' + (new Date().getTime());              
            }

            var map ={};
            map.currCd = currCd.toUpperCase();
            map.channelCode = channelCode;
            map.adminFee = adminFee;
            
            map.age = age;
            map.custAgeDay = custAgeDay;
            map.custAgeMonth = custAgeMonth;
            console.log('umur dalam bulan dari customer adalah : ========================== ',custAgeMonth);
            map.gender = gender;
            map.smokerStatus = smokerStatus;
            map.clazz = clazz;
            map.custIncome = custIncome;

            map.customerList = CUSTOMER_STORAGE;

            // var strPremi = replaceMoneyFormat($scope.manfaat.premi);
            // $scope.manfaat.premi = strPremi;
            map.manfaat = $scope.manfaat;            
            map.manfaat.premi = replaceMoneyFormat($scope.manfaat.premi);
            map.manfaatList = replaceMoneyFormatListBenefit($scope.benefitListSelected);

            map.rateCdList = [];

           
   
            if(isNaN($scope.manfaat.totalPremi)){
              map.manfaat.totalPremi = parseFloat($scope.manfaat.totalPremi.replace(/,/g , ""));  
            }

            var totalDeathBenefit;
            var medicalU1ZR;
            var facultativeU1ZR;
            var crisisIncome;
            var totAccU1ZR;
            var detFaculU1ZR;
            var sau1zr;
            var sabasic;
            var sa_basic;
            var up;
            var hsplan;
            var custSA = 0;
            var custSaver = 0;
            var isValid;

            var tmpMap = {};
            var tmpCust0;

            console.log(map.manfaatList);
            for(var i = 0; i < map.manfaatList.length; i++){
                var tmpManfaat = map.manfaatList[i];

                for(var zr = 0; zr < tmpManfaat.custList.length; zr++){
                  tmpCust0 = tmpManfaat.custList[zr];
                  for(var tml = 0; tml < tmpCust0.itemInput.length; tml++){
                    zeroFlag = tmpCust0.itemInput[tml].inputValue.substring(0, 1);
                    if(zeroFlag == '0'){
                      tmpManfaat.custList[zr].itemInput[tml].inputValue = tmpCust0.itemInput[tml].inputValue.replace(tmpCust0.itemInput[tml].inputValue.substring(0, 1), '');
                    }
                  }
                }

                if(tmpManfaat.coverageType == 'main'){
                    if(tmpManfaat.custList[0].itemInput[0] != undefined){
                        custSA = tmpManfaat.custList[0].itemInput[0].inputValue;  
                    }
                    
                }else if(tmpManfaat.coverageType == 'topup'){
                    if(tmpManfaat.custList[0].itemInput[0] != undefined){
                      custSaver = tmpManfaat.custList[0].itemInput[0].inputValue;
                    }  
                }

                var tmpRateCdList = $rootScope.COVERAGE[tmpManfaat.code].CHANNEL[channelCode];                    
                for(var j = 0; j < tmpRateCdList.length; j++){
                    tmpMap[tmpRateCdList[j]] = 0;
                }                
            }

            for(var t in tmpMap){
              map.rateCdList.push(t);
            }

            // START Add topup and withdrawal calculation
            var manfaatTopupList = $scope.manfaatTopup;
            var topupList = [];
            for(var i = 0; i <manfaatTopupList.length; i++){
                  for(var year = parseInt(manfaatTopupList[i].yearStart); year <= parseInt(manfaatTopupList[i].yearEnd); year++){
                      var tmpTopUp  = {year : year, amount : manfaatTopupList[i].amount};
                      topupList.push(tmpTopUp);
                  }
            }
            map.topupList = topupList;

            var manfaatWithdrawalList = $scope.manfaatPenarikan;
            var withdrawalList = [];
            for(var i = 0; i <manfaatWithdrawalList.length; i++){
                for(var year = parseInt(manfaatWithdrawalList[i].yearStart); year <= parseInt(manfaatWithdrawalList[i].yearEnd); year++){
                    var tmpWithdrawal = {year : year, amount : manfaatWithdrawalList[i].amount};
                    withdrawalList.push(tmpWithdrawal);
                }
            }
            map.withdrawalList = withdrawalList;
            // END Add topup and withdrawal calculation

            //Add custSA and custSaver
            map.custSA = parseFloat(custSA);
            map.custSaver = parseFloat(custSaver);            

            console.log('map === ', map);

            RateStorageService.getRateValue($q, map).then(function(rate){
              console.log(rate);
              $rootScope.RATE = rate;    
              console.log('isi data collection dari map ===== ', map);
              mapResultFormula = MathExpressionService.getUnappliedPremium(map, 'flagHitung');

              if(mapResultFormula){
                $scope.manfaat.premiUnapplied = mapResultFormula['UNAPPLIED'] ? Math.round(mapResultFormula['UNAPPLIED'])   : 0;
                $scope.manfaat.minimumUangPertanggungan = mapResultFormula['MINSA'] ? Math.round(mapResultFormula['MINSA']) : 0;
                $scope.manfaat.maksimumUangPertanggungan = mapResultFormula['MAXSA'] ? Math.round(mapResultFormula['MAXSA']) : 0;
                totalDeathBenefit = mapResultFormula['TOTALDEATHBENEFIT'] ? mapResultFormula['TOTALDEATHBENEFIT'] : 0;
                medicalU1ZR = mapResultFormula['OUT_MED_U1ZR'] ? mapResultFormula['OUT_MED_U1ZR'] : 0;
                facultativeU1ZR = mapResultFormula['OUT_FACULTATIVE_U1ZR'] ? mapResultFormula['OUT_FACULTATIVE_U1ZR'] : 0;
                crisisIncome = mapResultFormula['OUT_SA_I1DR'] ? mapResultFormula['OUT_SA_I1DR'] : 0;
                totAccU1ZR = mapResultFormula['OUT_TOT_ACC_U1ZR'] ? mapResultFormula['OUT_TOT_ACC_U1ZR'] : 0;
                detFaculU1ZR = mapResultFormula['OUT_DETERMINED_FACULTATIVE_U1ZR'] ? mapResultFormula['OUT_DETERMINED_FACULTATIVE_U1ZR'] : 0;
                sau1zr = mapResultFormula['OUT_SA_U1ZR'] ? mapResultFormula['OUT_SA_U1ZR'] : 0;
                sabasic = mapResultFormula['SABASIC'] ? mapResultFormula['SABASIC'] : 0;
                sa_basic = mapResultFormula['SA_BASIC'] ? mapResultFormula['SA_BASIC'] : 0;
                hsplan = mapResultFormula['HSPLAN'] ? mapResultFormula['HSPLAN'] : 0;
                console.log('value dari mapResultFormula[HSPLAN] adalah ===== ',mapResultFormula['HSPLAN']);
                var tmpIi;  
                var pruSever;
                var zeroFlag;
                var charLength;
                console.log('isi data collection dari benefitListSelected == ',$scope.benefitListSelected);

                var manfaatListCodeSelected = mapResultFormula['manfaatList']; //Manfaat list yang sudah di kalkulasi from MathExpression
                console.log('manfaatListCodeSelected == ',manfaatListCodeSelected);

                for(var j = 0; j < $scope.benefitListSelected.length; j++){
                  var mapResult = mapResultFormula.MAPRESULTCALCULATE;
                  var tmpBenef = $scope.benefitListSelected[j];

                  for(var b = 0; b < tmpBenef.custList.length; b++){
                    var tmpCust = tmpBenef.custList[b];
                    tmpCust.code = tmpBenef.code;

                    if(manfaatListCodeSelected.indexOf(tmpCust.code) > -1 ){
                      if(mapResult[tmpBenef.code+ '|' +tmpCust.customerId]){
                        tmpCust.annualPremi = mapResult[tmpBenef.code+ '|' +tmpCust.customerId]['riderPremium'].toFixed(2);  
                        console.log('isi dari tmpCust ========= ',tmpCust);

                        for(var r = 0; r<tmpCust.itemInput.length; r++){
                          tmpIi = tmpCust.itemInput[r];
                          tmpIi.code = tmpCust.code;
                          if(tmpIi.code == 'U1CR'){
                            pruSever = tmpIi.inputValue;
                          }
                          if(tmpIi.code == 'U1ZR'){
                            tmpIi.tmpTerm = 99;
                          }
                          console.log('value dari tmpIi ==== ',tmpIi);
                          if(tmpIi.key == 'PDPLAN' && tmpIi.inputValue != '0'){
                            tmpCust.itemInput[r].hsplan = hsplan;
                            if(tmpCust.itemInput[r].code == 'W1QR' || tmpCust.itemInput[r].code == 'W3BR'){
                              tmpCust.itemInput[r].hsplan = parseFloat(sabasic) + parseFloat(pruSever);
                            }
                            console.log('isi dari input value tmpCust.itemInput[r].hsplan adalah === ',tmpCust.itemInput[r].hsplan);
                          }else{
                            tmpCust.itemInput[r].hsplan = '0';
                          }

                          // add hsplan  
                          /*tmpCust.biayaBulanan = resultCalculate.chargeRider;                       
                          tmpCust.biayaBulanan = resultCalculate.chargeInsurance;*/
                          tmpCust.biayaBulanan = 0;
                          if(tmpBenef.coverageType == 'rider'){
                              console.log('cek biaya bulanan rider');
                              tmpCust.biayaBulanan = mapResult[tmpBenef.code+ '|' +tmpCust.customerId]['chargeRider'];    
                          }else if(tmpBenef.coverageType == 'main'){
                              console.log('cek biaya bulanan main');
                              tmpCust.biayaBulanan = mapResult[tmpBenef.code+ '|' +tmpCust.customerId]['chargeInsurance'];    
                          }
                        }
                      }
                    }
                  }
                }

                //ruleule.errorType === 'BLOCKED' WARNING
                //isValid = getTermAndAnb(map);
                console.log('isi dari mapResultFormula adalah ============================= ',mapResultFormula);

                if(mapResultFormula.rule.length > 0){

                  var valErrorMsgBlock;
                  var valSparatorBlock;
                  var valErrorMsgWarning;
                  var valSparatorWarning;

                  mapRule = sortingErrorMessageRule(mapResultFormula.rule);//messageAlert(mapResultFormula.rule);

                  $scope.mapRule = mapRule; //save rule validation to output storage, since used in output

                  console.log('isi dari Map mapRule ===== ',mapRule);
                  //revision by Efrat Yerikho
                  for(var er = 0; er<mapRule.length; er++){

                    var typeError = mapRule[er].type;

                    switch(typeError){

                      case "BLOCKED" :
                        valErrorMsgBlock = mapRule[er].errorMsg;
                        valSparatorBlock = valErrorMsgBlock.indexOf("{0}") > -1;
                        if(valSparatorBlock){
                          var valueError = parseFloat(mapRule[er].value).format().toString();
                          var hasilErmsgBlk = valErrorMsgBlock.replace('{0}',valueError);
                          $rootScope.AlertDialog(hasilErmsgBlk);
                          $scope.blockingFlag = true;
                        }else{
                          $rootScope.AlertDialog(valErrorMsgBlock);
                          $scope.blockingFlag = true;
                        }
                      break;

                      case "WARNING" :
                        valErrorMsgWarning = mapRule[er].errorMsg;
                        valSparatorWarning = valErrorMsgWarning.indexOf("{0}") > -1;
                        if(valSparatorWarning){
                          var valueWarning = parseFloat(mapRule[er].value).format().toString();
                          var hasilErmsgWar = valErrorMsgWarning.replace('{0}',valueWarning);
                          $rootScope.WarnDialog(hasilErmsgWar);
                          $scope.blockingFlag = false;
                        }else{
                          $rootScope.WarnDialog(valErrorMsgWarning);
                          $scope.blockingFlag = false;
                        }
                      break;

                      default :
                      break;

                    }

                    break;

                  }
                  //end revision by Efrat Yerikho

                }else{
                  $scope.blockingFlag = false;
                }

                QUOTATION_STORAGE.OutputId = outputId;
                QUOTATION_STORAGE.Manfaat.manfaatList = $scope.benefitListSelected;
                if(QUOTATION_STORAGE.QuotationDate == undefined){
                    QUOTATION_STORAGE.QuotationDate = new Date();
                }

                QuotationStorageService.addQuotationStorage($q, $rootScope.QuotationId, QUOTATION_STORAGE).then(function(){
                  OUTPUT_STORAGE.outputId = outputId;
                  OUTPUT_STORAGE.minimumUangPertanggungan = $scope.manfaat.minimumUangPertanggungan;
                  OUTPUT_STORAGE.maksimumUangPertanggungan = $scope.manfaat.maksimumUangPertanggungan;
                  OUTPUT_STORAGE.premiUnapplied = $scope.manfaat.premiUnapplied;
                  OUTPUT_STORAGE.totalDeathBenefit = (totalDeathBenefit).toString();
                  OUTPUT_STORAGE.medicalU1ZR = (medicalU1ZR).toString();
                  OUTPUT_STORAGE.facultativeU1ZR = (facultativeU1ZR).toString();

                  if(crisisIncome == null){
                    OUTPUT_STORAGE.crisisIncome = '0';
                  }else{
                    OUTPUT_STORAGE.crisisIncome = (crisisIncome).toString();
                  }

                  OUTPUT_STORAGE.totAccU1ZR = (totAccU1ZR).toString();
                  OUTPUT_STORAGE.detFaculU1ZR = (detFaculU1ZR).toString();
                  OUTPUT_STORAGE.sau1zr = (sau1zr).toString();

                   if(sa_basic == null){
                    OUTPUT_STORAGE.sa_basic = '0';
                  }else{
                    OUTPUT_STORAGE.sa_basic = (sa_basic).toString();
                  }

                  if(totalDeathBenefit >= medicalU1ZR){
                    OUTPUT_STORAGE.up = (totalDeathBenefit).toString();
                  }else{
                    OUTPUT_STORAGE.up = (medicalU1ZR).toString();
                  }

                  OUTPUT_STORAGE.mapRule = $scope.mapRule;

                  OutputStorageService.addOutputStorage($q, outputId, OUTPUT_STORAGE);

                });

              }

            });

          }  

          function getAgeAlt(code){
              for(var v = 0; $scope.ageList.length; v++){
                if($scope.ageList[v].code == code){
                  return $scope.ageList[v].label;
                }
              }
          }

          $scope.process = function(){
            var start = new Date();
            start = start.getHours() + ":" + start.getMinutes() + ":" + start.getSeconds();
            var end = null;
            if (outputId) {
              PublishGlobalService.getpdf($q, quotationId).then(function(res){
                  console.log(res);
                  if(res.rows.length > 0){
                      PublishGlobalService.removepdf($q, quotationId).then(function(){
                          console.log("pdfstore data cleared");
                      })
                  }else{
                      console.log("pdfstore data not exist");
                  }
              })
              var map ={};
              map.currCd = currCd.toUpperCase();
              map.channelCode = channelCode;
              map.adminFee = adminFee;
              
              map.age = age;
              map.custAgeDay = custAgeDay;
              map.custAgeMonth = custAgeMonth;    
              map.gender = gender;
              map.smokerStatus = smokerStatus;
              map.clazz = clazz;
              map.custIncome = custIncome;

              map.customerList = CUSTOMER_STORAGE;

              map.manfaat = $scope.manfaat;
              if(isNaN($scope.manfaat.totalPremi)){
                  map.manfaat.totalPremi = parseFloat($scope.manfaat.totalPremi.replace(/,/g , ""));  
              }
              map.manfaatList = $scope.benefitListSelected;


              // START Add topup and withdrawal calculation
              var manfaatTopupList = $scope.manfaatTopup;
              var topupList = [];
              for(var i = 0; i <manfaatTopupList.length; i++){
                  for(var year = parseInt(manfaatTopupList[i].yearStart); year <= parseInt(manfaatTopupList[i].yearEnd); year++){
                      var tmpTopUp  = {year : year, amount : manfaatTopupList[i].amount};
                      topupList.push(tmpTopUp);
                  }
              }
              map.topupList = topupList;

              var manfaatWithdrawalList = $scope.manfaatPenarikan;
              var withdrawalList = [];
              for(var i = 0; i <manfaatWithdrawalList.length; i++){
                  for(var year = parseInt(manfaatWithdrawalList[i].yearStart); year <= parseInt(manfaatWithdrawalList[i].yearEnd); year++){
                      var tmpWithdrawal = {year : year, amount : manfaatWithdrawalList[i].amount};
                      withdrawalList.push(tmpWithdrawal);
                  }
              }
              map.withdrawalList = withdrawalList;
              // END Add topup and withdrawal calculation


              var custSA = 0;
              var custSaver = 0;

              for(var i = 0; i < map.manfaatList.length; i++){
                  var tmpManfaat = map.manfaatList[i];

                  if(tmpManfaat.coverageType == 'main'){
                      if(tmpManfaat.custList[0].itemInput[0] != undefined){
                          custSA = tmpManfaat.custList[0].itemInput[0].inputValue;  
                      }
                      
                  }else if(tmpManfaat.coverageType == 'topup'){
                      if(tmpManfaat.custList[0].itemInput[0] != undefined){
                        custSaver = tmpManfaat.custList[0].itemInput[0].inputValue;
                      }  
                  }                
              }

              map.custSA = parseFloat(custSA);
              map.custSaver = parseFloat(custSaver);

              var mapResultFormula = MathExpressionService.getUnappliedPremium(getCustIncome(map),'flagIlustrasi');
              var flag = true;
              var errType;
              console.log('isi mapResultFormula saat proses ilustrasi = ',mapResultFormula);
              if(mapResultFormula.rule.length > 0){
                console.log('masuk sini kondisi block 1 =============================');
                mapRule = sortingErrorMessageRule(mapResultFormula.rule);
                for(var er = 0; er<mapRule.length; er++){
                  errType = mapRule[er].type;
                  if(mapRule[er].type === 'BLOCKED'){
                    console.log('masuk sini kondisi block 2 =============================');
                     var valErrorMsg = mapRule[er].errorMsg;
                      var valSparator = valErrorMsg.indexOf("{0}") > -1;
                      if(valSparator){
                        var hasilErmsg = valErrorMsg.replace('{0}',parseFloat(mapRule[er].value).format().toString());
                        $rootScope.AlertDialog(hasilErmsg);
                        $scope.blockingFlag = true;
                        break;
                      }else{
                        $rootScope.AlertDialog(mapRule[er].errorMsg);
                        $scope.blockingFlag = true;
                        //break;
                      }
                      //break;
                   }
                   break;
                }
              }else{
                $scope.blockingFlag = false;
                
              }
              if (flag) {
                if(errType == 'BLOCKED'){
                  $scope.blockingFlag = true;
                }else{
                  map.fundList = fundList;
                  map.rencanaPembayaran = $scope.manfaat.rencanaPembayaran == 0 ? 99 : $scope.manfaat.rencanaPembayaran;
                  map.alternatifRencanaPembayaran = getAgeAlt($scope.manfaat.alternatifRencanaPembayaran);
                  
                  var output = MathExpressionService.processIlustration(map);
                  if(output.status == '1' && output.content == null){
                      $rootScope.AlertDialog('Nilai Tunai pada 20 tahun pertama Polis tidak mencukupi untuk pembayaran Biaya Asuransi, Mohon untuk menambahkan Top-up Tunggal atau PRUsaver');
                  }else if(output.status == '2' && output.content == null){
                      $rootScope.AlertDialog('Sisa Nilai Tunai setelah Penarikan kurang dari ketentuan Produk');
                  }else{
                      OUTPUT_STORAGE.output = output.content;
                      end = new Date();
                      end = end.getHours() + ":" + end.getMinutes() + ":" + end.getSeconds();
                      console.log("Elapsed : " + start + " - " + end);
                      //return false;
                      OutputStorageService.addOutputStorage($q, outputId, OUTPUT_STORAGE).then(function(){
                          $state.go("salin-ilustrasi");
                      });
                  }
                }
              }
   
                  
          } else {
              $rootScope.AlertDialog('Silakan isi premi tahunan');
          }
          }

          function getBenefitSelected(tmpBenefitList){
            var tmpList = [];
            var tempPdsa = '';
            for(var i = 0; i < tmpBenefitList.length; i++){
              if(tmpBenefitList[i].checked == true){
                tempPdsa = replaceMoneyFormat(tmpBenefitList[i].itemInput[0].inputValue);
                tmpBenefitList[i].itemInput[0].inputValue = tempPdsa;
                tmpList.push(tmpBenefitList[i]);
              }
            }
            return tmpList;
          }


          var tempDeleteBenefits = [];
          $scope.editTakenBenefit = false;
          $scope.deleteTakenBenefit = false;

          $scope.editTakenBenefitAction = function (ev, editTakenBenefit){
            $scope.editTakenBenefit = !editTakenBenefit;
          }

          $scope.addDeleteTakenBenefitItem = function(obj, model){
            if(model == true){
              tempDeleteBenefits.push(obj);
            }else{
              var  index = tempDeleteBenefits.indexOf(obj);
              if (index > -1){
                tempDeleteBenefits.splice(index,1);
              }
            }
            if (tempDeleteBenefits.length > 0){
              $scope.deleteTakenBenefit = true;
            }else{
              $scope.deleteTakenBenefit = false;
            }
          }

          $scope.deleteTakenBenefitAction = function(){
            var bntLength = tempDeleteBenefits.length;
            for (var i=0; i < bntLength;i++){
              var  index = benefitLists.indexOf(tempDeleteBenefits[i]);
              var  index2 = takenBenefits.indexOf(tempDeleteBenefits[i]);
              if (index > -1){
                benefitLists[index]['taken'] = false;
              }
              if (index2 > -1){
                takenBenefits.splice(index2,1);
              }
            }
            $scope.deleteTakenBenefit = false;
            tempDeleteBenefits = [];
          }

      });   
  });
  $ionicLoading.hide();


  

  function getTotalPremi(premi, topup){
    if(isNaN(premi) && premi.indexOf(',') > -1){
       premi = premi.replace(/,/g , "");
    }

    if(isNaN(topup) && topup.indexOf(',') > -1){
       topup = topup.replace(/,/g , "");
    }

    
    var result = (parseInt(premi)+parseInt(topup));
    return result ? result : '0';
  }

  function replaceMoneyFormat(value){
    var result = '';
    console.log(value);
    if(value !== undefined){

      if(isNaN(value) && value.indexOf(',') > -1){
         value = value.replace(/,/g , "");
      }
    }
    result = value;
    return result ? result : '0';
  }

  function replaceMoneyFormatTopupWidraw(listValue){
    var listResult = listValue;
    var value;
    for(var i = 0; i<listResult.length; i++){
      value = listResult[i].amount;
      if(isNaN(value) && value.indexOf(',') > -1){
       value = value.replace(/,/g , "");
       listResult[i].amount = value;
      }
    }
    listValue = listResult;

    return listValue;
  }

  function replaceMoneyFormatListBenefit(tmpBenefitList){
      var benLIst = [];
      for(var d = 0; d < tmpBenefitList.length; d++){
          var tempBenf = tmpBenefitList[d];
          for(var g = 0; g < tempBenf.custList.length; g++){
            var custListTemp = tempBenf.custList[g];
            for(var f = 0; f < custListTemp.itemInput.length; f++){
                var ii = custListTemp.itemInput[f];
                ii.inputValue = replaceMoneyFormat(ii.inputValue);
            }
          }
          benLIst.push(tempBenf);
      }
      return benLIst;
  }
  
  function getProduct(channelId, productCatCd, productCd){
    var channel = $rootScope.CHANNEL[channelId];
    for(var i = 0; i < channel.PRODUCT_CATEGORY.length; i++){
      var prodCat = channel.PRODUCT_CATEGORY[i];
      if(prodCat.code === productCatCd){
        for(var j = 0; j < prodCat.PRODUCT.length; j++){
          var prod = prodCat.PRODUCT[j];
          if(prod.code === productCd){
            return prod;
            break;
          }
        }
      }
    }
  }

  function getCoverageList(product, currCd){
    for(var i=0; i < product.CURRENCY.length; i++){
      var currency = product.CURRENCY[i];
      if(currency.code === currCd){
        return currency.COVERAGE;
      }
    }
  }

  function setHalamanRingkasanTahun(ANB) {
      $scope.manfaat.halamanRingkasanTahun1 = ANB + 10;
      $scope.manfaat.halamanRingkasanTahun2 = ANB + 15;
      $scope.manfaat.halamanRingkasanTahun3 = ANB + 20;
  }

  function getDataTertanggung(key, map, list){
    var tertanggungUtama;

    var tmpCustId = map[key];
    for(var j = 0; j < list.length; j++){
        if(list[j].customerId == tmpCustId){
            tertanggungUtama = list[j];
            break;
        }
    }
    return tertanggungUtama;
  }

  function cloneBenefit(benefitList){
      var tempList = [];
      for(var i = 0; i < benefitList.length; i++){
        tempList.push(benefitList[i]);
      }
      return tempList;
  }

  function sortingErrorMessageRule(rule){
    var ruleList = [];
     if(rule && rule.length > 0){
        for(var x=0; x< rule.length; x++){
          if(rule[x].errorType.toUpperCase().trim() === "BLOCKED"){
            var tmpRule = rule[x];
            var ruleMap = {};
            ruleMap.flag = tmpRule.comparisson;
            ruleMap.type = tmpRule.errorType;
            ruleMap.errorMsg = tmpRule.errorMessageInd;
            if(tmpRule.value || tmpRule.value == 0){
              ruleMap.value = tmpRule.value;
            }
            
            ruleList.push(ruleMap);       
          }
        }
        for(var x=0; x< rule.length; x++){
          if(rule[x].errorType.toUpperCase().trim() === "WARNING"){
            var tmpRule = rule[x];
            var ruleMap = {};
            ruleMap.flag = tmpRule.comparisson;
            ruleMap.type = tmpRule.errorType;
            ruleMap.errorMsg = tmpRule.errorMessageInd;
            if(tmpRule.value || tmpRule.value == 0){
              ruleMap.value = tmpRule.value;
            }
            ruleList.push(ruleMap);       
          }
        }

     }
     return ruleList;
  }


  function clearItem(item){
    var itemInput;
    var custListTemp = [];
    var itemTmp;
    console.log('isi dari iTEM adalah ====== ',item);
    for(var i = 0; i < item.custList.length; i++){
        item.custList[i].annualPremi = 0;
        custListTemp = item.custList[i];
        for (var j = 0; j < custListTemp.itemInput.length; j++){
           
           custListTemp.itemInput[j];
           custListTemp.itemInput[j].annualPremi = 0;
           custListTemp.itemInput[j].inputValue = 0;
           custListTemp.itemInput[j].term = 0;
        }
    }

    return item;

  }

  function getCustIncome(map){
    var custIncome;
    var pembayarPremi;
    console.log('isi dari collection Map ==== ', map);
    for(var ii = 0; ii < map.customerList.length; ii++){

      if(map.customerList[ii].PembayaranPremi != undefined || map.customerList[ii].PembayaranPremi != null){
        pembayarPremi = map.customerList[ii].PembayaranPremi;
        console.log('pembayarPremi adalah ==== ', pembayarPremi);
        break;
      }
    }

    for(var ic = 0; ic < map.customerList.length; ic++){

      if(pembayarPremi == map.customerList[ic].key){

        if(map.customerList[ic].IncomePremi != undefined || map.customerList[ic].IncomePremi != null){
          custIncome = map.customerList[ic].IncomePremi;
          break;
        }

        if(map.customerList[ic].Income != undefined || map.customerList[ic].Income != null){
          custIncome = map.customerList[ic].Income;
          break;
        }
         
      }

      if(map.customerList[ii].PembayaranPremi == 1){
        custIncome = map.customerList[ic].Income;
        break;
      }

    }
      
    map.custIncome = custIncome;
    return map;
  }

  window.addEventListener('native.keyboardshow', keyboardShowHandler)
                    
  function keyboardShowHandler(e){
    $scope.calcHide = true;
  }
  
  window.addEventListener('native.keyboardhide', keyboardHideHandler)
                    
  function keyboardHideHandler(e){
    $scope.calcHide = false;
  }
  
  function getTermAndAnb(map){
    var tempTerm;
    var valTerm;
    var tempItemInput;
    var tempCustList;
    var tempListManfaat;
    var mapResultFormula;
    var isValid = false;
    for(var m = 0; m<map.manfaatList.length; m++){
      tempListManfaat = map.manfaatList[m];
      for(var n = 0; n<tempListManfaat.custList.length; n++){
        tempCustList = tempListManfaat.custList[n];
        console.log('isi dari tempCustList ==== ',tempCustList);
        for(var o = 0; o<tempCustList.itemInput.length; o++){
          console.log('isi dari tempCustList.itemInput ==== ',tempCustList);
          if(tempCustList.itemInput[o].key == 'PDTERM'){
            tempTerm = tempCustList.itemInput[o].inputValue;
            if(tempTerm){
              valTerm = parseFloat(tempTerm) - parseFloat(anbTmp);
              if(valTerm < 10){
                $rootScope.AlertDialog('Masa pertanggungan tidak boleh kurang dari usia tertanggung');
                break;
              }else{
                isValid = true;
              }
              break;
            }
            break;
          }
        }
      }
    }
    return isValid;
  }

  Number.prototype.format = function(n, x) {
    var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\.' : '$') + ')';
    return this.toFixed(Math.max(0, ~~n)).replace(new RegExp(re, 'g'), '$&,');
  };

});