﻿
var pruforce = angular.module('PruForce');

pruforce.controller('sendEmailSqsCtrl', function($q, $rootScope, $scope, newSqsService, $state, $mdDialog, QuotationStorageService, CustomerStorageService, $ionicScrollDelegate, $ionicPopup, $ionicLoading, PublishGlobalService, OutputService, $timeout) {
    
    // console.log('$rootScope.QuotationId == ',$rootScope.QuotationId);
    var transactionId = '12345678AG';
    var transactionTime = '2016-10-24 14:32:00.000';
    var signatureString = 'e78eb47305f70b34fe714c3f0b7a9d8402bbd018';
    var channelId = 'password-protector';
    var processCode = 'emailAttachmentNew';
    var pwdUser = 'Password09';
    var pwdOwner= 'Password09';
    var fileUrl = $('#fileUpload').val();
    var extn = angular.lowercase(fileUrl.split(".").pop());
    var fileName = fileUrl.split("\\").pop();
    var convertToBase64 = convertToBase64; 
    var base64att = $rootScope.base64Att;
    var channelCode = $rootScope.agent.channelType;
    var agentId = $rootScope.agent.code;
    var agentName = $rootScope.userLoginName;
    var agentOffice = $rootScope.agent.agentOfficeCode;
    var ProductCode;
    var productName;
    var tertanggungName;
    var tertanggungTambahan1;
    var tertanggungTambahan2;
    var tertanggungDob;
    var pemegangPolis;
    var pemegangPolisDob;
    var gender;
    var uangPertanggungan;

    var quotationId = $rootScope.QuotationId;
    var QUOTATION_STORAGE = {};
    var CUSTOMER = {};
    var CUSTOMER_PEMEGANGPOLIS = {};
    var CUSTOMER_TAMBAHAN1 = {};
    var CUSTOMER_TAMBAHAN2 = {};
    var manfaatList
    var data = {};
    var ilustrasi = {};

  QuotationStorageService.getQuotationStorageByKey($q, quotationId).then(function(resQuot){
      QUOTATION_STORAGE = resQuot;

      // console.log('QUOTATION_STORAGE == ',QUOTATION_STORAGE);
      
      // if(QUOTATION_STORAGE.Level){
      //     QUOTATION_STORAGE.Level = 6;
      //     QuotationStorageService.addQuotationStorage($q, quotationId, QUOTATION_STORAGE);
      // }

      var prodCatCd = QUOTATION_STORAGE.Product.ProductCategory;
      var prodCd = QUOTATION_STORAGE.Product.ProductCode;
      var currCd = QUOTATION_STORAGE.Product.ProductCurrency;
      var product = getProduct(channelCode, prodCatCd, prodCd);

      productName = product.shortName;
      manfaatList = sortingRiderTopupMain(QUOTATION_STORAGE.Manfaat.manfaatList);

      for(var x = 0; x < manfaatList.length; x++){
          var coverageType = manfaatList[x].coverageType;
          if(coverageType == 'main'){
            uangPertanggungan = manfaatList[x].itemInput[0].inputValue;
          }
      }

      var custId = QUOTATION_STORAGE.CustomerList['02'];
      CustomerStorageService.getCustomerStorageByKey($q, custId).then(function(resCust){
        CUSTOMER = resCust;

        tertanggungName = CUSTOMER.name;
        tertanggungDob = CUSTOMER.Dob;
        
        // var datetime = CUSTOMER.Dob.split('-');
        // $scope.ilustrasi.dob = getFormatDate(datetime[2].substr(0,2), datetime[1], datetime[0]);

        gender = getGender(CUSTOMER.jenisKelaminPerokok);

        console.log('ISI CUSTOMER == ',CUSTOMER);
      });

            //----- jika Pemegang Polis
      var custIdPemegangPolis = QUOTATION_STORAGE.CustomerList['01'];
      CustomerStorageService.getCustomerStorageByKey($q, custIdPemegangPolis).then(function(resCust){
        CUSTOMER_PEMEGANGPOLIS = resCust;
        pemegangPolis = CUSTOMER_PEMEGANGPOLIS.name;
        pemegangPolisDob = CUSTOMER_PEMEGANGPOLIS.Dob;
        
        console.log('custPP --- ',CUSTOMER_PEMEGANGPOLIS);
         
      });

      var custIdTambahan1 = QUOTATION_STORAGE.CustomerList['03'];
      CustomerStorageService.getCustomerStorageByKey($q, custIdTambahan1).then(function(resCustTT1){
        CUSTOMER_TAMBAHAN1 = resCustTT1;
        tertanggungTambahan1 = CUSTOMER_TAMBAHAN1.name;
         
      });

      var custIdTambahan2 = QUOTATION_STORAGE.CustomerList['04'];
      CustomerStorageService.getCustomerStorageByKey($q, custIdTambahan2).then(function(resCustTT2){
        CUSTOMER_TAMBAHAN2 = resCustTT2;
        tertanggungTambahan2 = CUSTOMER_TAMBAHAN2.name;
         
      });

      ilustrasi = QUOTATION_STORAGE.dataEmail;
      console.log('data email ... ', ilustrasi);

      if(base64att == undefined){
          console.log('base64att undefined...');

          if(ilustrasi != undefined){
            OutputService.createPdf(ilustrasi)
            .then(function (pdf) {
                var blob = new Blob([pdf], { type: 'application/pdf' });
                $scope.pdfUrl = URL.createObjectURL(blob);

                base64att = $rootScope.base64Att;

                if(base64att != undefined){
                    console.log('base64att tidak undefined...');  
                }
                

                // Display the modal view
                // $scope.modal.show();
            });
          }  
      }

      

      $ionicLoading.hide();
  });

  function getProduct(channelId, productCatCd, productCd){
    var channel = $rootScope.CHANNEL[channelId];
    for(var i = 0; i < channel.PRODUCT_CATEGORY.length; i++){
      var prodCat = channel.PRODUCT_CATEGORY[i];
      if(prodCat.code === productCatCd){
        for(var j = 0; j < prodCat.PRODUCT.length; j++){
          var prod = prodCat.PRODUCT[j];
          if(prod.code === productCd){
            return prod;
            break;
          }
        }
      }
    }
  }

  function getGender(keyword){
    var keywordList = keyword.split("|");
    var stringKeyword = "";
    for(var i = 0; i < keywordList.length; i++){
      if(i == 0){
        if(keywordList[i] == "M"){
          stringKeyword += "Bapak";
        }else{
          stringKeyword += "Ibu";
        }
      }
    }
    return stringKeyword;
  }

  
  function validateEmail(email) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
  }

  Number.prototype.format = function(n, x) {
    var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\.' : '$') + ')';
    return this.toFixed(Math.max(0, ~~n)).replace(new RegExp(re, 'g'), '$&,');
  };

  var getMonthName={
    '01':'Jan',
    '02':'Feb',
    '03':'Mar',
    '04':'Apr',
    '05':'Mei',
    '06':'Jun',
    '07':'Jul',
    '08':'Agu',
    '09':'Sep',
    '10':'Okt',
    '11':'Nov',
    '12':'Des',
  };
  
  function sortingRiderTopupMain(tempManfaatList){
    var manfaatList = [];
    for(var i = 0; i < tempManfaatList.length; i++){
      var tmpManfaat = tempManfaatList[i];
      for(var j = 0; j < tmpManfaat.custList.length; j++){
        var tmpCustList = tmpManfaat.custList[j];

        var manfaat = {};

        manfaat.code = tmpManfaat.code;
        manfaat.name = tmpManfaat.name;
        manfaat.disabled = tmpManfaat.disabled;
        manfaat.coverageType = tmpManfaat.coverageType;
        manfaat.type = tmpManfaat.type;
        manfaat.lifeAssureCd = tmpManfaat.lifeAssureCd;


        manfaat.tertanggungName = tmpCustList.name;
        manfaat.tertanggungAge = tmpCustList.anb;
        manfaat.tertanggungKey = tmpCustList.key;
        manfaat.tertanggungCustomerId = tmpCustList.customerId;
        manfaat.biayaBulanan = tmpCustList.biayaBulanan;
        manfaat.itemInput = tmpCustList.itemInput;

        manfaatList.push(manfaat);
      }         
    }
    return manfaatList;
  }

  $scope.sendMail = []

  $scope.send = function (ev){
              
              console.log('================ Data yang akan dikirim ======================== ');
              console.log('tertanggungName = ', tertanggungName);
              console.log('tertanggungNameDob = ',tertanggungDob);
              console.log('pemegangPolis = ',pemegangPolis);
              console.log('pemegangPolisDob = ',pemegangPolisDob);
              console.log('quotationId = ',quotationId);
              console.log('gender = ',gender);
              console.log('tertanggungTambahan1 = ',tertanggungTambahan1);
              console.log('tertanggungTambahan2 = ',tertanggungTambahan2);
              console.log('manfaatList = ',manfaatList);
              console.log('uangPertanggungan = ',uangPertanggungan);
              console.log('productName = ',productName);

              QuotationStorageService.getQuotationStorageByKey($q, quotationId).then(function(resQuot){
                QUOTATION_STORAGE = resQuot;
                    QUOTATION_STORAGE.Level = 6;
                    QuotationStorageService.addQuotationStorage($q, quotationId, QUOTATION_STORAGE);
              });
              // $rootScope.Level = 6;

              $scope.sendMail.subject = "Ilustrasi Manfaat Perlindungan Asuransi Jiwa";
              $scope.sendMail.transactionId = transactionId;
              $scope.sendMail.transactionTime = transactionTime;
              $scope.sendMail.signatureString = signatureString;
              $scope.sendMail.channelId = channelId;
              $scope.sendMail.processCode = processCode;
              $scope.sendMail.base64att = base64att;
              // $scope.sendMail.base64att = 'base64att';
              $scope.sendMail.fileName = "ilustrasi.pdf";
              $scope.sendMail.mimeType = "application/pdf";
              $scope.sendMail.name = pemegangPolis;
              $scope.sendMail.nomorIlustrasi = quotationId;
              $scope.sendMail.DobTertanggung = new Date(tertanggungDob);
              $scope.sendMail.DobPP = new Date(pemegangPolisDob);

              var ddPP = $scope.sendMail.DobPP.getDate().toString().length==1?'0'+$scope.sendMail.DobPP.getDate().toString():$scope.sendMail.DobPP.getDate().toString();
              var mmPP = ($scope.sendMail.DobPP.getMonth()+1).toString().length==1?'0'+($scope.sendMail.DobPP.getMonth()+1).toString():($scope.sendMail.DobPP.getMonth()+1).toString();
              var yyyyPP = $scope.sendMail.DobPP.getFullYear().toString().substr(2,2);

              var ddTertanggung = $scope.sendMail.DobTertanggung.getDate().toString().length==1?'0'+$scope.sendMail.DobTertanggung.getDate().toString():$scope.sendMail.DobTertanggung.getDate().toString();
              var mmTertanggung = ($scope.sendMail.DobTertanggung.getMonth()+1).toString().length==1?'0'+($scope.sendMail.DobTertanggung.getMonth()+1).toString():($scope.sendMail.DobTertanggung.getMonth()+1).toString();
              var yyyyTertanggung = $scope.sendMail.DobTertanggung.getFullYear().toString().substr(2,2);

              console.log('PP : '+ddPP+'-'+mmPP+'-'+yyyyPP);
              console.log('Tertanggung : '+ddTertanggung+'-'+mmTertanggung+'-'+yyyyTertanggung);

              var pwd = ddPP+getMonthName[mmPP]+yyyyPP+ddTertanggung+mmTertanggung;
              console.log('pwd == ',pwd);

              $scope.sendMail.pwdUser = pwd;
              $scope.sendMail.pwdOwner = pwd;

              $scope.sendMail.gender = gender;
              $scope.sendMail.tertanggungUtama = tertanggungName;
              $scope.sendMail.uangPertanggungan = parseFloat(uangPertanggungan.toString()).format();
              $scope.sendMail.productName = productName;

              if(agentId != undefined){
                  $scope.sendMail.agentId = agentId;  
              }else{
                  $scope.sendMail.agentId = '';
              }

              if(agentName != undefined){
                  $scope.sendMail.agentName = agentName;
              }else{
                  $scope.sendMail.agentName = '';
              }

              if(agentOffice != undefined){
                  $scope.sendMail.agentOffice = agentOffice;
              }else{
                  $scope.sendMail.agentOffice = '';
              }
              
              
              

              if(tertanggungTambahan1 != undefined){
                $scope.sendMail.tertanggungTambahan1 = tertanggungTambahan1;  
              }else{
                $scope.sendMail.tertanggungTambahan1 = '';
              }

              if(tertanggungTambahan2 != undefined){
                $scope.sendMail.tertanggungTambahan2 = tertanggungTambahan2;  
              }else{
                $scope.sendMail.tertanggungTambahan2 = '';
              }
              

              if($scope.sendMail.cc == undefined){
                $scope.sendMail.cc = '';
              }

              if($scope.sendMail.bcc == undefined){
                $scope.sendMail.bcc = '';
              }

              if($scope.sendMail.to != undefined && $scope.sendMail.to.trim() != ''){

                  if($scope.sendMail.to.indexOf(';') > -1){
                      var toEmailArray = $scope.sendMail.to.split(';');

                      for(var i = 0; i < toEmailArray.length; i++){
                          console.log(toEmailArray[i]);
                          if(!validateEmail(toEmailArray[i].trim())){
                              $rootScope.AlertDialog('Invalid email format To Address ');
                              return;
                          }     
                      }
                  }else{
                      if(!validateEmail($scope.sendMail.to.trim())){
                        $rootScope.AlertDialog('Invalid email format To Address ');
                        return;
                      }   
                  }

                                 
              }else{
                  $rootScope.AlertDialog('To Address is mandatory');
                      return;
              }

              // console.log('is valid email',validateEmail($scope.sendMail.to));


              console.log('sendMail data == ', $scope.sendMail);
              
            //var promise = newSqsService.send($scope.sendMail.to,$scope.sendMail.cc,$scope.sendMail.bcc,$scope.sendMail.subject,$scope.sendMail.transactionId,$scope.sendMail.transactionTime,$scope.sendMail.signatureString,$scope.sendMail.channelId,$scope.sendMail.processCode,$scope.sendMail.pwdUser,$scope.sendMail.pwdOwner,$scope.sendMail.base64att,$scope.sendMail.fileName,$scope.sendMail.mimeType,$scope.sendMail.name,$scope.sendMail.nomorIlustrasi,$scope.sendMail.Dob,$scope.sendMail.gender,$scope.sendMail.tertanggungUtama);
            var promise = newSqsService.send($scope.sendMail);

            if(promise){
              showAlert();
            }
            
            
            
        // $mdDialog.show(
        // $mdDialog.alert()
        // .parent(angular.element(document.querySelector('#popupContainer')))
        // .clickOutsideToClose(true)
        // .title('Success')
        // .textContent('Your Mail Succesfully Sent')
        // .ok('OK')
        // .targetEvent(ev)
        // );

          function showAlert(){
              $timeout(function(){
              var alertPopup = $ionicPopup.alert({
                title: "Email berhasil terkirim",
                template: "Email berhasil terkirim",
                cssClass: 'pru-white-alert without-header popup-large pru-logo-text button-side-duo',
                scope: $scope,
                buttons: [
                {
                  text: 'OK',
                  type: 'button-assertive',
                  onTap: function(e) {
                    alertPopup.close();
                    // confirmPopup.close();
                    console.log('lewat href');
                    $state.go("daftar-newsqs");
                    
                    // AutoRefresh();
                  }
                }
                ]
              }, 5);
            });
          }
        
  }


});
