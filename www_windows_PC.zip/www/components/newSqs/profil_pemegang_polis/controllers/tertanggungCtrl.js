﻿angular.module('PruForce.controllers')

  .controller('tertanggungCtrl', function ($q, $scope, $rootScope, $state, $ionicScrollDelegate, $ionicLoading, $ionicPopup, $localStorage, $filter, $document, $window, $timeout, PublishGlobalService, CustomerStorageService, QuotationStorageService, $timeout) {
    //user identity
    console.log('Quotation ID :' + $rootScope.QuotationId);
    console.log('Level        :' + $rootScope.Level);
    $rootScope.flagOpenTertanggung = true;
    
    $rootScope.agent.code;
    $scope.profileTertanggung={};
    $scope.tmp_input = {};
    
    var insuredDatas = {};
    var stringMessage;
    $scope.insertDatasList = [];
    
    var today = new Date();
    var age;
    

    $scope.valOccList = $rootScope.occupationList;

    $scope.settext_combo = function(val, type){
      if(!val){
        if(type == "pekerjaan")
          return "Pekerjaan";
        else if(type == "usaha")
          return "Bidang Usaha";
        else if(type == "jabatan")
          return "Jabatan/Pangkat/Golongan";
        else if(type == "pekerjaan2")
          return "Pekerjaan";
      }else{
        if(val.nameInd)
          return val.nameInd;
        else
          return val.descriptionInd;
      }
    }

    function resetLoadListData(state){
        $scope.loadList = $rootScope.loadList;

      
        var mapTertanggungLoad = {
            'Tertanggung Utama':'1', //tertanggung utama
            'Tertanggung Kedua':'2', //tertanggung tambahan 1
            'Tertanggung Ketiga':'3' //tertanggung tambahan 2
        };

        var loadListTemporary = new Array([]);
        loadListTemporary = JSON.stringify($scope.loadList);

        var loadTempTertanggung = [];

        for(var i = 0; i < JSON.parse(loadListTemporary).length; i++){
            var loadObject = JSON.parse(loadListTemporary)[i];
            var loadObjectValue = loadObject.value;
            var key = parseInt($scope.profileTertanggung.key) - 1;
            var valueTemp = [];
            //console.log("loadObjectValue ", loadObjectValue);
            for(var j = 0; j <loadObjectValue.length; j++){
                //console.log(loadObjectValue[j].level +"=="+ key);
                if(loadObjectValue[j].level == key){
                    var loadTmp = {
                      code: loadObjectValue[j].code,
                      level: loadObjectValue[j].level,
                      value: loadObjectValue[j].value
                    };
                    //console.log("valueTemp ", valueTemp);
                    valueTemp.push(loadTmp);
                }
              
            }

            if($scope.profileTertanggung.loadList){
                for(var k = 0; k < $scope.profileTertanggung.loadList.length; k++){
                    var tempLoad = $scope.profileTertanggung.loadList[k];
                    if(loadObject.code == tempLoad.code){
                      loadObject.selectedLoad = tempLoad.selectedCode;
                    }
                }
            }

            loadObject.value = valueTemp;
            loadTempTertanggung.push(loadObject);

        }

        
        $scope.loadList = loadTempTertanggung;
        console.log("$scope.loadList before ", $scope.loadList);
        var L1 = [];
        var L2 = [];
        var C1 = [];
        var C2 = [];
        var B1 = [];
        var B2 = [];
        var E1 = [];
        var E2 = [];
        var A1 = [];
        var A2 = [];
        var T1 = [];
        var T2 = [];
        var H1 = [];
        var P1 = [];

        var I1 = [];
        var I2 = [];
        var D1 = [];

        if(state != "kedua"){
            for(var i=0;i<$scope.loadList.length;i++){
                if($scope.loadList[i].code == "L1")
                    L1.push($scope.loadList[i]);
                else if($scope.loadList[i].code == "L2")
                    L2.push($scope.loadList[i]);
                else if($scope.loadList[i].code == "C1")
                    C1.push($scope.loadList[i]);
                else if($scope.loadList[i].code == "C2")
                    C2.push($scope.loadList[i]);
                else if($scope.loadList[i].code == "B1")
                    B1.push($scope.loadList[i]);
                else if($scope.loadList[i].code == "B2")
                    B2.push($scope.loadList[i]);
                else if($scope.loadList[i].code == "E1")
                    E1.push($scope.loadList[i]);
                else if($scope.loadList[i].code == "E2")
                    E2.push($scope.loadList[i]);
                else if($scope.loadList[i].code == "A1")
                    A1.push($scope.loadList[i]);
                else if($scope.loadList[i].code == "A2")
                    A2.push($scope.loadList[i]);
                else if($scope.loadList[i].code == "T1")
                    T1.push($scope.loadList[i]);
                else if($scope.loadList[i].code == "T2")
                    T2.push($scope.loadList[i]);
                else if($scope.loadList[i].code == "H1")
                    H1.push($scope.loadList[i]);
                else if($scope.loadList[i].code == "P1")
                    P1.push($scope.loadList[i]);
            }
            $scope.loadList = L1.concat(L2).concat(C1).concat(C2).concat(B1).concat(B2).concat(E1).concat(E2).concat(A1).concat(A2).concat(T1).concat(T2).concat(H1).concat(P1);
        }else{
            for(var i=0;i<$scope.loadList.length;i++){
                if($scope.loadList[i].code == "L1")
                    L1.push($scope.loadList[i]);
                else if($scope.loadList[i].code == "L2")
                    L2.push($scope.loadList[i]);
                else if($scope.loadList[i].code == "C1")
                    C1.push($scope.loadList[i]);
                else if($scope.loadList[i].code == "T1")
                    T1.push($scope.loadList[i]);
                else if($scope.loadList[i].code == "I1")
                    I1.push($scope.loadList[i]);
                else if($scope.loadList[i].code == "T2")
                    T2.push($scope.loadList[i]);
                else if($scope.loadList[i].code == "I2")
                    I2.push($scope.loadList[i]);
                else if($scope.loadList[i].code == "D1")
                    D1.push($scope.loadList[i]);
                else if($scope.loadList[i].code == "E1")
                    E1.push($scope.loadList[i]);
                else if($scope.loadList[i].code == "E2")
                    E2.push($scope.loadList[i]);
            }
            $scope.loadList = L1.concat(L2).concat(C1).concat(T1).concat(I1).concat(T2).concat(I2).concat(D1).concat(E1).concat(E2);
        }
        
        //console.log("$scope.loadList ", $scope.loadList);
    }

    function getDataTertanggung(key, map, list){
      var tertanggung;

      var tmpCustId = map[key];
      for(var j = 0; j < list.length; j++){
          if(list[j].customerId == tmpCustId){
              tertanggung = list[j];
              console.log('tertanggung ',tertanggung);
              break;
          }
      }
      return tertanggung;
    }

    function orderByKey(mapCustID, customerList){
      console.log('--------orderByKey--------');
      var tempList = [];

        for(var i=1; i<=6; i++){
          console.log('mapCustID    ',mapCustID);
          console.log('customerList ',customerList);
            var tempCustIdOrder = mapCustID['0'+i];
            if(tempCustIdOrder != null){
                for(var j=0; j < customerList.length; j++){
                    var tempCustList = {};

                          console.log('1' ,customerList[j]);
                    if(tempCustIdOrder == customerList[j].customerId){
                        for(var key in customerList[j]){
                          console.log('key ',key);
                            tempCustList[key] = customerList[j][key];
                            console.log('2' ,customerList[j]);
                                if(tempCustList.Dob){
                                    tempCustList.Dob = new Date(customerList[j].Dob);                     
                                    tempCustList.anb = tempCustList.anb ? tempCustList.anb : (parseInt(tempCustList.age)+1);
                                }
                                tempCustList.tanggalBerlakuSurut = tempCustList.tanggalBerlakuSurut ? new Date(customerList[j].tanggalBerlakuSurut) : '';
                        }
                            
                        for(var k=0; k < $rootScope.registerPolicyHolders.length; k++){
                            var tempAlias = $rootScope.registerPolicyHolders[k];
                            if(tempAlias.key == i){
                                tempCustList.alias = tempAlias.value;
                                tempCustList.key = i;
                                if(i == 1){
                                    tempCustList.flagAccordion = false;
                                } else {
                                    tempCustList.flagAccordion = true;
                                }
                                break;
                            }
                        }

                        if(mapCustID['01'] == customerList[j].customerId){

                          console.log(customerList[j].pemegang +" || "+  tempCustList.key);
                            if(customerList[j].pemegang == tempCustList.key){
                                tempCustList.flagField = true;
                            } else {
                                tempCustList.flagField = false;
                            }                            
                        } else {
                            tempCustList.flagField = false;
                        }

                        tempList.push(tempCustList);
                        break;
                    

                    } 
                }  
            }
        }
        resetLoadListData("");
        console.log('Isinya nih : ', tempList);
        return tempList;
    }

    var QStorage;


    var counter = 0;
    function getCustomerListFromJStore(){
      console.log('ini counter'+counter);
      if(counter <= 0){
          console.log('end');
          order();
      }else{
            if(QStorage['0'+counter] != null){
                var query = {agentId: $rootScope.agent.code, customerId : QStorage['0'+counter]};
                var options = {exact: false
                           //limit: 100 //returns a maximum of 10 documents
                      };

                WL.JSONStore.get('CustomerStorage').find(query, options).then(function(res){
                  console.log('RES : ', res);
                  try{
                    if(res.length > 0){
                      var result =  res[0].json.invocationResult;
                      $scope.insertDatasList.push(result);
                      counter--;
                      getCustomerListFromJStore();
                    }   
                  } catch(error){
                    console.log('aaaaaa',error)
                  }           
                }).fail(function(error){
                  console.log('bbbbbbb',error)
                });          
            }else{
                counter--;         
                getCustomerListFromJStore();
            }
      }
    }

    function order(){

               // var res =$scope.insertDatasList;

                console.log('$scope.insertDatasList ',$scope.insertDatasList);
                $scope.insertDatasList = $scope.insertDatasList ? orderByKey(QStorage, $scope.insertDatasList) : [];
                var policyHolder = getDataTertanggung('01', QStorage, $scope.insertDatasList) ? getDataTertanggung('01', QStorage, $scope.insertDatasList) : {};
                console.log('policyHolder ',policyHolder);
                if(policyHolder.pemegang > 1){
                    console.log('ah');
                    // var key = ['0'+policyHolder.pemegang];
                    // lifeAssured = getDataTertanggung(key, QStorage, $scope.insertDatasList) ? getDataTertanggung(key, QStorage, $scope.insertDatasList) : {};
                    // var LA = parseInt(policyHolder.pemegang)-1;
                    $timeout(function(){
                        $scope.profileTertanggung = $scope.insertDatasList[1];
                        //console.log("$scope.profileTertanggung.Position ", $scope.profileTertanggung);
                        var resprof = $rootScope.positionList.filter(function(obj){
                          return obj.code == $scope.profileTertanggung.Position;
                        })
                        if(resprof.length > 0){
                            $scope.tmp_input.inp_pos = resprof[0];
                        }
                        resprof = $rootScope.businessList.filter(function(obj){
                          return obj.code == $scope.profileTertanggung.Business;
                        })
                        if(resprof.length > 0){
                            $scope.tmp_input.inp_bss = resprof[0];
                        }
                        if(policyHolder.key == 1)
                          resetLoadListData("");
                        else
                          resetLoadListData("kedua");
                    });
                    
                }else{
                    console.log('aha');
                    if(!$scope.insertDatasList[1]){
                      console.log('oho');
                        var newCustId = genCustId();
                        $scope.profileTertanggung = {
                                customerId :  newCustId,
                                alias : 'Tertanggung Utama',
                                key   : 2,
                                flagAccordion : true,
                                flagField : false
                        };
                        QStorage['02'] = newCustId;
                        $scope.insertDatasList.push($scope.profileTertanggung);
                        $timeout(function(){
                        $scope.profileTertanggung = $scope.insertDatasList[1];
                          var resprof = $rootScope.positionList.filter(function(obj){
                            return obj.code == $scope.profileTertanggung.Position;
                          })
                          if(resprof.length > 0){
                              $scope.tmp_input.inp_pos = resprof[0];
                          }
                          resprof = $rootScope.businessList.filter(function(obj){
                            return obj.code == $scope.profileTertanggung.Business;
                          })
                          if(resprof.length > 0){
                              $scope.tmp_input.inp_bss = resprof[0];
                          }
                        resetLoadListData("");
                        })
                    } else {
                        $timeout(function(){
                        $scope.profileTertanggung = $scope.insertDatasList[1];
                          var resprof = $rootScope.positionList.filter(function(obj){
                            return obj.code == $scope.profileTertanggung.Position;
                          })
                          if(resprof.length > 0){
                              $scope.tmp_input.inp_pos = resprof[0];
                          }
                          resprof = $rootScope.businessList.filter(function(obj){
                            return obj.code == $scope.profileTertanggung.Business;
                          })
                          if(resprof.length > 0){
                              $scope.tmp_input.inp_bss = resprof[0];
                          }
                        resetLoadListData("");
                        })
                    }
                    
                }

                if($scope.valOccList == undefined || $scope.valOccList.length == 0){
                    $scope.valOccList = $rootScope.occupationList;
                }
            
    }

    if ($rootScope.QuotationId) {
        var lifeAssured = {};

        QuotationStorageService.getQuotationStorageByKey($q, $rootScope.QuotationId).then(function(result){
        QuotationStorage = result ? result : {};
        QStorage = result ? result.CustomerList : {};
        console.log('QuotationStorage ',QuotationStorage);
        console.log('QStorage ',QStorage);

        counter = Object.size(QStorage);
        getCustomerListFromJStore();
        console.log('bbbbbbb' + $scope.insertDatasList.length);

        $ionicLoading.hide();

        });

    } else {
        console.log('!Quotation');
        var QuotationStorage = {};
        var tempCustList = {};
        var newCustId = genCustId();
        var reDate = moment(today).format('YYYYMMDDHHMMSS');
        var genQuotId = $rootScope.agent.code + reDate;
        $scope.insertDatasList = [];
        var tempInsertDatasList = [];

        tempCustList['01'] = newCustId;
        tempCustList['02'] = newCustId+'_02';
        tempCustList['03'] = null;
        tempCustList['04'] = null;
        tempCustList['05'] = null;
        tempCustList['06'] = null;
                
        QuotationStorage.CustomerList = tempCustList; 
        QuotationStorage.QuotationDate = today;
        QuotationStorage.QuotationId = $rootScope.agent.code + reDate;

        $scope.profileTertanggung.customerId = tempCustList['01'];
        tempInsertDatasList.push(
            {
              alias : $scope.profileTertanggung.alias,
              customerId : $scope.profileTertanggung.customerId
            },
            {
              alias : 'Tertanggung Utama',
              customerId : tempCustList['02']
            }
        );

        $scope.insertDatasList = tempInsertDatasList ? orderByKey(QuotationStorage.CustomerList, tempInsertDatasList) : [];

        $scope.profileTertanggung = $scope.insertDatasList[1] ? $scope.insertDatasList[1] : {};
        CustomerStorageService.addCustomerStorage($q, $scope.profileTertanggung.customerId, $scope.profileTertanggung);
        resetLoadListData("");
    }

    $scope.profileTertanggung.checkbox = false; 

    function genCustId(){
        return 'PLCHLDR' + new Date().getTime();
    }
    
  $scope.addInsuredData = function(){
      var sorted = {};
      Object.keys(QStorage).sort().forEach(function(key){
                                                      sorted[key] = QStorage[key];
                                                      });
      console.log("QStorage sorted ", sorted);
      QStorage = angular.copy(sorted);
      if($scope.insertDatasList.length >= 6){ 
          $scope.insuredMaxPopUp(); 
      } else { 
          for(var key in QStorage){
              if(QStorage[key] == null){
              var newLifeAssured = {};
                  var newCustId = genCustId();

                  QStorage[key] = newCustId+'_'+[key];
                  newLifeAssured.customerId = QStorage[key];
                  
                  QuotationStorage.CustomerList = QStorage;
                  QuotationStorage.Level = 2;
                  newLifeAssured.flagField = false;
                  $scope.insertDatasList.push(newLifeAssured);
                  console.log('$scope.insertDatasList >>>>>>>>>>>>>>>>>>>>>>>>',$scope.insertDatasList);
                  break;
              }
          }
          $scope.insertDatasList = orderByKey(QStorage, $scope.insertDatasList);
          $scope.profileTertanggung = $scope.insertDatasList[$scope.insertDatasList.length-1];
          $scope.tmp_input = {};
      }

      console.log('add $scope.insertDatasList ',$scope.insertDatasList);
      resetLoadListData("kedua"); 
  }

    /*-------- Validate for PremiBackdate ----------*/
    $scope.myDate = new Date();
    $scope.minDate = new Date(
       $scope.myDate.getFullYear(),
       $scope.myDate.getMonth(),
       $scope.myDate.getDate() - 180);
    $scope.maxDate = new Date(
       $scope.myDate.getFullYear(),
       $scope.myDate.getMonth(),
       $scope.myDate.getDate());

    // ------ test Buat PH!=LA -------
    $scope.minDatePH = new Date(
       $scope.myDate.getFullYear() - 100,
       $scope.myDate.getMonth(),
       $scope.myDate.getDate());
    $scope.maxDatePH = new Date(
       $scope.myDate.getFullYear()+100,
       $scope.myDate.getMonth(),
       $scope.myDate.getDate());

    Date.prototype.ddmmyyyy = function() {
    var mm = this.getMonth() + 1; // getMonth() is zero-based
    var dd = this.getDate();

    return [(dd>9 ? '' : '0') + dd,
            (mm>9 ? '' : '0') + mm,
            this.getFullYear()
            
           ].join(' ');
    };

    

  $scope.tmp_required = {};
  $scope.bool_tidakbekerja = false;
  $scope.keyPress = function(title, value){

      if (title === 'name') {
      $scope.profileTertanggung.name = value.name;
      }
      
      if (title === 'dob') {
        if($scope.profileTertanggung.anb === NaN){
          $scope.profileTertanggung.anb = '';
        } else {
          var today = new Date();
          var birthDate = new Date(value.Dob);
          age = today.getFullYear() - birthDate.getFullYear();
          var day = today.getMonth() - birthDate.getMonth();
          var m = today.getMonth() - birthDate.getMonth();
          if (m < 0 || (m === 0 && today.getDate() <= birthDate.getDate())) {
            age--;
          }
          var intervalDate = today - birthDate;
          var intervalDay = Math.round((intervalDate / 24 / 60 / 60 / 1000) - 1);
          $scope.profileTertanggung.Dob = value.Dob;
          $scope.profileTertanggung.age = age; 
          $scope.profileTertanggung.custAge = age;
          if (today.ddmmyyyy() === new Date($scope.profileTertanggung.Dob).ddmmyyyy()) {
              $scope.profileTertanggung.anb = 0;
          }else{
              $scope.profileTertanggung.anb = age+1;
          }
          $scope.profileTertanggung.custAgeDay = intervalDay;//Math.abs(today - birthDate);
          $scope.profileTertanggung.custAgeMonth = (((today.getFullYear() - birthDate.getFullYear())*12) + parseInt(m));
        }
          // ------ jika tertanggung <= 15
          $scope.valOccList = [];
          if($scope.profileTertanggung.age <= 15){
              for(var voc = 0; voc < $rootScope.occupationList.length; voc++){
                    if($rootScope.occupationList[voc].code =='NSTN' || $rootScope.occupationList[voc].code =='STDN'){
                        var bantu = $rootScope.occupationList[voc]; 
                        $scope.valOccList.push(bantu);
                        $scope.profileTertanggung.pekerjaanCode = value.pekerjaanCode;
                        $scope.profileTertanggung.Occupation = getOccupation(value.pekerjaanCode);
                    }
              }
           }else{
              $scope.valOccList = $rootScope.occupationList;
          }
       }

      if($scope.profileTertanggung.anb === NaN){
          $scope.profileTertanggung.anb = '';
      } else {
          $scope.profileTertanggung.custAge = value.age;
      }

      if (title === 'tpl') {
      $scope.profileTertanggung.tanggalPerkiraanLahir = value.tanggalPerkiraanLahir;
      }

      if (title === 'jkp') {
      $scope.profileTertanggung.jenisKelaminPerokok = value.jenisKelaminPerokok;
          console.log('aza ',$scope.insertDatasList);
          // for(var i=0; i < $scope.insertDatasList.length; i++){
              if($scope.insertDatasList[0].customerId == $scope.profileTertanggung.customerId){
                  $scope.insertDatasList[0].jenisKelaminPerokok = value.jenisKelaminPerokok;
                // break;
              }
          // }
      }

      $scope.profileTertanggung.usiaKehamilan = value.usiaKehamilan;
      
      
      //Occupation
      if (title === 'occupation'){
          $scope.profileTertanggung.pekerjaanCode = value.Occupation.code;
          //$scope.profileTertanggung.Occupation = getOccupation(value.pekerjaanCode);
          $scope.profileTertanggung.Occupation = value.Occupation;
          $scope.tmp_required.bss = 'required';
          $scope.tmp_required.dep = 'required';
          $scope.tmp_required.pos = 'required';
          if(value.Occupation != undefined){
              if(value.Occupation.code == 'HSWF' || value.Occupation.code == 'UNEM' || value.Occupation.code == 'RETI' || value.Occupation.code == 'NSTN'){
                  for(var od=0; od< $rootScope.businessList.length; od++){
                      if($rootScope.businessList[od].code == 'X'){
                          $scope.profileTertanggung.Business = $rootScope.businessList[od].code;
                          $scope.tmp_input.inp_bss = $rootScope.businessList[od];
                          break;
                      }
                  }
                  for(var jab=0; jab < $rootScope.positionList.length; jab++){
                      if($rootScope.positionList[jab].code == 'UNP'){
                        $scope.profileTertanggung.Position = $rootScope.positionList[jab].code;
                        $scope.tmp_input.inp_pos = $rootScope.positionList[jab];
                        break;
                      }
                  }
                  for(var ic =0; ic < $rootScope.totalIncomes.length; ic++){
                      if($rootScope.totalIncomes[ic].code == 'O'){
                        $scope.profileTertanggung.Income = $rootScope.totalIncomes[ic].code;
                      }
                  }
                  $scope.profileTertanggung.Department = 'Tidak Bekerja';
                  $scope.tmp_required.bss = '';
                  $scope.tmp_required.dep = '';
                  $scope.tmp_required.pos = '';
                  $scope.bool_tidakbekerja = true;
              }else if(value.Occupation.code == 'STDN'){
                  for(var od=0; od< $rootScope.businessList.length; od++){
                      if($rootScope.businessList[od].code == 'S'){
                          $scope.profileTertanggung.Business = $rootScope.businessList[od].code;
                          $scope.tmp_input.inp_bss = $rootScope.businessList[od];
                          break;
                      }
                  }
                  for(var jab=0; jab < $rootScope.positionList.length; jab++){
                      if($rootScope.positionList[jab].code == 'UNP'){
                        $scope.profileTertanggung.Position = $rootScope.positionList[jab].code;
                        $scope.tmp_input.inp_pos = $rootScope.positionList[jab];
                        break;
                      }
                  }
                  for(var ic =0; ic < $rootScope.totalIncomes.length; ic++){
                      if($rootScope.totalIncomes[ic].code == 'O'){
                        $scope.profileTertanggung.Income = $rootScope.totalIncomes[ic].code;
                      }
                  }
                  $scope.profileTertanggung.Department = 'Tidak Bekerja';
                  $scope.tmp_required.bss = '';
                  $scope.tmp_required.dep = '';
                  $scope.tmp_required.pos = '';
                  $scope.bool_tidakbekerja = true;
              }else{
                $scope.tmp_required.bss = 'required';
                $scope.tmp_required.dep = 'required';
                $scope.tmp_required.pos = 'required';
                // $scope.tmp_input = {};
                //clear jika sebelumnya adalah "tidak bekerja"
                if($scope.bool_tidakbekerja){
                    $scope.tmp_input = {};
                    $scope.profileTertanggung.Department = '';
                    $scope.profileTertanggung.Business = [];
                    $scope.profileTertanggung.Position = [];
                    $scope.profileTertanggung.Income = [];
                }
                $scope.bool_tidakbekerja = false;
              }
              $scope.searchPekerjaan = '';
          }
      }

      //Business
      if (title === 'business'){
      $scope.profileTertanggung.Business = $scope.tmp_input.inp_bss.code;
      }

      if (title === 'department'){
      $scope.profileTertanggung.Department = value.Department;
      }

      //Position
      if (title === 'position'){
      $scope.profileTertanggung.Position = $scope.tmp_input.inp_pos.code;
      }

      //Income
      $scope.totalIncomesTemp = [ 
          {individualInd: "Tidak Berpenghasilan", individualEng:"No Income", value: "O"}
      ]

      if (title === 'income'){
      $scope.profileTertanggung.Income = value.Income;
      $scope.profileTertanggung.Incomes = value.Incomes; 
          // for(var i=0; i < $scope.insertDatasList.length; i++){
              if($scope.insertDatasList[0].customerId == $scope.profileTertanggung.customerId){
                  $scope.insertDatasList[0].Income = value.Income;
                // break;
              }
          // }
      }

      if (title === 'premibackdate') {
      $scope.profileTertanggung.tanggalBerlakuSurut = value.tanggalBerlakuSurut;
      $scope.minDatePremi;
      $scope.maxDatePremi;
      var today = value.tanggalBerlakuSurut;
      var birthDate = new Date(value.Dob);
      age = today.getFullYear() - birthDate.getFullYear();
      var day = today.getMonth() - birthDate.getMonth();
      var m = today.getMonth() - birthDate.getMonth();
      if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }
      $scope.profileTertanggung.Dob = value.Dob; 
      $scope.profileTertanggung.age = age;
      $scope.profileTertanggung.custAge = age;
      $scope.profileTertanggung.anb = age+1;
      $scope.profileTertanggung.custAgeDay = Math.abs(today - birthDate);
      $scope.profileTertanggung.custAgeMonth = (((today.getFullYear() - birthDate.getFullYear())*12) + parseInt(m));
      }

      if(title === 'checkbox'){
      $scope.profileTertanggung.checkbox = value.checkbox;
      }

      
      if (title === 'subStandart') {
      $scope.profileTertanggung.subStandard = value.subStandard;
      }


      if(title === 'subStandartList') {
        console.log(value);
        console.log($scope.loadList);
        var subStdList = [];
        for(var zz = 0; zz < $scope.loadList.length; zz++){
          var tmpload = $scope.loadList[zz];         
          if(tmpload.selectedLoad){
              for(var ls = 0; ls < tmpload.value.length; ls++){
                  if(tmpload.value[ls].code == tmpload.selectedLoad){
                      var tempSubstd = {
                          code : tmpload.code,
                          selectedCode : tmpload.value[ls].code,
                          selectedValue : tmpload.value[ls].value
                      }
                      subStdList.push(tempSubstd);              
                      break;
                  }
              }
          }
        }
        $scope.profileTertanggung.loadList = subStdList;
      }

      if(title === 'pengecualian') {
        console.log(value.Pengecualian);
        $scope.profileTertanggung.Pengecualian = value.Pengecualian;
      }

      if ($scope.profileTertanggung !== undefined) {
          if (!$rootScope.QuotationId) {
              console.log('has id ' + $rootScope.QuotationId);
              var today = new Date();
              var reDate = moment(today).format('YYYYMMDDHHMMSS');
              $scope.profileTertanggung.CreateDate = today.toString();
              var genCustId = 'CUST' + today.getMilliseconds();
              var genQuotId = $rootScope.agent.code + reDate;
              $rootScope.QuotationId = genQuotId;
              QuotationStorage.QuotationId = genQuotId;
          } else {
              console.log('has no id ' + $rootScope.QuotationId); 
          }         
      }

      console.log($scope.profileTertanggung);
      CustomerStorageService.addCustomerStorage($q, $scope.profileTertanggung.customerId, $scope.profileTertanggung);


      QuotationStorageService.addQuotationStorage($q, $rootScope.QuotationId, QuotationStorage);
      
  } 

  function getOccupation(code){
      for(var g = 0; g < $rootScope.occupationList.length; g++){
          if($rootScope.occupationList[g].code == code){
              return $rootScope.occupationList[g];
          }
      }
  }

  $scope.searchTerm;
  $scope.clearSearchTerm = function() {
     $scope.searchTerm = '';
  }

  $scope.clearPemegangPolis = function() {
      $scope.searchPemegangPolis = '';
      console.log($scope.searchPemegangPolis);
  };

  $scope.insuredName = {isExpanded:false}; 

  $scope.usiaKehamilanList = [];
  $scope.usiaKehamilan = [];
  for (var u=4; u < 33; u++) {
      $scope.usiaKehamilan.push(u);
  }

  $scope.arrayForDeleteInsured = []; 

  $scope.chooseInsuredList = function(id) {
    console.log(id);
  }
 
  var custIdObj;
  $scope.addInsuredList = function(insuredItem, id){
    console.log('Delete -- ID : ',id);
      if(insuredItem == true){ 
          //CHECKED FOR DELETE
          $scope.arrayForDeleteInsured.push(id);
          console.log($scope.arrayForDeleteInsured);
          
      }else{ 
          //UNCHECK FOR DELETE
          var index = $scope.arrayForDeleteInsured.indexOf(id); 
          if(index !== -1) { 
            $scope.arrayForDeleteInsured.splice(index, 1); 
          } 
      } 
  } 

  $scope.deleteInsured = function(){
      console.log($scope.arrayForDeleteInsured);
      var customerIdObj = {};
      for (var i=0; i < $scope.arrayForDeleteInsured.length; i++) {
          var custId = $scope.arrayForDeleteInsured[i].customerId;
          console.log($scope.arrayForDeleteInsured[i]);
          for(var j=0; j < $scope.insertDatasList.length; j++){
              console.log('$scope.insertDatasList ',$scope.insertDatasList);
              if($scope.insertDatasList[j].key > 2 && custId == $scope.insertDatasList[j].customerId){
                  
                  $scope.insertDatasList.splice(j, 1);
              }
              console.log('$scope.insertDatasList deleted ',$scope.insertDatasList);

              var keyTemp = j+1;
              if($scope.insertDatasList[j]){
                  $scope.insertDatasList[j].key = keyTemp;
                  /*if($scope.insertDatasList[j].key == 1){
                      $scope.insertDatasList[j].pemegang = 1;
                  }*/

                  var custTempKey = '0'+keyTemp;
                  customerIdObj[custTempKey] = $scope.insertDatasList[j].customerId;
                  
              }
              
          }
      }

      QStorage = {};
      for(var l=1; l<=6; l++){
          QStorage['0'+l] = null;
          for(var k in customerIdObj){
              QStorage[k] = customerIdObj[k];
          }
      }
      console.log('QStorage         ',QStorage);

      QuotationStorage.CustomerList = QStorage;
      QuotationStorageService.addQuotationStorage($q, $rootScope.QuotationId, QuotationStorage);
      $scope.insertDatasList = orderByKey(QStorage, $scope.insertDatasList); 
      $scope.arrayForDeleteInsured = [];
if($scope.insertDatasList.length > 2)
      resetLoadListData("kedua"); 
else
resetLoadListData(""); 
  } 

  $scope.jenisKelaminPerokokList = [ 
    {nameInd: "Pria/Bukan Perokok", nameEng:"Male/Not Smoker", value: "M|NS"},
    {nameInd: "Pria/Perokok", nameEng:"Male/Smoker", value: "M|S"},
    {nameInd: "Perempuan/Bukan Perokok", nameEng:"Female/Not Smoker", value: "F|NS"},
    {nameInd: "Perempuan/Perokok", nameEng:"Female/Smoker", value: "F|S"}
  ]
 
  $scope.insuredName = {isExpanded:false}; 
  $scope.selectedItemChange = function (item) { 
    $scope.valOccList = []; // -- GET DATA PEKERJAAN SAAT KLIK LIST TERTANGGUNG
    if(item.age <= 15){
      for(var voc = 0; voc < $rootScope.occupationList.length; voc++){
          if($rootScope.occupationList[voc].code =='NSTN' || $rootScope.occupationList[voc].code =='STDN'){
              var bantu = $rootScope.occupationList[voc]; 
              $scope.valOccList.push(bantu);                 
          }
      }
    }else{
        $scope.valOccList = $rootScope.occupationList;
    }
      $timeout(function(){
      if(item){
          $scope.profileTertanggung = item;
      }else{
        $scope.profileTertanggung = $scope.insuredDatas[0];
      }
        if(item.key == 2)
              resetLoadListData("");
          else
              resetLoadListData("kedua");

      var resprof = $rootScope.positionList.filter(function(obj){
        return obj.code == $scope.profileTertanggung.Position;
      })
      if(resprof.length > 0){
          $scope.tmp_input.inp_pos = resprof[0];
      }
      resprof = $rootScope.businessList.filter(function(obj){
        return obj.code == $scope.profileTertanggung.Business;
      })
      if(resprof.length > 0){
          $scope.tmp_input.inp_bss = resprof[0];
      }
    })

    $scope.insuredName = {isExpanded:false}; 
     
  } 
 
  $scope.insuredMaxPopUp = function(e) { 
    var myPopup = $ionicPopup.show({ 
      title: "<strong>PRU</strong><em>force</em> SQS", 
      template: 'Batas maksimal adalah 5 tertanggung.', 
      cssClass: 'pru-alert pru-logo-text', 
      scope: $scope, 
      buttons: [ 
      { 
        text: 'Kembali', 
        type: 'button-assertive', 
        onTap: function(e) { 
        } 
      } 
      ] 
    }); 
  }; 

  $scope.editSubstandardModel = false; 
  $scope.editInsuredName = false; 

  function validasiPhLa(){
    $rootScope.check = true;
    $rootScope.dataset = [];
    $rootScope.datasetTertanggung = [];
    $rootScope.datasetWarning = [];
    $rootScope.datasetWarningTertanggung = [];
    var isWarningJKAge = true;
    var isComplete = true;
    var flagVal;
    var jumIsian = $scope.insertDatasList.length;
    var tmpListDataValidasi;
    var isPempbayarPremi1;
    var isPempbayarPremi2;
    var isPempbayarPremi3;
    var isPempbayarPremi4;
    var isPempbayarPremi5;
    var isWarn = true;
    for(var i=0; i < $scope.insertDatasList.length; i++){
        tmpListDataValidasi = $scope.insertDatasList[i];



        //-- VALIDASI MANDATORY PEMEGANG POLIS DAN TERTANGGUNG  
        if(i == 0){
            if(tmpListDataValidasi.name== undefined || tmpListDataValidasi.name== null){
                $rootScope.dataset.push({icon : 'ion-ios-close assertive', info : 'Nama Harus diisi'});
                isComplete = false;
            }
            if(tmpListDataValidasi.tipe== undefined || tmpListDataValidasi.tipe== null || tmpListDataValidasi.tipe== "" ){
                $rootScope.dataset.push({icon : 'ion-ios-close assertive', info : 'Tipe Harus Diisi'});
                isComplete = false;
            }
            if(tmpListDataValidasi.pemegang== undefined || tmpListDataValidasi.pemegang== null || tmpListDataValidasi.pemegang== ""){
                $rootScope.dataset.push({icon : 'ion-ios-close assertive', info : 'Pemegang Polis juga Sebagai Harus Diisi'});
                isComplete = false;
            }
            if(tmpListDataValidasi.MaritalStatus== undefined || tmpListDataValidasi.MaritalStatus== null  || tmpListDataValidasi.MaritalStatus== ""){
                $rootScope.dataset.push({icon : 'ion-ios-close assertive', info : 'Status Pernikahan Harus Diisi'});
                isComplete = false;
            }
            if(tmpListDataValidasi.Dob== undefined || tmpListDataValidasi.Dob== null || tmpListDataValidasi.Dob== ""){
                $rootScope.dataset.push({icon : 'ion-ios-close assertive', info : 'Tanggal Lahir Harus Diisi'});
                isComplete = false;
            }
            if(tmpListDataValidasi.Occupation== undefined || tmpListDataValidasi.Occupation== null || tmpListDataValidasi.Occupation== ""){
                $rootScope.dataset.push({icon : 'ion-ios-close assertive', info : 'Pekerjaan Harus Diisi'});
                isComplete = false;
            }
            if(tmpListDataValidasi.Business== undefined || tmpListDataValidasi.Business== null || tmpListDataValidasi.Business== ""){
                $rootScope.dataset.push({icon : 'ion-ios-close assertive', info : 'Bidang Usaha Harus Diisi'});
                isComplete = false;
            }
            if(tmpListDataValidasi.Department== undefined || tmpListDataValidasi.Department== null || tmpListDataValidasi.Department== ""){
                $rootScope.dataset.push({icon : 'ion-ios-close assertive', info : 'Department Harus Diisi'});
                isComplete = false;
            }
            if(tmpListDataValidasi.Position== undefined || tmpListDataValidasi.Position== null || tmpListDataValidasi.Position== ""){
                $rootScope.dataset.push({icon : 'ion-ios-close assertive', info : 'Jabatan Harus Diisi'});
                isComplete = false;
            }
            if(tmpListDataValidasi.PembayaranPremi== undefined || isNaN(tmpListDataValidasi.PembayaranPremi) || tmpListDataValidasi.PembayaranPremi== null || tmpListDataValidasi.PembayaranPremi== ""){
                $rootScope.dataset.push({icon : 'ion-ios-close assertive', info : 'Pembayar Premi Harus Diisi'});
                isComplete = false;
            }
            // Validasi ketika jabatan pilih lainnya
            if(tmpListDataValidasi.Position== 'OTH'){
                if(tmpListDataValidasi.PositionLainnya == undefined || tmpListDataValidasi.PositionLainnya == null || tmpListDataValidasi.PositionLainnya ==""){
                    $rootScope.dataset.push({icon : 'ion-ios-close assertive', info : 'Jabatan lainnya Harus Diisi'});
                    isComplete = false;
                }
            }  

            // Validasi bkan PH & Pembayar = pemegang polis
            if(tmpListDataValidasi.PembayaranPremi==1 && tmpListDataValidasi.pemegang ==1 && tmpListDataValidasi.Incm== undefined){ 
                $rootScope.dataset.push({icon : 'ion-ios-close assertive', info : 'Total Penghasilan Harus Diisi'});
                isComplete = false;
            }
            // Validasi Minimum usia Pemegang Polis adalah 21 atau 18 (jika sudah menikah)
            if(tmpListDataValidasi.MaritalStatus=='single' && tmpListDataValidasi.age < 21){ 
               $rootScope.dataset.push({icon : 'ion-ios-close assertive', info : 'Minimum usia Pemegang Polis adalah 21 atau 18 (jika sudah menikah)'});
                isComplete = false;
            }
            // Validasi sudah menikah tapi dibawah 18 th dan beli polis
            if((tmpListDataValidasi.MaritalStatus =='married' || tmpListDataValidasi.MaritalStatus =='widow') && tmpListDataValidasi.age < 18){
               $rootScope.dataset.push({icon : 'ion-ios-close assertive', info : 'Minimum usia Pemegang Polis adalah 21 atau 18 (jika sudah menikah)'});
                isComplete = false;
            }
            // validasi input pembayar premi / lainnya
            if(tmpListDataValidasi.PembayaranPremi==7){
                if(tmpListDataValidasi.namePremi == undefined || tmpListDataValidasi.namePremi == null || tmpListDataValidasi.namePremi == ""){
                  $rootScope.dataset.push({icon : 'ion-ios-close assertive', info : 'Nama Pembayar Premi Harus diisi'});
                  isComplete = false;
                }
                if(tmpListDataValidasi.workPremi == undefined || tmpListDataValidasi.workPremi == null || tmpListDataValidasi.workPremi == ""){
                  $rootScope.dataset.push({icon : 'ion-ios-close assertive', info : 'Pekerjaan Pembayar Premi Harus diisi'});
                  isComplete = false;
                }
                if(tmpListDataValidasi.IncomePremi == undefined || tmpListDataValidasi.IncomePremi == null || tmpListDataValidasi.IncomePremi == ""){
                  $rootScope.dataset.push({icon : 'ion-ios-close assertive', info : 'Total Penghasilan Pembayar Premi Harus diisi'});
                  isComplete = false;
                }
            }
            // warning pembayar premi sebagai pemegang polis
            if(tmpListDataValidasi.PembayaranPremi== 1 && tmpListDataValidasi.Occupation != undefined){
              for(var c in tmpListDataValidasi.Occupation){
                  if(tmpListDataValidasi.Occupation[c]=='HSWF' || tmpListDataValidasi.Occupation[c]=='UNEM' || tmpListDataValidasi.Occupation[c]=='RETI'|| tmpListDataValidasi.Occupation[c]=='STDN' ||tmpListDataValidasi.Occupation[c]=='NSTN'){
                      $rootScope.datasetWarning.push({icon : 'ion-ios-checkmark balanced valid_pp valid', info : 'Pembayar Premi wajib mengisi formulir "Pernyataan Khusus untuk (calon) Pembayar Premi/Kontributor"'});
                      isComplete = true;
                  }
              }
            }                
        }else{
            if(tmpListDataValidasi.name== undefined || tmpListDataValidasi.name== null){
                if(i==1){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Nama '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
                if(i==2){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Nama '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
                if(i==3){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Nama '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
                if(i==4){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Nama '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
                if(i==5){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Nama '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete  = false;
                }
            }
            if(tmpListDataValidasi.Dob== undefined || tmpListDataValidasi.Dob== null || tmpListDataValidasi.Dob== ""){
                if(i==1){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Tanggal lahir '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
                if(i==2){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Tanggal lahir '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
                if(i==3){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Tanggal lahir '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
                if(i==4){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Tanggal lahir '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
                if(i==5){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Tanggal lahir '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
            }
            if(tmpListDataValidasi.jenisKelaminPerokok== undefined || tmpListDataValidasi.jenisKelaminPerokok== null || tmpListDataValidasi.jenisKelaminPerokok== ""){
                if(i==1){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Jenis Kelamin / Perokok '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
                if(i==2){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Jenis Kelamin / Perokok '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
                if(i==3){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Jenis Kelamin / Perokok '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
                if(i==4){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Jenis Kelamin / Perokok '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
                if(i==5){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Jenis Kelamin / Perokok '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
            }
            if(tmpListDataValidasi.Occupation== undefined || tmpListDataValidasi.Occupation== null || tmpListDataValidasi.Occupation== ""){
                if(i==1){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Pekerjaan '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
                if(i==2){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Pekerjaan '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
                if(i==3){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Pekerjaan '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
                if(i==4){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Pekerjaan '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
                if(i==5){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Pekerjaan '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
            }
            if(tmpListDataValidasi.Business== undefined || tmpListDataValidasi.Business== null || tmpListDataValidasi.Business== ""){
                if(i==1){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Bidang Usaha '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
                if(i==2){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Bidang Usaha '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
                if(i==3){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Bidang Usaha '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
                if(i==4){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Bidang Usaha '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
                if(i==5){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Bidang Usaha '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
            }
            if(tmpListDataValidasi.Department== undefined || tmpListDataValidasi.Department== null || tmpListDataValidasi.Department== ""){
                if(i==1){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Department/Instansi '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
                if(i==2){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Department/Instansi '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
                if(i==3){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Department/Instansi '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
                if(i==4){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Department/Instansi '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
                if(i==5){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Department/Instansi '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
            }
            if(tmpListDataValidasi.Position== undefined || tmpListDataValidasi.Position== null || $scope.insertDatasList[i].Position== ""){
                if(i==1){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Jabatan '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
                if(i==2){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Jabatan '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
                if(i==3){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Jabatan '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
                if(i==4){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Jabatan '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
                if(i==5){
                    $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Jabatan '+tmpListDataValidasi.alias+' Harus diisi'});
                    isComplete = false;
                }
            }
            if(tmpListDataValidasi.Income== undefined || tmpListDataValidasi.Income== null || tmpListDataValidasi.Income== ""){

                if(tmpListDataValidasi.pekerjaanCode != 'HSWF'){
                    //jika pekerjaan bukan housewife
                    if(i==1){
                        $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Total Penghasilan '+tmpListDataValidasi.alias+' Harus diisi'});
                        isComplete = false;
                    }
                    if(i==2){

                        $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Total Penghasilan '+tmpListDataValidasi.alias+' Harus diisi'});
                        isComplete = false;
                    }
                    if(i==3){
                        $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Total Penghasilan '+tmpListDataValidasi.alias+' Harus diisi'});
                        isComplete = false;
                    }
                    if(i==4){
                        $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Total Penghasilan '+tmpListDataValidasi.alias+' Harus diisi'});
                        isComplete = false;
                    }
                    if(i==5){
                        $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Total Penghasilan '+tmpListDataValidasi.alias+' Harus diisi'});
                        isComplete = false;
                    }  
                }
                
            }

           // Validasi ketika jabatan pilih lainnya
            if(tmpListDataValidasi.Position== 'OTH'){
                if(tmpListDataValidasi.PositionLainnya == undefined || tmpListDataValidasi.PositionLainnya == null || tmpListDataValidasi.PositionLainnya ==""){
                    if(i == 1){
                      $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Jabatan lainnya '+tmpListDataValidasi.alias+' Harus Diisi'});
                      isComplete = false;
                    }
                    if(i == 2){
                      $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Jabatan lainnya '+tmpListDataValidasi.alias+' Harus Diisi'});
                      isComplete = false;
                    }
                    if(i == 3){
                      $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Jabatan lainnya '+tmpListDataValidasi.alias+' Harus Diisi'});
                      isComplete = false;
                    }
                    if(i == 4){
                      $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Jabatan lainnya '+tmpListDataValidasi.alias+' Harus Diisi'});
                      isComplete = false;

                    }
                    if(i == 5){
                      $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Jabatan lainnya '+tmpListDataValidasi.alias+' Harus Diisi'});
                      isComplete = false;                      
                    }
                }
            }  
  

          // warning message harus isi data orang tua
          if(tmpListDataValidasi.age <=15 && jumIsian==2){
              $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Silahkan isi Profil Orang Tua karena Tertanggung Utama adalah anak'});
              isComplete = false;                  
          }
          // warning persetujuan PremiBackDate
          if(tmpListDataValidasi.berlakuSurut == true && ($scope.insertDatasList[i].checkbox == false || $scope.insertDatasList[i].checkbox == undefined)){
              if(jumIsian==2){
                  $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Mohon menyetujui kalimat pernyataan premi backdate apabila ingin melanjutkan'});
                  isComplete = false;                      
              }
          }
          // warning persetujuan substandar
          if(tmpListDataValidasi.subStandard == true && (tmpListDataValidasi.checkboxSubStandard == undefined || tmpListDataValidasi.checkboxSubStandard == false)){
              if(i == 1 && jumIsian==2){
                  $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Mohon menyetujui kalimat pernyataan substandard apabila ingin melanjutkan'});
                  isComplete = false;
              }
              if(i == 2 && jumIsian==3){
                  $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Mohon menyetujui kalimat pernyataan substandard apabila ingin melanjutkan'});
                  isComplete = false;
              }
              if(i == 3 && jumIsian==4){
                  $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Mohon menyetujui kalimat pernyataan substandard apabila ingin melanjutkan'});
                  isComplete = false;
              }

          }
      }
    } //--END LOOPING
    
    /*-- validasi untuk pembayar premi tetapi data belum ditambah sesuai pembayar preminya --*/
    var tmpPemegangPolis = getCustDataByIdx(1);

    if(tmpPemegangPolis.PembayaranPremi==3 && jumIsian==2){
        $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Data Tertanggung ke-2 Tidak Tersedia'});
        isComplete = false;
    }else if(tmpPemegangPolis.PembayaranPremi==4 && (jumIsian==3 || jumIsian==2)){
        $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Data Tertanggung ke-3 Tidak Tersedia'});
        isComplete = false;
    }else if(tmpPemegangPolis.PembayaranPremi==5 && (jumIsian==4 || jumIsian==3 || jumIsian==2)){
        $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Data Tertanggung ke-4 Tidak Tersedia'});
        isComplete = false;
    }else if(tmpPemegangPolis.PembayaranPremi==6 && (jumIsian==5 || jumIsian==4 || jumIsian==3 || jumIsian==2)){
        $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Data Tertanggung ke-5 Tidak Tersedia'});
        isComplete = false;
    }


    // -- Temporary GetAllData LA
    var tmpDataTertanggungUtama = getCustDataByIdx(2);
    var tmpDataTertanggungKedua = getCustDataByIdx(3);
    var tmpDataTertanggungKetiga = getCustDataByIdx(4);
    var tmpDataTertanggungKeempat = getCustDataByIdx(5);
    var tmpDataTertanggungKelima = getCustDataByIdx(6);
    console.log('dataTertanggung utama : ',tmpDataTertanggungUtama);
    console.log('dataTertanggung ke-2 : ',tmpDataTertanggungKedua);
    console.log('dataTertanggung ke-3 : ',tmpDataTertanggungKetiga);
    console.log('dataTertanggung ke-4 : ',tmpDataTertanggungKeempat);
    console.log('dataTertanggung ke-5 : ',tmpDataTertanggungKelima);

    // -- Temporary GetAllData Pekerjaan LA
    var tmpPekerjaanTertanggung1 = getPekerjaan(2); 
    var tmpPekerjaanTertanggung2 = getPekerjaan(3);
    var tmpPekerjaanTertanggung3 = getPekerjaan(4);
    var tmpPekerjaanTertanggung4 = getPekerjaan(5);
    var tmpPekerjaanTertanggung5 = getPekerjaan(6);

    // -- Temporary GetAllData JK LA
    var tmpJenisKelamin1 = getJenisKelaminn(2);
    var tmpJenisKelamin2 = getJenisKelaminn(3);
    var tmpJenisKelamin3 = getJenisKelaminn(4);
    var tmpJenisKelamin4 = getJenisKelaminn(5);
    var tmpJenisKelamin5 = getJenisKelaminn(6);

    /*-- warning Message Validate ketika pembayar premi LA --*/
    if(tmpPemegangPolis.PembayaranPremi > 1){
        if(tmpPemegangPolis.PembayaranPremi == 2){
            isPempbayarPremi1 = true;
        }
        if(tmpPemegangPolis.PembayaranPremi == 3){
           isPempbayarPremi2 = true;
        }
        if(tmpPemegangPolis.PembayaranPremi == 4){
           isPempbayarPremi3 = true;
        }
        if(tmpPemegangPolis.PembayaranPremi == 5){
           isPempbayarPremi4 = true;
        }
        if(tmpPemegangPolis.PembayaranPremi == 6){
           isPempbayarPremi5 = true;
        }

        var tmpKodePekerjaanTTU = getKodePekerjaan(2);
        var tmpKodePekerjaanTT2 = getKodePekerjaan(3);
        var tmpKodePekerjaanTT3 = getKodePekerjaan(4);
        var tmpKodePekerjaanTT4 = getKodePekerjaan(5);
        var tmpKodePekerjaanTT5 = getKodePekerjaan(6);
        if(tmpKodePekerjaanTTU== 'HSWF' || tmpKodePekerjaanTTU== 'UNEM' || tmpKodePekerjaanTTU== 'RETI' || tmpKodePekerjaanTTU== 'STDN' || tmpKodePekerjaanTTU == 'NSTN'){
            if((isPempbayarPremi1 == true && isPempbayarPremi1 != undefined) && tmpDataTertanggungUtama.key== 2){
                  $rootScope.datasetWarningTertanggung.push({icon : 'ion-ios-checkmark balanced valid_pp valid', info : 'Pembayar Premi wajib mengisi formulir "Pernyataan Khusus untuk (calon) Pembayar Premi/Kontributor"'});
                  isWarn = true;
            }                
        }
        if(tmpKodePekerjaanTT2== 'HSWF' || tmpKodePekerjaanTT2== 'UNEM' || tmpKodePekerjaanTT2== 'RETI' || tmpKodePekerjaanTT2== 'STDN' || tmpKodePekerjaanTT2 == 'NSTN'){
            if((isPempbayarPremi2 == true && isPempbayarPremi2 != undefined) && tmpDataTertanggungKedua.key== 3){
                  $rootScope.datasetWarningTertanggung.push({icon : 'ion-ios-checkmark balanced valid_pp valid', info : 'Pembayar Premi wajib mengisi formulir "Pernyataan Khusus untuk (calon) Pembayar Premi/Kontributor"'});
                  isWarn = true;
            }                
        }
        if(tmpKodePekerjaanTT3== 'HSWF' || tmpKodePekerjaanTT3== 'UNEM' || tmpKodePekerjaanTT3== 'RETI' || tmpKodePekerjaanTT3== 'STDN' || tmpKodePekerjaanTT3 == 'NSTN'){
            if((isPempbayarPremi3 == true && isPempbayarPremi3 != undefined) && tmpDataTertanggungKetiga.key== 4){
                  $rootScope.datasetWarningTertanggung.push({icon : 'ion-ios-checkmark balanced valid_pp valid', info : 'Pembayar Premi wajib mengisi formulir "Pernyataan Khusus untuk (calon) Pembayar Premi/Kontributor"'});
                  isWarn = true;
            }                
        }
        if(tmpJenisKelamin4== 'HSWF' || tmpJenisKelamin4== 'UNEM' || tmpJenisKelamin4== 'RETI' || tmpJenisKelamin4== 'STDN' || tmpJenisKelamin4 == 'NSTN'){
            if((isPempbayarPremi4 == true && isPempbayarPremi4 != undefined) && tmpDataTertanggungKeempat.key== 5){
                  $rootScope.datasetWarningTertanggung.push({icon : 'ion-ios-checkmark balanced valid_pp valid', info : 'Pembayar Premi wajib mengisi formulir "Pernyataan Khusus untuk (calon) Pembayar Premi/Kontributor"'});
                  isWarn = true;
            }                
        }
        if(tmpKodePekerjaanTT5== 'HSWF' || tmpKodePekerjaanTT5== 'UNEM' || tmpKodePekerjaanTT5== 'RETI' || tmpKodePekerjaanTT5== 'STDN' || tmpKodePekerjaanTT5 == 'NSTN'){
            if((isPempbayarPremi5 == true && isPempbayarPremi5 != undefined) && tmpDataTertanggungKelima.key== 5){
                  $rootScope.datasetWarningTertanggung.push({icon : 'ion-ios-checkmark balanced valid_pp valid', info : 'Pembayar Premi wajib mengisi formulir "Pernyataan Khusus untuk (calon) Pembayar Premi/Kontributor"'});
                  isWarn = true;
            }                
        }
    }


    // Validasi Jenis Kelamin dan Pekerjaan yang dipilih
    if(tmpDataTertanggungUtama){
      if(tmpJenisKelamin1){
        if(tmpPekerjaanTertanggung1.gender != tmpJenisKelamin1 && tmpPekerjaanTertanggung1.gender != 'All'){
          $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Jenis kelamin dengan jenis pekerjaan yang dipilih Tertanggung Utama tidak sesuai'});
          isComplete = false;
        }
      }              
    }
    if(tmpDataTertanggungKedua){
      if(tmpJenisKelamin2){
        if(tmpPekerjaanTertanggung2.gender !=tmpJenisKelamin2 && tmpPekerjaanTertanggung2.gender != 'All'){
          $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Jenis kelamin dengan jenis pekerjaan yang dipilih Tertanggung Ke-2 tidak sesuai'});
          isComplete = false;
        }
      }              
    }
    if(tmpDataTertanggungKetiga){
      if(tmpJenisKelamin3){
        if(tmpPekerjaanTertanggung3.gender != tmpJenisKelamin3 && tmpPekerjaanTertanggung3.gender != 'All'){
          $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Jenis kelamin dengan jenis pekerjaan yang dipilih Tertanggung Ke-3 tidak sesuai'});
          isComplete = false;
        }
      }              
    }
    if(tmpDataTertanggungKeempat){
      if(tmpJenisKelamin4){
        if(tmpPekerjaanTertanggung4.gender != tmpJenisKelamin4 && tmpPekerjaanTertanggung4.gender != 'All'){
          $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Jenis kelamin dengan jenis pekerjaan yang dipilih Tertanggung Ke-4 tidak sesuai'});
          isComplete = false;
        }
      }              
    }
    if(tmpDataTertanggungKelima){
      if(tmpJenisKelamin5){
        if(tmpPekerjaanTertanggung5.gender != tmpJenisKelamin5 && tmpPekerjaanTertanggung5.gender != 'All'){
          $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Jenis kelamin dengan jenis pekerjaan yang dipilih Tertanggung Ke-5 tidak sesuai'});
          isComplete = false;
        }
      }              
    }


  //--validasi jenis kelamin di TT2 & TT3 dst
  if(tmpDataTertanggungUtama){
      if(tmpDataTertanggungUtama.age){
          if(tmpDataTertanggungUtama.age >= 18 && tmpDataTertanggungUtama.age <= 65){
              var tmpList = [];
              if(tmpDataTertanggungKedua){
                  if(tmpDataTertanggungKedua.age && tmpDataTertanggungKedua.age >= 18){
                    console.log(getJenisKelaminn(3));
                      if(getJenisKelaminn(2) == getJenisKelaminn(3)){
                          $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Jenis Kelamin Tertanggung Utama dan Tertanggung ke-2 harus berbeda, karena mereka adalah pasangan Suami-Istri'});
                          tmpList.push(false);
                      }
                      if(tmpDataTertanggungKetiga) {
                          if(tmpDataTertanggungKetiga.age && tmpDataTertanggungKetiga.age > 15){                              
                              $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Usia Tertanggung ke-3 harus antara 1 dan 15, apabila Tertanggung Utama adalah dewasa'});
                              tmpList.push(false);
                          }
                      }
                      if(tmpDataTertanggungKeempat){
                          if(tmpDataTertanggungKeempat.age && tmpDataTertanggungKeempat.age > 15){
                              $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Usia Tertanggung ke-4 harus antara 1 dan 15, apabila Tertanggung Utama adalah dewasa'});
                              tmpList.push(false);
                          }
                      }
                      if(tmpDataTertanggungKelima){
                          if(tmpDataTertanggungKelima && tmpDataTertanggungKelima.age > 15){
                              $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Usia Tertanggung ke-5 harus antara 1 dan 15, apabila Tertanggung Utama adalah dewasa'});
                              tmpList.push(false);
                          }
                      }
                  }
              }

              for(var x = 0; x < tmpList.length; x++){
                  if(tmpList[x] == false){
                    isWarningJKAge = false;
                    break;
                  }
              }

          }else if(tmpDataTertanggungUtama.age <= 15){
              var tmpList = [];
              if(tmpDataTertanggungKedua && tmpDataTertanggungKetiga){
                  if(getJenisKelaminn(3) == getJenisKelaminn(4)){
                      $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Jenis Kelamin Tertanggung ke-2 dan tertanggung ke-3 harus berbeda, apabila tertanggung utama adalah anak'});
                      tmpList.push(false);
                  }                    
              }
              if(tmpDataTertanggungKedua){              
                  if(tmpDataTertanggungKedua.age && (tmpDataTertanggungKedua.age < 18 || tmpDataTertanggungKedua.age > 65)){
                      $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Usia Masuk Tertanggung ke-2 harus diantara 18 dan 65 , apabila Tertanggung Utama adalah anak'});
                      tmpList.push(false);
                  }
              }
              if(tmpDataTertanggungKetiga) {
                  if(tmpDataTertanggungKetiga.age && (tmpDataTertanggungKetiga.age < 18 || tmpDataTertanggungKetiga.age > 65)){
                      $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Usia Masuk Tertanggung ke-3 harus diantara 18 dan 65 , apabila Tertanggung Utama adalah anak'});
                      tmpList.push(false);
                  }
              }
              if(tmpDataTertanggungKeempat){
                  if(tmpDataTertanggungKeempat.age && tmpDataTertanggungKeempat.age < 18 && tmpDataTertanggungKeempat.age > 65){
                      $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Usia Masuk Tertanggung ke-4 harus diantara 18 dan 65 , apabila Tertanggung Utama adalah anak'});
                      tmpList.push(false);
                  }
              }
              if(tmpDataTertanggungKelima){
                  if(tmpDataTertanggungKelima.age && tmpDataTertanggungKelima.age < 18 && tmpDataTertanggungKelima.age > 65){
                      $rootScope.datasetTertanggung.push({icon : 'ion-ios-close assertive', info : 'Usia Masuk Tertanggung ke-5 harus diantara 18 dan 65 , apabila Tertanggung Utama adalah anak'});
                      tmpList.push(false);
                  }
              }
              for(var x = 0; x < tmpList.length; x++){
                  if(tmpList[x] == false){
                    isWarningJKAge = false;
                    break;
                  }
              }
          }
      }
  }          



    // ---- JIKA VALIDASI TERPENUHI ---
    if (isComplete== true && isWarningJKAge == true && isWarn == true){
        $rootScope.check = false;
        $state.go("produk-manfaat");
    }


  }

  function getKodePekerjaan(idx){
    for(var i = 0; i < $scope.insertDatasList.length; i++){
      if($scope.insertDatasList[i].key == idx){
         if($scope.insertDatasList[i].Occupation){
            return $scope.insertDatasList[i].Occupation.code;
         }
      }
    }
  }


  function getPekerjaan(idx){
    for(var i = 0; i < $scope.insertDatasList.length; i++){
      if($scope.insertDatasList[i].key == idx){
         if($scope.insertDatasList[i].Occupation){
            return $scope.insertDatasList[i].Occupation;
         }
      }
    }
  }

  function getJenisKelaminn(idx){
    for(var i = 0; i < $scope.insertDatasList.length; i++){
        if($scope.insertDatasList[i].key == idx){
          if($scope.insertDatasList[i].jenisKelaminPerokok){
            var jk = $scope.insertDatasList[i].jenisKelaminPerokok.split('|');
            return jk[0];            
          }
        }
    }
  }

  function getCustDataByIdx(idx){
      for(var i = 0; i < $scope.insertDatasList.length; i++){
          if($scope.insertDatasList[i].key == idx){
              return $scope.insertDatasList[i];          
          }
      }
  }

  $scope.addSubstandards = function(){
    var id = $scope.profileTertanggung["substd"].length +1;
    var obj = {id:id, model:"substd"+id, checked:true, data:{val1: "B1", val2: "B2" }};
    $scope.profileTertanggung["substd"].push(obj);
  }

  
  $scope.produkmanfaat = function(event) {
      validasiPhLa();
  }

  $scope.numClassPemegangPolisItems = function(className) {
    var result = $window.document.getElementsByClassName(className);
     return result.length;
  };

  $scope.doFocus = function(id, tab, e) {
    $scope.openValidation = false;
    if(tab == 'pp'){
      var menuTab_ = $scope.menuTabs[0]
    }else if( tab = 't'){
      var menuTab_ = $scope.menuTabs[1]
    }
    if(menuTab_.url != $scope.currentMenuTab.url){
      $scope.movingTab(e, menuTab_);
      $timeout(function(){focus(id);}, 100);
    }else{
      focus(id);
    }
    
  };
  
  $scope.searchPekerjaan;
  $scope.clearPekerjaan = function() {
    $scope.searchPekerjaan = '';
  };

  $scope.searchBidang;
  $scope.clearBidang = function() {
    $scope.searchBidang = '';
  };

  $scope.searchPosition;
  $scope.clearPosition = function() {
    $scope.searchPosition = '';
  };
/*    var keysPP = Object.keys($scope.insertDatasList);
    var keysT = Object.keys($scope.validationRule.tertanggung);
    $scope.ruleLengthPemegangPolis = keysPP.length;
    console.log($scope.ruleLengthPemegangPolis);
    $scope.ruleLengthTertanggung = keysT.length;
    $scope.ruleLength = $scope.insertDatasList.length;*/

pruforce.config(function($mdDateLocaleProvider) {
  $mdDateLocaleProvider.formatDate = function(date) {
    return date ? moment(date).format('DD MMMM YYYY') : '';
  };
});

pruforce.factory('focus', function($timeout, $window, $ionicScrollDelegate) {
  return function(id) {
    $timeout(function() {
      var element = $window.document.getElementById(id);
      var targetPosition = $('#'+id).offset().top;
      var currentPosition = $ionicScrollDelegate.getScrollPosition().top;
      var posiblePosition = (currentPosition + targetPosition) - 175;
      if (targetPosition<50){
        $ionicScrollDelegate.scrollTo(0, posiblePosition, true )
      }
      $timeout(function(){
      if(element)
        if(element.children[1]){
          var oid = element.children[1].children[0].id;
          var u = $window.document.getElementById(oid);
          if(u)
          u.focus();
        }else{
          if(element)
          element.focus();
        }
      }, 200);
    });
  };
});

  
  })