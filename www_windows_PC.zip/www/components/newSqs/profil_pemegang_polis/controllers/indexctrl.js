﻿var pruforce = angular.module('PruForce');

pruforce.controller('IndexCtrl', function($q, $scope, $ionicScrollDelegate, $ionicPopup,$ionicLoading, $rootScope, $state, $localStorage, PublishGlobalService, CustomerStorageService, QuotationStorageService, $timeout) {
          $scope.menuTabs = [
              {name: "Pemegang polis",  url: "components/newSqs/profil_pemegang_polis/pemegang-polis.html"},
              {name: "Tertanggung",  url: "components/newSqs/profil_pemegang_polis/tertanggung.html"}
          ];

          $scope.movingTab = function(e, menuTab){
              e.preventDefault();
              $scope.currentMenuTab = menuTab;

              var self = $(e.toElement);
              var tabContentTitle = self.attr("href");

              $(".tab-scrolling").animate({scrollLeft: self.attr("data-position-left")}, 300);
              self.parent().find("a").removeClass("active");
              self.addClass("active");
              $(tabContentTitle).addClass("active");
          }

          console.log("view entered");
          if ($rootScope.Level >= 2) {
              console.log('masuk sini');
              $scope.currentMenuTab = $scope.menuTabs[1];
          } else {
              console.log('masuk sana');
              $scope.currentMenuTab = $scope.menuTabs[0];  
          }

          $scope.isActiveTab = function(menuTabUrl){
              return $scope.currentMenuTab.url === menuTabUrl;
          };

          $scope.previous = function(){
              console.log('masuk previous')
              $state.go("daftar-newsqs");
          }
});