﻿angular.module('PruForce.services')

	.factory('QuotationStorageService', function ($rootScope) {

		///var deferred = $q.defer();
		var collection = JsonStoreConfig.QuotationStorage;

		function getQuotationStorage($q){
			var deferredAllQuotation = $q.defer();
			//console.log("Retrieve data from json store " + collection.JSONSTORE_NAME);
			try{
				
				var query = {agentId: $rootScope.agent.code};
				var options = {exact: false
					    	   //limit: 100 //returns a maximum of 10 documents
				   	  };
				
				WL.JSONStore.get(collection.JSONSTORE_NAME).find(query, options).then(function(res){
				 	try{
						if(res.length > 0){
							var result =  res;
							deferredAllQuotation.resolve(result);
						}		
					} catch(error){
						deferredAllQuotation.reject(error);
					}						
				}).fail(function(error){
				 	deferredAllQuotation.reject(error);
				});
			} catch (error) {
				deferredAllQuotation.reject(error);
			}
			return deferredAllQuotation.promise;
		}


		function getQuotationStorageByKey($q, quotationId){
			var deferredOneQuot = $q.defer();
			//console.log("Retrieve data from json store " + collection.JSONSTORE_NAME);
			try{				
				var query = {agentId: $rootScope.agent.code, quotationId : quotationId};
				var options = {exact: false
					    	   //limit: 100 //returns a maximum of 10 documents
				   	  };
				
				WL.JSONStore.get(collection.JSONSTORE_NAME).find(query, options).then(function(res){
		          try{
		            if(res.length > 0){
			            var result =  res[0].json;
			            deferredOneQuot.resolve(result.invocationResult);
		            }else{
		            	deferredOneQuot.resolve();
		            }
		          } catch(error){
		            deferredOneQuot.reject(error);
		          }           
		        }).fail(function(error){
		          deferredOneQuot.reject(error);
		        });
			} catch (error) {
				deferredOneQuot.reject(error);
			}
			return deferredOneQuot.promise;
		}

		function deleteQuotationStorageByKey($q, quotationId){
			//console.log("Retrieve data from json store " + collection.JSONSTORE_NAME);
			console.log('deleting ' + quotationId);
			var deferredOneCust = $q.defer();
			try{
				
				var query = {agentId: $rootScope.agent.code, quotationId : quotationId};

				var options = {exact: false
					    	   //limit: 100 //returns a maximum of 10 documents
				   	  };
				
				WL.JSONStore.get(collection.JSONSTORE_NAME).remove(query, options).then(function(res){
				 	try{
						if(res.length > 0){
							var result =  res[0].json;
							console.log(result);
							deferredOneCust.resolve(result.invocationResult);
						}		
					} catch(error){
						deferredOneCust.reject(error);
					}						
				}).fail(function(error){
				 	deferredOneCust.reject(error);
				});
			} catch (error) {
				deferredOneCust.reject(error);
			}
			return deferredOneCust.promise;
		}

		function addQuotationStorage($q, quotationId, param){
			var deferredAddQuot = $q.defer();
			var result = {};
			result.retrieveDate = new Date();
			result.agentId = $rootScope.agent.code;

			var data = {};
			data.invocationResult = param;
			data.agentId = result.agentId;
			data.quotationId = quotationId;
			data.retrieveDate = result.retrieveDate;
			
			var query = {agentId: $rootScope.agent.code, quotationId : quotationId};

			var options = {exact: false
				    	   //limit: 100 //returns a maximum of 10 documents
			   	  };


			WL.JSONStore.get(collection.JSONSTORE_NAME).find(query, options).then(function(res){
			 	try{
					if(res.length > 0){
						res[0].json.invocationResult = param;
						WL.JSONStore.get(collection.JSONSTORE_NAME).replace(res).then(function () {
							AppsLog.log("Success adding data to jsonstore " + collection.JSONSTORE_NAME);
							deferredAddQuot.resolve(data);
						}).fail(function (error) {
							AppsLog.log("Failed adding data to jsonstore " + collection.JSONSTORE_NAME);
							deferredAddQuot.reject(error);
						});
						

					}else{
						WL.JSONStore.get(collection.JSONSTORE_NAME).add(data).then(function () {
							AppsLog.log("Success adding data to jsonstore " + collection.JSONSTORE_NAME);
							deferredAddQuot.resolve(data);
						}).fail(function (error) {
							AppsLog.log("Failed adding data to jsonstore " + collection.JSONSTORE_NAME);
							deferredAddQuot.reject(error);
						});
						
					}	
					deferredAddQuot.resolve(true);
				} catch(error){
					deferredAddQuot.reject(error);
				}						
			}).fail(function(error){
			 	deferredAddQuot.reject(error);
			});
                        return deferredAddQuot.promise;
		}


		return {
			getQuotationStorage : getQuotationStorage,
			getQuotationStorageByKey : getQuotationStorageByKey,
			addQuotationStorage : addQuotationStorage,
			deleteQuotationStorageByKey : deleteQuotationStorageByKey
		};
	});