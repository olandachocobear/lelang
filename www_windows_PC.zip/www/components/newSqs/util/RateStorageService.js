﻿angular.module('PruForce.services')

	.factory('RateStorageService', function ($rootScope) {

		function getRateValue($q, param){
			var deferredRate = $q.defer();
			var result = new Array();
			console.log("Retrieve data from sqlite Rate");
			
    		
				$rootScope.db.transaction(function (tx) {
			        var query = "SELECT * FROM newsqsrate where agent_cd = '"+$rootScope.agent.code+"' and rate_cd in (";
			        for(var i = 0; i < param.rateCdList.length; i++){
						if(i > 0){
							query += ",";
						}
						query += "'" +param.rateCdList[i]+ "'";
			        }
			        query += ") "
				
					// if(param.age){
					// 	query += "and (age_life_1 = '"+ param.age +"' or age_life_1 = ' ') ";
					// }
					if(param.gender){
						query += "and (gender = '"+ param.gender +"' or gender = ' ') ";
					}
					if(param.smokerStatus){
						query += "and (smoker_status = '"+ param.smokerStatus +"' or smoker_status = ' ') ";
					}
					if(param.clazz){
						query += "and (clazz = '"+ param.clazz +"' or clazz = ' ') ";
					}

					console.log(query);

					tx.executeSql(query, [], function (tx, rs) {
						
						var len = rs.rows.length;

				        for (var i = 0; i < len; i++) {
				            var row = rs.rows.item(i);
				            result.push(row);
				        }
				        console.log('result',result);
						deferredRate.resolve(result);

						// console.log(rs.rows.item);
						// deferredRate.resolve(rs.rows.item);

					});
							
				}, function(error) {
				    console.log('nub-----------------------------');	  					
				});
			
			return deferredRate.promise;	
		}

		function getRateByCoverage($q, param, ITEM, mapProperties){

			var deferredAllRate = $q.defer();
			var task = [];
			console.log("Retrieve data from sqlite Rate bangcat");
			
			var tempListRateCd = ITEM.CHANNEL[param.channelCode];
			   		

    		if(tempListRateCd){
				$rootScope.db.transaction(function (tx) {
					for(var j = 0; j < tempListRateCd.length; j++){

						// function ccc(){
					        var rate = $rootScope.RATE[tempListRateCd[j]];

					        var query = "SELECT * FROM newsqsrate where agent_cd = '"+$rootScope.agent.code+"' and rate_cd = '"+rate.rateCd+"' ";
						
							if(param.age){
								query += "and (age_life_1 = '"+ param.age +"' or age_life_1 = ' ') ";
							}
							if(param.gender){
								query += "and (gender = '"+ param.gender +"' or gender = ' ') ";
							}
							if(param.smokerStatus){
								query += "and (smoker_status = '"+ param.smokerStatus +"' or smoker_status = ' ') ";
							}
							if(param.clazz){
								query += "and (clazz = '"+ param.clazz +"' or clazz = ' ') ";
							}
							if(mapProperties['PDTERM']){
								query += "and (term = '"+ mapProperties['PDTERM'] +"' or term = ' ') ";
							}
							if(mapProperties['PDPLAN']){
								query += "and (plan = '"+ mapProperties['PDPLAN'] +"' or plan = ' ') ";
							}

							console.log(rate.rateTypeCd + '============================');

							tx.executeSql(query, [], function (tx, rs) {
								console.log(rate.rateTypeCd + '+++++++++++++++++++++++');
								mapProperties[rate.rateTypeCd] = rs.rows.item(0) ? rs.rows.item(0).value : 0;
								deferredAllRate.resolve(mapProperties);
							});
							
					//     }
					//     task.push(ccc());
						
					// deferredAllRate.resolve($q.all(task));
			    	}
				}, function(error) {
				    console.log('nub-----------------------------');	  					
				});
			    	
			    	
			}
				
				
			
			return deferredAllRate.promise;

		}

		function getRate($q, rateCode, ageLife1, gender, smokerStatus, clazz, term, plan){

			var deferredAllRate = $q.defer();
			console.log("Retrieve data from sqlite Rate");
			try{

				$rootScope.db.transaction(function (tx) {
					var query = "SELECT * FROM newsqsrate where agent_cd = '"+$rootScope.agent.code+"' and rate_cd = '"+rateCode+"' ";
					
					if(ageLife1){
						query += "and (age_life_1 = '"+ ageLife1 +"' or age_life_1 = ' ') ";
					}
					if(gender){
						query += "and (gender = '"+ gender +"' or gender = ' ') ";
					}
					if(smokerStatus){
						query += "and (smoker_status = '"+ smokerStatus +"' or smoker_status = ' ') ";
					}
					if(clazz){
						query += "and (clazz = '"+ clazz +"' or clazz = ' ') ";
					}
					if(term){
						query += "and (term = '"+ term +"' or term = ' ') ";
					}
					if(plan){
						query += "and (plan = '"+ plan +"' or plan = ' ') ";
					}

					console.log(query);

					tx.executeSql(query, [], function (tx, rs) {
						// console.log(rs);
						// console.log(rs.rows.item(0));
						deferredAllRate.resolve(rs);
					}, function (tx, error) {
						console.log('SELECT error: ' + error.message);
					});
				});


				// var query = {agentId: $rootScope.agent.code,rateCode:rateCode,ageLife1:ageLife1,ageLife2:ageLife2};
				// var options = {exact: false
				// 	    	   //limit: 100 //returns a maximum of 10 documents
				//    	  };
				// console.log("JSONSTORE_NAME: "+collection.JSONSTORE_NAME);
				// WL.JSONStore.get(collection.JSONSTORE_NAME).find(query, options).then(function(res){
				//  	try{
				// 		 console.log("res!");
				// 		 console.log(res);
				// 		if(res.length > 0){
				// 			var result =  res[0].json;
				// 			deferredAllRate.resolve(result.invocationResult.content);
				// 		}		
				// 	} catch(error){
				// 		deferredAllRate.reject(error);
				// 	}						
				// }).fail(function(error){
				//  	deferredAllRate.reject(error);
				// });
			} catch (error) {
				deferredAllRate.reject(error);
			}
			return deferredAllRate.promise;

		}


		return {
			getRateValue : getRateValue,
			getRate : getRate,
			getRateByCoverage : getRateByCoverage
		};
	});