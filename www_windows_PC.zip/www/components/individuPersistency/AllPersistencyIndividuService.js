﻿angular.module('PruForce.services')
.service('AllPersistencyIndividuService', function(DataFactory, $q){
function invoke(agentNumberIndiv,pageIndiv,sizeIndiv,searchByIndiv,searchValIndiv,searchBy2Indiv,searchVal2Indiv,orderByIndiv,directionIndiv,pruforceId,agentCode){
		
		var req = {
				adapter : "HTTPAdapter3",
				procedure : "findAllPersistencyIndividuDetailByAgentNumber",
				method: WLResourceRequest.POST,
				parameters : {"params":"['"+agentNumberIndiv+"',"+pageIndiv+","+sizeIndiv+",'"+searchByIndiv+"','"+searchValIndiv+"','"+searchBy2Indiv+"','"+searchVal2Indiv+"','"+orderByIndiv+"','"+directionIndiv+"','"+pruforceId+"','"+agentCode+"']"}
				};
		
	    var deferred = $q.defer();
		
		DataFactory.invoke(req,true)
	    .then(function (res) {
        	deferred.resolve(res);
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
	}
	
	return {
		invoke: invoke
	}
});

