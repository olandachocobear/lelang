﻿/**
 * 
 */
angular.module('PruForce.controllers')
	.controller('InboxCtrl', function ($scope, $translate, $rootScope, $ionicLoading, $state, $filter, GetListInbox, GetAplicationPackService, GetListPendingDocService, GetReasonPendingDocService, SignatureService, InboxService) {

		var date = new Date();
		var timeHours = date.getHours();
		var timeMinute = date.getMinutes();
		var timeAll = timeHours + ":" + timeMinute;
		var size = 25;
		var pageInbox = 1;
		$scope.numberOfItemsToDisplay = 25;
		var filterBy = 'all';
		$scope.listAllInbox = [];
		$scope.addNewListInbox = [];
		getListInboxSuccess(GetListInbox);

		function getListInboxSuccess(res) {
			$ionicLoading.hide();
			$scope.moreItemsAvailable = true;
			try {
				if (res.invocationResult.statusCode == 200) {
					if (res.invocationResult.array.length != 0) {
						for (var i = 0; i < res.invocationResult.array.length; i++) {
							var data = {};
							data.opened = res.invocationResult.array[i].opened;
							data.id = res.invocationResult.array[i].id;
							data.userid = res.invocationResult.array[i].userid;
							data.notif = res.invocationResult.array[i].alert;
							var listNotif = res.invocationResult.array[i].payload;
							data.category = listNotif.docList;
							data.reqId = listNotif.reqId;
							data.npa = listNotif.npa;
							data.agentcode = listNotif.agentcode;
							data.module = res.invocationResult.array[i].module;
							data.icon = iconInbox(listNotif.reqId);
							data.time = moment(res.invocationResult.array[i].time_stamp).format("dddd, D MMMM YYYY");
							$scope.listAllInbox.push(data);
						}
						console.log($scope.listAllInbox);
						$scope.dataNotifications = $scope.listAllInbox;
					}
				}

			} catch (error) {
				AppsLog.log(error);
			}
		}

		$scope.loadMore = function () {
			if ($scope.listAllInbox.length < 25) {
				$scope.moreItemsAvailable = false;
			} else {
				AppsLog.log("Enter Loadmore");
				pageInbox += 1;
				getDataFromService();
				$scope.$broadcast('scroll.infiniteScrollComplete');
			}

		};

		function getDataFromService() {
			InboxService.invoke(userId, filterBy, size, pageInbox).then(function (res) {
				getLengthInboxMessageSuccess(res);
			});
		}

		function iconInbox(reqId) {
			var icon;
			var reqIdIcon = $filter('lowercase')(reqId);
			switch (reqIdIcon) {
				case "sign":
					icon = "icon-notif_icons-font_paperclip";
					break;
				case "doc":
					icon = "icon-notif_icons-font_document";
					break;
				case "changemanager":
					icon = "icon-notif_icons-font_document";
					break;
				case "changerecruiter":
					icon = "icon-notif_icons-font_document";
					break;
				case "fs":
					icon = "icon-notif_icons-font_clock";
					break;
				case "aaji":
					icon = "icon-notif_icons-font_calendar";
					break;
				case "ag_done":
					icon = "icon-notif_icons-font_bookmark";
					break;
				case "info":
					icon = "icon-notif_icons-font_bookmark";
					break;
				case "doc_ag":
					icon = "icon-notif_icons-font_document";
					break;
			}

			return icon;

		}
		$scope.DetailNotif = function (params) {
			if (params.opened) {
				$rootScope.AlertDialog($filter('translate')('DATA_HASBEEN_PROCCESSED'));
			} else {
				$rootScope.candidate.detailwithnpa = params.npa;
				$rootScope.candidate.npa = params.npa;
				$ionicLoading.show();
				$rootScope.candidate.statusAgentJourney = 'complete';
				$rootScope.inbox.changemanager = false;
				$rootScope.flagBPMSubmit = false;
				var reqId = $filter('lowercase')(params.reqId);
				switch (reqId) {
					case "sign":
						$rootScope.inbox.reqId = "sign";
						$rootScope.inbox.idInbox = params.id;
						DetailSign(params.npa);
						break;
					case "doc":
						$rootScope.inbox.idInbox = params.id;
						$rootScope.inbox.reqId = "doc";
						$rootScope.flagBPMSubmit = true;
						DetailPendingDoc(params);
						break;
					case "changemanager":
						$rootScope.inbox.idInbox = params.id;
						$rootScope.inbox.changemanager = true;
						$rootScope.inbox.reqId = "changemanager";
						DetailChangeManager(params);
						break;
					case "changerecruiter":
						$rootScope.inbox.reqId = "changerecruiter";
						DetailChangeRecruiter();
						break;
					case "fs":
						DetailFS();
						break;
					case "aaji":
						$rootScope.mandatoryBuktiBayar = false;
						$rootScope.inbox.reqId = "AAJI";
						$rootScope.inbox.idInbox = params.id;
						$rootScope.inbox.senderNotif = params.agentcode;
						$rootScope.inbox.userid = params.userid;
						DetailAAJI();
						break;
					case "ag_done":
						$rootScope.inbox.idInbox = params.id;
						DetailAg_Done(params);
						break;
					case "info":
						$rootScope.inbox.userid = params.userid;
						DetailInfo(params.id);
						break;
					case "doc_ag":
						$rootScope.inbox.idInbox = params.id;
						$rootScope.inbox.reqId = "doc_ag";
						$rootScope.flagBPMSubmit = true;
						DetailPendingDoc(params);
						break;

					/* this start of bacth notification */
					case "news_update":
						DetailNewsUpdate();
						break;
					case "pending_proses_proposal":
						PendingProsesProposal();
						break;
					case "pending_proses_billing":
						PendingProsesBilling();
						break;
					case "pending_proses_perubahan_polis":
						PendingProsesPerubahanPolis();
						break;
					case "pending_proses_klaim":
						PendingProsesKlaim();
						break;
					case "polis_lewat_jatuh_tempo":
						PolisLewatJatuhTempo();
						break;
					case "ulang_tahun":
						UlangTahun();
						break;
					case "contest_detail":
						KontesDetail();
						break;
					case "contest_achieve":
						KontesAchievement(true);
						break;
					case "contest_not_achieve":
						KontesAchievement(false);
						break;
					/* this end of bacth notification*/

				}
			}

		}

		function DetailSign(npa) {
			$ionicLoading.hide();
			SignatureService.signature().addSignatureLeaderRecruiter('');
			$state.go("detail-notification-sign", { 'npa': npa });
		}

		function DetailPendingDoc(params) {
			$rootScope.flagPending = true;
			var pendingdesc = '';
			var count = 0;
			for (var i = 0; i < params.category.length; i++) {
				if (params.category[i] != "" && params.category[i] != undefined && params.category[i] != null) {
					GetListPendingDocService.invoke(params.category[i]).then(function (res) {
						if (res.invocationResult.statusCode == 200) {

							if (res.invocationResult.array.length != 0) {
								var desc = res.invocationResult.array[0].description;
								pendingdesc += ' - ' + desc + '<br>';
								var npaParams = params.npa;

								if ($rootScope.agent.userType == "candidate") {
									npaParams = params.userid;
								}
								count++;
								if (count == params.category.length) {
									getReasonPendingDoc(pendingdesc, npaParams);
								}

							} else {
								$ionicLoading.hide();
							}
						} else {
							$ionicLoading.hide();
						}
					});
				} else {
					count++;
					if (count == params.category.length) {
						getReasonPendingDoc(pendingdesc, npaParams);
					}
				}
			}

		}

		function getReasonPendingDoc(pendingdesc, npa) {
			GetReasonPendingDocService.invoke(npa).then(function (res) {
				$ionicLoading.hide();
				if (res.invocationResult.statusCode == 200) {
					if (res.invocationResult.array.length != 0) {
						var reason = res.invocationResult.array[0].reason;
						$rootScope.flagBPMSubmit = true;
						var pendingState = ['dataKandidatPack'];
						$rootScope.candidate.npa = npa;
						if ($rootScope.agent.userType != "candidate") {
							pendingState = ['detailNotifSign'];
						}
						$rootScope.DialogWithCancel($filter('translate')('PRU_49') + '<br>' + pendingdesc + '<br>' + ' Keterangan : ' + reason, pendingState);
					}
				} else {
				}
			});
		}

		$rootScope.detailNotifSign = function () {
			$state.go("detail-notification-sign", { 'npa': $rootScope.candidate.npa });
		}

		$rootScope.dataKandidatPack = function () {
			$state.go('data-kandidat-pack');
		}

		function DetailChangeManager(params) {

			if ($rootScope.agent.userType != "candidate") {
				var agentCode;
				var npa = params.category[0];

				if ($rootScope.agent.code != undefined && $rootScope.agent.code != null && $rootScope.agent.code != '') {
					agentCode = $rootScope.agent.code;
				} else {
					agentCode = npa;
				}

				var dataCandidateParam = {
					agentId: agentCode,
					npa: npa
				}

				GetAplicationPackService.getDataCandidatePack(dataCandidateParam).then(function (res) {
					$ionicLoading.hide();
					var candidateDataResponse = res.json;
					if (candidateDataResponse.activeCandidate == 'EXPIRED') {
						$rootScope.AlertDialog($filter('translate')('PRU_27'));
					} else if (candidateDataResponse.rejectStatus == 'REJECTED') {
						var msgReject = $filter('translate')('PRU_29');
						if (candidateDataResponse.rejectStatus != null && candidateDataResponse.rejectStatus.indexOf('Recruiter') > 0) {
							msgReject = $filter('translate')('PRU_30');
						}
						$rootScope.AlertDialog(msgReject);
					} else {
						$state.go("detail-notification-sign", { 'npa': npa });
					}
				});
			} else {
				DetailInfo(params.id);
			}

		}

		function DetailChangeRecruiter() {
			$state.go("lembar-persetujuan-tanda-tangan");
		}

		function DetailFS() {
			if ($rootScope.agent.userType == 'candidate') {
				$state.go('data-kandidat-pack');
			} else {
				$state.go('data-kandidat-pack');
			}
		}
		function DetailAAJI() {
			$ionicLoading.hide();
			$state.go("aaji_agent");
		}

		function DetailAg_Done(params) {
			var agentCode = params.category[0];
			$rootScope.agent.agCodeReceived = agentCode;
			$state.go("agentcode-received");
		}

		function DetailInfo(idInbox) {
			UpdateInboxService.invoke(idInbox).then(function (res) {
				$ionicLoading.hide();
				if (res.invocationResult.statusCode == 200) {
					if ($rootScope.agent.userType != "candidate") {
						$state.go('home-menu.agent');
					} else {
						$state.go('home-menu.candidate');
					}
				}
			});
		}

		/* this start of bacth notification */

		function DetailNewsUpdate() {
			$state.go("news_updates");
		}

		function PendingProsesProposal() {
			$state.go("to_do_new_business_pending_requirement", { agentNumber: 0 });
		}

		function PendingProsesBilling() {
			$state.go("to_do_billing_pending_requirement", { agentNumber: 0 });

		}
		function PendingProsesPerubahanPolis() {
			$state.go("to_do_policy_holder_pending_requirement", { agentNumber: 0 });
		}

		function PendingProsesKlaim() {
			$state.go("to_do_claim_pending_requirement", { agentNumber: 0 });

		}

		function PolisLewatJatuhTempo() {
			$state.go("after_due_date", { agentNumber: 0 });

		}

		function UlangTahun() {
			$state.go("customers_birthday", { 'Flag': '2', 'agentNumber': 0 });
		}

		function KontesDetail(contestCode) {
			$state.go("my_contest_detail", { contestCode: contestCode });
		}

		function KontesAchievement(achieve) {
			var defaultContestTab = achieve == true ? 'components/contest/contest_monitoring.html' : 'components/contest/contest_completed.html';
			localStorage.setItem('currentTabContest', defaultContestTab);
			$state.go("contest-tab");
		}

		/* this end of bacth notification*/

		angular.element(document).ready(function () {
		});
	});