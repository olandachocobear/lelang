﻿angular.module('PruForce.services')

    .service('GetReasonPendingDocService', function (CandidateFactory, $q) {

        function invoke(npa) {
            var req = {
                adapter: "HTTPAdapterAuth",
                procedure: "GetReasonPendingDoc",
                method: WLResourceRequest.POST,
                parameters: { "params": "['" + npa + "']" }
            };

            var deferred = $q.defer();

            CandidateFactory.invoke(req, true)
                .then(function (res) {
                    deferred.resolve(res);
                }, function (error) {
                    deferred.reject(error);
                });

            return deferred.promise;
        }

        return {
            invoke: invoke
        }
    });

