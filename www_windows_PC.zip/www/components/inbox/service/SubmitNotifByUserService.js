﻿angular.module('PruForce.services')

    .service('SubmitNotifByUserService', function (AOBResources, $q) {

        function invoke(userId, eventId, token, subtituteParam) {

            var req = {
                adapter: "PUSHNotifAdapter",
                procedure: "sendPushNotifMessage",
                method: WLResourceRequest.POST,
                parameters: { "params": "['" + userId + "','" + eventId + "','" + token + "','" + JSON.stringify(subtituteParam) + "']" }
            };

            var deferred = $q.defer();

            AOBResources.invoke(req, true)
                .then(function (res) {
                    deferred.resolve(res);
                }, function (error) {
                    deferred.reject(error);
                });

            return deferred.promise;
        }

        return {
            invoke: invoke
        }
    });

