﻿angular.module('PruForce.controllers')

	.controller('HomePublicController', function ($scope, $ionicHistory, $ionicSideMenuDelegate, $filter, $translate, $state, $rootScope) {
		$scope.openpdf = function () {
			url = "http://10.170.49.172/download/usermanual-publicpage.pdf";
			$rootScope.openPDF(url);
		}

		$scope.privacyPolicy = function () {
			$state.go("privacy_policy");
		}

		AppsLog.log("START >> HomePublicController " + new Date());
		$ionicSideMenuDelegate.canDragContent(false);

		$scope.goTologin = function () {
			$state.go('login');
		}

		AppsLog.log("END >> HomePublicController " + new Date());
	});