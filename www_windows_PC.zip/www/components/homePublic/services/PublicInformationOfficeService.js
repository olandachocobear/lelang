﻿angular.module('PruForce.services')

	.service('PublicInformationOfficeService', function (DataFactory, $q, $rootScope) {

		function invoke(pageOffice, sizeOffice, filterCityCode, filterPublicInformationSearch) {
			var req = {
				adapter: "HTTPAdapter3",
				procedure: "findPublicInformationOffice",
				method: WLResourceRequest.POST,
				parameters: { "params": "[" + pageOffice + "," + sizeOffice + ",'" + filterCityCode + "','" + filterPublicInformationSearch + "']" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			$rootScope.flagingAlwaysOnline = false;
			return deferred.promise;
		}

		return {
			invoke: invoke
		}
	});

