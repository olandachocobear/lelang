﻿angular.module('PruForce.services')

	.service('PublicInformationHospitalService', function (DataFactory, $q, $rootScope) {

		function invoke(pageHospital, sizeHospital, filterCityCode, filterPublicInformationSearch) {
			var req = {
				adapter: "HTTPAdapter3",
				procedure: "findPublicInformationHospital",
				method: WLResourceRequest.POST,
				parameters: { "params": "[" + pageHospital + "," + sizeHospital + ",'" + filterCityCode + "','" + filterPublicInformationSearch + "']" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			$rootScope.flagingAlwaysOnline = false;
			return deferred.promise;
		}

		return {
			invoke: invoke
		}
	});

