﻿angular.module('PruForce.controllers')
	.controller('NewsUpdateCtrl', function ($scope, $rootScope, $http, $state, $sce, newsListPriorityService, $q) {
		AppsLog.log("START >> NewsUpdateCtrl " + new Date());
		AnalyticsLog.logPage("prudential.comission.est.inq");

		var ListTopThree = [];

		$scope.newsListPriorityService = newsListPriorityService;
		$scope.loading = true;
		$scope.loadingSmall = true;
		$scope.successResult = true;
		$scope.successCall = true;

		$scope.init = function () {
			$scope.loading = true;
			$scope.loadingSmall = true;
			$scope.successResult = true;
			$scope.successCall = true;

			newsListPriorityService.invoke($rootScope.username, $rootScope.agent.code, $rootScope.agent_agentTypeId, true).then(function (res) {
				getTopThreeNewsUpdateSuccess(res);
				$scope.loading = false;
			});
		}

		collection = JsonStoreConfig['newsListPriority'];
		$scope.$on(collection.JSONSTORE_NAME, function (event, args) {
			$scope.successCall = (args.status == "success") ? true : false;

			newsListPriorityService.invoke($rootScope.username, $rootScope.agent.code, $rootScope.agent_agentTypeId, false)
				.then(function (res) {
					getTopThreeNewsUpdateSuccess(res);
					$scope.loading = false;
					$scope.loadingSmall = false;
				}, function () {
					$scope.loading = false;
					$scope.loadingSmall = false;
				});

		});

		$scope.init();

		function getTopThreeNewsUpdateSuccess(result) {

			ListTopThree = [];

			for (var i = 0; i < result.invocationResult.length; i++) {
				
				var dt = {};
				var news_date = new Date(result.invocationResult[i].startPublishDate);

				dt.news_date = moment(news_date).format('DD MMMM YYYY');
				dt.news_time = moment(news_date).format('hh.mm');
				dt.news_id = result.invocationResult[i].id;
				dt.news_title = result.invocationResult[i].title;
				dt.news_image = result.invocationResult[i].imageName;
				dt.news_short_description = result.invocationResult[i].description;
				dt.news_type = result.invocationResult[i].newsTypeId;
				dt.news_attachment = result.invocationResult[i].fileName;
				dt.news_type_icon = "data:image/png;base64," + result.invocationResult[i].newsTypeIcon;
				dt.urutan = i;

				ListTopThree[i] = dt;
			}

			$rootScope.ListNewsMain = [];
			$scope.ListTopThree = ListTopThree;
			$rootScope.ListNewsPriority = ListTopThree;
		}

		$scope.setFirstNews = function (urutan) {
			$rootScope.firstNews = urutan;
		}

		$scope.goToDetail = function(newsId, flag){
			$state.go("news_updates_detail", { "Urutan": newsId, "Flag": flag });
		}
	});
