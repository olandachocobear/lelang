﻿angular.module('PruForce.controllers')
	.controller('NewsUpdateDetailCtrl', function ($scope, $http, $sce, $stateParams, $state, $ionicBackdrop, $ionicModal, $ionicLoading, $ionicSlideBoxDelegate, $ionicScrollDelegate, $rootScope, newsListMobileService, $q, ListImage) {
		AppsLog.log("START >> NewsUpdateDetailCtrl " + new Date());
		AnalyticsLog.logPage("prudential.newsupdate.detail");

		var contestImageUrl = $rootScope.ImageIP + "commonUtils/commonFile/getFile?fileName=";
		var contestImageModule = "&module=newsUpdate";

		$scope.init = function (ListImage) {
			$scope.ListBanner = [];
			if (ListImage != null) {
				for (var i = 0; i < ListImage.invocationResult.content.length; i++) {
					$scope.ListBanner.push({ imgUrl: "data:image/jpeg;base64," + ListImage.invocationResult.content[i] });
				}
			}
		}

		var ListNewsMainDetail = [];

		ListNewsMainDetail = ($stateParams.Flag == "1") ? $rootScope.ListNewsPriority : $rootScope.ListNewsMain;

		$scope.init(ListImage);
		$scope.Flag = $stateParams.Flag;

		var Urutan = parseInt($stateParams.Urutan);
		var Batas = ListNewsMainDetail.length - 1;
		var Next = Urutan + 1;
		var Prev = Urutan - 1;

		$scope.news_id = ListNewsMainDetail[Urutan].news_id;
		$scope.news_title = ListNewsMainDetail[Urutan].news_title;

		var convert_description = ListNewsMainDetail[Urutan].news_short_description;

		convert_description = convert_description.replace(/#product#pru.*?#\/product#/gi, function myFunction(matches) {
			var productName = matches.substring(9, matches.length - 10);
			return $rootScope.productPruFunc(productName);
		}
		);

		convert_description = convert_description.replace(/#product#.*?#\/product#/gi, function myFunction(matches) {
			var productName = matches.substring(9, matches.length - 10);
			return "<em style=\"font-family:garamond-italic\">" + productName + "</em>";
		}
		);

		$scope.news_description = $sce.trustAsHtml(convert_description);
		$scope.news_type = ListNewsMainDetail[Urutan].news_type;
		$scope.news_date = ListNewsMainDetail[Urutan].news_date;
		$scope.news_time = ListNewsMainDetail[Urutan].news_time;
		$scope.news_next_id = (Urutan == Batas) ? '' : Next;
		$scope.news_prev_id = Prev;
		$scope.news_type_icon = ListNewsMainDetail[Urutan].news_type_icon;

		//Attachment
		if (ListNewsMainDetail[Urutan].news_attachment != null && ListNewsMainDetail[Urutan].news_attachment != undefined && ListNewsMainDetail[Urutan].news_attachment != "") {

			var listAtt = []
			var listAttachment = [];
			splAttch = ListNewsMainDetail[Urutan].news_attachment.split(",");


			for (var i = 0; i < splAttch.length; i++) {
				var dt = {};
				dt.Attachment = splAttch[i];
				listAtt[i] = dt;
			}

			for (var k = 0; k < listAtt.length; k++) {
				var dt2 = {};
				var Attachment = (listAtt[k].Attachment != null && listAtt[k].Attachment.indexOf("|")) ? listAtt[k].Attachment.split("|") : null;
				dt2.attachmentID = Attachment ? Attachment[1] : "";
				dt2.attachmentName = Attachment ? Attachment[0] : "pdf";
				listAttachment[k] = dt2;

			}

			$scope.listAttachment = listAttachment;
		}

		$scope.openpdf = function (name, originalName, title) {
			$ionicLoading.show();
			$state.go('common_pdfjs', { fileName: name, originalFileName: originalName, module: "newsUpdate", pageTitle: "PREVIEW", pageLogId: "" });
		}

		$scope.data = {};
    $scope.data.currentPage = 1;

    $scope.zoomMin = 1;

    $scope.showImages = function (index) {
      $scope.activeSlide = index;
      $scope.showModal('components/news_update/zoomSlider.html', index);
    };

    $scope.showModal = function (templateUrl, index) {
      $ionicModal.fromTemplateUrl(templateUrl, {
        scope: $scope
      }).then(function (modal) {
        $scope.modal = modal;
        $scope.imgSrc = $scope.ListBanner[index]
        $scope.modal.show();
      });
    }

    $scope.closeModal = function () {
			angular.element(".news-and-updates").css('height', '0%');
			angular.element(".news-and-updates-details").css('height', '0%');
			$scope.modal.hide();
			$scope.modal.remove();
    };

		$(window).resize(function () {
			$scope.$apply(function () {
				angular.element(".news-and-updates").css('height', '0%');
				angular.element(".news-and-updates-details").css('height', '0%');
			});
    })

    $scope.updateSlideStatus = function (slide) {
      var zoomFactor = $ionicScrollDelegate.$getByHandle('scrollHandle' + slide).getScrollPosition().zoom;
      if (zoomFactor == $scope.zoomMin) {
        $ionicSlideBoxDelegate.enableSlide(true);
      } else {
        $ionicSlideBoxDelegate.enableSlide(false);
      }
    };

    $scope.next = function () {
			$ionicSlideBoxDelegate.next();
    };

    $scope.previous = function () {
			$ionicSlideBoxDelegate.previous();
    };


    var setupSlider = function () {
			//some options to pass to our slider
			$scope.data.sliderOptions = {
				initialSlide: 1,
				direction: 'horizontal', //or vertical
				speed: 300 //0.3s transition
			};
    };

    $ionicSlideBoxDelegate.update();

    $scope.addCountNewsDetail = function (newsId, flag) {
			$rootScope.countNewsDetail = newsId - $rootScope.firstNews;
			$state.go("news_updates_detail", { "Urutan": newsId, "Flag": flag });
    }

		$scope.sliderOptions = {
			autoplay: 2500,
			autoplayDisableOnInteraction: false
		};
		AppsLog.log("END >> NewsUpdateDetailCtrl " + new Date());
	});
