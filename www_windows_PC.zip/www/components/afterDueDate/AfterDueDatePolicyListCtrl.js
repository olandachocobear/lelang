﻿angular.module('PruForce.controllers')
	.controller('AfterDueDatePolicyListCtrl', function ($scope, $rootScope, $ionicLoading, $http, $state, $filter, $stateParams, AfterDueDateDays, AfterDueDatePolicyListService, AfterDueDatePolicyListUnitService) {
		AnalyticsLog.logPage("prudential.AfterDueDatePolicyList");
		AppsLog.log("START >> AfterDueDatePolicyListCtrl with Params >>> " + $stateParams.AgeCategory + ">>>" + new Date());

		var sizeIndividu = 30;
		var pageIndividu = 1;
		var searchByIndividu = '';
		var searchValIndividu = '';
		var searchBy2Individu = '';
		var searchVal2Individu = '';
		var orderByIndividu = '';
		var directionIndividu = 'asc';
		$scope.transaction = [];
		var ListDueDate = [];
		var listIndividuAfterAdd = [];
		var startDay;
		var endDay;
		var AgeCateg = $stateParams.AgeCategory;
		var type;
		$scope.noMoreItemsAvailable = false;
		$scope.numberOfItemsToDisplay = 30;

		$scope.agentNumber = $stateParams.agentNumber;
		$scope.policyHolderNames = {
			data: [{
				id: 0,
				name: $filter('translate')('DEFAULT_SORT')
			},
				{
					id: 1,
					name: $filter('translate')('POLICY_NAME')
				},
				{
					id: 2,
					name: $filter('translate')('POLICY_NUMBER')
				},]
		};

		if (AgeCateg == 5 || AgeCateg == 4) {
			$scope.policyStatusData = {
				data: [{
					id: 0,
					name: $filter('translate')('DEFAULT_SORT_2')
				},
					{
						id: 1,
						name: 'Contract Lapsed'
					}]
			};
		} else {
			$scope.policyStatusData = {
				data: [{
					id: 0,
					name: $filter('translate')('DEFAULT_SORT_2')
				},
					{
						id: 1,
						name: 'In Force'
					}]
			};
		}


		$scope.selected = $scope.policyStatusData.data[0];

		$scope.sortItem = {
			onRequest: $scope.policyHolderNames.data[0]
		};
		if (AgeCateg == 1) {
			startDay = 0;
			endDay = 14;
			type = "inForce";
		} else if (AgeCateg == 2) {
			startDay = 15;
			endDay = 29;
			type = "inForce";
		} else if (AgeCateg == 3) {
			startDay = 30;
			endDay = 44;
			type = "inForce";
		} else if (AgeCateg == 4) {
			startDay = 45;
			endDay = 62;
			type = "Lapsed";
		} else if (AgeCateg == 5) {
			startDay = 63;
			endDay = 729;
			type = "Lapsed";
		}

		$scope.loadMore = function () {
			pageIndividu += 1;
			$scope.showSpinner = true;
			getDataFromService();
			$scope.noMoreItemsAvailable = false;
			$scope.$broadcast('scroll.infiniteScrollComplete');
		};

		$scope.GoSearching_GoFiltering = function () {
			$ionicLoading.show();
			ListDueDate = [];
			sizeIndividu = 30;
			pageIndividu = 1;
			searchValIndividu = ($scope.transaction.searchString == undefined) ? "" : $scope.transaction.searchString.replace(/['|"|\\]/g, "\\$&");
			searchByIndividu = '';

			if ($scope.sortItem.onRequest.id === 0) {
				$scope.descSorted = false;
				orderByIndividu = 'clientName';
			} else if ($scope.sortItem.onRequest.id === 1) {
				$scope.descSorted = false;
				$scope.policyOption = '';
				orderByIndividu = 'clientName';
			} else {
				$scope.descSorted = false;
				$scope.policyOption = 'policyNumber';
				orderByIndividu = 'policyNumber';
			}
			if (searchValIndividu == undefined) {
				searchValIndividu = '';
			}
			$scope.noMoreItemsAvailable = false;
			getDataFromService();
		}

		function getDataFromService() {
			if ($stateParams.agentNumber == 0) {
				AfterDueDatePolicyListService.invoke($rootScope.username, $rootScope.agent.code, type, startDay, endDay, searchValIndividu, orderByIndividu, "ASC", sizeIndividu, pageIndividu)
					.then(function (res) {
						getAfterDueDateDaysListSuccess(res);
					});
			}
			else {
				AfterDueDatePolicyListUnitService.invoke($rootScope.username, $rootScope.agent.code, type, startDay, endDay, searchValIndividu, orderByIndividu, "ASC", sizeIndividu, pageIndividu, $stateParams.agentNumber, "unit")
					.then(function (res) {
						getAfterDueDateDaysListSuccess(res);
					});
			}
		}


		getAfterDueDateDaysListSuccess(AfterDueDateDays);

		function getAfterDueDateDaysListSuccess(result) {
			AppsLog.log("START >> getAfterDueDateDaysListSuccess " + new Date());
			if (result.invocationResult.isSuccessful) {
				var momentDate;

				if (result.invocationResult.array != null) {
					if (ListDueDate.length == 0) {
						ListDueDate = [];
						for (var i = 0; i < result.invocationResult.array.length; i++) {
							var dt = {};

							dt.policyNumber = result.invocationResult.array[i].policyNumber;
							dt.clientName = result.invocationResult.array[i].clientName;
							dt.ownerNumber = result.invocationResult.array[i].ownerNumber;
							dt.agentNumber = result.invocationResult.array[i].agentNumber;
							dt.billingChannel = result.invocationResult.array[i].billingChannel;
							dt.policyStatus = result.invocationResult.array[i].policyStatus;
							dt.paidToDate = moment(result.invocationResult.array[i].paidToDate).format('LL');
							dt.productName = result.invocationResult.array[i].productName;
							ListDueDate[i] = dt;
							pageIndividu = 1;
							var retrieveDate2 = new Date(result.retrieveDate);
							momentDate = moment(retrieveDate2).format('LLLL');
							$scope.lastUpdate = momentDate;
						}
					} else {
						for (var i = 0; i < result.invocationResult.array.length; i++) {
							var dt = {};
							dt.policyNumber = result.invocationResult.array[i].policyNumber;
							dt.clientName = result.invocationResult.array[i].clientName;
							dt.ownerNumber = result.invocationResult.array[i].ownerNumber;
							dt.agentNumber = result.invocationResult.array[i].agentNumber;
							dt.billingChannel = result.invocationResult.array[i].billingChannel;
							dt.policyStatus = result.invocationResult.array[i].policyStatus;
							dt.paidToDate = moment(result.invocationResult.array[i].paidToDate).format('LL');
							dt.productName = result.invocationResult.array[i].productName;
							listIndividuAfterAdd[i] = dt;
							ListDueDate.push(listIndividuAfterAdd[i]);
							$scope.numberOfItemsToDisplay += listIndividuAfterAdd.length;
							var retrieveDate2 = new Date(result.retrieveDate);
							momentDate = moment(retrieveDate2).format('LLLL');
							$scope.lastUpdate = momentDate;
						}
					}
				}
				$scope.ListDueDate = ListDueDate;
				$ionicLoading.hide();
				$scope.showSpinner = false;
				$scope.noMoreItemsAvailable = false;
				if (result.invocationResult.statusCode == 500) {
					$scope.showSpinner = false;
					$ionicLoading.hide();
					$scope.noMoreItemsAvailable = true;
					AppsLog.log("No data found1. Please try again later!");
				}
			} else if (result.invocationResult.statusCode == 500) {
				$scope.showSpinner = false;
				$ionicLoading.hide();
				$scope.noMoreItemsAvailable = true;
				AppsLog.log("No data found2. Please try again later!");
			} else {
				AppsLog.log("No data found. Please try again later!");
			}

			function getAfterDueDate15DaysListFailed(result) {
				$ionicLoading.hide();
				$scope.showSpinner = false;
				AppsLog.log("Data Individu Failed, Please Check Your Connection");
			}
			AppsLog.log("END >> AfterDueDateDaysCtrl " + new Date());
		}
	});