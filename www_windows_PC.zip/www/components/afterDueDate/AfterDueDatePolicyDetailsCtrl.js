﻿
angular.module('PruForce.controllers')
	.controller('AfterDueDatePolicyDetailsCtrl', function ($scope, $rootScope, $ionicLoading, $http, $state, $filter, AfterDueDatePolicyDetails) {

		AnalyticsLog.logPage("prudential.AfterDueDatePolicy.dtl");

		AppsLog.log("START >> AfterDueDatePolicyDetailsCtrl " + new Date());

		getAfterDueDatePolicyDetailsSuccess(AfterDueDatePolicyDetails);


		function getAfterDueDatePolicyDetailsSuccess(result) {

			AppsLog.log("START >> getAfterDueDatePolicyDetailsSuccess " + new Date());
			if (result.invocationResult.isSuccessful) {
				var momentDate;
				if (result.invocationResult != null) {

					$scope.policyNumber = result.invocationResult.policyNumber;
					$scope.clientName = result.invocationResult.clientName;
					$scope.paidToDate = moment(result.invocationResult.paidToDate).format("LL");
					$scope.mobileNumber1 = result.invocationResult.mobileNumber1;
					$scope.mobileNumber2 = result.invocationResult.mobileNumber2;
					$scope.mobileNumber3 = result.invocationResult.mobileNumber3;
					$scope.policyStatus = result.invocationResult.policyStatus;
					$scope.currency = result.invocationResult.currency;
					$scope.paymentMethod = result.invocationResult.paymentMethod;
					$scope.currencySymbol = result.invocationResult.currencySymbol;
					$scope.suspend = Number(result.invocationResult.suspend).formatMoney(2, '.', ',');

					var TOTCOMM4 = Number(result.invocationResult.instalmentPremium);
					$scope.instalmentPremium = TOTCOMM4.formatMoney(2, '.', ',');

					AppsLog.log("CTRL NAME " + $scope.clientName);
					var retrieveDate2 = new Date(result.retrieveDate);
					momentDate = moment(retrieveDate2).format('LLLL');
				}

				$scope.lastUpdate = momentDate;

				AppsLog.log("END >> getAfterDueDatePolicyDetailsSuccess " + new Date());
			}

			function getAfterDueDatePolicyDetailsFailed(result) {
				$ionicLoading.hide();
				AppsLog.log("Data Individu Failed, Please Check Your Connection");
			}

			AppsLog.log("END >> AfterDueDatePolicyDetailsCtrl " + new Date());
		}
	});