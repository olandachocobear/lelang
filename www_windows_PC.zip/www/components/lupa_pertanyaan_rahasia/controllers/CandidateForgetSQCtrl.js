﻿/**
 * 
 */
angular.module('PruForce.controllers')

	.controller('CandidateForgetSQCtrl', function ($scope, $translate, $filter, $rootScope, $ionicLoading, $state, $localStorage, $ionicPopup, CandidateVerifyingDataService) {

		$scope.initModel = {};
		$scope.VerifyCandidateFSQ = function () {
			if ($scope.initModel.npa == undefined || $scope.initModel.nama == undefined || $scope.initModel.idcardno == undefined) {
				$rootScope.AlertDialog($filter('translate')('PRU_05'));
			} else {
				$ionicLoading.show();
				$rootScope.candidate.npa = $scope.initModel.npa;
				$rootScope.candidate.name = $scope.initModel.nama;
				$rootScope.candidate.idcardno = $scope.initModel.idcardno;
				var checksalesforceidflag = "N";
				$rootScope.candidate.checksalesforceidflag = checksalesforceidflag;
				CandidateVerifyingDataService.invoke($scope.initModel.npa, $scope.initModel.nama, $scope.initModel.idcardno, checksalesforceidflag).then(function (res) {
					VerifyCandidateFSQSuccess(res);
				});
			}

		}

		function VerifyCandidateFSQSuccess(res) {
			$ionicLoading.hide();
			if (res.invocationResult.respCode == 200) {
				$state.go("verifikasi-sms", { 'smsType': 'ForgetSecurityQuestion', 'userType': 'candidate' });
			} else {
				$rootScope.AlertDialog($filter('translate')('PRU_24'));
			}
		}


	})