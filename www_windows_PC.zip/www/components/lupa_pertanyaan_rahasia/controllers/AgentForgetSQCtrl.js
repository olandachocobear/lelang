﻿/**
 * 
 */
angular.module('PruForce.controllers')

	.controller('AgentForgetSQCtrl', function ($scope, $rootScope, $translate, $filter, $ionicLoading, $state, $localStorage, $ionicPopup, AgentVerifyingDataService, CheckIDEmailService) {

		$scope.flagShowPlaceHolder = true;
		$scope.removeClass = function ($event) {
			$scope.flagShowPlaceHolder = false;
		}
		$scope.checkDate = function ($event) {
			if ($scope.initModel.dob == undefined || $scope.initModel.dob == '') {
				$scope.flagShowPlaceHolder = true;
			}
		}

		$scope.initModel = {};

		$scope.VerifyAgentFSQ = function () {
			if ($scope.initModel.agentCode == undefined || $scope.initModel.idcardno == undefined || $scope.initModel.dob == undefined || $scope.initModel.phonenumber == undefined) {
				$rootScope.AlertDialog($filter('translate')('PRU_05'));
			} else {
				$ionicLoading.show();
				$rootScope.agent.code = $scope.initModel.agentCode;
				$rootScope.agent.idcardno = $scope.initModel.idcardno;
				$rootScope.agent.dob = $scope.initModel.dob;
				$rootScope.agent.phonenumber = $scope.initModel.phonenumber;
				var dateOfBirth = $filter('date')($scope.initModel.dob, 'yyyy-MM-dd');
				AgentVerifyingDataService.invoke($scope.initModel.agentCode, $scope.initModel.idcardno, dateOfBirth, $scope.initModel.phonenumber).then(function (res) {
					VerifyAgentForgetSQSuccess(res);
				});
			}
		}

		function VerifyAgentForgetSQSuccess(result) {
			if (result.invocationResult.respCode == 200) {
				CheckIDEmailDataAgent();
			} else {
				$ionicLoading.hide();
				$rootScope.AlertDialog($filter('translate')('PRU_25'));
			}

		}

		function CheckIDEmailDataAgent() {
			CheckIDEmailService.invoke($rootScope.agent.code, $rootScope.userType).then(function (res) {
				CheckIDEmailAgentDataSuccess(res);
			});
		}

		function CheckIDEmailAgentDataSuccess(res) {
			$ionicLoading.hide();
			if (res.invocationResult.statusCode == 200) {
				$rootScope.agent.email_agent = res.invocationResult.email;
				$state.go("verifikasi-sms", { 'smsType': 'ForgetSecurityQuestion', 'userType': 'agent' });
			} else {
				$rootScope.AlertDialog($filter('translate')('PRU_39'));

			}
		}
	});