﻿/**
 * 
 */
angular.module('PruForce.controllers')
	.controller('CandidateHomeCtrl', function ($scope, $translate, $rootScope, $ionicSideMenuDelegate, $state, $ionicLoading, $ionicPopup, $localStorage, $filter, getCreateDate) {

		$ionicLoading.hide();
		var data = $rootScope.candidate.agentjourney;
		var agCount = $rootScope.candidate.countagentjourney;

		getCreateDateSuccess(getCreateDate);
		function getCreateDateSuccess(res) {
			try {
				if (res[0].result != undefined) {
					$scope.dateSubmit = moment(res[0].result.createdate).format('LL');
				}
			} catch (error) {
				console.log(error);
			}
		}
		if (data.length != 0 && agCount != 0 || localStorage['CandidateSubmit' + $rootScope.candidate.npa]) {
			$scope.status_data_kandidat = $filter('translate')('THREE');
			$scope.DataKandidatDate = $scope.dateSubmit;
			$scope.DokumenPendukungDate = $scope.dateSubmit;
			$scope.SyaratdanKetentuanDate = $scope.dateSubmit;
			$scope.status_kode_etik = $filter('translate')('TWO');
			$scope.status_ujian = $filter('translate')('DONE');
			$scope.status_training = $filter('translate')('DONE');
			$scope.icon_status_kode_etik = "ion-ios-checkmark balanced";
			$scope.icon_status_ujian = "ion-ios-checkmark balanced";
			$scope.icon_status_training = "ion-ios-checkmark balanced";
			$scope.icon_status_data_kandidat = "ion-ios-checkmark balanced";
			$scope.icon_status_document = "ion-ios-checkmark balanced";
			$scope.icon_status_syarat_ketentuan = "ion-ios-checkmark balanced";
		} else {
			$scope.status_data_kandidat = $filter('translate')('UNDONE');
			$scope.DataKandidatDate = $filter('translate')('UNDONE');
			$scope.DokumenPendukungDate = $filter('translate')('UNDONE');
			$scope.SyaratdanKetentuanDate = $filter('translate')('UNDONE');
			$scope.icon_status_data_kandidat = "ion-ios-close assertive";
			$scope.icon_status_document = "ion-ios-close assertive";
			$scope.icon_status_syarat_ketentuan = "ion-ios-close assertive";
			$scope.status_ujian = $filter('translate')('UNSTARTED');
			if (localStorage['AML' + $rootScope.candidate.npa]) {
				$scope.status_kode_etik = $filter('translate')('ONE');
				$scope.status_training = $filter('translate')('DONE');
				$scope.icon_status_training = "ion-ios-checkmark balanced";
				$scope.icon_status_kode_etik = "ion-ios-information energized";
				$scope.icon_status_ujian = "ion-ios-close assertive";

				if ($rootScope.candidate.UjianKodeEtikFlag) {
					$scope.status_kode_etik = $filter('translate')('TWO');
					$scope.status_ujian = $filter('translate')('DONE');
					$scope.icon_status_kode_etik = "ion-ios-checkmark balanced";
					$scope.icon_status_ujian = "ion-ios-checkmark balanced";
				}
			} else {
				$scope.icon_status_kode_etik = "ion-ios-close assertive";
				$scope.icon_status_ujian = "ion-ios-close assertive";
				$scope.icon_status_training = "ion-ios-close assertive";
				$scope.status_kode_etik = $filter('translate')('ZERO');
				$scope.status_training = $filter('translate')('UNSTARTED');
			}
		}

	})