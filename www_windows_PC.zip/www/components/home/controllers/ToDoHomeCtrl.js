﻿angular.module('PruForce.controllers')
	.controller('ToDoHomeCtrl', function ($state, $translate, $scope, $rootScope, findTotalTodoService, $q) {
		$scope.loading = true;
		$scope.successCall = true;

		$scope.findTotalTodoService = findTotalTodoService;

		$scope.init = function () {
			$scope.loading = true;
			$scope.successCall = true;
			findTotalTodoService.invoke($rootScope.agent.code, $rootScope.username, true).then(function (res) {
				getTotalTodo(res);
				$scope.loading = false;
			});
		}

		collection = JsonStoreConfig['findTotalTodo'];
		$scope.$on(collection.JSONSTORE_NAME, function (event, args) {
			$scope.successCall = (args.status == "success") ? true : false;

			var qfindTotalTodoService = findTotalTodoService.invoke($rootScope.agent.code, $rootScope.username, false).then(function (res) {
				getTotalTodo(res);
			});

			$q.all([qfindTotalTodoService]).then(function () {
				$scope.loadingSmall = false;
				$scope.loading = false;
			});
		});

		$scope.init();

		function getTotalTodo(result) {
			if (result.invocationResult.isSuccessful) {
				$scope.TotalTodo = result.invocationResult.total;
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}

		$scope.goToDoList = function(){
			$state.go("to_do");
		}

	})