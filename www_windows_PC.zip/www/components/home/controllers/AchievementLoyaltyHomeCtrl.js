﻿angular.module('PruForce.controllers')
	.controller('AchievementLoyaltyHomeCtrl', function ($scope, $rootScope, AchievementLoyaltyHomeService, $q) {
		AppsLog.log("START >> AchievementLoyaltyHomeCtrl " + new Date());
		$scope.bonus = 0;
		$scope.bonusRate = "";
		$scope.lastUpdatedTime = "";
		$scope.targetCollectionRate = "";
		$scope.actualCollectionRate = "";
		var lastUpdatedTimeTemp = "";

		$scope.loading = true;
		$scope.loadingSmall = true;
		$scope.successCall = true;
		$scope.successResult = true;

		$scope.AchievementLoyaltyHomeService = AchievementLoyaltyHomeService;

		$scope.init = function () {
			$scope.loading = true;
			$scope.loadingSmall = true;
			$scope.successCall = true;
			$scope.successResult = true;

			AchievementLoyaltyHomeService.invoke($rootScope.username, $rootScope.agent.code, $rootScope.agent.code, $rootScope.periodMonth, $rootScope.periodYear, true)
				.then(function (res) {
					getDataAchievementLoyaltyCtrlSuccess(res);
					$scope.loading = false;
				});
		}

		collection = JsonStoreConfig['findBonusTahun'];
		$scope.$on(collection.JSONSTORE_NAME, function (event, args) {
			$scope.successCall = (args.status == "success") ? true : false;

			var qAchievementLoyaltyHomeService = AchievementLoyaltyHomeService.invoke($rootScope.username, $rootScope.agent.code, $rootScope.agent.code, $rootScope.periodMonth, $rootScope.periodYear, false)
				.then(function (res) {
					getDataAchievementLoyaltyCtrlSuccess(res);
				});

			$q.all([qAchievementLoyaltyHomeService]).then(function () {
				$scope.loading = false;
				$scope.loadingSmall = false;
			});
		});

		$scope.init();

		function getDataAchievementLoyaltyCtrlSuccess(result) {
			if (result.invocationResult.statusCode == 200) {
				var vBonus = Number(result.invocationResult.bonus);
				$scope.bonus = vBonus.formatMoney(2, '.', ',');
				$scope.bonusRate = result.invocationResult.bonusRate;
				lastUpdatedTimeTemp = new Date(result.invocationResult.lastUpdatedTime);
				if (lastUpdatedTimeTemp != undefined) {
					var lastUpdatedTimeTemp = moment(lastUpdatedTimeTemp).format('LLLL');
					$scope.lastUpdatedTime = lastUpdatedTimeTemp;
				}
				$scope.targetCollectionRate = result.invocationResult.targetCollectionRate;
				$scope.actualCollectionRate = result.invocationResult.actualCollectionRate;
			} else {
				$scope.successResult = false;
			}
		}

		var flagBonus = localStorage.getItem("flagBonus");
		if (flagBonus == "true") {
			$scope.statusBonusAchievement = true;
		} else {
			$scope.statusBonusAchievement = false;
		}
		AppsLog.log("END >> AchievementLoyaltyHomeCtrl " + new Date());
	})