﻿angular.module('PruForce.controllers')

	.controller('HomeListCtrl', function ($scope, $rootScope, $timeout, $state, $stateParams, $ionicSideMenuDelegate, $translate, FindUserApplicationConfigService, getDisclaimerConfigService, UpdateDisclaimerConfigService, $ionicPopup, $ionicLoading) {
		AppsLog.log("START >> HomeListCtrl " + new Date());
		$scope.reload = function () {

			AppsLog.log("START >> reload " + new Date());

			$('#rightNotif').removeClass('hide');
			AppsLog.log("state  ada ya" + $state.Current);
			$state.go("home", $stateParams, {
				inherit: false,
				notify: true
			});
			$("#AgName").html($rootScope.userLoginName);
			AppsLog.log("TEST CORRY");
			AppsLog.log("TEST CORRY 2" + g_agentdetail.isretaker);
			if (g_agentdetail.isretaker) {
				checkingIsRetaker($rootScope.agent.code);
			}

			AppsLog.log("END >> reload " + new Date());

		}

		$scope.loadAfterLogin = function () {

			AppsLog.log("START >> loadAfterLogin " + new Date());

			$state.go("home", $stateParams, {
				reload: true,
				inherit: false,
				notify: true
			});
			$("#AgName").html($rootScope.userLoginName);
			if (g_agentdetail.isretaker) {
				checkingIsRetaker($rootScope.agent.code);
			}

			AppsLog.log("END >> loadAfterLogin " + new Date());
		}

		$scope.achievement = function () {
			$('#rightNotif').removeClass('hide');
			$state.go("achievement_landing");
			$ionicSideMenuDelegate.toggleLeft();
		}

		$scope.newsUpdates = function () {
			$('#rightNotif').removeClass('hide');
			$state.go("news_updates");
			$ionicSideMenuDelegate.toggleLeft();
		}

		$scope.Settings = function () {
			$state.go("settings");
			$ionicSideMenuDelegate.toggleLeft();
		}

		$scope.faq = function () {
			$state.go("faq");
			$ionicSideMenuDelegate.toggleLeft();
		}
		$scope.inquiry = function () {
			AppsLog.log("masuk inquiry");
			$state.go("inquiry");
			$ionicSideMenuDelegate.toggleLeft();
		}
		$scope.agenProfile = function () {
			$state.go("agent_profile");
			$ionicSideMenuDelegate.toggleLeft();
		}

		$scope.userManual = function () {
			$state.go("public_page_daftar_informasi");
			$ionicSideMenuDelegate.toggleLeft();
		}

		$scope.initConfiguration = function () {
			AppsLog.log("START >> initConfiguration " + new Date());
			FindUserApplicationConfigService.invoke($rootScope.agent.code).then(function (res) {
				FindUserApplicationConfigListSuccess(res);
			});

			function FindUserApplicationConfigListSuccess(result) {
				if (result.invocationResult.isSuccessful) {
					ListUserAppConfig = [];


					for (var i = 0; i < result.invocationResult.resultSet.length; i++) {
						var dt = {};
						dt.userId = result.invocationResult.resultSet[i].id_user;
						dt.appConfId = result.invocationResult.resultSet[i].id_appconf;
						dt.valueConf = result.invocationResult.resultSet[i].val;
						ListUserAppConfig[i] = dt;
					}
					$translate.use(ListUserAppConfig[0].valueConf);
					var localeString = ListUserAppConfig[0].valueConf.substring(0, 2);
					moment.locale(localeString);
				}

				function UpdateWidgetToggleConfigListFailed(result) {
					AppsLog.log("Data Bank Failed, Please Check Your Connection");
				}
			}
			AppsLog.log("END >> initConfiguration " + new Date());
		}

		$scope.closeDisclaimer = function () {
			$rootScope.alertPopup.close();

			UpdateDisclaimerConfigService.update(username).then(function (res) {
				AppsLog.log("update disclaimer berhasil");
				AppsLog.log(res);
			}, function (error) {
				AppsLog.log("Error");
				AppsLog.log(error);
			}
			);

		}

		$scope.doRefresh = function () {

			AppsLog.log('Refreshing!');
			$timeout(function () {
				//simulate async response
				$('#rightNotif').removeClass('hide');
				AppsLog.log("state  ada ya" + $state.Current);
				$state.go("home", $stateParams, {
					inherit: false,
					notify: true
				});
				$("#AgName").html($rootScope.userLoginName);
				AppsLog.log("TEST CORRY");
				AppsLog.log("TEST CORRY 2" + g_agentdetail.isretaker);
				if (g_agentdetail.isretaker) {
					checkingIsRetaker($rootScope.agent.code);
				}
				//Stop the ion-refresher from spinning
				$scope.$broadcast('scroll.refreshComplete');

			}, 1000);

		};

		if ($ionicLoading.show()) {
			$ionicLoading.hide();
		}

		AppsLog.log("END >> HomeListCtrl " + new Date());
	});

