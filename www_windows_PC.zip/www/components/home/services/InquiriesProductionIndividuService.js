﻿angular.module('PruForce.services')
	.service('InquiriesProductionIndividuService', function (DataFactory, $q) {
		function invoke(agentNumber, pruforceId) {
			AppsLog.log("Test Invoke InquiriesProductionIndividuService");
			var req = {
				adapter: "HTTPAdapter3",
				procedure: "findMTDYTDProductionIndividuByAgentNumber",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + agentNumber + "','" + pruforceId + "']" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, false)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invoke: invoke
		}
	});

