﻿angular.module('PruForce.services')
	.service('UserBonusService', function (DataFactoryOffline, $q) {
		function invoke(salesforceId, agentCode) {
			var req = {
				adapter: "HTTPAdapter3",
				procedure: "findUserBonus",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + salesforceId + "','" + agentCode + "']" }
			};

			var deferred = $q.defer();

			DataFactoryOffline.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}
		return {
			invoke: invoke
		}
	});