﻿/**
 * 
 */

angular.module('PruForce.controllers')
	.controller('GroupUnitPersistencyCtrl', function ($scope, $state, $stateParams, $interval, $http, $rootScope, $ionicLoading, $filter, ListData, ListFilter, GroupUnitPersistencyService) {
		AnalyticsLog.logPage("prudential.persistency.groupunit");
		var size = 30;
		var page = 1;
		var filterBy = "";
		var filterVal = "";
		var searchVal = "";
		var sortBy = "";
		var sortVal = "";

		$scope.transaction = [];
		$scope.noMoreItemsAvailable = false;
		$scope.numberOfItemsToDisplay = 30;

		var listDataAll = [];

		$scope.titleHeader = ($stateParams.persistencyCode == "U") ? $filter('translate')('PERSISTENCY_UNIT') : $filter('translate')('PERSISTENCY_GROUP');
		$scope.persistencyCode = $stateParams.persistencyCode;

		$scope.loadMore = function () {
			page += 1;
			$scope.showLoading = true;
			$scope.numberOfItemsToDisplay += size;
			getDataFromService();
			$scope.$broadcast('scroll.infiniteScrollComplete');
		};

		$scope.GoFiltering = function () {
			$ionicLoading.show();
			page = 1;
			listDataAll = [];
			searchVal = ($scope.transaction.searchString == undefined) ? "" : $scope.transaction.searchString.replace(/['|"|\\]/g, "\\$&");

			if ($scope.filterItem.onRequest.group == "Tingkat Agen") {
				filterBy = "agentType";
				filterVal = $scope.filterItem.onRequest.key;
			} else if ($scope.filterItem.onRequest.group == $filter('translate')('OLD_PERSISTENCY')) {
				filterBy = "current";
				filterVal = $scope.filterItem.onRequest.key;
			} else if ($scope.filterItem.onRequest.group == $filter('translate')('ROLLING_PERSISTENCY')) {
				filterBy = "rolling";
				filterVal = $scope.filterItem.onRequest.key;
			} else {
				filterBy = "";
				filterVal = "";
			}

			if ($scope.sortItem.onRequest.group == $filter('translate')('OLD_PERSISTENCY')) {
				sortBy = "current";
				sortVal = $scope.sortItem.onRequest.key;
			} else if ($scope.sortItem.onRequest.group == $filter('translate')('ROLLING_PERSISTENCY')) {
				sortBy = "rolling";
				sortVal = $scope.sortItem.onRequest.key;
			} else {
				sortBy = "";
				sortVal = "";
			}

			if (searchVal == undefined) {
				searchVal = "";
			}
			getDataFromService();
		}

		function addList(array, data, group_label) {
			var arrayList = array;
			if (data.length > 0) {
				for (var i = 0; i < data.length; i++) {
					var list = {};
					list["value"] = data[i].value;
					list["key"] = data[i].key;
					list["group"] = group_label;
					arrayList.push(list);
				}
			}
			return arrayList;
		}

		function setListData(result) {
			if (result.invocationResult.isSuccessful) {

				var retrieveDate = new Date(result.invocationResult.date);
				momentDate = moment(retrieveDate).format('LLLL');
				$scope.getDate = momentDate == "Invalid date" ? "" : momentDate;

				var dataArray = result.invocationResult.result;
				if (dataArray != null) {
					for (var i = 0; i < dataArray.length; i++) {
						listDataAll.push(dataArray[i]);
					}
				}
				$scope.getListData = listDataAll;
				$scope.showLoading = false;
				$ionicLoading.hide();
				$scope.noMoreItemsAvailable = false;
				if (result.invocationResult.statusCode == 500 || dataArray.length == 0) {
					$ionicLoading.hide();
					$scope.noMoreItemsAvailable = true;
					AppsLog.log("No data found1. Please try again later!");
				}
			} else if (result.invocationResult.statusCode == 500) {
				$scope.showLoading = false;
				$ionicLoading.hide();
				$scope.noMoreItemsAvailable = true;
				AppsLog.log("No data found2. Please try again later!");
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}

		function setListFilter(result) {
			if (result.invocationResult.isSuccessful) {
				var listFilter = [];

				var AgentType = result.invocationResult.AgentType;
				var Current = result.invocationResult.Current;
				var Rolling = result.invocationResult.Rolling;

				var Default = [];
				var listDefault = {};
				listDefault["key"] = "";
				listDefault["value"] = $filter('translate')('SHOW_ALL');
				Default.push(listDefault);

				listFilter = addList(listFilter, Default, "");
				if (AgentType.length > 0) {
					listFilter = addList(listFilter, AgentType, "Tingkat Agen");
				}
				if (Current.length > 0) {
					listFilter = addList(listFilter, Current, $filter('translate')('OLD_PERSISTENCY'));
				}
				if (Rolling.length > 0) {
					listFilter = addList(listFilter, Rolling, $filter('translate')('ROLLING_PERSISTENCY'));
				}



				$scope.getListFilter = listFilter;
				$scope.filterItem = {
					onRequest: $scope.getListFilter[0]
				}
			} else if (result.invocationResult.statusCode == 500) {
				$ionicLoading.hide();
				AppsLog.log("No data found2. Please try again later!");
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}

		function getDataFromService() {
			GroupUnitPersistencyService.invokeData(page, size,
				$rootScope.agent.code, $rootScope.agent.code, filterBy, filterVal, searchVal, sortBy, sortVal,
				$rootScope.username, $rootScope.agent.code,
				$stateParams.persistencyCode, $stateParams.period).then(function (res) {
					setListData(res);
					$ionicLoading.hide();
				}, function (error) {
					AppsLog.log("no more page");
					$scope.showLoading = false;
					$ionicLoading.hide();
				});
		}

		setListData(ListData);

		setListFilter(ListFilter);

		listSortData = [];

		var Default = [];
		var listDefault = {};
		listDefault["key"] = "";
		listDefault["value"] = "Default";
		Default.push(listDefault);
		listSortData = addList(listSortData, Default, "");

		var Sort = [];
		var listSort = {};
		listSort["key"] = "PrsctyDesc";
		listSort["value"] = $filter('translate')('HIGHEST_APE');
		Sort.push(listSort);
		listSort = {};
		listSort["key"] = "PrsctyAsc";
		listSort["value"] = $filter('translate')('LOWEST_APE');
		Sort.push(listSort);
		listSort = {};
		listSort["key"] = "LapsedApi";
		listSort["value"] = $filter('translate')('HIGHEST_LAPSED_API');
		Sort.push(listSort);
		listSort = {};
		listSort["key"] = "DecreasedApi";
		listSort["value"] = $filter('translate')('HIGHEST_DECREMENT_API');
		Sort.push(listSort);

		listSortData = addList(listSortData, Sort, $filter('translate')('OLD_PERSISTENCY'));
		listSortData = addList(listSortData, Sort, $filter('translate')('ROLLING_PERSISTENCY'));

		$scope.getListSort = listSortData;
		$scope.sortItem = {
			onRequest: $scope.getListSort[0]
		}
	})