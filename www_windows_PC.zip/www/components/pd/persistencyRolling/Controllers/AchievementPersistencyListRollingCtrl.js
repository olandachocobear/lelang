﻿/**
 * 
 */

angular.module('PruForce.controllers').controller('AchievementPersistencyListRollingCtrl', function ($scope, $rootScope, $ionicLoading, $state, $stateParams, $interval, $http, $filter, AchievementPersistencyListService) {

	$scope.init = function (ListDataRolling, ListFilterRolling) {
		setListDataRolling(ListDataRolling);
		setListFilterRolling(ListFilterRolling);
	}

	var size = 30;
	var pageRolling = 1;

	var filterBy = "";
	var filterVal = "";
	var searchVal = "";
	var sortVal = "";

	var listDataRolling = [];

	$scope.transaction = [];
	$scope.noMoreItemsAvailable = false;
	$scope.numberOfItemsToDisplayRolling = 30;

	$scope.GoSearchRolling = function () {
		$ionicLoading.show();
		pageRolling = 1;
		listDataRolling = [];
		searchVal = $scope.transaction.searchStringRolling;

		if ($scope.filterItemRolling.onRequest.group == "Status Polis") {
			filterBy = "PolicyStatus";
			filterVal = $scope.filterItemRolling.onRequest.key;
		} else if ($scope.filterItemRolling.onRequest.group == "API") {
			filterBy = "API";
			filterVal = $scope.filterItemRolling.onRequest.key;
		} else {
			filterBy = "";
			filterVal = "";
		}

		sortVal = $scope.sortItemRolling.onRequest.key;

		if (searchVal == undefined) {
			searchVal = "";
		}
		getDataRollingFromService();
	}

	$scope.loadMoreRolling = function () {
		pageRolling += 1;
		$scope.showLoading = true;
		$scope.numberOfItemsToDisplayRolling += size;
		getDataRollingFromService();
		$scope.$broadcast('scroll.infiniteScrollComplete');
	};

	function addList(array, data, group_label) {
		var arrayList = array;
		if (data.length > 0) {
			for (var i = 0; i < data.length; i++) {
				var list = {};
				list["value"] = data[i].value;
				list["key"] = data[i].key;
				list["group"] = group_label;
				arrayList.push(list);
			}
		}
		return arrayList;
	}

	listSortData = [];

	var Default = [];
	var listDefault = {};
	listDefault["key"] = "";
	listDefault["value"] = "Default";
	Default.push(listDefault);
	listSortData = addList(listSortData, Default, "");

	var Sort = [];
	var listSort = {};
	listSort["key"] = "policyHolderName";
	listSort["value"] = $filter('translate')('POLICY_NAME');
	Sort.push(listSort);
	listSort = {};
	listSort["key"] = "policyNumber";
	listSort["value"] = $filter('translate')('POLICY_NUMBER');
	Sort.push(listSort);
	listSort = {};
	listSort["key"] = "lapsedApi";
	listSort["value"] = $filter('translate')('HIGHEST_LAPSED_API');
	Sort.push(listSort);
	listSort = {};
	listSort["key"] = "decreasedApi";
	listSort["value"] = $filter('translate')('HIGHEST_DECREMENT_API');
	Sort.push(listSort);
	listSortData = addList(listSortData, Sort, "");

	$scope.getListSortRolling = listSortData;
	$scope.sortItemRolling = {
		onRequest: $scope.getListSortRolling[0]
	}

	function setListFilterRolling(result) {
		if (result.invocationResult.isSuccessful) {
			var listFilter = [];

			var PolicyStatus = result.invocationResult.PolicyStatus;
			var API = result.invocationResult.API;

			var Default = [];
			var listDefault = {};
			listDefault["key"] = "";
			listDefault["value"] = $filter('translate')('SHOW_ALL');
			Default.push(listDefault);

			listFilter = addList(listFilter, Default, "");
			if (PolicyStatus.length > 0) {
				listFilter = addList(listFilter, PolicyStatus, "Status Polis");
			}
			if (API.length > 0) {
				listFilter = addList(listFilter, API, "API");
			}

			$scope.getListFilterRolling = listFilter;
			$scope.filterItemRolling = {
				onRequest: $scope.getListFilterRolling[0]
			}
		} else if (result.invocationResult.statusCode == 500) {
			$ionicLoading.hide();
			AppsLog.log("No data found2. Please try again later!");
		} else {
			AppsLog.log("No data found. Please try again later!");
		}
	}

	function setListDataRolling(result) {
		if (result.invocationResult.isSuccessful) {
			var dataArray = result.invocationResult.result;
			if (dataArray != null) {
				for (var i = 0; i < dataArray.length; i++) {
					listDataRolling.push(dataArray[i]);
				}
			}
			$scope.getListRolling = listDataRolling;

			var retrieveDate2 = new Date(result.invocationResult.date);
			momentDate = moment(retrieveDate2).format('LLLL');
			$scope.getDateRolling = momentDate == "Invalid date" ? "" : momentDate;

			$scope.showLoading = false;
			$ionicLoading.hide();
			$scope.noMoreItemsAvailable = false;
			if (result.invocationResult.statusCode == 500 || dataArray.length == 0) {
				$ionicLoading.hide();
				$scope.noMoreItemsAvailable = true;
				AppsLog.log("No data found1. Please try again later!");
			}
		} else if (result.invocationResult.statusCode == 500) {
			$scope.showLoading = false;
			$ionicLoading.hide();
			$scope.noMoreItemsAvailable = true;
			AppsLog.log("No data found2. Please try again later!");
		} else {
			AppsLog.log("No data found. Please try again later!");
		}
	}

	function getDataRollingFromService() {
		AchievementPersistencyListService.invokeDataRolling(
			pageRolling,
			size,
			($stateParams.agentNumber == "") ? $rootScope.agent.code : $stateParams.agentNumber, filterBy, filterVal, searchVal, sortVal,
			$rootScope.username, $rootScope.agent.code,
			$stateParams.period).then(function (res) {
				setListDataRolling(res);
				$ionicLoading.hide();
			}, function (error) {
				AppsLog.log("no more page");
				$scope.showLoading = false;
				$ionicLoading.hide();
			});
	}

	$scope.changePage = function (id) {
		var pageType = ($stateParams.agentNumber == "") ? "" : "unit";
		AppsLog.log(pageType);
		$state.go('inquiries_proposal_policy_details', {
			policyNumber: id,
			Type: "2",
			agentNumber: ($stateParams.agentNumber == "") ? $rootScope.agent.code : $stateParams.agentNumber,
			PageType: pageType
		});
	}
})