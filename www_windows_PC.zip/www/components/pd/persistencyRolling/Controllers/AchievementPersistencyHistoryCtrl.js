﻿/**
 * 
 */

angular.module('PruForce.controllers').controller('AchievementPersistencyHistoryCtrl', function ($scope, $state, $stateParams, $interval, $http, $filter, ListData) {
	AnalyticsLog.logPage("prudential.persistency.history");
	$scope.toggleGroup = function (group) {
		if ($scope.isGroupShown(group)) {
			$scope.shownGroup = null;
		} else {
			$scope.shownGroup = group;
		}
	};
	$scope.isGroupShown = function (group) {
		return $scope.shownGroup === group;
	};

	setListData(ListData);
	function setListData(result) {
		if (result.invocationResult.isSuccessful) {
			$scope.data = result.invocationResult;

			var retrieveDate = new Date(result.invocationResult.date);
			momentDate = moment(retrieveDate).format('LLLL');
			$scope.lastUpdate = momentDate == "Invalid date" ? "" : momentDate;
		}
	}

	$scope.persistencyCode = $stateParams.persistencyCode;

	$scope.changePage = function (persistencyCode, agentNumber, period) {
		if (persistencyCode == "I") {
			$state.go('achievement_persistency_list', {
				agentNumber: agentNumber,
				period: period
			});
		} else {
			$state.go('group_unit_persistency', {
				persistencyCode: persistencyCode,
				period: period
			});
		}
	}
})