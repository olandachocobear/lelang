﻿/**
 * 
 */

angular.module('PruForce.controllers')


	.controller("PersistencyCRCtrl", function ($scope, $rootScope, $state, $q, $filter, AchievementPersistencyService) {
		$scope.loading = true;
		$scope.loadingSmall = true;
		$scope.successCall = true;
		$scope.successResult = true;

		function setListData(result) {

			var retrieveDate = new Date(result.invocationResult.date);
			momentDate = moment(retrieveDate).format('LLLL');
			$scope.lastUpdate = momentDate == "Invalid date" ? "" : momentDate;

			$scope.data = result.invocationResult;
			if (result.invocationResult.statusCode == 200) {
				$scope.Individu = result.invocationResult.Individu;
				$scope.Unit = result.invocationResult.Unit;
				$scope.Group = result.invocationResult.Group;
			}
		}
		$scope.init = function () {
			$scope.loading = true;
			$scope.loadingSmall = true;
			$scope.successCall = true;
			$scope.successResult = true;

			AchievementPersistencyService.invokePersistency($rootScope.agent.code, $rootScope.username, $rootScope.agent.code, true).then(function (res) {
				setListData(res)
				$scope.loading = false;
			});
		}

		collection = JsonStoreConfig['findPersistencyGraphCR'];
		$scope.$on(collection.JSONSTORE_NAME, function (event, args) {
			$scope.successCall = (args.status == "success") ? true : false;

			var qAchievementPersistencyService = AchievementPersistencyService.invokePersistency($rootScope.agent.code, $rootScope.username, $rootScope.agent.code, false).then(function (res) {
				setListData(res);
			});

			$q.all([qAchievementPersistencyService]).then(function () {
				$scope.loadingSmall = false;
				$scope.loading = false;
			});
		});

		$scope.init();
	})