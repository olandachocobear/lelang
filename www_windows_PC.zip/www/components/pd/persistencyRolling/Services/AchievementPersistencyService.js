﻿/**
 * 
 */

angular.module('PruForce.services')
	.service('AchievementPersistencyService', function (DataFactoryOffline, DataFactory, $q) {
		function invokePersistency(agentNumber, salesforceId, agentCode, callservice) {
			var req = {
				adapter: "HTTPAdapterInquiry",
				procedure: "findPersistencyGraphCR",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + agentNumber + "','" + salesforceId + "','" + agentCode + "']" }
			};

			var deferred = $q.defer();

			DataFactoryOffline.invoke(req, callservice)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		function invokeHistory(agentNumber, salesforceId, agentCode) {
			var req = {
				adapter: "HTTPAdapterInquiry",
				procedure: "findAllPersistencyHistory",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + agentNumber + "','" + salesforceId + "','" + agentCode + "']" }
			};

			var deferred = $q.defer();

			DataFactoryOffline.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invokePersistency: invokePersistency,
			invokeHistory: invokeHistory
		}
	});