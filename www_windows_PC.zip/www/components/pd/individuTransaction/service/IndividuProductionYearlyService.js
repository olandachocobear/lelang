﻿angular.module('PruForce.services')

.service('IndividuProductionYearlyService', function(DataFactory, $q){
	function invoke(agentNumberIndiv,pageIndiv,sizeIndiv,searchByIndiv,searchValIndiv,searchBy2Indiv,searchVal2Indiv,orderByIndiv,directionIndiv,pruforceId,agentCode){		

		var req = {
			adapter : "HTTPAdapter3",
			procedure : "findAllProductionIndividuYearly",
			//headers: headers
			    method: WLResourceRequest.POST,
				parameters : {"params":"['"+agentNumberIndiv+"',"+pageIndiv+","+sizeIndiv+",'"+searchByIndiv+"','"+searchValIndiv+"','"+searchBy2Indiv+"','"+searchVal2Indiv+"','"+orderByIndiv+"','"+directionIndiv+"','"+pruforceId+"','"+agentCode+"']"}
			};
		
		AppsLog.log("Request Filtering" + searchByIndiv);
		AppsLog.log("Request 1 :" + searchByIndiv);
		AppsLog.log("Request 2 :" + searchValIndiv);
		AppsLog.log("Request 3 :" + pageIndiv);
		AppsLog.log("Request 4 :" + sizeIndiv);
		AppsLog.log("Request 5 :" + orderByIndiv);
		AppsLog.log("Request 6 :" + directionIndiv);
		AppsLog.log("Request 7 :" + searchBy2Indiv);
		AppsLog.log("Request 8 :" + searchVal2Indiv);
		
		var deferred = $q.defer();
		
		DataFactory.invoke(req,true)
	    .then(function (res) {
        	deferred.resolve(res);
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
	}
	
	return {
		invoke: invoke
	}
});
