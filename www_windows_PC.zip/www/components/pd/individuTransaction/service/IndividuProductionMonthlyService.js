﻿angular.module('PruForce.services')

.service('IndividuProductionMonthlyService', function(DataFactory, $q){
	function invoke(agentNumberIndiv,pageIndiv,sizeIndiv,searchByIndiv,searchValIndiv,searchBy2Indiv,searchVal2Indiv,orderByIndiv,directionIndiv,pruforceId,agentCode){
		AppsLog.log("test pruforceId :"+pruforceId);

		var req = {
                adapter : "HTTPAdapter3",
                procedure : "findAllProductionIndividuMonthly",
                //headers: headers
                method: WLResourceRequest.POST,
				parameters : {"params":"['"+agentNumberIndiv+"',"+pageIndiv+","+sizeIndiv+",'"+searchByIndiv+"','"+searchValIndiv+"','"+searchBy2Indiv+"','"+searchVal2Indiv+"','"+orderByIndiv+"','"+directionIndiv+"','"+pruforceId+"','"+agentCode+"']"}
			};
     		  

		AppsLog.log("Request Filtering" + searchByIndiv);
		AppsLog.log("Request 1 :" + searchByIndiv);
		AppsLog.log("Request 2 :" + searchValIndiv);
		AppsLog.log("Request 3 :" + pageIndiv);
		AppsLog.log("Request 4 :" + sizeIndiv);
		AppsLog.log("Request 5 :" + orderByIndiv);
		AppsLog.log("Request 6 :" + directionIndiv);
		AppsLog.log("Request 7 :" + searchBy2Indiv);
		AppsLog.log("Request 8 :" + searchVal2Indiv);
		
		var deferred = $q.defer();
		
		DataFactory.invoke(req,true)
	    .then(function (res) {
        	deferred.resolve(res);
        	AppsLog.log("test 2");
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
                    }
	
                   	return {
		invoke: invoke
	}
});


