﻿angular.module('PruForce.services')
	.service('PDUnitPolicyHolderPendingRequirementService', function (DataFactory, $q) {

		function invokeFilterAgentType(salesforceId, agentCode) {
			var req = {
                adapter: "HTTPAdapterInquiry",
                procedure: "findPolicyHolderPendingRequirementPD",
                method: WLResourceRequest.POST,
				parameters: { "params": "['" + salesforceId + "','" + agentCode + "']" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		function invokeList(salesforceId,agentCode,filterBy,sortDir,sizedata,pagedata){

			var req = {
					adapter : "HTTPAdapterInquiry",
					procedure : "findAgentTypePolicyHolderPendingRequirementPD",
					method: WLResourceRequest.POST,
					parameters : {"params":"['"+salesforceId+"','"+agentCode+"','"+filterBy+"','"+sortDir+"',"+sizedata+","+pagedata+"]"}
				};
			
			var deferred = $q.defer();
			
			DataFactory.invoke(req,true)
			.then(function (res) {
				deferred.resolve(res);
			}, function(error){
				deferred.reject(error);
			});
			
			return deferred.promise;
		}

		return {
			invokeFilterAgentType: invokeFilterAgentType,
			invokeList: invokeList
		}
	});

