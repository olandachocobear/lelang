﻿angular.module('PruForce.services')
	.service('PDCustomerBirthdayUnitService', function (DataFactory, $q) {
		function invokeAllBirthdayListByMonth(searchBy, filterBy, orderBy, page, size, month, salesforceId, agentNumber, agentCode, pageType) {
			var req = {
				adapter: "HTTPAdapterInquiry",
				procedure: "findAllBirthdayListByMonthUnitPD",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + searchBy + "','" + filterBy + "','" + orderBy + "'," + page + "," + size + ",'" + month + "','" + salesforceId + "','" + agentNumber + "' ,'" + agentCode + "','" + pageType + "']" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		function invokeBirthdayListToday(searchBy, filterBy, orderBy, page, size, salesforceId, agentNumber, agentCode, pageType) {
			var req = {
				adapter: "HTTPAdapterInquiry",
				procedure: "findBirthdayListTodayUnitPD",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + searchBy + "','" + filterBy + "','" + orderBy + "'," + page + "," + size + ",'" + salesforceId + "','" + agentNumber + "' ,'" + agentCode + "','" + pageType + "']" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		function invokeBirthdayListRecent(searchBy, filterBy, orderBy, page, size, salesforceId, agentNumber, agentCode, pageType) {
			var req = {
				adapter: "HTTPAdapterInquiry",
				procedure: "findBirthdayListRecentUnitPD",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + searchBy + "','" + filterBy + "','" + orderBy + "'," + page + "," + size + ",'" + salesforceId + "','" + agentNumber + "' ,'" + agentCode + "','" + pageType + "']" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		function invokeBirthdayListUpcoming(searchBy, filterBy, orderBy, page, size, salesforceId, agentNumber, agentCode, pageType) {
			var req = {
				adapter: "HTTPAdapterInquiry",
				procedure: "findBirthdayListUpcomingUnitPD",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + searchBy + "','" + filterBy + "','" + orderBy + "'," + page + "," + size + ",'" + salesforceId + "','" + agentNumber + "' ,'" + agentCode + "','" + pageType + "']" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		function invokeBirthdayListStatus(month, salesforceId, agentNumber, agentCode, pageType) {
			var req = {
				adapter: "HTTPAdapterInquiry",
				procedure: "findBirthdayListStatusUnitPD",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + month + "','" + salesforceId + "','" + agentNumber + "' ,'" + agentCode + "','" + pageType + "']" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invokeAllBirthdayListByMonth: invokeAllBirthdayListByMonth,
			invokeBirthdayListToday: invokeBirthdayListToday,
			invokeBirthdayListRecent: invokeBirthdayListRecent,
			invokeBirthdayListStatus: invokeBirthdayListStatus,
			invokeBirthdayListUpcoming: invokeBirthdayListUpcoming
		}
	});
