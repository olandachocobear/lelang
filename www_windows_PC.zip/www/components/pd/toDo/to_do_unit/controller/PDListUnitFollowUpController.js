﻿angular.module('PruForce.controllers')
	.controller("PDListUnitFollowUpController", function ($scope, $rootScope, $stateParams, $ionicLoading, $http, $state, $filter, FindListUnitFollowUpService, findFilterUnitFollowUpService, ListUnitFollowUp, FilterUnitFollowUp) {

		var sizeData = 30;
		var pageData = 1;
		var filterBy = 'ALL';
		var sortDir = 'asc';
		var ListUnit = [];
		var ListUnitAfterAdd = [];
		$scope.noMoreItemsAvailable = false;
		$scope.numberOfItemsToDisplay = 30;
		$scope.transaction = [];

		getDataUnitListSuccess(ListUnitFollowUp);
		getUnitFilterStatusSuccess(FilterUnitFollowUp);
		
		$scope.statePage = $stateParams.statePage;

		$scope.changePage = function (agentNumber) {
			$state.go($scope.statePage, { agentNumber: agentNumber });
		}

		$scope.sortOptions = {
			st: [
				{ id: 0, name: $filter('translate')('DEFAULT_SORT') },
				{ id: 1, name: $filter('translate')('AGENT_ASC') },
				{ id: 2, name: $filter('translate')('AGENT_DESC') }
			]
		};

		$scope.sortItem = {
			onRequest: $scope.sortOptions.st[0]
		};


		function getDataFromService() {
			FindListUnitFollowUpService.invoke($rootScope.username, $rootScope.agent.code, filterBy, sortDir, sizeData, pageData).then(function (res) {
				AppsLog.log("hasil halaman page " + sizeData);
				AppsLog.log("hasil halaman " + pageData);
				getDataUnitListSuccess(res);
			});
		}

		$scope.loadMore = function () {
			pageData += 1;
			$scope.showSpinner = true;
			getDataFromService();
			$scope.noMoreItemsAvailable = false;
			$scope.$broadcast('scroll.infiniteScrollComplete');
		};

		$scope.GoSearching_GoFiltering = function () {
			$ionicLoading.show();
			ListUnit = [];
			sizeData = 30;
			pageData = 1;

			if ($scope.filterItem.onRequest == $filter('translate')('SHOW_ALL')) {
				filterBy = 'ALL';
			} else {
				filterBy = $scope.filterItem.onRequest;
			}

			if ($scope.sortItem.onRequest.id === 2) {
				sortDir = 'desc';
			} else {
				sortDir = 'asc';
			}

			if ($rootScope.searchWords == undefined) {
				$rootScope.searchWords = '';
			}

			$scope.noMoreItemsAvailable = false;
			getDataFromService();
		}

		function getDataUnitListSuccess(result) {
			if (result.invocationResult.isSuccessful) {
				$scope.showSpinner = false;
				if (result.invocationResult.array != null) {
					if (ListUnit.length == 0) {
						AppsLog.log("masuk sini bro new");
						ListUnit = [];
						for (var i = 0; i < result.invocationResult.array.length; i++) {

							var dt = {};
							dt.agentType = result.invocationResult.array[i].agentType;
							dt.clientName = result.invocationResult.array[i].clientName;
							dt.agentNumber = result.invocationResult.array[i].agentNumber;

							ListUnit[i] = dt;
							pageData = 1;

						}
					} else {
						AppsLog.log("masuk sini bro add");
						for (var i = 0; i < result.invocationResult.array.length; i++) {

							var dt = {};
							dt.agentType = result.invocationResult.array[i].agentType;
							dt.clientName = result.invocationResult.array[i].clientName;
							dt.agentNumber = result.invocationResult.array[i].agentNumber;

							ListUnitAfterAdd[i] = dt;
							ListUnit.push(ListUnitAfterAdd[i]);
							$scope.numberOfItemsToDisplay += ListUnitAfterAdd.length;

						}
					}
				}
				$scope.ListUnit = ListUnit;

				$ionicLoading.hide();
				$scope.noMoreItemsAvailable = false;
				if (result.invocationResult.statusCode == 500) {
					$ionicLoading.hide();
					$scope.noMoreItemsAvailable = true;
					AppsLog.log("No data found1. Please try again later!");
				}

			}
			else if (result.invocationResult.statusCode == 500) {
				$scope.showLoading = false;
				$ionicLoading.hide();
				$scope.noMoreItemsAvailable = true;
				AppsLog.log("No data found2. Please try again later!");
			}
			else {
				AppsLog.log("No data found. Please try again later!");
			}
		}

		function getDataUnitListFailed(result) {
			AppsLog.log("Load Data Failed, Please Check Your Connection");
		}

		function getUnitFilterStatusSuccess(result) {
			if (result.invocationResult.isSuccessful) {
				if (result.invocationResult.array != null) {

					$scope.agentTypeList = [];
					for (var i = 0; i < result.invocationResult.array.length; i++) {

						if (i == 0) {
							$scope.agentTypeList.push($filter('translate')('SHOW_ALL'));
						} else {
							$scope.agentTypeList.push(result.invocationResult.array[i].name);
						}
					}

					$scope.filterItem = {
                        onRequest: $scope.agentTypeList[0]
					}
				}
			} else if (result.invocationResult.statusCode == 500) {
				$ionicLoading.hide();
				AppsLog.log("No data found2. Please try again later!");
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}
		function getUnitFilterStatusFailed(result) {
			$ionicLoading.hide();
			AppsLog.log("Data Individu Failed, Please Check Your Connection");
		}

	})