﻿angular.module('PruForce.controllers')
  .controller("PDToDoCtrl", function ($scope, $location, ListUnitFollowUp, FilterUnitFollowUp, $ionicScrollDelegate, $rootScope) {
    AnalyticsLog.logPage("prudential.ToDo.Landing");
    $scope.ListUnitFollowUp = ListUnitFollowUp;
    $scope.FilterUnitFollowUp = FilterUnitFollowUp;


    $scope.toDoTabs = [{
      title: 'my tasks',
      url: 'components/toDo/to_do_my_tasks.html'
    }, {
        title: 'unit',
        url: 'components/toDo/to_do_unit/to_do_unit.html'
      }];

    $scope.currentToDoTab = 'components/toDo/to_do_my_tasks.html';
    $scope.onClickTab = function (toDoWidgetTab) {
      $scope.currentToDoTab = toDoWidgetTab;
    }

    $scope.isActiveTab = function (toDoWidgetTabUrl) {
      return toDoWidgetTabUrl == $scope.currentToDoTab;
    }

    $scope.go = function (path) {
      $scope.currentToDoTab = path;
      localStorage.setItem('currentTabToDo', $scope.currentToDoTab);
      $ionicScrollDelegate.scrollTop();
    }

    $scope.currentToDoTab = localStorage.getItem('currentTabToDo');

    $scope.accordionInit = function () {
	     var accordions = $(".list-info-accordion");

	     $.each(accordions, function (index, value) {
	       var accordionBody = $(value).find(".accordion-body");

	       if (!$(value).hasClass("collapsed")) {
	         accordionBody.attr("style", "margin-top: -" + accordionBody.height() + "px;")
	       }
	     });
	   }

	   $scope.collapseAccordion = function (e) {
	     var self = $(e.toElement);
	     var accordion = self.parents(".list-info-accordion");
	     var accordionBody = accordion.find(".accordion-body");

	     if (accordion.hasClass("collapsed")) {
	       accordion.removeClass("collapsed");
	       accordionBody.attr("style", "margin-top: -" + accordionBody.height() + "px;");
	     } else {
	       accordion.addClass("collapsed");
	       accordionBody.css("margin-top", 0);

	     }
	   }


    $scope.focusIn = function () {
      $scope.message = 'focus in';
      AppsLog.log('focus in');
    }
    $scope.focusOut = function () {
      $scope.message = 'focus out';
    }

    if (!$rootScope.UnitByAgentType) {
      angular.element("#todoMenu").css('display', 'none');
      angular.element("#todoView").removeClass("tabs-non-scroll");
      angular.element("#todofollowup").removeClass("mtop-header-space");
      angular.element(".header").removeClass("bar-positive");
      angular.element(".header").addClass("bar-assertive");
    }
  });

