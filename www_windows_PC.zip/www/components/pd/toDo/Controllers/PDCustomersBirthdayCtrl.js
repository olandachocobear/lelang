﻿angular.module('PruForce.controllers')
	.controller("PDCustomersBirthdayCtrl", function ($state, $ionicScrollDelegate, $scope, $rootScope, $ionicLoading, $location, $stateParams, $filter, BirthdayViewAll, BirthdayToday, BirthdayRecent, BirthdayUpcoming, ClientStatusInquiry, ClientStatusTodoToday, ClientStatusTodoRecent, ClientStatusTodoUpComing, CustomerBirthdayService, CustomerBirthdayUnitService) {

		AppsLog.log("agentnumberclick birthday " + $stateParams.agentNumber);

		var BirthdayType;
		var ClientStatusTab;

		var ClientStatusTabRecent;
		var ClientStatusTabUpComing;

		if ($stateParams.Flag == 1) {

			$scope.toDoTabs = [
				{
					title: $filter('translate')('TODO_VIEWALL'),
					url: 'components/pd/toDo/pd_to_do_customers_birthday_today.html',
					type: '1'
				}, {
					title: $filter('translate')('TODO_MONTH'),
					url: 'components/toDo/to_do_customers_birthday_by_month.html',
					type: '2'
				}];

			$scope.currentToDoTab = $scope.toDoTabs[0].url;
			$scope.BirthdayType = '1';
			$scope.TabsCSS = "two-menu";
			$scope.BirthdayViewAllToday = BirthdayViewAll;
			getListClientStatusSuccess(ClientStatusInquiry);
			$scope.ClientStatusTab = ClientStatusTab;

		}
		else if ($stateParams.Flag == 2) {
			$scope.toDoTabs = [{
				title: $filter('translate')('TODO_RECENT'),
				url: 'components/pd/toDo/pd_to_do_customers_birthday_recent.html',
				type: '3'
			}, {
					title: $filter('translate')('TODO_TODAY'),
					url: 'components/pd/toDo/pd_to_do_customers_birthday_today.html',
					type: '4'
				}, {
					title: $filter('translate')('TODO_UPCOMING'),
					url: 'components/pd/toDo/pd_to_do_customers_birthday_upcoming.html',
					type: '5'
				}];

			$scope.currentToDoTab = $scope.toDoTabs[1].url;
			$scope.BirthdayType = '4';
			$scope.TabsCSS = "three-menu";
			$scope.BirthdayViewAllToday = BirthdayToday;
			$scope.BirthdayRecent = BirthdayRecent;
			$scope.BirthdayUpcoming = BirthdayUpcoming;
			getListClientStatusSuccess(ClientStatusTodoToday);
			getListClientStatusSuccess2(ClientStatusTodoRecent);
			getListClientStatusSuccess3(ClientStatusTodoUpComing);
			$scope.ClientStatusTab = ClientStatusTab;
			$scope.ClientStatusTab2 = ClientStatusTab2;
			$scope.ClientStatusTab3 = ClientStatusTab3;

		}

		function getClientStatusService() {
			var cStatus;

			if (BirthdayType == "1") {
				cStatus = "13";
			} else if (BirthdayType == "3") {
				cStatus = "14";
			} else if (BirthdayType == "4") {
				cStatus = "15";
			} else if (BirthdayType == "5") {
				cStatus = "16";
			}

			if ($stateParams.agentNumber == 0) {
				CustomerBirthdayService.invokeBirthdayListStatus(cStatus, $rootScope.username, $rootScope.agent.code).then(function (res) {
					getListClientStatusSuccess(res);
				});
			}
			else {
				CustomerBirthdayUnitService.invokeBirthdayListStatus(cStatus, $rootScope.username, $stateParams.agentNumber, $rootScope.agent.code, "unit").then(function (res) {
					getListClientStatusSuccess(res);
				});
			}
		}

		function getListClientStatusSuccess(result) {
			AppsLog.log(" hasil json :" + JSON.stringify(result));
			if (result.invocationResult.isSuccessful) {
				if (result.invocationResult.array != null) {
					ClientStatusTab = [];
					ClientStatusTab.push({ "desc": $filter('translate')('SHOW_ALL'), "key": "" });
					for (var i = 0; i < result.invocationResult.array.length; i++) {
						ClientStatusTab.push({ "desc": result.invocationResult.array[i].clientStatus, "key": result.invocationResult.array[i].clientStatusCode });
					}
				} else {
					ClientStatusTab = [];
					ClientStatusTab.push({ "desc": $filter('translate')('SHOW_ALL'), "key": "" });
				}
			} else if (result.invocationResult.statusCode == 500) {
				$ionicLoading.hide();
				AppsLog.log("No data found2. Please try again later!");
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}

		function getListClientStatusSuccess2(result) {
			AppsLog.log(" hasil json :" + JSON.stringify(result));
			if (result.invocationResult.isSuccessful) {
				if (result.invocationResult.array != null) {
					ClientStatusTab2 = [];
					ClientStatusTab2.push({ "desc": $filter('translate')('SHOW_ALL'), "key": "" });
					for (var i = 0; i < result.invocationResult.array.length; i++) {
						ClientStatusTab2.push({ "desc": result.invocationResult.array[i].clientStatus, "key": result.invocationResult.array[i].clientStatusCode });
					}
				} else {
					ClientStatusTab2 = [];
					ClientStatusTab2.push({ "desc": $filter('translate')('SHOW_ALL'), "key": "" });
				}
			} else if (result.invocationResult.statusCode == 500) {
				$ionicLoading.hide();
				AppsLog.log("No data found2. Please try again later!");
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}

		function getListClientStatusSuccess3(result) {
			AppsLog.log(" hasil json :" + JSON.stringify(result));
			if (result.invocationResult.isSuccessful) {
				if (result.invocationResult.array != null) {
					ClientStatusTab3 = [];
					ClientStatusTab3.push({ "desc": $filter('translate')('SHOW_ALL'), "key": "" });
					for (var i = 0; i < result.invocationResult.array.length; i++) {
						ClientStatusTab3.push({ "desc": result.invocationResult.array[i].clientStatus, "key": result.invocationResult.array[i].clientStatusCode });
					}
				} else {
					ClientStatusTab3 = [];
					ClientStatusTab3.push({ "desc": $filter('translate')('SHOW_ALL'), "key": "" });
				}
			} else if (result.invocationResult.statusCode == 500) {
				$ionicLoading.hide();
				AppsLog.log("No data found2. Please try again later!");
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}

		$scope.onClickTab = function (toDoWidgetTab) {
			$scope.currentToDoTab = toDoWidgetTab;
		}

		$scope.isActiveTab = function (toDoWidgetTabUrl) {
			return toDoWidgetTabUrl == $scope.currentToDoTab;
		}

		$scope.go = function (path, type) {
			$scope.currentToDoTab = path;
			$scope.BirthdayType = type;
			BirthdayType = type;

			$ionicScrollDelegate.scrollTop();
			$scope.ClientStatusTab = ClientStatusTab;
		}

		$scope.focusIn = function () {
			$scope.message = 'focus in';
			AppsLog.log('focus in');
		}
		$scope.focusOut = function () {
			$scope.message = 'focus out';
		}

		$scope.goToBirthdayPerMonth = function (month) {
			$state.go("pd_customers_birthday_list_month", { "Month": month });
		}

	});