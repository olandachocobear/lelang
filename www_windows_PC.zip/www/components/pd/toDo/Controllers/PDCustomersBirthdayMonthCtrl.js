﻿angular.module('PruForce.controllers')
	.controller('PDCustomersBirthdayMonthCtrl', function ($scope, $rootScope, $ionicLoading, $http, $state, $filter, $ionicPopup, $stateParams, BirthdayViewAll, ClientStatus, PDCustomerBirthdayService) {
		AppsLog.log("START >> CustomersBirthdayMonthCtrl " + new Date());

		var sizeIndividu = 30;
		var pageIndividu = 1;
		var searchByIndividu = '';
		var searchValIndividu = '';
		var searchBy2Individu = '';
		var searchVal2Individu = '';
		var orderByIndividu = '';
		var directionIndividu = '';
		$scope.transaction = [];
		var ListDailyBirthDay = [];
		var ListDailyBirthDayAfterAdd = [];
		$scope.noMoreItemsAvailable = false;
		$scope.numberOfItemsToDisplay = 30;
		var ListClientStatus = [];

		$rootScope.inProgress = false;

		$scope.policyHolderNames = {
			data: [{
				id: 0,
				name: $filter('translate')('DEFAULT_SORT')
			},
				{
					id: 1,
					name: $filter('translate')('BIRTHDAY_ASC')
				},
				{
					id: 2,
					name: $filter('translate')('BIRTHDAY_DESC')
				},]
		};

		$scope.policyStatusData = {
			data: [{
				id: 0,
				name: $filter('translate')('DEFAULT_SORT')
			},
				{
					id: 1,
					name: 'In Force'
				}]
		};

		$scope.selected = $scope.policyStatusData.data[0];

		$scope.sortItem = {
			onRequest: $scope.policyHolderNames.data[0]
		};

		$scope.loadMore = function () {
			if (!$rootScope.inProgress) {
				$rootScope.inProgress = true;
				pageIndividu += 1;
				$scope.showSpinner = true;
				getDataFromService();
			}
			$scope.noMoreItemsAvailable = false;
			$scope.$broadcast('scroll.infiniteScrollComplete');
		};

		//direct to client detail
		$scope.changePage = function (id) {
			$state.go('inquiries_client_details', { clientNumber: id });
		}

		$scope.GoSearching_GoFiltering = function () {
			$ionicLoading.show();
			ListDailyBirthDay = [];
			sizeIndividu = 30;
			pageIndividu = 1;
			searchValIndividu = ($scope.transaction.searchString==undefined)?"":$scope.transaction.searchString.replace(/['|"|\\]/g, "\\$&");
			searchByIndividu = '';
			if ($scope.filterItem.onRequest == $filter('translate')('SHOW_ALL')) {
				searchByIndividu = '';
			} else {
				searchVal2Individu = $scope.filterItem.onRequest.key;
			}

			if ($scope.sortItem.onRequest.id === 0) {
				$scope.descSorted = false;
				orderByIndividu = '';
			} else if ($scope.sortItem.onRequest.id === 2) {
				$scope.descSorted = false;
				$scope.policyOption = '';
				orderByIndividu = 'desc';
			} else {
				$scope.descSorted = false;
				$scope.policyOption = '';
				orderByIndividu = 'asc';
			}
			if (searchValIndividu == undefined) {
				searchValIndividu = '';
			}

			AppsLog.log("List Request 1 :" + searchByIndividu);
			AppsLog.log("List Request 2 :" + searchValIndividu);
			AppsLog.log("List Request 3 :" + pageIndividu);
			AppsLog.log("List Request 4 :" + sizeIndividu);
			AppsLog.log("List Request 5 :" + orderByIndividu);
			AppsLog.log("List Request 6 :" + directionIndividu);
			AppsLog.log("List Request 7 :" + searchBy2Individu);
			AppsLog.log("List Request 8 :" + searchVal2Individu);
			$scope.noMoreItemsAvailable = false;
			getDataFromService();
		}

		//Title Month
		if ($stateParams.Month == "1") {
			$scope.PageTitle = $filter('translate')('JANUARY');
		} else if ($stateParams.Month == "2") {
			$scope.PageTitle = $filter('translate')('FEBRUARY');
		} else if ($stateParams.Month == "3") {
			$scope.PageTitle = $filter('translate')('MARCH');
		} else if ($stateParams.Month == "4") {
			$scope.PageTitle = $filter('translate')('APRIL');
		} else if ($stateParams.Month == "5") {
			$scope.PageTitle = $filter('translate')('MAY');
		} else if ($stateParams.Month == "6") {
			$scope.PageTitle = $filter('translate')('JUNE');
		} else if ($stateParams.Month == "7") {
			$scope.PageTitle = $filter('translate')('JULY');
		} else if ($stateParams.Month == "8") {
			$scope.PageTitle = $filter('translate')('AUGUST');
		} else if ($stateParams.Month == "9") {
			$scope.PageTitle = $filter('translate')('SEPTEMBER');
		} else if ($stateParams.Month == "10") {
			$scope.PageTitle = $filter('translate')('OCTOBER');
		} else if ($stateParams.Month == "11") {
			$scope.PageTitle = $filter('translate')('NOVEMBER');
		} else if ($stateParams.Month == "12") {
			$scope.PageTitle = $filter('translate')('DECEMBER');
		}

		$scope.init = function (res) {
			getBirthdayListTodoSuccess(res);
		};

		getListPolisStatusSuccess(ClientStatus);

		function getListPolisStatusSuccess(result) {
			AppsLog.log(" hasil json :" + JSON.stringify(result));
			if (result.invocationResult.isSuccessful) {
				if (result.invocationResult.array != null) {
					$scope.listPolisStatus = [];
					$scope.listPolisStatus.push({ "desc": $filter('translate')('SHOW_ALL'), "key": "" });
					for (var i = 0; i < result.invocationResult.array.length; i++) {
						//$scope.listPolisStatus.push(result.invocationResult.array[i].description);
						$scope.listPolisStatus.push({ "desc": result.invocationResult.array[i].clientStatus, "key": result.invocationResult.array[i].clientStatusCode });
					}
				} else {
					$scope.listPolisStatus = [];
					$scope.listPolisStatus.push({ "desc": $filter('translate')('SHOW_ALL'), "key": "" });
				}

				$scope.filterItem = {
                    onRequest: $scope.listPolisStatus[0]
				}

			} else if (result.invocationResult.statusCode == 500) {
				$ionicLoading.hide();
				AppsLog.log("No data found2. Please try again later!");
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}

		$scope.init(BirthdayViewAll);

		function getDataFromService() {
			PDCustomerBirthdayService.invokeAllBirthdayListByMonth(searchValIndividu, searchVal2Individu, orderByIndividu, pageIndividu, sizeIndividu, $stateParams.Month, $rootScope.username, $rootScope.agent.code)
				.then(function (res) {
					getBirthdayListTodoSuccess(res);
				});
		}

		function getBirthdayListTodoSuccess(result) {
			AppsLog.log("START >> getBirthdayListTodoSuccess " + new Date());
			if (result.invocationResult.isSuccessful) {
				var momentDate;

				if (result.invocationResult.array != null) {
					if (ListDailyBirthDay.length == 0) {
						ListDailyBirthDay = [];
						for (var i = 0; i < result.invocationResult.array.length; i++) {
							var dt = {};

							dt.clientname = result.invocationResult.array[i].clientName;
							dt.old = result.invocationResult.array[i].old;
							dt.dateofbirth = moment(result.invocationResult.array[i].dateOfBirth).format('LL');
							dt.address1 = result.invocationResult.array[i].address1;
							dt.clientnumber = result.invocationResult.array[i].clientNumber;
							dt.clientStatus = [];
							dt.clientStatus = result.invocationResult.array[i].clientStatus.replace(/;/g, ",");
							dt.agentCode = result.invocationResult.array[i].agentCode;
							dt.agentName = result.invocationResult.array[i].agentName;
							ListDailyBirthDay[i] = dt;
							pageIndividu = 1;
							var retrieveDate2 = new Date(result.retrieveDate);
							momentDate = moment(retrieveDate2).format('LLLL');
							$scope.lastUpdate = momentDate;
						}
					} else {
						for (var i = 0; i < result.invocationResult.array.length; i++) {
							var dt = {};
							var TotalStatus;

							dt.clientname = result.invocationResult.array[i].clientName;
							dt.old = result.invocationResult.array[i].old;
							dt.dateofbirth = moment(result.invocationResult.array[i].dateOfBirth).format('LL');
							dt.address1 = result.invocationResult.array[i].address1;
							dt.clientnumber = result.invocationResult.array[i].clientNumber;
							dt.clientStatus = result.invocationResult.array[i].clientStatus.replace(/;/g, ",");
							dt.agentCode = result.invocationResult.array[i].agentCode;
							dt.agentName = result.invocationResult.array[i].agentName;
							dt.TotalStatus = '';
							ListDailyBirthDayAfterAdd[i] = dt;
							ListDailyBirthDay.push(ListDailyBirthDayAfterAdd[i]);
							$scope.numberOfItemsToDisplay += ListDailyBirthDayAfterAdd.length;
							var retrieveDate2 = new Date(result.retrieveDate);
							momentDate = moment(retrieveDate2).format('LLLL');
							$scope.lastUpdate = momentDate;
						}
					}
					$scope.noMoreItemsAvailable = false;
				} else {
					$scope.noMoreItemsAvailable = true;
				}
				$scope.ListDailyBirthDay = ListDailyBirthDay;

				$ionicLoading.hide();
				$scope.showSpinner = false;
				if (result.invocationResult.statusCode == 500) {
					$scope.showSpinner = false;
					$ionicLoading.hide();
					$scope.noMoreItemsAvailable = true;
					AppsLog.log("No data found1. Please try again later!");
				}
			} else if (result.invocationResult.statusCode == 500) {
				$scope.showSpinner = false;
				$ionicLoading.hide();
				$scope.noMoreItemsAvailable = true;
				AppsLog.log("No data found2. Please try again later!");
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
			AppsLog.log("END >> getBirthdayListTodoDailySuccess" + new Date());


			function getBirthdayListFailed(result) {
				$ionicLoading.hide();
				$scope.showSpinner = false;
				AppsLog.log("Data Load Failed, Please Check Your Connection");
			}

			AppsLog.log("END >> getBirthdayListTodoDailySuccess " + new Date());

			$rootScope.inProgress = false;
		}
	});