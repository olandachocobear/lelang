﻿angular.module('PruForce.controllers')
	.controller('PDCustomersBirthdayListCtrl', function ($scope, $rootScope, $http, $state, $filter, $ionicPopup, $ionicLoading, CustomerBirthdayService, PDCustomerBirthdayUnitService, $stateParams) {
		AppsLog.log("START >> CustomersBirthdayListCtrl " + new Date());

		var sizeIndividu = 30;
		var pageIndividu = 1;
		var searchByIndividu = '';
		var searchValIndividu = '';
		var searchBy2Individu = '';
		var searchVal2Individu = '';
		var orderByIndividu = '';
		var directionIndividu = '';
		$scope.transaction = [];
		var ListDailyBirthDay = [];
		var ListDailyBirthDayAfterAdd = [];
		$scope.noMoreItemsAvailable = false;
		$scope.numberOfItemsToDisplay = 30;
		var BirthdayTypeShow;
		var ListClientStatus = [];
		var statusLoadmore = true;

		$scope.policyHolderNames = {
			data: [{
				id: 0,
				name: $filter('translate')('DEFAULT_SORT')
			},
			{
				id: 1,
				name: $filter('translate')('BIRTHDAY_ASC')
			},
			{
				id: 2,
				name: $filter('translate')('BIRTHDAY_DESC')
			}]
		};

		$scope.policyStatusData = {
			data: [{
				id: 0,
				name: $filter('translate')('DEFAULT_SORT')
			},
			{
				id: 1,
				name: 'In Force'
			}]
		};

		$scope.selected = $scope.policyStatusData.data[0];

		$scope.sortItem = {
			onRequest: $scope.policyHolderNames.data[0]
		};

		$scope.loadMore = function () {
			if (statusLoadmore) {
				//$ionicLoading.show();
				$scope.showSpinner = true;
				statusLoadmore = false;
				AppsLog.log("Enter Loadmore");
				pageIndividu += 1;
				getDataFromService();
				$scope.noMoreItemsAvailable = false;
			}
		};

		//direct to client detail
		$scope.changePage = function (id) {
			$state.go('inquiries_client_details', { clientNumber: id });
		}

		$scope.GoSearching_GoFiltering = function () {
			$ionicLoading.show();
			ListDailyBirthDay = [];
			sizeIndividu = 30;
			pageIndividu = 1;
			searchValIndividu = ($scope.transaction.searchString == undefined) ? "" : $scope.transaction.searchString.replace(/['|"|\\]/g, "\\$&");
			searchByIndividu = '';
			if ($scope.filterItem.onRequest == $filter('translate')('SHOW_ALL')) {
				searchByIndividu = '';
			} else {
				searchVal2Individu = $scope.filterItem.onRequest.key;
			}

			if ($scope.sortItem.onRequest.id === 0) {
				$scope.descSorted = false;
				orderByIndividu = '';
			} else if ($scope.sortItem.onRequest.id === 2) {
				$scope.descSorted = false;
				$scope.policyOption = '';
				orderByIndividu = 'desc';
			} else {
				$scope.descSorted = false;
				$scope.policyOption = '';
				orderByIndividu = 'asc';
			}
			if (searchValIndividu == undefined) {
				searchValIndividu = '';
			}

			AppsLog.log("List Request 1 :" + searchByIndividu);
			AppsLog.log("List Request 2 :" + searchValIndividu);
			AppsLog.log("List Request 3 :" + pageIndividu);
			AppsLog.log("List Request 4 :" + sizeIndividu);
			AppsLog.log("List Request 5 :" + orderByIndividu);
			AppsLog.log("List Request 6 :" + directionIndividu);
			AppsLog.log("List Request 7 :" + searchBy2Individu);
			AppsLog.log("List Request 8 :" + searchVal2Individu);
			$scope.noMoreItemsAvailable = false;
			getDataFromService();
		}

		function getDataFromService() {
			if (BirthdayTypeShow == "3") {
				if ($stateParams.agentNumber == 0) {
					PDCustomerBirthdayService.invokeBirthdayListRecent(searchValIndividu, searchVal2Individu, orderByIndividu, pageIndividu, sizeIndividu, $rootScope.username, $rootScope.agent.code)
						.then(function (res) {
							getBirthdayListTodoSuccess(res);
						});
				} else {
					PDCustomerBirthdayUnitService.invokeBirthdayListRecent(searchValIndividu, searchVal2Individu, orderByIndividu, pageIndividu, sizeIndividu, $rootScope.username, $stateParams.agentNumber, $rootScope.agent.code, "unit")
						.then(function (res) {
							getBirthdayListTodoSuccess(res);
						});
				}
			} else if (BirthdayTypeShow == "5") {
				if ($stateParams.agentNumber == 0) {
					PDCustomerBirthdayService.invokeBirthdayListUpcoming(searchValIndividu, searchVal2Individu, orderByIndividu, pageIndividu, sizeIndividu, $rootScope.username, $rootScope.agent.code)
						.then(function (res) {
							getBirthdayListTodoSuccess(res);
						});
				} else {
					PDCustomerBirthdayUnitService.invokeBirthdayListUpcoming(searchValIndividu, searchVal2Individu, orderByIndividu, pageIndividu, sizeIndividu, $rootScope.username, $stateParams.agentNumber, $rootScope.agent.code, "unit")
						.then(function (res) {
							getBirthdayListTodoSuccess(res);
						});
				}
			} else if (BirthdayTypeShow == "1" || BirthdayTypeShow == "4") {
				if (BirthdayTypeShow == "1") {
					if ($stateParams.agentNumber == 0) {
						PDCustomerBirthdayService.invokeAllBirthdayListByMonth(searchValIndividu, searchVal2Individu, orderByIndividu, pageIndividu, sizeIndividu, "13", $rootScope.username, $rootScope.agent.code)
							.then(function (res) {
								getBirthdayListTodoSuccess(res);
							});
					} else {
						PDCustomerBirthdayUnitService.invokeAllBirthdayListByMonth(searchValIndividu, searchVal2Individu, orderByIndividu, pageIndividu, sizeIndividu, "13", $rootScope.username, $stateParams.agentNumber, $rootScope.agent.code, "unit")
							.then(function (res) {
								getBirthdayListTodoSuccess(res);
							});
					}
				} else {
					if ($stateParams.agentNumber == 0) {
						PDCustomerBirthdayService.invokeBirthdayListToday(searchValIndividu, searchVal2Individu, orderByIndividu, pageIndividu, sizeIndividu, $rootScope.username, $rootScope.agent.code)
							.then(function (res) {
								getBirthdayListTodoSuccess(res);
							});
					} else {
						PDCustomerBirthdayUnitService.invokeBirthdayListToday(searchValIndividu, searchVal2Individu, orderByIndividu, pageIndividu, sizeIndividu, $rootScope.username, $stateParams.agentNumber, $rootScope.agent.code, "unit")
							.then(function (res) {
								getBirthdayListTodoSuccess(res);
							});
					}
				}
			}
		}

		$scope.init = function (BirthdayViewAllToday, BirthdayRecent, BirthdayType, BirthdayUpcoming, ClientStatusTab) {
			BirthdayTypeShow = BirthdayType;

			if (BirthdayTypeShow == "3") {
				getBirthdayListTodoSuccess(BirthdayRecent);
			} else if (BirthdayTypeShow == "1" || BirthdayTypeShow == "4") {
				getBirthdayListTodoSuccess(BirthdayViewAllToday);
			} else if (BirthdayTypeShow == "5") {
				getBirthdayListTodoSuccess(BirthdayUpcoming);
			}


			getListClientStatus(ClientStatusTab);
		};

		function getListClientStatus(result) {
			if (result.length != 0) {
				$scope.listPolisStatus = result;
				$scope.filterItem = {
                    onRequest: $scope.listPolisStatus[0]
				}
			}
		}

		function getBirthdayListTodoSuccess(result) {
			$scope.ListDailyBirthDay = [];
			AppsLog.log("START >> getBirthdayListTodoSuccess " + new Date());
			if (result.invocationResult.isSuccessful) {
				var momentDate;

				if (result.invocationResult.array != null) {
					if (ListDailyBirthDay.length == 0) {
						ListDailyBirthDay = [];
						for (var i = 0; i < result.invocationResult.array.length; i++) {
							var dt = {};

							dt.clientname = result.invocationResult.array[i].clientName;
							dt.old = result.invocationResult.array[i].old;
							dt.dateofbirth = moment(result.invocationResult.array[i].dateOfBirth).format('LL');
							dt.address1 = result.invocationResult.array[i].address1;
							dt.clientnumber = result.invocationResult.array[i].clientNumber;
							dt.clientStatus = result.invocationResult.array[i].clientStatus.replace(/;/g, ",");
							dt.agentCode = result.invocationResult.array[i].agentCode;
							dt.agentName = result.invocationResult.array[i].agentName;

							ListDailyBirthDay[i] = dt;
							pageIndividu = 1;
							var retrieveDate2 = new Date(result.retrieveDate);
							momentDate = moment(retrieveDate2).format('LLLL');
							$scope.lastUpdate = momentDate;
						}
					} else {
						for (var i = 0; i < result.invocationResult.array.length; i++) {
							var dt = {};

							dt.clientname = result.invocationResult.array[i].clientName;
							dt.old = result.invocationResult.array[i].old;
							dt.dateofbirth = moment(result.invocationResult.array[i].dateOfBirth).format('LL');
							dt.address1 = result.invocationResult.array[i].address1;
							dt.clientnumber = result.invocationResult.array[i].clientNumber;
							dt.clientStatus = result.invocationResult.array[i].clientStatus.replace(/;/g, ",");
							dt.agentCode = result.invocationResult.array[i].agentCode;
							dt.agentName = result.invocationResult.array[i].agentName;
							ListDailyBirthDayAfterAdd[i] = dt;
							ListDailyBirthDay.push(ListDailyBirthDayAfterAdd[i]);
							$scope.numberOfItemsToDisplay += ListDailyBirthDayAfterAdd.length;
							var retrieveDate2 = new Date(result.retrieveDate);
							momentDate = moment(retrieveDate2).format('LLLL');
							$scope.lastUpdate = momentDate;
						}
					}
				}
				$scope.ListDailyBirthDay = ListDailyBirthDay;
				$ionicLoading.hide();
				$scope.showSpinner = false;
				$scope.noMoreItemsAvailable = false;
				if (result.invocationResult.statusCode == 500) {
					$scope.showSpinner = false;
					$ionicLoading.hide();
					$scope.noMoreItemsAvailable = true;
					AppsLog.log("No data found1. Please try again later!");
				}
			} else if (result.invocationResult.statusCode == 500) {
				$scope.showSpinner = false;
				$ionicLoading.hide();
				$scope.noMoreItemsAvailable = true;
				AppsLog.log("No data found2. Please try again later!");
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
			statusLoadmore = true;
			$scope.$broadcast('scroll.infiniteScrollComplete');
			AppsLog.log("END >> getBirthdayListTodoDailySuccess" + new Date());


			function getBirthdayListFailed(result) {
				$ionicLoading.hide();
				$scope.showSpinner = false;
				AppsLog.log("Data Load Failed, Please Check Your Connection");
			}
			AppsLog.log("END >> getBirthdayListTodoDailySuccess " + new Date());
		}
	});