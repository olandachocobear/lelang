﻿angular.module('PruForce.services')
	.service('PDCustomerBirthdayService', function (DataFactory, $q) {
		function invokeAllBirthdayListByMonth(searchBy, filterBy, orderBy, page, size, month, salesforceId, agentNumber) {
			var req = {
				adapter: "HTTPAdapterInquiry",
				procedure: "findAllBirthdayListByMonthPD",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + searchBy + "','" + filterBy + "','" + orderBy + "'," + page + "," + size + ",'" + month + "','" + salesforceId + "','" + agentNumber + "']" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		function invokeBirthdayListToday(searchBy, filterBy, orderBy, page, size, salesforceId, agentNumber) {
			var req = {
				adapter: "HTTPAdapterInquiry",
				procedure: "findBirthdayListTodayPD",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + searchBy + "','" + filterBy + "','" + orderBy + "'," + page + "," + size + ",'" + salesforceId + "','" + agentNumber + "']" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		function invokeBirthdayListRecent(searchBy, filterBy, orderBy, page, size, salesforceId, agentNumber) {
			var req = {
				adapter: "HTTPAdapterInquiry",
				procedure: "findBirthdayListRecentPD",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + searchBy + "','" + filterBy + "','" + orderBy + "'," + page + "," + size + ",'" + salesforceId + "','" + agentNumber + "']" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		function invokeBirthdayListUpcoming(searchBy, filterBy, orderBy, page, size, salesforceId, agentNumber) {
			var req = {
				adapter: "HTTPAdapterInquiry",
				procedure: "findBirthdayListUpcomingPD",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + searchBy + "','" + filterBy + "','" + orderBy + "'," + page + "," + size + ",'" + salesforceId + "','" + agentNumber + "']" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		function invokeBirthdayListStatus(month, salesforceId, agentNumber) {
			var req = {
				adapter: "HTTPAdapterInquiry",
				procedure: "findBirthdayListStatusPD",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + month + "','" + salesforceId + "','" + agentNumber + "']" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invokeAllBirthdayListByMonth: invokeAllBirthdayListByMonth,
			invokeBirthdayListToday: invokeBirthdayListToday,
			invokeBirthdayListRecent: invokeBirthdayListRecent,
			invokeBirthdayListStatus: invokeBirthdayListStatus,
			invokeBirthdayListUpcoming: invokeBirthdayListUpcoming
		}
	});
