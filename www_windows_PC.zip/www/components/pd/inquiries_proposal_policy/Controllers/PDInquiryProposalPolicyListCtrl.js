﻿angular.module('PruForce.controllers')
	.controller('PDInquiryProposalPolicyListCtrl', function ($scope, $rootScope, $ionicLoading, $http, $state, $interval, $filter, $stateParams, ListProposalPolicy, ListProposalPolicyStatus, PDInquiryProposalPolicyService) {

		AnalyticsLog.logPage("prudential.inquiry.proposalpolicy.list");

		$scope.Flag = $stateParams.Flag;
		$scope.PlaceHolderFilter = ($stateParams.Flag == "1") ? $filter('translate')('SEARCH_PROP') : $filter('translate')('SEARCH_PROD');
		$scope.HeaderTitle = ($stateParams.Flag == "1") ? $filter('translate')('PROPOSAL_LIST') : $filter('translate')('POLICY_LIST');

		if($rootScope.pd){
			if($rootScope.UnitByAgentType) {
				$scope.PlaceHolderFilter = ($stateParams.Flag == "1") ? $filter('translate')('SEARCH_PROP_PD') : $filter('translate')('SEARCH_PROD_PD');
				$scope.HeaderTitle = ($stateParams.Flag == "1") ? $filter('translate')('PROPOSAL_UNIT_LIST') : $filter('translate')('POLICY_UNIT_LIST');
			}
		}

		var sizeIndividu = 30;
		var pageIndividu = 1;
		var searchByIndividu = '';
		var searchValIndividu = '';
		var searchBy2Individu = '';
		var searchVal2Individu = '';
		var orderByIndividu = '';
		var directionIndividu = 'asc';
		$scope.transaction = [];
		var ListProposalPolicyListAll = [];
		var ListProposalPolicyListAllAfterAdd = [];
		$scope.noMoreItemsAvailable = true;
		$scope.numberOfItemsToDisplay = 30;
		if ($stateParams.Flag == "1") {
			$scope.policyHolderNames = {
				data: [
					{ id: 0, name: $filter('translate')('DEFAULT_SORT') },
					{ id: 1, name: $filter('translate')('PROPOSAL_NAME') },
					{ id: 2, name: $filter('translate')('PROPOSAL_NUMBER') },
				]
			};
		} else {
			$scope.policyHolderNames = {
				data: [{ id: 0, name: $filter('translate')('DEFAULT_SORT') },
					{ id: 1, name: $filter('translate')('POLICY_NAME_ASC') },
					{ id: 11, name: $filter('translate')('POLICY_NAME_DESC') },
					{ id: 2, name: $filter('translate')('POLICY_NUMBER_ASC') },
					{ id: 21, name: $filter('translate')('POLICY_NUMBER_DESC') },
					{ id: 3, name: $filter('translate')('ISSUED_DATE_ASC') },
					{ id: 31, name: $filter('translate')('ISSUED_DATE_DESC') },]
			};
		}

		$scope.sortItem = { onRequest: $scope.policyHolderNames.data[0] };

		$scope.loadMore = function () {

			pageIndividu += 1;
			$scope.showSpinner = true;
			getDataFromService();
			$scope.noMoreItemsAvailable = false;
			$scope.$broadcast('scroll.infiniteScrollComplete');

		};
		$scope.GoSearching_GoFiltering = function () {
			$ionicLoading.show();
			ListProposalPolicyListAll = [];
			sizeIndividu = 30;
			pageIndividu = 1;
			searchValIndividu = ($scope.transaction.searchString == undefined) ? "" : $scope.transaction.searchString.replace(/['|"|\\]/g, "\\$&");
			searchByIndividu = '';

			if ($scope.filterItem.onRequest.name == $filter('translate')('SHOW_ALL')) {
				searchVal2Individu = '';
			} else {
				searchVal2Individu = $scope.filterItem.onRequest.value;
			}

			if ($scope.sortItem.onRequest.id === 0) {
				orderByIndividu = 'policyHolderName';
			} else if ($scope.sortItem.onRequest.id === 1) {
				orderByIndividu = 'policyHolderName';
			} else if ($scope.sortItem.onRequest.id === 11) {
				orderByIndividu = 'policyHolderNameDesc';
			} else if ($scope.sortItem.onRequest.id === 3) {
				orderByIndividu = 'policyByDate';
			} else if ($scope.sortItem.onRequest.id === 31) {
				orderByIndividu = 'policyByDateDesc';
			} else {
				if ($scope.sortItem.onRequest.id === 21) {
					orderByIndividu = ($stateParams.Flag == "1") ? 'proposalNumberDesc' : 'policyNumberDesc';
				} else {
					orderByIndividu = ($stateParams.Flag == "1") ? 'proposalNumber' : 'policyNumber';
				}
			}
			if (searchValIndividu == undefined) {
				searchValIndividu = '';
			}

			$scope.noMoreItemsAvailable = false;
			getDataFromService();
		}


		$scope.changePage = function (policyNumber, agentCode) {
			$state.go('inquiries_proposal_policy_details', { policyNumber: policyNumber, Type: $stateParams.Flag, agentNumber: agentCode, PageType: "unit" });
		}

		$scope.init = function () {
			getListPolisStatusSuccess(ListProposalPolicyStatus);
			getDataProposalPolicyListSuccess(ListProposalPolicy);
		}

		$scope.init();

		function getListPolisStatusSuccess(result) {
			if (result.invocationResult.isSuccessful) {
				if (result.invocationResult.array != null) {

					$scope.listPolisStatus = [];
					for (var i = 0; i < result.invocationResult.array.length; i++) {
						$scope.listPolisStatus.push({ name: result.invocationResult.array[i].name.replace("Show All", $filter('translate')('SHOW_ALL')), value: result.invocationResult.array[i].value });
					}

					$scope.filterItem = { onRequest: $scope.listPolisStatus[0] }

				}
			} else if (result.invocationResult.statusCode == 500) {
				$ionicLoading.hide();
				AppsLog.log("No data found2. Please try again later!");
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}

		function getDataFromService() {
			var Type = '';
			var StatusList = [];

			if ($stateParams.Flag == "1") {
				Type = "proposal";
				if (searchVal2Individu != '') {
					var splitVal = searchVal2Individu.toString().split(",");
					for (var i = 0; i < splitVal.length; i++) {
						StatusList.push("'" + splitVal[i] + "'");
					}
					StatusList = "[" + StatusList + "]";
				} else {
					StatusList = "['PR','PS','PO','WD','UW','DC']";
				}
			} else {
				Type = "policy";

				if (searchVal2Individu != '') {
					var splitVal = searchVal2Individu.toString().split(",");
					for (var i = 0; i < splitVal.length; i++) {
						StatusList.push("'" + splitVal[i] + "'");
					}
					StatusList = "[" + StatusList + "]";
				} else {
					StatusList = "['IF','LA','SU','CF','DH','CC','MA','RD','TP','TR','VF']";
				}
			}

			var agentType = "";

			if($rootScope.UnitByAgentType){
				agentType = "unit";
			}

			PDInquiryProposalPolicyService.invokeListProposalPolicy($rootScope.agent.code, $rootScope.username, $rootScope.agent.code, pageIndividu, sizeIndividu, searchValIndividu, orderByIndividu, StatusList, Type,  agentType).then(function (res) {
				getDataProposalPolicyListSuccess(res);
			});
		}

		function getDataProposalPolicyListSuccess(result) {

			if (result.invocationResult.isSuccessful) {
				var policyHolderNameTemp;
				$scope.showSpinner = false;

				if (result.invocationResult.array != null) {
					if (ListProposalPolicyListAll.length == 0) {
						ListProposalPolicyListAll = [];

						for (var i = 0; i < result.invocationResult.array.length; i++) {
							var dt = {};

							dt.policyHolderName = result.invocationResult.array[i].policyHolderName;
							dt.policyNumber = result.invocationResult.array[i].policyNumber;
							dt.productCode = result.invocationResult.array[i].productName;
							dt.agentCode = result.invocationResult.array[i].agentCode;
							dt.agentName = result.invocationResult.array[i].agentName;
							dt.PruCodeEnd = (dt.productCode).substring(3, (dt.productCode).size);
							dt.proposalNumber = result.invocationResult.array[i].proposalNumber;
							dt.status = result.invocationResult.array[i].status;
							if (result.invocationResult.array[i].policyIssuedDate != null) {
								dt.issueDate = $rootScope.convertNumberMonthToIndonesianWordsMonth(result.invocationResult.array[i].policyIssuedDate, "yyyy-MM-dd");
							}

							ListProposalPolicyListAll[i] = dt;
							pageIndividu = 1;
							var retrieveDate2 = new Date(result.retrieveDate);
							momentDate = moment(retrieveDate2).format('LLLL');
							$scope.lastUpdate = momentDate;

						}

					} else {
						for (var i = 0; i < result.invocationResult.array.length; i++) {
							var dt = {};

							dt.policyHolderName = result.invocationResult.array[i].policyHolderName;
							dt.policyNumber = result.invocationResult.array[i].policyNumber;
							dt.productCode = result.invocationResult.array[i].productName;
							dt.agentCode = result.invocationResult.array[i].agentCode;
							dt.agentName = result.invocationResult.array[i].agentName;
							dt.PruCodeEnd = (dt.productCode).substring(3, (dt.productCode).size);
							dt.proposalNumber = result.invocationResult.array[i].proposalNumber;
							dt.status = result.invocationResult.array[i].status;
							if (result.invocationResult.array[i].policyIssuedDate != null) {
								dt.issueDate = $rootScope.convertNumberMonthToIndonesianWordsMonth(result.invocationResult.array[i].policyIssuedDate, "yyyy-MM-dd");
							}
							ListProposalPolicyListAllAfterAdd[i] = dt;
							ListProposalPolicyListAll.push(ListProposalPolicyListAllAfterAdd[i]);
							$scope.numberOfItemsToDisplay += ListProposalPolicyListAllAfterAdd.length;
							var retrieveDate2 = new Date(result.retrieveDate);
							momentDate = moment(retrieveDate2).format('LLLL');
							$scope.lastUpdate = momentDate;

						}
					}

				}
				$scope.agentList = ListProposalPolicyListAll;
				$ionicLoading.hide();
				$scope.noMoreItemsAvailable = false;
				if (result.invocationResult.statusCode == 500) {
					$ionicLoading.hide();
					$scope.noMoreItemsAvailable = true;
					AppsLog.log("No data found1. Please try again later!");
				}
			} else if (result.invocationResult.statusCode == 500) {
				$scope.showLoading = false;
				$ionicLoading.hide();
				$scope.noMoreItemsAvailable = true;
				AppsLog.log("No data found2. Please try again later!");
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}

	})















