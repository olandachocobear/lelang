﻿angular.module('PruForce.services')
	.service('PDInquiryProposalPolicyService', function (DataFactory, $q, $rootScope) {

		function invokeListProposalPolicy(agentNumber, pruforceId, agentCode, page, size, searchWords, sortBy, statusList, type, PageType) {
			var req = {
				adapter: "HTTPAdapterInquiry",
				procedure: "findListProposalPolicyPD",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + agentNumber + "','" + pruforceId + "','" + agentCode + "'," + page + "," + size + ",'" + searchWords + "','" + sortBy + "'," + statusList + ",'" + type + "','" + PageType + "']" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		function invokeFilterListProposalPolicy(pruforceId, agentNumber, agentCode, statusList, type, pageType) {
			var req = {
				adapter: "HTTPAdapterInquiry",
				procedure: "findFilterListProposalPolicyPD",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + pruforceId + "','" + agentNumber + "','" + agentCode + "'," + statusList + ",'" + type + "','" + pageType + "']" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invokeListProposalPolicy: invokeListProposalPolicy,
			invokeFilterListProposalPolicy: invokeFilterListProposalPolicy
		}
	});
