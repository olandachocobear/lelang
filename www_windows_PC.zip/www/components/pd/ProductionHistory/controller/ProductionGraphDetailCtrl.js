﻿/**
 * 
 */

angular.module('PruForce.controllers')

	.controller('ProductionGraphDetailCtrl', function ($scope, $rootScope, $http, $filter, ProdDetailHistoryData, PDLastUpdateProdHistoryService, $stateParams, $state) {

		PDLastUpdateProdHistoryService.invoke($rootScope.username, $rootScope.agent.code).then(function (res) {
			getLastUpdateSuccess(res);
		});

		getDataDetailProdHistorySuccess(ProdDetailHistoryData);

		function getDataDetailProdHistorySuccess(result) {
			if (result.invocationResult.isSuccessful) {

				ListDataProdHistory = [];
				if (result.invocationResult.array != null || result.invocationResult.array.length != 0) {
					$scope.flagShow = true;
					for (var i = 0; i < result.invocationResult.array.length; i++) {

						var dt = {};
						dt.periodYear = result.invocationResult.array[i].periodYear;
						apeNet = result.invocationResult.array[i].apeNet;
						dt.apeNet = Number(apeNet).formatMoney(2, '.', ',');

						saver = result.invocationResult.array[i].saver;
						dt.saver = Number(saver).formatMoney(2, '.', ',');

						topUp = result.invocationResult.array[i].topUp;
						dt.topUp = Number(topUp).formatMoney(2, '.', ',');

						dt.periodMonth = result.invocationResult.array[i].periodMonth;
						var periodMonth = result.invocationResult.array[i].periodMonth;
						dt.periodMonths = $filter('translate')(replaceMonthNumberToStringFullMonth(periodMonth));

						api = result.invocationResult.array[i].api;
						dt.api = Number(api).formatMoney(2, '.', ',');
						spi = result.invocationResult.array[i].spi;
						dt.spi = Number(spi).formatMoney(2, '.', ',');

						ListDataProdHistory[i] = dt;
					}
				}
				$scope.ListDataProdHistory = ListDataProdHistory;

			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}

		function getDataPolicyClientFailed(result) {
			AppsLog.log("Load Data Failed, Please Check Your Connection");
		}

		function getLastUpdateSuccess(result) {
			if (result.invocationResult.statusCode == 200) {
				var lastUpdate = result.invocationResult.latest;
				var lastUpdateConv = moment(lastUpdate).format('LLLL');
				$scope.lastUpdateConv = lastUpdateConv;
				AppsLog.log("Last update: " + $scope.lastUpdateConv);

			} else {
				$scope.successResult = false;
			}
		}

		$scope.gotoDetail = function (year, month) {
			if ($stateParams.type == 'individu') {
				$state.go("detail_individu_transaction_prodhistory", { year: year, month: month });
			} else {
				$state.go("unit_prod_history", { year: year, month: month });
			}

		}

		$scope.headerTitle = $stateParams.type;
	})