﻿/**
 * 
 */

angular.module('PruForce.controllers')

	.controller("PolicyListProdHistoryIndividuCtrl", function ($scope, $rootScope, $ionicLoading, $http, $state, $filter, ProdHistoryDetailIndividu, PolicyListProdHistoryIndividuService, $stateParams, PolicyFilterIndividu, getLastUpdate) {

		var sizeData = 30;
		var pageData = 1;
		var searchValue = '';
		var filterBy = 'ALL';
		var sortBy = '';
		var sortDir = 'asc';
		var ListPolicy = [];
		var ListPolicyAfterAdd = [];
		$scope.noMoreItemsAvailable = false;
		$scope.numberOfItemsToDisplay = 30;
		$scope.transaction = [];


		$scope.policyHolderNames = {
			data: [{
				id: 0,
				name: $filter('translate')('DEFAULT_SORT')
			}, {
					id: 1,
					name: $filter('translate')('POLICY_NAME')
				}, {
					id: 2,
					name: $filter('translate')('POLICY_NUMBER')
				}, {
					id: 3,
					name: $filter('translate')('TRANSACTION_DATE_ASC')
				}, {
					id: 4,
					name: $filter('translate')('TRANSACTION_DATE_DESC')
				}]
		};

		$scope.sortItem = {
			onRequest: $scope.policyHolderNames.data[0]
		};

		getDataPolicyListSuccess(ProdHistoryDetailIndividu);
		$scope.getDataPolicyListSuccess = getDataPolicyListSuccess;

		function getDataFromService() {
			PolicyListProdHistoryIndividuService.invoke($rootScope.username, $rootScope.agent.code, $rootScope.agent.code, $stateParams.year, $stateParams.month, searchValue,
				filterBy, sortBy, sortDir, sizeData, pageData, "individu").then(function (res) {
					getDataPolicyListSuccess(res);
				});
		}

		$scope.loadMore = function () {

			pageData += 1;
			$scope.showSpinner = true;
			getDataFromService();
			$scope.noMoreItemsAvailable = false;
			$scope.$broadcast('scroll.infiniteScrollComplete');

		};

		$scope.GoSearching_GoFiltering = function () {
			$ionicLoading.show();
			ListPolicy = [];
			sizeData = 30;
			pageData = 1;
			searchValue = ($scope.transaction.searchString == undefined) ? "" : $scope.transaction.searchString.replace(/['|"|\\]/g, "\\$&");


			filterBy = $scope.filterItem.onRequest;

			if ($scope.sortItem.onRequest.id === 0) {
				sortBy = 'clientName';
				sortDir = 'asc';
			} else if ($scope.sortItem.onRequest.id === 1) {
				sortBy = 'clientName';
				sortDir = 'asc';
			} else if ($scope.sortItem.onRequest.id === 2) {
				sortBy = 'policyNumber';
				sortDir = 'asc';
			} else if ($scope.sortItem.onRequest.id === 3) {
				sortBy = 'transactionDate';
				sortDir = 'asc';
			} else if ($scope.sortItem.onRequest.id === 4) {
				sortBy = 'transactionDate';
				sortDir = 'desc';
			}
			if (searchValue == undefined) {
				searchValue = '';
			}

			$scope.noMoreItemsAvailable = false;
			getDataFromService();
		}

		function getDataPolicyListSuccess(result) {
			if (result.invocationResult.isSuccessful) {
				$scope.showSpinner = false;
				if (result.invocationResult.array != null) {
					if (ListPolicy.length == 0) {
						ListPolicy = [];
						for (var i = 0; i < result.invocationResult.array.length; i++) {
							var dt = {};
							api = result.invocationResult.array[i].api;
							dt.api = Number(api).formatMoney(2, '.', ',');

							dt.policyNumber = result.invocationResult.array[i].policyNumber;
							dt.productCode = result.invocationResult.array[i].productCode;
							dt.PruCodeEnd = (dt.productCode).substring(3, (dt.productCode).size);
							dt.transactionType = result.invocationResult.array[i].transactionType;
							dt.clientName = result.invocationResult.array[i].clientName;
							dt.transactionDate = moment(result.invocationResult.array[i].transactionDate).format('LL');
							ListPolicy[i] = dt;
							pageData = 1;
						}
					} else {
						for (var i = 0; i < result.invocationResult.array.length; i++) {
							var dt = {};
							dt.api = result.invocationResult.array[i].api;
							dt.policyNumber = result.invocationResult.array[i].policyNumber;
							dt.productCode = result.invocationResult.array[i].productCode;
							dt.PruCodeEnd = (dt.productCode).substring(3, (dt.productCode).size);
							dt.transactionType = result.invocationResult.array[i].transactionType;
							dt.clientName = result.invocationResult.array[i].clientName;
							dt.transactionDate = moment(result.invocationResult.array[i].transactionDate).format('LL');
							ListPolicyAfterAdd[i] = dt;
							ListPolicy.push(ListPolicyAfterAdd[i]);
							$scope.numberOfItemsToDisplay += ListPolicyAfterAdd.length;
						}
					}
				}
				$scope.ListPolicy = ListPolicy;

				$ionicLoading.hide();
				$scope.noMoreItemsAvailable = false;
				if (result.invocationResult.statusCode == 500) {
					$ionicLoading.hide();
					$scope.noMoreItemsAvailable = true;
					AppsLog.log("No data found1. Please try again later!");
				}

			}
			else if (result.invocationResult.statusCode == 500) {
				$scope.showLoading = false;
				$ionicLoading.hide();
				$scope.noMoreItemsAvailable = true;
				AppsLog.log("No data found2. Please try again later!");
			}
			else {
				AppsLog.log("No data found. Please try again later!");
			}
		}

		function getDataPolicyListFailed(result) {
			AppsLog.log("Load Data Failed, Please Check Your Connection");
		}

		getPolicyFilterStatusSuccess(PolicyFilterIndividu);
		$scope.getPolicyFilterStatusSuccess = getPolicyFilterStatusSuccess;
		function getPolicyFilterStatusSuccess(result) {
			if (result.invocationResult.isSuccessful) {
				if (result.invocationResult.array != null) {

					var listPolisStatus = [];
					for (var i = 0; i < result.invocationResult.array.length; i++) {
						var data = {};
						if (i == 0) {
							data.name = $filter('translate')('SHOW_ALL');
						} else {
							data.name = result.invocationResult.array[i].name;
						}
						data.value = result.invocationResult.array[i].value;
						listPolisStatus[i] = data;
					}
					$scope.listPolisStatus = listPolisStatus;
					$scope.filterItem = {
						onRequest: listPolisStatus[0].name
					}
				}
			} else if (result.invocationResult.statusCode == 500) {
				$ionicLoading.hide();
				AppsLog.log("No data found2. Please try again later!");
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}
		function getListPolisStatusFailed(result) {
			$ionicLoading.hide();
			AppsLog.log("Data Individu Failed, Please Check Your Connection");
		}

		getLastUpdateSuccess(getLastUpdate);
		$scope.getLastUpdateSuccess = getLastUpdateSuccess;
		function getLastUpdateSuccess(result) {
			if (result.invocationResult.statusCode == 200) {
				var lastUpdate = result.invocationResult.latest;
				var lastUpdateConv = moment(lastUpdate).format('LLLL');
				$scope.lastUpdateConv = lastUpdateConv;
				AppsLog.log("Last update: " + $scope.lastUpdateConv);

			} else {
				$scope.successResult = false;
			}
		}

		$scope.changePage = function (id) {
			$state.go('inquiries_proposal_policy_details', { policyNumber: id, Type: "2", agentNumber: $state.params.agentNumber });
		}
	})