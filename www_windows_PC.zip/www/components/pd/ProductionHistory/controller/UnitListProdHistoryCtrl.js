﻿/**
 * 
 */

angular.module('PruForce.controllers')

	.controller("UnitListProdHistoryCtrl", function ($scope, $rootScope, $ionicLoading, $http, $state, $filter, $stateParams, ProdHistoryDetailUnit, UnitListProdHistoryService, UnitFilterProdHistory, getLastUpdate) {

		var sizeData = 30;
		var pageData = 1;
		var filterBy = 'ALL';
		var sortDir = 'asc';
		var ListUnit = [];
		var ListUnitAfterAdd = [];
		$scope.noMoreItemsAvailable = false;
		$scope.numberOfItemsToDisplay = 30;
		$scope.transaction = [];

		$scope.changePage = function (agentNumber) {
			$state.go('detail_individu_transaction_prodhistory_byUnit', { agentNumber: agentNumber, year: $stateParams.year, month: $stateParams.month });
			AppsLog.log("agent id user klik " + agentNumber);
			AppsLog.log("year user klik " + $stateParams.year);
			AppsLog.log("month user klik " + $stateParams.month);
			$rootScope.agentNumberClickByUser = agentNumber;
		}

		$scope.sortOptions = {
			st: [
				{
					id: 0,
					name: $filter('translate')('DEFAULT_SORT')

				},
				{ id: 1, name: $filter('translate')('HIGHEST_APE_PROD') },
				{ id: 2, name: $filter('translate')('LOWEST_APE_PROD') }
			]
		};

		$scope.sortItem = {
			onRequest: $scope.sortOptions.st[0]
		};

		getDataUnitListSuccess(ProdHistoryDetailUnit);
		$scope.getDataUnitListSuccess = getDataUnitListSuccess;

		function getDataFromService() {
			UnitListProdHistoryService.invoke($rootScope.username, $rootScope.agent.code, $stateParams.year, $stateParams.month,
				filterBy, sortDir, sizeData, pageData).then(function (res) {
					AppsLog.log("hasil halaman page " + sizeData);
					AppsLog.log("hasil halaman " + pageData);
					getDataUnitListSuccess(res);
				});
		}

		$scope.loadMore = function () {

			pageData += 1;
			$scope.showSpinner = true;
			getDataFromService();
			$scope.noMoreItemsAvailable = false;
			$scope.$broadcast('scroll.infiniteScrollComplete');

		};

		$scope.GoSearching_GoFiltering = function () {
			$ionicLoading.show();
			ListUnit = [];
			sizeData = 30;
			pageData = 1;

			if ($scope.filterItem.onRequest == $filter('translate')('SHOW_ALL')) {
				filterBy = 'ALL';
			} else {
				filterBy = $scope.filterItem.onRequest;
			}

			if ($scope.sortItem.onRequest.id === 0) {
				sortDir = 'asc';
			} else if ($scope.sortItem.onRequest.id === 1) {
				sortDir = 'desc';
			} else {
				sortDir = 'asc';
			}

			$scope.noMoreItemsAvailable = false;
			getDataFromService();
		}

		function getDataUnitListSuccess(result) {
			if (result.invocationResult.isSuccessful) {
				$scope.showSpinner = false;
				if (result.invocationResult.array != null) {
					if (ListUnit.length == 0) {
						AppsLog.log("masuk sini bro new");
						ListUnit = [];
						for (var i = 0; i < result.invocationResult.array.length; i++) {

							var dt = {};
							dt.clientNumber = result.invocationResult.array[i].clientNumber;
							dt.agentType = result.invocationResult.array[i].agentType;
							dt.clientName = result.invocationResult.array[i].clientName;
							dt.agentNumber = result.invocationResult.array[i].agentNumber;

							totalApe = result.invocationResult.array[i].totalApe;
							dt.totalApe = Number(totalApe).formatMoney(2, '.', ',');
							ListUnit[i] = dt;
							pageData = 1;

						}
					} else {
						AppsLog.log("masuk sini bro add");
						for (var i = 0; i < result.invocationResult.array.length; i++) {

							var dt = {};
							dt.clientNumber = result.invocationResult.array[i].clientNumber;
							dt.agentType = result.invocationResult.array[i].agentType;
							dt.clientName = result.invocationResult.array[i].clientName;
							dt.agentNumber = result.invocationResult.array[i].agentNumber;
							totalApe = result.invocationResult.array[i].totalApe;
							dt.totalApe = Number(totalApe).formatMoney(2, '.', ',');
							ListUnitAfterAdd[i] = dt;
							ListUnit.push(ListUnitAfterAdd[i]);
							$scope.numberOfItemsToDisplay += ListUnitAfterAdd.length;

						}
					}
				}
				$scope.ListUnit = ListUnit;

				$ionicLoading.hide();
				$scope.noMoreItemsAvailable = false;
				if (result.invocationResult.statusCode == 500) {
					$ionicLoading.hide();
					$scope.noMoreItemsAvailable = true;
					AppsLog.log("No data found1. Please try again later!");
				}

			}
			else if (result.invocationResult.statusCode == 500) {
				$scope.showLoading = false;
				$ionicLoading.hide();
				$scope.noMoreItemsAvailable = true;
				AppsLog.log("No data found2. Please try again later!");
			}
			else {
				AppsLog.log("No data found. Please try again later!");
			}
		}

		function getDataUnitListFailed(result) {
			AppsLog.log("Load Data Failed, Please Check Your Connection");
		}

		getUnitFilterStatusSuccess(UnitFilterProdHistory);
		$scope.getUnitFilterStatusSuccess = getUnitFilterStatusSuccess;
		function getUnitFilterStatusSuccess(result) {
			if (result.invocationResult.isSuccessful) {
				if (result.invocationResult.array != null) {

					$scope.agentTypeList = [];
					for (var i = 0; i < result.invocationResult.array.length; i++) {

						if (i == 0) {
							$scope.agentTypeList.push($filter('translate')('SHOW_ALL'));
						} else {
							$scope.agentTypeList.push(result.invocationResult.array[i].name);
						}
					}

					$scope.filterItem = {
                        onRequest: $scope.agentTypeList[0]
					}
				}
			} else if (result.invocationResult.statusCode == 500) {
				$ionicLoading.hide();
				AppsLog.log("No data found2. Please try again later!");
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}
		function getUnitFilterStatusFailed(result) {
			$ionicLoading.hide();
			AppsLog.log("Data Individu Failed, Please Check Your Connection");
		}

		getLastUpdateSuccess(getLastUpdate);
		$scope.getLastUpdateSuccess = getLastUpdateSuccess;
		function getLastUpdateSuccess(result) {
			if (result.invocationResult.statusCode == 200) {
				var lastUpdate = result.invocationResult.latest;
				var lastUpdateConv = moment(lastUpdate).format('LLLL');
				$scope.lastUpdateConv = lastUpdateConv;
				AppsLog.log("Last update: " + $scope.lastUpdateConv);

			} else {
				$scope.successResult = false;
			}
		}

	})