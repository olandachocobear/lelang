﻿/**
 * 
 */
angular.module('PruForce.services')


	.service('PolicyListProdHistoryIndividuService', function (DataFactory, $q) {
		function invoke(salesforceId, agentCode, agentNumber, yeardata, monthdata, searchValue, filterBy, sortBy, sortDir, sizedata, pagedata, pageType) {

			var req = {
                adapter: "HTTPAdapter3",
                procedure: "findPolicyListProdHistoryIndividu",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + salesforceId + "','" + agentCode + "','" + agentNumber + "','" + yeardata + "','" + monthdata + "','" + searchValue + "','" + filterBy + "','" + sortBy + "','" + sortDir + "'," + sizedata + "," + pagedata + ",'" + pageType + "']" }
            };

			var deferred = $q.defer();

			DataFactory.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invoke: invoke
		}
	});

