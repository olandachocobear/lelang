﻿/**
 * 
 */
angular.module('PruForce.services')


	.service('UnitFilterProdHistoryService', function (DataFactory, $q) {
		function invoke(salesforceId, agentCode, yeardata, monthdata) {

			var req = {
                adapter: "HTTPAdapter3",
                procedure: "findUnitFilterProdHistory",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + salesforceId + "','" + agentCode + "','" + yeardata + "','" + monthdata + "']" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invoke: invoke
		}
	});

