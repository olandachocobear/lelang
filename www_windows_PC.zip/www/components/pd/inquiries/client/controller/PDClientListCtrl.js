﻿angular.module('PruForce.controllers')
	.controller("PDClientListCtrl", function ($scope, $rootScope,$ionicLoading, $http, $state, ClientListData, PDClientListService, LastUpdateClient) {
		$scope.changePage = function (id) {
			$rootScope.flagScrollToTop = 'false';
			$state.go("inquiries_client_details", { clientNumber: id });
			//clientNumberClick = id;
		}
		var sizeData = 30;
		var pageData = 1;
		var searchByClient = '';
		var ListClient = [];
		var ListClientAfterAdd = [];
		$scope.noMoreItemsAvailable = false;
		$scope.numberOfItemsToDisplay = 30;
		$scope.transaction = [];

		$scope.PlaceHolderFilter = "POLICY_NAME";

		if($rootScope.pd){
			if($rootScope.UnitByAgentType) {
				$scope.PlaceHolderFilter = "SEARCH_CLIENT";
			}
		}

		getDataClientListSuccess(ClientListData);
		$scope.getDataClientListSuccess = getDataClientListSuccess;

		function getDataFromService() {
			PDClientListService.invoke($rootScope.agent.code, pageData, sizeData, searchByClient,
				$rootScope.username, $rootScope.agent.code).then(function (res) {
					getDataClientListSuccess(res);
				});
		}

		$scope.loadMore = function () {
			pageData += 1;
			$scope.showSpinner = true;
			getDataFromService();
			$scope.noMoreItemsAvailable = false;
			$scope.$broadcast('scroll.infiniteScrollComplete');
		};

		$scope.GoSearching_GoFiltering = function () {
			$ionicLoading.show();
			ListClient = [];
			sizeData = 30;
			pageData = 1;
			searchByClient = ($scope.transaction.searchString==undefined)?"":$scope.transaction.searchString.replace(/['|"|\\]/g, "\\$&");

			if (searchByClient == undefined) {
				searchByClient = '';
			}

			$scope.noMoreItemsAvailable = false;
			getDataFromService();
		}

		function getDataClientListSuccess(result) {
			if (result.invocationResult.isSuccessful) {
				$scope.showSpinner = false;
				if (result.invocationResult.array != null && result.invocationResult.array.length > 0) {
					if (ListClient.length == 0) {
						ListClient = [];
						for (var i = 0; i < result.invocationResult.array.length; i++) {
							var dt = {};
							dt.clientNumber = result.invocationResult.array[i].clientNumber;
							dt.clientName = result.invocationResult.array[i].clientName;
							dt.agentCode = result.invocationResult.array[i].agentCode;
							dt.agentName = result.invocationResult.array[i].agentName;
							dt.address1 = result.invocationResult.array[i].address1;
							dt.address2 = result.invocationResult.array[i].address2;
							dt.address3 = result.invocationResult.array[i].address3;
							dt.address4 = result.invocationResult.array[i].address4;
							dt.address5 = result.invocationResult.array[i].address5;
							ListClient[i] = dt;
							pageData = 1;
						}
					} else {
						for (var i = 0; i < result.invocationResult.array.length; i++) {
							var dt = {};
							dt.clientNumber = result.invocationResult.array[i].clientNumber;
							dt.clientName = result.invocationResult.array[i].clientName;
							dt.agentCode = result.invocationResult.array[i].agentCode;
							dt.agentName = result.invocationResult.array[i].agentName;
							dt.address1 = result.invocationResult.array[i].address1;
							dt.address2 = result.invocationResult.array[i].address2;
							dt.address3 = result.invocationResult.array[i].address3;
							dt.address4 = result.invocationResult.array[i].address4;
							dt.address5 = result.invocationResult.array[i].address5;
							ListClientAfterAdd[i] = dt;
							ListClient.push(ListClientAfterAdd[i]);
							$scope.numberOfItemsToDisplay += ListClientAfterAdd.length;
						}
					}
				} else {
					$scope.noMoreItemsAvailable = true;
					AppsLog.log("No data found1. Please try again later!");
				}
				$scope.ListClient = ListClient;

				$ionicLoading.hide();
				//if(ListClient.length>0){$scope.noMoreItemsAvailable = false;}
				if (result.invocationResult.statusCode == 500) {
					$ionicLoading.hide();
					$scope.noMoreItemsAvailable = true;
					AppsLog.log("No data found1. Please try again later!");
				}
			}
			else if (result.invocationResult.statusCode == 500) {
				$scope.showLoading = false;
				$ionicLoading.hide();
				$scope.noMoreItemsAvailable = true;
				AppsLog.log("No data found2. Please try again later!");
			}
			else {
				AppsLog.log("No data found. Please try again later!");
			}
		}

		function getDataClientListFailed(result) {
			AppsLog.log("Load Data Failed, Please Check Your Connection");
		}

		getLastUpdateClientSuccess(LastUpdateClient);
		function getLastUpdateClientSuccess(result) {
			if (result.invocationResult.isSuccessful) {
				var lastUpdateClient = result.invocationResult.latest;
				var lastUpdate = moment(lastUpdateClient).format('LLLL');
				$scope.lastUpdateClient = lastUpdate;
			} else if (result.invocationResult.statusCode == 500) {
				$ionicLoading.hide();
				AppsLog.log("No data found2. Please try again later!");
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}
		function getLastUpdateClientFailed(result) {
			$ionicLoading.hide();
			AppsLog.log("Data Last Update Failed, Please Check Your Connection");
		}
	})