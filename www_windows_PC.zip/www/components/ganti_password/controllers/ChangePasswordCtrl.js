﻿
angular.module('PruForce.controllers')
	.controller('ChangePasswordCtrl', function ($scope, $ionicPopup, $translate, $filter, $state, $rootScope, $ionicLoading, ChangePasswordService) {

		$scope.initModel = [];
		$scope.ChangePassword = function () {

			if ($scope.initModel.currentPassword == undefined || $scope.initModel.newPassword == undefined || $scope.initModel.newPasswordConfirm == undefined ||
				$scope.initModel.currentPassword == "" || $scope.initModel.newPassword == "" || $scope.initModel.newPasswordConfirm == "") {
				$rootScope.AlertDialog($filter('translate')('PRU_05'));
			} else if ($scope.initModel.newPassword != $scope.initModel.newPasswordConfirm) {
				$rootScope.AlertDialog($filter('translate')('PRU_37'));
			} else {
				AnalyticsLog.logPage("Change.Password");
				$ionicLoading.show();
				ChangePasswordService.invoke($rootScope.username, $scope.initModel.newPassword, $scope.initModel.currentPassword).then(function (res) {
					ChangePassSuccess(res);
				});
			}
		}


		function ChangePassSuccess(result) {
			$ionicLoading.hide();
			var responCode = result.invocationResult.errorCode;
			if (responCode == 000000) {
				if ($rootScope.temp.expiredPassword) {
					$rootScope.DialogEvents($filter('translate')('PRU_38'), 'login');
					$rootScope.temp = {};
				} else {
					if ($rootScope.agent.userType == "candidate") {
						$rootScope.DialogEvents($filter('translate')('PRU_38'), 'home-menu.candidate');
					} else {
						$rootScope.DialogEvents($filter('translate')('PRU_38'), 'home-menu.agent');
					}
				}
			} else {
				$rootScope.AlertDialog(result.invocationResult.errorMessage);
			}
		}

	});