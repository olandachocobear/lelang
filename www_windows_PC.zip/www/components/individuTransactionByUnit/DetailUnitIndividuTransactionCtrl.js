﻿/**
 * 
 */
angular.module('PruForce.controllers')
    .controller('DetailUnitIndividuTransactionCtrl', function ($scope, $rootScope, $ionicLoading, $state, $filter, $stateParams, $interval, IndividuProductionData, DetailUnitIndividuTransactionMonthlyService, DetailUnitIndividuTransactionYearlyService, IndividuPolisStatus) {
        AnalyticsLog.logPage("prudential.production.dtl.indv.unit");
        var sizeIndividuUnit = 30;
        var pageIndividuUnit = 1;
        var searchByIndividu = '';
        var searchValIndividu = '';
        var searchBy2Individu = '';
        var searchVal2Individu = '';
        var orderByIndividu = '';
        var directionIndividu = 'asc';
        $scope.transaction = [];
        var listIndividuAll = [];
        var listIndividuAfterAdd = [];
        
        $scope.numberOfItemsToDisplay = 30;
        $scope.policyHolderNames = {
            data: [{
                id: 0,
                name: $filter('translate')('DEFAULT_SORT')
            }, {
                    id: 1,
                    name: $filter('translate')('POLICY_NAME')
                }, {
                    id: 2,
                    name: $filter('translate')('POLICY_NUMBER')
                }, {
                    id: 3,
                    name: $filter('translate')('TRANSACTION_DATE_ASC')
                }, {
                    id: 4,
                    name: $filter('translate')('TRANSACTION_DATE_DESC')
                }]
        };

        $scope.sortItem = {
            onRequest: $scope.policyHolderNames.data[0]
        };

        $scope.init = function () {
            $ionicLoading.show();
            getDataIndividuListSuccess(IndividuProductionData);
        };

        $scope.init();

        $scope.loadMore = function () {
            pageIndividuUnit += 1;
            $scope.showSpinner = true;
            getDataFromService();
            $scope.noMoreItemsAvailable = false;
            $scope.$broadcast('scroll.infiniteScrollComplete');
        };

        $scope.GoSearching_GoFiltering = function () {
            $ionicLoading.show();
            listIndividuAll = [];
            sizeIndividuUnit = 30;
            pageIndividuUnit = 1;
            searchValIndividu = ($scope.transaction.searchString == undefined) ? "" : $scope.transaction.searchString.replace(/['|"|\\]/g, "\\$&");
            searchByIndividu = '';
            if ($scope.filterItem.onRequest == $filter('translate')('SHOW_ALL')) {
                searchByIndividu = '';
                searchVal2Individu = '';
            } else {
                searchVal2Individu = $scope.filterItem.onRequest;
                searchBy2Individu = 'policyStatus';
            }

            if ($scope.sortItem.onRequest.id === 0) {
                $scope.descSorted = false;
                orderByIndividu = 'policyHolderName';
                directionIndividu = 'asc';
            } else if ($scope.sortItem.onRequest.id === 1) {
                $scope.descSorted = false;
                $scope.policyOption = 'policyHolderName';
                orderByIndividu = 'policyHolderName';
                directionIndividu = 'asc';
            } else if ($scope.sortItem.onRequest.id === 2) {
                $scope.descSorted = false;
                $scope.policyOption = 'policyNumber';
                orderByIndividu = 'policyNumber';
                directionIndividu = 'asc';
            } else if ($scope.sortItem.onRequest.id === 3) {
                $scope.descSorted = false;
                $scope.policyOption = 'transactionDate';
                orderByIndividu = 'transactionDateAsc';
                directionIndividu = 'asc';
            } else if ($scope.sortItem.onRequest.id === 4) {
                $scope.descSorted = true;
                $scope.policyOption = 'transactionDate';
                orderByIndividu = 'transactionDateDesc';
                directionIndividu = 'desc';
            }
            if (searchValIndividu == undefined) {
                searchValIndividu = '';
            }
            $scope.noMoreItemsAvailable = true;
            getDataFromService();
        }

        function getDataFromService() {
            if ($stateParams.type == 'mtd') {
                DetailUnitIndividuTransactionMonthlyService.invoke(
                    $rootScope.agentNumberClickByUser, pageIndividuUnit, sizeIndividuUnit,
                    searchByIndividu, searchValIndividu, searchBy2Individu, searchVal2Individu, orderByIndividu, directionIndividu, $rootScope.username, $rootScope.agent.code)
                    .then(function (res) {
                        getDataIndividuListSuccess(res);
                    });
            } else {
                DetailUnitIndividuTransactionYearlyService
                    .invoke($rootScope.agentNumberClickByUser, pageIndividuUnit, sizeIndividuUnit,
                    searchByIndividu, searchValIndividu, searchBy2Individu, searchVal2Individu, orderByIndividu,
                    directionIndividu, $rootScope.username, $rootScope.agent.code)
                    .then(
                    function (res) {
                        getDataIndividuListSuccess(res);
                    });
            }
        }
    

        function getDataIndividuListSuccess(result) {
            if (result.invocationResult.isSuccessful) {
                var policyHolderNameTemp;
                if (result.invocationResult.array != null) {
                    if (listIndividuAll.length == 0) {
                        listIndividuAll = [];
                        for (var i = 0; i < result.invocationResult.array.length; i++) {
                            var dt = {};
                            var policyHolderName1 = result.invocationResult.array[i].policyHolderName;

                            if (policyHolderName1 == null) {
                                policyHolderNameTemp = "";
                            } else {
                                policyHolderNameTemp = policyHolderName1;
                            }

                            policyValue = result.invocationResult.array[i].policyValue;
                            dt.policyValue = policyValue.formatMoney(2, '.', ',');
                            dt.policyHolderName = policyHolderNameTemp;
                            dt.policyNumber = result.invocationResult.array[i].policyNumber;
                            dt.policyStatus = result.invocationResult.array[i].policyStatus;
                            dt.productCode = result.invocationResult.array[i].productCode;
                            dt.PruCodeEnd = (dt.productCode).substring(3, (dt.productCode).size);
                            dt.transactionDate = moment(result.invocationResult.array[i].transactionDate).format('LL');
                            listIndividuAll[i] = dt;
                            pageIndividuUnit = 1;

                            var responseTimestamp = new Date(result.invocationResult.array[i].responseTimestamp);
                            responseTimestamp = moment(responseTimestamp).format('LLLL');
                            $scope.lastUpdate = responseTimestamp;
                        }
                    } else {
                        for (var i = 0; i < result.invocationResult.array.length; i++) {
                            var dt = {};
                            var policyHolderName1 = result.invocationResult.array[i].policyHolderName;

                            if (policyHolderName1 == null) {
                                policyHolderNameTemp = "";
                            } else {
                                policyHolderNameTemp = policyHolderName1;
                            }

                            policyValue = result.invocationResult.array[i].policyValue;
                            dt.policyValue = policyValue.formatMoney(2, '.', ',');
                            dt.policyHolderName = policyHolderNameTemp;
                            dt.policyNumber = result.invocationResult.array[i].policyNumber;
                            dt.policyStatus = result.invocationResult.array[i].policyStatus;
                            dt.productCode = result.invocationResult.array[i].productCode;
                            dt.PruCodeEnd = (dt.productCode).substring(3, (dt.productCode).size);
                            dt.transactionDate = moment(result.invocationResult.array[i].transactionDate).format('LL');
                            listIndividuAfterAdd[i] = dt;
                            listIndividuAll.push(listIndividuAfterAdd[i]);
                            $scope.numberOfItemsToDisplay += listIndividuAfterAdd.length;

                            var responseTimestamp = new Date(result.invocationResult.array[i].responseTimestamp);
                            responseTimestamp = moment(responseTimestamp).format('LLLL');
                            $scope.lastUpdate = responseTimestamp;
                        }
                    }

                    //								var retrieveDate2 = new Date(
                    //										result.retrieveDate);
                    //								var momentDate = moment(retrieveDate2).format(
                    //										'LLLL');
                    //								$scope.lastUpdate = momentDate;

                }

                $scope.agentList = listIndividuAll;

                Array.prototype.removeValue = function (name, value) {
                    var array = $.map(this, function (v, i) {
                        return v[name] === value ? null : v;
                    });
                    this.length = 0; //clear original array
                    this.push.apply(this, array); //push all elements except the one we want to delete
                }

                $ionicLoading.hide();
                $scope.showSpinner = false;
                $scope.noMoreItemsAvailable = false;
                if (result.invocationResult.statusCode == 500) {
                    $scope.showSpinner = false;
                    $ionicLoading.hide();
                    $scope.noMoreItemsAvailable = true;
                    AppsLog.log("No data found1. Please try again later!");
                }
            } else if (result.invocationResult.statusCode == 500) {
                $scope.showSpinner = false;
                $ionicLoading.hide();
                $scope.noMoreItemsAvailable = true;
                AppsLog.log("No data found2. Please try again later!");
            } else {
                AppsLog.log("No data found. Please try again later!");
            }
        }

        function getDataIndividuListFailed(result) {
            $ionicLoading.hide();
            AppsLog.log("Data Individu Failed, Please Check Your Connection");
        }

        getListPolisStatusSuccess(IndividuPolisStatus);
        $scope.getListPolisStatusSuccess = getListPolisStatusSuccess;
        function getListPolisStatusSuccess(result) {
            if (result.invocationResult.isSuccessful) {
                if (result.invocationResult.array != null) {

                    $scope.listPolisStatus = [];
                    $scope.listPolisStatus.push($filter('translate')('SHOW_ALL'));
                    for (var i = 0; i < result.invocationResult.array.length; i++) {
                        $scope.listPolisStatus.push(result.invocationResult.array[i].value);
                    }

                    $scope.filterItem = {
                        onRequest: $scope.listPolisStatus[0]
                    }

                } else {
                    $ionicLoading.hide();

                    $scope.listPolisStatus = [];
                    $scope.listPolisStatus.push($filter('translate')('SHOW_ALL'));

                    $scope.filterItem = {
                        onRequest: $scope.listPolisStatus[0]
                    }
                }
            } else if (result.invocationResult.statusCode == 500) {
                $ionicLoading.hide();
                AppsLog.log("No data found2. Please try again later!");
            } else {
                AppsLog.log("No data found. Please try again later!");
            }
        }
        function getListPolisStatusFailed(result) {
            $ionicLoading.hide();
            AppsLog.log("Data Individu Failed, Please Check Your Connection");
        }

        $scope.changePage = function (id) {
            $state.go('inquiries_proposal_policy_details', { policyNumber: id, Type: "2", agentNumber: $state.params.agentNumber, PageType: "unit" });
        }
    })