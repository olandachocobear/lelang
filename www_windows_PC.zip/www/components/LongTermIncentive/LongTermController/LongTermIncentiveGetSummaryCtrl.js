﻿/**
 * 
 */

angular.module('PruForce.controllers')

.controller('LongTermIncentiveGetSummaryCtrl', function($scope) {
	
	$scope.getDataLongTermIncentiveSuccess = getDataLongTermIncentiveSuccess;	
	
	$scope.init = function(IncentiveSummary){
		AppsLog.log("masuk init yach "+IncentiveSummary);
		getDataLongTermIncentiveSuccess(IncentiveSummary);
	};
	
	function getDataLongTermIncentiveSuccess(result) {
	    if (result.invocationResult.isSuccessful){
	    	 
	    	ListDataIncentive = [];
	    	if(result.invocationResult.array != null){
	            for (var i = 0; i < result.invocationResult.array.length; i++){
	            	
	                var dt = {};
	                var unitRetained = result.invocationResult.array[i].unitRetained;
	                var entitlement = result.invocationResult.array[i].entitlement;
	                dt.year = result.invocationResult.array[i].year;
	                dt.yearRelease = result.invocationResult.array[i].yearRelease;
	                dt.fund = result.invocationResult.array[i].fund;
	                var releaseUnit = result.invocationResult.array[i].releaseUnit;
	                
	                dt.unitRetained = Number(unitRetained).formatMoney(2, '.', ',');
	                dt.entitlement = Number(entitlement).formatMoney(2, '.', ',');
	                dt.releaseUnit = Number(releaseUnit).formatMoney(2, '.', ',');
	                
	                ListDataIncentive[i] = dt; 

	            }
	    	}
            $scope.ListDataIncentive = ListDataIncentive;
            
	    } else {
            AppsLog.log("No data found. Please try again later!");
        }
    }
 
    function getDataLongTermIncentiveFailed(result){
         AppsLog.log("Load Data Failed, Please Check Your Connection");
    }
	
})