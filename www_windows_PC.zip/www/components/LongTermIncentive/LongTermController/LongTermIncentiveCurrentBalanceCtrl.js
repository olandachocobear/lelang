﻿/**
 * 
 */

angular.module('PruForce.controllers')
	.controller('LongTermIncentiveCurrentBalanceCtrl', function ($scope, $rootScope, LongTermIncentiveCurrentBalanceService, LastUpdateLongTermService, $q) {
		$scope.loading = true;
		$scope.loadingSmall = true;
		$scope.successCall = true;
		$scope.successResult = true;
		$scope.LongTermIncentiveCurrentBalanceService = LongTermIncentiveCurrentBalanceService;
		$scope.LastUpdateLongTermService = LastUpdateLongTermService;
		$scope.init = function () {
			$scope.loading = true;
			$scope.loadingSmall = true;
			$scope.successCall = true;
			$scope.successResult = true;
			LastUpdateLongTermService.invoke($rootScope.agent.code, $rootScope.username, $rootScope.agent.code, true)
				.then(function (res) {
					getLastUpdateLTISuccess(res);
					$scope.loading = false;
				});

			LongTermIncentiveCurrentBalanceService.invoke($rootScope.agent.code, $rootScope.username, $rootScope.agent.code, true)
				.then(function (res) {
					getDataLongTermIncentiveCurrentBalanceSuccess(res);
					$scope.loading = false;
				});
		};

		collection = JsonStoreConfig['findLatestUpdateLTI'];
		$scope.$on(collection.JSONSTORE_NAME, function (event, args) {
			$scope.successCall = (args.status == "success") ? true : false;

			var qLastUpdateLongTermService = LastUpdateLongTermService.invoke($rootScope.agent.code, $rootScope.username, $rootScope.agent.code, false)
				.then(function (res) {
					getLastUpdateLTISuccess(res);
					$scope.loading = false;
				});

			$q.all([qLastUpdateLongTermService]).then(function () {
				$scope.loadingSmall = false;
				$scope.loading = false;
			});
		});

		collection = JsonStoreConfig['findCurrentBalanceLTI'];
		$scope.$on(collection.JSONSTORE_NAME, function (event, args) {
			$scope.successCall = (args.status == "success") ? true : false;

			var qLongTermIncentiveCurrentBalanceService = LongTermIncentiveCurrentBalanceService.invoke($rootScope.agent.code, $rootScope.username, $rootScope.agent.code, false)
				.then(function (res) {
					getDataLongTermIncentiveCurrentBalanceSuccess(res);
					$scope.loading = false;
				});

			$q.all([qLongTermIncentiveCurrentBalanceService]).then(function () {
				$scope.loadingSmall = false;
				$scope.loading = false;
			});
		})

		$scope.init();

		function getDataLongTermIncentiveCurrentBalanceSuccess(result) {
			if (result.invocationResult.statusCode == 200) {

				var unitRetained = result.invocationResult.unitRetained;
				var totalUnit = result.invocationResult.totalUnit;
				var period = result.invocationResult.period;
				var unitRelease = result.invocationResult.unitRelease;
				$scope.fundType = result.invocationResult.fundType;

				$scope.periodDate = moment(period).format('LL');

				$scope.unitRetained = Number(unitRetained).formatMoney(2, '.', ',');
				$scope.totalUnit = Number(totalUnit).formatMoney(2, '.', ',');
				$scope.unitRelease = Number(unitRelease).formatMoney(2, '.', ',');

			} else {
				AppsLog.log("No data found. Please try again later!");
				$scope.successResult = false;
			}
		}

		function getLastUpdateLTISuccess(result) {
			if (result.invocationResult.statusCode == 200) {
				var lastUpdateLTI = result.invocationResult.latest;
				var lastUpdate = moment(lastUpdateLTI).format('LLLL');
				$scope.lastUpdateLTI = lastUpdate;
			} else {
				AppsLog.log("Data Last Update Not Found!");
				$scope.successResult = false;
			}
		}
	})