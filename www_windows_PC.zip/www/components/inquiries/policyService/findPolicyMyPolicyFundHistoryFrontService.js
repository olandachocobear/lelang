﻿/**
 * 
 */
angular.module('PruForce.services')
.service('findPolicyMyPolicyFundHistoryFrontService', function(DataFactory, $q){
	function invoke(agentNumber,pruforceId,policyNumber,page, size, searchWords, sortBy,filterListFund,directionFund){
	    var req = {
	            adapter : "HTTPAdapterInquiry",
	            procedure : "findFundHistoryPolicyList",
	            method: WLResourceRequest.POST,
				parameters : {"params":"['"+agentNumber+"','"+pruforceId+"','"+policyNumber+"',"+page+","+size+",'"+searchWords+"','"+sortBy+"',"+filterListFund+",'"+directionFund+"']"}
			};
		
	    var deferred = $q.defer();
		
	  //AppsLog.log("masuk service fund history test "+agentNumber,pruforceId,policyNumber,page, size, searchWords, sortBy,filterListFund,directionFund);
	    
		DataFactory.invoke(req,true)
	    .then(function (res) {
        	deferred.resolve(res);
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
        }
	
	return {
		invoke: invoke
	}
});

