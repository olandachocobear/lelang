﻿/**
 * 
 */
angular.module('PruForce.services')
.service('findFilterFollowUpStatusToDoService', function(DataFactory, $q){
	function invoke(agentNumber,pruforceId,policyNumberFollowUp, type){
	    var req = {
	            adapter : "HTTPAdapterInquiry",
	            procedure : "findFilterFollowUpStatusToDo",
	            method: WLResourceRequest.POST,
				parameters : {"params":"['"+agentNumber+"','"+pruforceId+"','"+policyNumberFollowUp+"','"+type+"']"}
			};
	    
	    var deferred = $q.defer();
		
		DataFactory.invoke(req,true)
	    .then(function (res) {
        	deferred.resolve(res);
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
	}
	
	return {
		invoke: invoke
	}
});