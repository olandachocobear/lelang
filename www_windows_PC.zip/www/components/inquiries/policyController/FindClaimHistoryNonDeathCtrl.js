﻿
angular.module('PruForce.controllers')
	.controller("FindClaimHistoryNonDeathCtrl", function ($scope, $rootScope, $state, $stateParams, findClaimHistoryNonDeathService) {
		$scope.accordionWidgetCollapse = function (e) {
			var self = $(e.toElement);
			var accordion = self.parents(".widget-policy");
			var accordionBody = accordion.find(".list-info");

			if (accordion.hasClass("collapse")) {
				accordion.removeClass("collapse");
				accordionBody.attr("style", "margin-top: -" + (accordionBody.height() + 15) + "px;");
				// accordionBody.css({"margin-bottom":"-18px"});
			} else {
				accordion.addClass("collapse");
				accordionBody.css("margin-top", "0px");
			}
		}

		$scope.initNonDeath = function (res) {
			getMyNonDeathClaimHistorySuccess(res);
		};

		findClaimHistoryNonDeathService.invoke($rootScope.agent.code, $rootScope.username, $stateParams.policyNumber).then(function (result) {
			getMyNonDeathClaimHistorySuccess(result);
		});

		function getMyNonDeathClaimHistorySuccess(result) {

			if (result.invocationResult.isSuccessful) {
				ListNonDeathClaimHistory = [];
				AppsLog.log("test policy inforce" + result.invocationResult.array);
				if (result.invocationResult.array != null) {
					for (var i = 0; i < result.invocationResult.array.length; i++) {
						var dt = {};
						var separator_approvedAmount = result.invocationResult.array[i].approvedAmount;
						dt.approvedAmount = (separator_approvedAmount).formatMoney(2, '.', ',');
						dt.claimDecisionDate = moment(result.invocationResult.array[i].claimDecisionDate).format('LL');
						dt.claimStatus = result.invocationResult.array[i].claimStatus;
						dt.creationDate = moment(result.invocationResult.array[i].creationDate).format('LL');
						dt.firstPaymentDate = moment(result.invocationResult.array[i].firstPaymentDate).format('LL');
						dt.insuranceBenefit = result.invocationResult.array[i].insuranceBenefit;
						dt.bank = result.invocationResult.array[i].bank;
						ListNonDeathClaimHistory[i] = dt;
					}
					$scope.ListNonDeathClaimHistory = ListNonDeathClaimHistory;
				}
				else if (result.invocationResult.statusCode == 500) {
					ListNonDeathClaimHistory = [];
					$scope.ListNonDeathClaimHistory = ListNonDeathClaimHistory;
					AppsLog.log("No data found. Please try again later! .statusCode==500");
				} else {
					ListNonDeathClaimHistory = [];
					$scope.ListNonDeathClaimHistory = ListNonDeathClaimHistory;
					AppsLog.log("No data found. Please try again later!");
				}
			}
			else {
				ListNonDeathClaimHistory = [];
				AppsLog.log("No data found. Please try again later!");
			}
		}

		function getMyNonDeathClaimHistoryFailed(result) {
			AppsLog.log("Load Data Failed, Please Check Your Connection");
		}
	})