﻿
angular.module('PruForce.controllers')
    .controller("TotalPolicyGraphCtrl", function($state, $templateCache, $scope, $rootScope, $http, TotalPolicyGraphService, PDTotalPolicyGraphService, findLastUpdateService, $q) {
        $scope.loading = true;
        $scope.loadingSmall = true;
        $scope.successCall = true;
        $scope.successResult = true;
        $scope.TotalPolicyGraphService = TotalPolicyGraphService;
        $scope.findLastUpdateService = findLastUpdateService;

        //$scope.getDataAgentProfileSuccess = getDataAgentProfileSuccess;

		/*$scope.initPolicyTotalGraph = function(result){
			getDataTotalPolicyGraphSuccess(result).then(function(res){
	
			}).fail(function(error){
				AppsLog.log("log error");
				AppsLog.log(error);
			})
	
		};*/

        $scope.init = function() {
            $scope.loading = true;
            $scope.loadingSmall = true;
            $scope.successCall = true;
            $scope.successResult = true;
			if($rootScope.pd){
				initPD();
			} else {
				initAgency();
			}
            var qfindLastUpdateService = findLastUpdateService.invoke($rootScope.agent.code, $rootScope.username, true).then(function(res) {
                getMyProposalLastUpdateSuccess(res);
            });
        }

        function initAgency(){
            var qTotalPolicyGraphService = TotalPolicyGraphService.invoke($rootScope.agent.code, $rootScope.username, true).then(function(res) {
                getDataTotalPolicyGraphSuccess(res);
                $scope.loading = false;
            });
        }

        function prepareAgencyData(){
            collection = JsonStoreConfig['findTotalPolicyGraph'];
            $scope.$on(collection.JSONSTORE_NAME, function(event, args) {
                $scope.successCall = (args.status == "success") ? true : false;
                var qTotalPolicyGraphService = TotalPolicyGraphService.invoke($rootScope.agent.code, $rootScope.username, false).then(function(res) {
                    getDataTotalPolicyGraphSuccess(res);
                });
                $q.all([qTotalPolicyGraphService]).then(function() {
                    $scope.loadingSmall = false;
                    $scope.loading = false;
                });
            });
        }

        function initPD(){
            var qTotalPolicyGraphService = PDTotalPolicyGraphService.invoke($rootScope.agent.code, $rootScope.username, true).then(function(res) {
                getDataTotalPolicyGraphSuccess(res);
                $scope.loading = false;
            });
        }

        function preparePDData(){
            collection = JsonStoreConfig['findTotalPolicyGraphPD'];
            $scope.$on(collection.JSONSTORE_NAME, function(event, args) {
                $scope.successCall = (args.status == "success") ? true : false;
                var qTotalPolicyGraphService = PDTotalPolicyGraphService.invoke($rootScope.agent.code, $rootScope.username, false).then(function(res) {
                    getDataTotalPolicyGraphSuccess(res);
                });
                $q.all([qTotalPolicyGraphService]).then(function() {
                    $scope.loadingSmall = false;
                    $scope.loading = false;
                });
            });
        }

		if($rootScope.pd){
			preparePDData();
		} else {
			prepareAgencyData();
		}

        collection = JsonStoreConfig['findLastUpdateProposalPolicy'];
        $scope.$on(collection.JSONSTORE_NAME, function(event, args) {
            $scope.successCall = (args.status == "success") ? true : false;

            var qfindLastUpdateService = findLastUpdateService.invoke($rootScope.agent.code, $rootScope.username, false).then(function(res) {
                getMyProposalLastUpdateSuccess(res);
            });

            $q.all([qfindLastUpdateService]).then(function() {
            });
        });

        $scope.init();

        function getDataTotalPolicyGraphSuccess(result) {
            if (result.invocationResult.statusCode == 200) {
                $scope.inForce = result.invocationResult.inForce;
                $scope.lapsed = result.invocationResult.lapsed;
                $scope.surrender = result.invocationResult.surrender;
                $scope.cancelled = result.invocationResult.cancelled;
                $scope.others = result.invocationResult.others;
                $scope.total = result.invocationResult.total;

                if ($("#inquiriesChartPolicyIndividu").length === 1) {
                    var inquiriesChartPolicyIndividu = new d3pie("inquiriesChartPolicyIndividu", {
                        "size": {
                            "canvasWidth": 160,
                            "canvasHeight": 160,
                            "pieOuterRadius": "100%"
                        },
                        "data": {
                            "content": [
                                {
                                    "label": "In force",
                                    "value": $scope.inForce,
                                    "color": "#ec1b2c"
                                },
                                {
                                    "label": "Lapsed",
                                    "value": $scope.lapsed,
                                    "color": "#4b79bc"
                                },
                                {
                                    "label": "Surrender",
                                    "value": $scope.surrender,
                                    "color": "#fdc056"
                                },
                                {
                                    "label": "Canceled",
                                    "value": $scope.cancelled,
                                    "color": "#696a6c"
                                },
                                {
                                    "label": "Others",
                                    "value": $scope.others,
                                    "color": "#48752a"
                                }
                            ]
                        },
                        "labels": {
                            "outer": {
                                "format": "none",
                                "pieDistance": 16
                            },
                            "inner": {
                                "format": "percentage"
                            },
                            "mainLabel": {
                                "fontSize": 20,
                                //"color": "#ffffff"
                            },
                            "percentage": {
                                "color": "#ffffff",
                                "fontSize": 12,
                                "decimalPlaces": 0
                            },
                            "value": {
                                "color": "#adadad",
                                "fontSize": 19
                            },
                            "lines": {
                                "enabled": true
                            },
                            "truncation": {
                                "enabled": true
                            }
                        },
                        "effects": {
                            "pullOutSegmentOnClick": {
                                "effect": "none",
                                "speed": 400,
                                "size": 8
                            }
                        },
                        "misc": {
                            "gradient": {
                                "enabled": false,
                                "percentage": 100
                            }
                        }
                    });
                }
            } else {
                AppsLog.log("No data found. Please try again later!");
                $scope.successResult = false;
            }
        }

        function getDataTotalPolicyGraphFailed(result) {
            AppsLog.log("Load Data Failed, Please Check Your Connection");
        }

        function getMyProposalLastUpdateSuccess(result) {
            if (result.invocationResult.statusCode == 200) {
                var lastUpdateProp = result.invocationResult.latest;
                var lastUpdate = moment(lastUpdateProp).format('LLLL');
                $scope.lastUpdateProp = lastUpdate;
            } else {
                $scope.successResult = false;
            }
        }

		$scope.goToPolicyList = function(){
			if($rootScope.pd){
				$state.go("pd_inquiries_list_proposal_policy", {"Flag": "2"});
			} else {
				$state.go("inquiries_proposal", {"Type": "2"});
			}
		}
    })