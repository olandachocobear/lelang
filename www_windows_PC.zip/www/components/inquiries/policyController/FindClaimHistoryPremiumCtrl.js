﻿
angular.module('PruForce.controllers')
	.controller("FindClaimHistoryPremiumCtrl", function ($scope, $rootScope, $state, $stateParams, findClaimHistoryPremiumClaimService) {
		$scope.accordionWidgetCollapse = function (e) {
			var self = $(e.toElement);
			var accordion = self.parents(".widget-policy");
			var accordionBody = accordion.find(".list-info");

			if (accordion.hasClass("collapse")) {
				accordion.removeClass("collapse");
				accordionBody.attr("style", "margin-top: -" + (accordionBody.height() + 15) + "px;");
				// accordionBody.css({"margin-bottom":"-18px"});
			} else {
				accordion.addClass("collapse");
				accordionBody.css("margin-top", "0px");
			}
		}
		$scope.initPremiumClaim = function (res) {
			getMyPremimumClaimHistorySuccess(res);
		};

		findClaimHistoryPremiumClaimService.invoke($rootScope.agent.code, $rootScope.username, $stateParams.policyNumber).then(function (result) {
			getMyPremimumClaimHistorySuccess(result);
		});

		function getMyPremimumClaimHistorySuccess(result) {
			if (result.invocationResult.isSuccessful) {
				ListPremiumClaimHistory = [];
				if (result.invocationResult.array != null) {
					for (var i = 0; i < result.invocationResult.array.length; i++) {
						var dt = {};
						dt.approvedAmount = result.invocationResult.array[i].approvedAmount;
						dt.claimDecisionDate = moment(result.invocationResult.array[i].claimDecisionDate).format('LL');
						dt.claimStatus = result.invocationResult.array[i].claimStatus;
						dt.creationDate = moment(result.invocationResult.array[i].creationDate).format('LL');
						dt.firstPaymentDate = moment(result.invocationResult.array[i].firstPaymentDate).format('LL');
						dt.insuranceBenefit = result.invocationResult.array[i].insuranceBenefit;
						ListPremiumClaimHistory[i] = dt;
					}
					$scope.ListPremiumClaimHistory = ListPremiumClaimHistory;
				} else if (result.invocationResult.statusCode == 500) {
					ListPremiumClaimHistory = [];
					$scope.ListPremiumClaimHistory = ListPremiumClaimHistory;
				} else {
					ListPremiumClaimHistory = [];
				}
			}
			else {
				ListPremiumClaimHistory = [];
				AppsLog.log("No data found. Please try again later!");
			}
		}

		function getMyPremimumClaimHistoryFailed(result) {
			AppsLog.log("Load Data Failed, Please Check Your Connection");
		}
	})