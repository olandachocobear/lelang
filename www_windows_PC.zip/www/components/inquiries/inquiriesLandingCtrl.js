﻿angular.module('PruForce.controllers')

.controller('inquiriesLandingCtrl',function($scope, $location, $ionicPopup, $filter, $rootScope, $localStorage
		/*,TotalClientAgent,LastUpdateProp, LastUpdateClient*/
		){
 // $scope.ClientDailyBirthday = ClientDailyBirthday;
	
	AnalyticsLog.logPage("prudential.InquiriesLanding");
	
  /*$scope.TotalClientAgent = TotalClientAgent;
  var updateProp = 'updateProp';
  var updateClient = 'updateClient';
  
  getMyProposalLastUpdateSuccess(LastUpdateProp,updateProp);
  getMyProposalLastUpdateSuccess(LastUpdateClient,updateClient);
  
  function getMyProposalLastUpdateSuccess(result,params)
  {
	  if (result.invocationResult.isSuccessful){
		  var lastUpdateProp = result.invocationResult.latest; 		
		  var lastUpdate = moment(lastUpdateProp).format('LLLL');
		  if(params=='updateProp'){
			  $scope.lastUpdateProp = lastUpdate;	
		  }else{
			  $scope.lastUpdateClient = lastUpdate;	
		  }
	  }
  }*/
	
	
  /*$scope.inquiriesProposal = function(){
	  window.location = "#/inquiries_proposal";
  };
  
  $scope.inquiriesPolicy = function(){
	  window.location = "#/inquiries_policy";
  };
  
  $scope.inquiriesMyClient = function(){
	  window.location = "#/inquiries_my_client";
  };*/
  
  $scope.birthdayList = function(){
	  window.location = "#/inquiries_my_client"
  };

  $scope.go = function(path){
	  $location.path(path);
  }
	
  $scope.proposalWidgetTabs = [
  {title: 'Individu', url: 'components/inquiries/inquiries_landing_proposal.html'},
  {title: 'Unit', url: 'components/inquiries/inquiries_landing_proposal_unit.html'},
  {title: 'Group', url: 'components/inquiries/inquiries_landing_proposal_group.html'}
  ];

  $scope.policyWidgetTabs = [
  {title: 'Individu', url: 'components/inquiries/inquiries_landing_policy_proposal.html'},
  {title: 'Unit', url: 'components/inquiries/inquiries_landing_policy_proposal_unit.html'},
  {title: 'Group', url: 'components/inquiries/inquiries_landing_policy_proposal_group.html'}
  ];

  $scope.currentProposalWidgetTab = $scope.proposalWidgetTabs[0];
  $scope.currentPolicyWidgetTab = $scope.policyWidgetTabs[0];
	
	localStorage.setItem('currentTabPP','components/inquiries_proposal_policy/inquiries_proposal_policy_individu.html'); 

  $scope.proposalOnClickTab = function(proposalTab){
    $scope.currentProposalWidgetTab = proposalTab;
  };

  $scope.proposalIsActiveTab = function(proposalWidgetTabUrl){
    return $scope.currentProposalWidgetTab.url === proposalWidgetTabUrl;
  };

  $scope.policyOnClickTab = function(policyWidgetTab){
    $scope.currentPolicyWidgetTab = policyWidgetTab;
  };

  $scope.policyIsActiveTab = function(policyWidgetTabUrl){
    return $scope.currentPolicyWidgetTab.url === policyWidgetTabUrl;
  };
  
  $scope.showDetails = function() {
	    var alertPopup = $ionicPopup.alert({
	      title: 'Tumenggung Raden Intan Nawacita',
	      templateUrl: 'components/inquiries/template_birthday_list.html',
	      okText: $filter('translate')('CLOSE')
	    });
	  };

	  $scope.closePopup = function() {
	    alertPopup.close();
	  };

	  $scope.accordionInit = function(){
	    var accordions = $(".list-info-accordion");

	    $.each(accordions, function( index, value ) {
	      var accordionBody = $(value).find(".accordion-body");

	      if(!$(value).hasClass("collapsed")){
	        accordionBody.attr("style", "margin-top: -" + accordionBody.height() + "px;")
	      }
	    });
	  }

	  $scope.collapseAccordion = function(e){
	    var self = $(e.toElement);
	    var accordion = self.parents(".list-info-accordion");
	    var accordionBody = accordion.find(".accordion-body");

	    if(accordion.hasClass("collapsed")){
	      accordion.removeClass("collapsed");
	      accordionBody.attr("style", "margin-top: -" + accordionBody.height() + "px;");
	    }else{
	      accordion.addClass("collapsed");
	      accordionBody.css("margin-top", 0);
	    }
	  }

	  angular.element(document).ready(function() {
	    $scope.accordionInit();
	  });
  
	  
	  $scope.agentNumber = $rootScope.agent.code;

		$scope.headerProposalTitle = 'PROPOSAL';
		$scope.headerPolicyTitle = 'POLICY';

		if($rootScope.pd){
			if($rootScope.UnitByAgentType == true){
				$scope.headerProposalTitle = 'PROPOSAL_UNIT';
				$scope.headerPolicyTitle = 'POLICY_UNIT';
			}
		}

});