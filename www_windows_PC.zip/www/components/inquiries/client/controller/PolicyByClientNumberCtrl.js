﻿/**
 * 
 */

angular.module('PruForce.controllers')

.controller("PolicyByClientNumberCtrl", function($scope, $http){
	
	$scope.getDataPolicyClientSuccess = getDataPolicyClientSuccess;
	$scope.flagShow = false;
	
	$scope.init = function(PolicyByClientData){
		AppsLog.log("masuk init yach "+PolicyByClientData);
		getDataPolicyClientSuccess(PolicyByClientData);
	};	
	
	function getDataPolicyClientSuccess(result) {
	    if (result.invocationResult.isSuccessful){
	    	
	    	ListClientPolicyData = [];
	    	if(result.invocationResult.array != null || result.invocationResult.array.length!=0){
	    		$scope.flagShow = true;
	            for (var i = 0; i < result.invocationResult.array.length; i++){
	            	
	                var dt = {};
	                dt.clientNumber = result.invocationResult.array[i].clientNumber;
	                dt.policyStatus = result.invocationResult.array[i].policyStatus;
	                dt.policyNumber = result.invocationResult.array[i].policyNumber;
	                dt.productCode = result.invocationResult.array[i].productCode;
	                dt.PruCodeEnd = (dt.productCode).substring(3,(dt.productCode).size);
	                
	                ListClientPolicyData[i] = dt; 
	                
	            }
	    	}
            $scope.ListClientPolicyData = ListClientPolicyData;
            
	    } else {
            AppsLog.log("No data found. Please try again later!");
        }
    }
 
    function getDataPolicyClientFailed(result){
         AppsLog.log("Load Data Failed, Please Check Your Connection");
    }
	    
})