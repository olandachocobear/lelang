﻿
angular.module('PruForce.controllers')
	.controller("TotalProposalGraphCtrl", function ($state, $templateCache, $scope, $rootScope, $http, findProposalHomeGraphService, findLastUpdateService, PDfindProposalHomeGraphService, $q) {
		$scope.loading = true;
		$scope.loadingSmall = true;
		$scope.successCall = true;
		$scope.successResult = true;

		/*$scope.findProposalHomeGraphService = findProposalHomeGraphService;
		$scope.findLastUpdateService = findLastUpdateService;*/
		//$scope.getDataAgentProfileSuccess = getDataAgentProfileSuccess;

		/*$scope.initProposalTotalGraph = function(result){
			getDataTotalProposalGraphSuccess(result).then(function(res){
				
			}).fail(function(error){
				AppsLog.log("log error");
				AppsLog.log(error);
			})
			
		};*/

		$scope.init = function () {
			$scope.loading = true;
			$scope.loadingSmall = true;
			$scope.successCall = true;
			$scope.successResult = true;
			if($rootScope.pd){
				initPD();
			} else {
				initAgency();
			}

			var qfindLastUpdateService = findLastUpdateService.invoke($rootScope.agent.code, $rootScope.username, true).then(function (res) {
				getMyProposalLastUpdateSuccess(res);
			});
		}

		function initAgency(){
			var qTotalProposalGraphService = findProposalHomeGraphService.invoke($rootScope.agent.code, $rootScope.username, true).then(function (res) {
				getDataTotalProposalGraphSuccess(res);
				$scope.loading = false;
			});
		}

		function prepareAgencyData(){
			collection = JsonStoreConfig['findTotalProposalGraph'];
			$scope.$on(collection.JSONSTORE_NAME, function (event, args) {
				$scope.successCall = (args.status == "success") ? true : false;

				var qTotalProposalGraphService = findProposalHomeGraphService.invoke($rootScope.agent.code, $rootScope.username, false).then(function (res) {
					getDataTotalProposalGraphSuccess(res);
				});

				$q.all([qTotalProposalGraphService]).then(function () {
					$scope.loading = false;
					$scope.loadingSmall = false;
				});
			});
		}

		function initPD(){
			var qTotalProposalGraphService = PDfindProposalHomeGraphService.invoke($rootScope.agent.code, $rootScope.username, true).then(function (res) {
				getDataTotalProposalGraphSuccess(res);
				$scope.loading = false;
			});
		}

		function preparePDData(){
			collection = JsonStoreConfig['findTotalProposalGraphPD'];
			$scope.$on(collection.JSONSTORE_NAME, function (event, args) {
				$scope.successCall = (args.status == "success") ? true : false;

				var qTotalProposalGraphService = PDfindProposalHomeGraphService.invoke($rootScope.agent.code, $rootScope.username, false).then(function (res) {
					getDataTotalProposalGraphSuccess(res);
				});

				$q.all([qTotalProposalGraphService]).then(function () {
					$scope.loading = false;
					$scope.loadingSmall = false;
				});
			});
		}

		if($rootScope.pd){
			preparePDData();
		} else {
			prepareAgencyData();
		}

		collection = JsonStoreConfig['findLastUpdateProposalPolicy'];
		$scope.$on(collection.JSONSTORE_NAME, function (event, args) {
			$scope.successCall = (args.status == "success") ? true : false;

			var qfindLastUpdateService = findLastUpdateService.invoke($rootScope.agent.code, $rootScope.username, false).then(function (res) {
				getMyProposalLastUpdateSuccess(res);
			});

			$q.all([qfindLastUpdateService]).then(function () {
			});
		});

		$scope.init();

		function getDataTotalProposalGraphSuccess(result) {
			var retrieveDate2 = new Date(result.retrieveDate);
			var momentDate = moment(retrieveDate2).format('LLLL');
			var retrieveDate4 = momentDate.toString();
			$scope.lastUpdate = momentDate;
			if (result.invocationResult.statusCode == 200) {
				$scope.totalProposal = result.invocationResult.P;
				$scope.totalUW = result.invocationResult.UA;

				$scope.totalDecline = result.invocationResult.DC;
				$scope.totalPostpone = result.invocationResult.PO;
				$scope.totalNTU = result.invocationResult.WD;
				$scope.total = result.invocationResult.total;

				var inquiriesChartIndividuProposal = new d3pie("inquiriesChartIndividuProposal", {
					"size": {
						"canvasWidth": 160,
						"canvasHeight": 160,
						"pieOuterRadius": "100%"
					},
					"data": {
						"content": [
							{
								"label": "a",
								"value": $scope.totalProposal,
								"color": "#ec1b2c"
							},
							{
								"label": "b",
								"value": $scope.totalUW,
								"color": "#fdc056"
							},
							{
								"label": "c",
								"value": $scope.totalNTU,
								"color": "#696a6c"
							}
						]
					},
					"labels": {
						"outer": {
							"format": "none",
							"pieDistance": 16
						},
						"inner": {
							"format": "percentage"
						},
						"mainLabel": {
							"fontSize": 20,
							//"color": "#ffffff"
						},
						"percentage": {
							"color": "#ffffff",
							"fontSize": 12,
							"decimalPlaces": 0
						},
						"value": {
							"color": "#adadad",
							"fontSize": 19
						},
						"lines": {
							"enabled": true
						},
						"truncation": {
							"enabled": true
						}
					},
					"effects": {
						"pullOutSegmentOnClick": {
							"effect": "none",
							"speed": 400,
							"size": 8
						}
					},
					"misc": {
						"gradient": {
							"enabled": false,
							"percentage": 100
						}
					}
				});
			} else {
				AppsLog.log("No data found. Please try again later!");
				$scope.successResult = false;
			}
		}

		function getDataTotalProposalGraphFailed(result) {
			AppsLog.log("Load Data Failed, Please Check Your Connection");
		}

		function getMyProposalLastUpdateSuccess(result) {
			if (result.invocationResult.statusCode == 200) {
				var lastUpdateProp = result.invocationResult.latest;
				var lastUpdate = moment(lastUpdateProp).format('LLLL');
				$scope.lastUpdateProp = lastUpdate;
			} else {
				$scope.successResult = false;
			}
		}

		$scope.goToProposalList = function(){
			if($rootScope.pd){
				$state.go("pd_inquiries_list_proposal_policy", {"Flag": "1"});
			} else {
				$state.go("inquiries_proposal", {"Type": "1"});
			}
		}
	})