﻿function checkingValidAAJI(dt1, dt2) {
    var count = 0, interval = 0;
    var data = {}; var flag = false;
    data.date = new Array();

    var parts1 = dt1.split('-');
    var date1 = new Date(parts1[0], parts1[1] - 1, parts1[2]);
    var parts2 = dt2.split('-');
    var date2 = new Date(parts2[0], parts2[1] - 1, parts2[2]);
    var getDay1 = date1.getDay();
    var getDay2 = date2.getDay();
    date2 = date2.addDays(1)
    var ONE_DAY = 1000 * 60 * 60 * 24;
    var interval = (date2 - date1) / ONE_DAY;

    for (var i = 0; i < interval; i++) {
        data.date[data.date.length] = date1;
        date1 = date1.addDays(1)
    }

    if (interval > 10) {
        for (var i = 0; i < data.date.length; i++) {
            if (data.date[i].getDay() == 6 || data.date[i].getDay() == 0) {
                count = count;
                flag = true;
            } else {
                count = count + 1;
            }
        }
    } else {
        for (var i = 0; i < data.date.length; i++) {
            if (data.date[i].getDay() == 6 || data.date[i].getDay() == 0) {
                count = count;
                flag = true;
            } else {
                count = count + 1;
            }
        }
    }

    return count;
}

function checkAAJICount(AAJIDate) {
    var date = new Date();
    var aajiexamdate = new Date(AAJIDate);
    var currentHour = date.getHours();
    var month = date.getMonth() + 1;
    var day = date.getDate();
    var AAJImonth = aajiexamdate.getMonth() + 1;
    var AAJIday = aajiexamdate.getDate();
    var tgl = date.getFullYear() + '-' +
        (month < 10 ? '0' : '') + month + '-' +
        (day < 10 ? '0' : '') + day;
    var AAJIexamdatestr = aajiexamdate.getFullYear() + '-' +
        (AAJImonth < 10 ? '0' : '') + AAJImonth + '-' +
        (AAJIday < 10 ? '0' : '') + AAJIday;
    var currentDate = tgl.toString();
    var aajidate = AAJIexamdatestr.toString();
    var count = checkingValidAAJI(currentDate, aajidate);
    return count;
}


