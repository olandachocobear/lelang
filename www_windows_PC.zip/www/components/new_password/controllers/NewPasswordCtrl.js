﻿/**
 * 
 */
angular.module('PruForce.controllers')

    .controller('NewPasswordCtrl', function ($scope, $translate, $filter, $state, $rootScope, $localStorage, $ionicPopup, $ionicLoading, NewPasswordService) {

        $scope.initModel = {};
        $scope.initModel.pruforceId = $rootScope.agent.pruforceId;
        $scope.initModel.readOnly = $rootScope.temp.readOnly;

        $scope.NewPass = function () {
            if ($scope.initModel.pruforceId == undefined || $scope.initModel.password == undefined || $scope.initModel.cpassword == undefined) {
                $rootScope.AlertDialog($filter('translate')('PRU_05'));
            } else if ($scope.initModel.password != $scope.initModel.cpassword) {
                $rootScope.AlertDialog($filter('translate')('PRU_37'));
            } else {
                $ionicLoading.show();
                NewPasswordService.invoke($scope.initModel.pruforceId, $scope.initModel.password)
                    .then(function (res) {
                        NewPasswordSuccess(res);
                    });
            }
        }
        function NewPasswordSuccess(result) {
            $ionicLoading.hide();
            if (result.invocationResult.errorCode == 000000) {
                $rootScope.AlertDialog($filter('translate')('PRU_38'));
                $state.go("login");
            } else {
                $rootScope.AlertDialog(result.invocationResult.errorMessage);
            }

        }

    })