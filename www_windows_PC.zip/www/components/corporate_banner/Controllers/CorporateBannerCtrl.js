﻿angular.module('PruForce.controllers').controller("CorporateBannerCtrl", function ($scope, $ionicBackdrop, $ionicModal, $ionicSlideBoxDelegate, $ionicScrollDelegate, CorporateBannerService, newsListMobileService, $rootScope) {

  $scope.init = function (ListImage) {
    $scope.ListBanner = [];
    for (var i = 0; i < ListImage.length; i++) {
      $scope.ListBanner.push({ imgUrl: "data:image/jpeg;base64," + ListImage[i].imageBase64 });
    }
  };

  $scope.data = {};
  $scope.data.currentPage = 1;

  $scope.zoomMin = 1;

  $scope.showImages = function (index) {
    AnalyticsLog.logPage("prudential.corporatebanner.detail");
    $scope.activeSlide = index;
    $scope.showModal('components/news_update/zoomSlider.html', index);

  };

  $scope.showModal = function (templateUrl, index) {
    $ionicModal.fromTemplateUrl(templateUrl, {
      scope: $scope
    }).then(function (modal) {
      $scope.modal = modal;
      $scope.imgSrc = $scope.ListBanner[index]
      $scope.modal.show();
    });
  }

  $scope.closeModal = function () {
    $scope.modal.hide();
    $scope.modal.remove()
  };

  $scope.updateSlideStatus = function (slide) {
    var zoomFactor = $ionicScrollDelegate.$getByHandle('scrollHandle' + slide).getScrollPosition().zoom;
    if (zoomFactor == $scope.zoomMin) {
      $ionicSlideBoxDelegate.enableSlide(true);
    } else {
      $ionicSlideBoxDelegate.enableSlide(false);
    }
  };

  $scope.next = function () {
    AnalyticsLog.logPage("prudential.corporatebanner.detail");
    $ionicSlideBoxDelegate.next();

  };

  $scope.previous = function () {
    AnalyticsLog.logPage("prudential.corporatebanner.detail");
    $ionicSlideBoxDelegate.previous();
  };

  var setupSlider = function () {
    $scope.data.sliderOptions = {
      initialSlide: 1,
      direction: 'horizontal',
      speed: 300
    };
  };

  $scope.sliderOptions = {
    autoplay: 2500,
    autoplayDisableOnInteraction: false
  };

  $ionicSlideBoxDelegate.update();

});

