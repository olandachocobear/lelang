﻿angular.module('PruForce.services')
	.service('CorporateBannerService', function (DataFactory, $q, $cordovaSQLite, $rootScope) {

		$rootScope.dbBanner = null;

		function invoke(salesforceId, agentNumber, channelType) {
			var req = {
				adapter: "HTTPAdapterNewsUpdate",
				procedure: "getCorporateBanner",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + salesforceId + "','" + agentNumber + "', '"+channelType+"']" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, false, false)
				.then(function (res) {
					var imageList = [];
					var newBanner = [];
					var lookupId = [];

					if (res.invocationResult.isSuccessful) {
						if (res.invocationResult.array != null) {
							for (var i = 0; i < res.invocationResult.array.length; i++) {
								var dt = {};

								dt.news_id = res.invocationResult.array[i].id;
								dt.news_title = res.invocationResult.array[i].title;
								dt.imgUrl = res.invocationResult.array[i].imageName;
								
								var bannerImage = (dt.imgUrl != null && dt.imgUrl.indexOf("|")) ? dt.imgUrl.split("|") : null;
								dt.bannerImageName = bannerImage ? bannerImage[0] : "image"; 
								dt.bannerImageFileName = bannerImage ? bannerImage[1] : ""; 

								newBanner.push(dt.bannerImageFileName);
								lookupId.push(dt.bannerImageFileName);
								imageList.push(dt);
							}
						}
					}

					return selectLocalCorporateBanner(newBanner).then(function(localBanner){

					if(localBanner != null && localBanner.length > 0){
						angular.forEach(localBanner, function(bannerImage, key)
						{
							var index = newBanner.indexOf(bannerImage.imageName);

							if(index > -1){
								imageList[lookupId.indexOf(bannerImage.imageName)].imageBase64 = bannerImage.imageBase64;
								newBanner.splice(index, 1);
							}
						});
					}
					
					if(newBanner.length > 0){
						return invokeNewsFileRecord(newBanner.join(), "corporatebanner").then(
							function (result) {
								if (result.invocationResult.isSuccessful) {
									if(result.invocationResult.content != null){
										var newBannerImage = [];
										angular.forEach(result.invocationResult.content, function(value, key)
										{
											newBannerImage.push({
												"imageName": value.fileName,
												"imageBase64" : value.fileData 
											});
											imageList[lookupId.indexOf(value.fileName)].imageBase64 = value.fileData;
										});
										addImage(newBannerImage).then(function(){
											deferred.resolve(imageList);
										});
									}
								}
							},
							function (error) {
								deferred.reject(error);
							}
						);
					}

					deferred.resolve(imageList);
				});

				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		function invokeNewsFileRecord(fileName, module) {
			var req = {
				adapter: "HTTPAdapterNewsUpdate",
				procedure: "getFileRecordBanner",
                method: WLResourceRequest.POST,
				parameters: { "params": "['" + fileName + "','" + module + "']" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, true, false)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		function addImage(images){
			try {
				var deferred = $q.defer();
				if(images.length > 0){
					var insertValues = [];

					angular.forEach(images, function(newBannerImage, key){
						insertValues.push("('" + newBannerImage.imageName + "','" + newBannerImage.imageBase64 +"')");
					})
					var insertQuery = "INSERT INTO tblImageBanner (imageName, imageBase64) VALUES " + insertValues.join();

					$rootScope.dbBanner.transaction(function (tx) {
						tx.executeSql(insertQuery, [], function (tx, res) {
							deferred.resolve(res);
						}, function (tx, error) {
							AppsLog.log('Insert error: ' + error.message);
							deferred.reject(error);
						});
					});
				}

				return deferred.promise;
			} catch (error) {
                AppsLog.log("Error Insert Banner :" + error);
			}
		}

		function removeImageExcept(newBanner) {
			var deferred = $q.defer();
			try {
				$rootScope.dbBanner.transaction(function (tx) {
					var notInValue = [];
					angular.forEach(newBanner,function(value){
						notInValue.push("'" + value + "'");
					});
					var query = "DELETE FROM tblImageBanner WHERE imageName not in (" + notInValue.join() + ")";
					tx.executeSql(query, [], function (tx, res) {
						AppsLog.log('DELETE succcess');
						deferred.resolve(res);
					}, function (tx, error) {
						AppsLog.log('DELETE error: ' + error.message);
						deferred.resolve(error);
					});
				});
				return deferred.promise;
			} catch (error) {
                AppsLog.log("Error Delete Banner :" + error);
				deferred.resolve(error);
			}
		}

		function selectLocalCorporateBanner(newBanner) {
			var deferred = $q.defer();
			prepareDB().then(function(){
				try {
					removeImageExcept(newBanner).then(function(){
						$rootScope.dbBanner.transaction(function (tx) {
							var query = "SELECT * FROM tblImageBanner";
							tx.executeSql(query, [], function (tx, rs) {
								var localBanner = [];
								for (var i = 0; i < rs.rows.length; i++) {
									var rows = $rootScope.platform == 'preview' ? rs.rows[i] : rs.rows.item(i);

									localBanner.push({
										"imageName": rows.imageName, 
										"imageBase64": rows.imageBase64
									});
								}
								deferred.resolve(localBanner);
							}, function (tx, error) {
								AppsLog.log(error);
								deferred.reject(error);
							});
						});
					});
				} catch (error) {
					AppsLog.log(error);
					deferred.reject(error);
				}
			});
			return deferred.promise;
		}

		function prepareDB() {
			var deferred = $q.defer();
			try {
                if ($rootScope.platForm == 'iphone' || $rootScope.platForm == 'ipad') {
                    $rootScope.dbBanner = $cordovaSQLite.openDB({ name: "imageBanner.db", location: "default" }); //device
                } else {
                    $rootScope.dbBanner = window.openDatabase("imageBanner.db", '1', 'my', 1024 * 1024 * 10000); // browser
                }
                $cordovaSQLite.execute($rootScope.dbBanner, "CREATE TABLE IF NOT EXISTS tblImageBanner (imageName, imageBase64)").then(function(res){
					deferred.resolve(res);
				}, function(){
					AppsLog.log(error);
					deferred.reject(error);
				});
				return deferred.promise;
            } catch (error) {
                AppsLog.log("error to prepare DB Banner :" + error);
				deferred.reject(error);
            }
		}

		return {
			invoke: invoke
		}
	});

