﻿angular.module('PruForce.services')

.service('SyaratKetentuanService', function($q, $filter, AOBResources){
	
	var collection = JsonStoreConfig.DataSyaratKetentuan;
	
	function getDataSyaratKetentuan(candidateParam){
		var networkState = navigator.connection.type;
		
		var promise;
		
		if (networkState == Connection.NONE)
		{
			promise = getDataSyaratKetentuanFromJsonStore(candidateParam);
		} else {
			var childpromise;
			promise = getDataSyaratKetentuanFromJsonStore(candidateParam).then(
				function(result){
					if(result === 'empty'){
						childpromise = getDataSyaratKetentuanFromServer(candidateParam).then(
							function(res){
								return getDataSyaratKetentuanFromJsonStore(candidateParam);
							},
							function(error){

							}
						);
					} else {
						childpromise = getDataSyaratKetentuanFromJsonStore(candidateParam);
					}

					return childpromise;
				},
				function(error){
					
				}
			);
			
		}
		
		return promise;
	};
	
	function getDataSyaratKetentuanFromJsonStore(candidateParam){
		var deferred = $q.defer();
		
		try{
			var query = candidateParam;
			var options = {exact: false
				    	   //limit: 100 //returns a maximum of 10 documents
				    	  };
			
			WL.JSONStore.get(collection.JSONSTORE_NAME).find(query, options).then(function(res){
				try{
					if(res.length > 0){
						deferred.resolve(res[0]);
					} else {
						deferred.resolve("empty");
					}		
				} catch(error){
					deferred.reject(error);
				}						
			}).fail(function(error){
				deferred.reject(error);
			});
		} catch (error) {
			deferred.reject(error);
		}
		
		return deferred.promise;
	}
	
	function getDataSyaratKetentuanFromServer(candidateParam){
		
		var promise = getDataSyaratKetentuanFromJsonStore(candidateParam);
		
		return promise;
	}
	
	function saveDataSyaratKetentuan(dataParam){
		var deferred = $q.defer();
		
		var data = dataParam;
		
		var dataCandidateParam = {
				  agentId: data.agentId,
				  npa: data.npa
			  }
		
		
		getDataSyaratKetentuanFromJsonStore(dataCandidateParam).then(
			function(result){
				if(result === 'empty'){
					WL.JSONStore.get(collection.JSONSTORE_NAME).add(data).then(function () {
						deferred.resolve(result);
					}).fail(function (error) {
						deferred.reject(error);
					});
				} else {
					result.json = data;
					var options = {};
					WL.JSONStore.get(collection.JSONSTORE_NAME).replace(result, options).then(function (numberOfDocsReplaced) {
						deferred.resolve("Success modify " + numberOfDocsReplaced + " documents");
					}).fail(function (error) {
						deferred.reject(error);
					});
				}
			},
			function(error){
				deferred.reject(error);
			}
		);
		
		return deferred.promise;
	}
	
	

	return {
		getDataSyaratKetentuan: getDataSyaratKetentuan,
		saveDataSyaratKetentuan: saveDataSyaratKetentuan
	}
});