﻿angular.module('PruForce.services')

    .service('GetInquiryBOService', function (AOBResources, $q) {

        function invoke(OBJID, AGNTSEL) {

            var req = {
                adapter: "HTTPAdapterAuth",
                procedure: "getInquiryBO",
                method: WLResourceRequest.POST,
                parameters: { "params": "['" + OBJID + "','" + AGNTSEL + "']" }
            };

            var deferred = $q.defer();

            AOBResources.invoke(req, true)
                .then(function (res) {
                    deferred.resolve(res);
                }, function (error) {
                    deferred.reject(error);
                });

            return deferred.promise;
        }

        return {
            invoke: invoke
        }
    });

