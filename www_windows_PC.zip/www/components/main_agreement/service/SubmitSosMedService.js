﻿angular.module('PruForce.services')

    .service('SubmitSosMedService', function (AOBResources, $q) {

        function invoke(npa, snstype, accountname, description) {

            var req = {
                adapter: "HTTPAdapterAuth",
                procedure: "inputSnsAccount",
                method: WLResourceRequest.POST,
                parameters: { "params": "['" + npa + "','" + snstype + "','" + accountname + "','" + description + "']" }
            };

            var deferred = $q.defer();

            AOBResources.invoke(req, true)
                .then(function (res) {
                    deferred.resolve(res);
                }, function (error) {
                    deferred.reject(error);
                });

            return deferred.promise;
        }

        return {
            invoke: invoke
        }
    });
