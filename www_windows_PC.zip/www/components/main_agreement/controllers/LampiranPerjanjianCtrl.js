﻿var pruforce = angular.module('PruForce');

pruforce.controller('LampiranPerjanjianCtrl', function ($scope, $ionicScrollDelegate, $timeout) {
  $timeout(function () {
    var sv = $ionicScrollDelegate.$getByHandle('horizontal').getScrollView();

    var container = sv.__container;

    var originaltouchStart = sv.touchStart;
    var originalmouseDown = sv.mouseDown;
    var originaltouchMove = sv.touchMove;
    var originalmouseMove = sv.mouseMove;

    container.removeEventListener('touchstart', sv.touchStart);
    container.removeEventListener('mousedown', sv.mouseDown);
    document.removeEventListener('touchmove', sv.touchMove);
    document.removeEventListener('mousemove', sv.mousemove);


    sv.touchStart = function (e) {
      e.preventDefault = function () { }
      originaltouchStart.apply(sv, [e]);
    }

    sv.touchMove = function (e) {
      e.preventDefault = function () { }
      originaltouchMove.apply(sv, [e]);
    }

    sv.mouseDown = function (e) {
      e.preventDefault = function () { }
      if (originalmouseDown) {
        originalmouseDown.apply(sv, [e]);
      }
    }

    sv.mouseMove = function (e) {
      e.preventDefault = function () { }
      if (originalmouseMove) {
        originalmouseMove.apply(sv, [e]);
      }
    }

    container.addEventListener("touchstart", sv.touchStart, false);
    container.addEventListener("mousedown", sv.mouseDown, false);
    document.addEventListener("touchmove", sv.touchMove, false);
    document.addEventListener("mousemove", sv.mouseMove, false);
  });

  $timeout(function () {
    var sv = $ionicScrollDelegate.$getByHandle('horizontal2').getScrollView();

    var container = sv.__container;

    var originaltouchStart = sv.touchStart;
    var originalmouseDown = sv.mouseDown;
    var originaltouchMove = sv.touchMove;
    var originalmouseMove = sv.mouseMove;

    container.removeEventListener('touchstart', sv.touchStart);
    container.removeEventListener('mousedown', sv.mouseDown);
    document.removeEventListener('touchmove', sv.touchMove);
    document.removeEventListener('mousemove', sv.mousemove);


    sv.touchStart = function (e) {
      e.preventDefault = function () { }
      originaltouchStart.apply(sv, [e]);
    }

    sv.touchMove = function (e) {
      e.preventDefault = function () { }
      originaltouchMove.apply(sv, [e]);
    }

    sv.mouseDown = function (e) {
      e.preventDefault = function () { }
      if (originalmouseDown) {
        originalmouseDown.apply(sv, [e]);
      }
    }

    sv.mouseMove = function (e) {
      e.preventDefault = function () { }
      if (originalmouseMove) {
        originalmouseMove.apply(sv, [e]);
      }
    }

    container.addEventListener("touchstart", sv.touchStart, false);
    container.addEventListener("mousedown", sv.mouseDown, false);
    document.addEventListener("touchmove", sv.touchMove, false);
    document.addEventListener("mousemove", sv.mouseMove, false);
  });
});

(function () {
  var HorizontalScrollFix = (function () {
    function HorizontalScrollFix($timeout, $ionicScrollDelegate) {
      return {
        restrict: 'A',
        link: function (scope, element, attrs) {
          var mainScrollID = attrs.horizontalScrollFix,
            scrollID = attrs.delegateHandle;

          var getEventTouches = function (e) {
            return e.touches && (e.touches.length ? e.touches : [
              {
                pageX: e.pageX,
                pageY: e.pageY
              }
            ]);
          };

          var fixHorizontalAndVerticalScroll = function () {
            var mainScroll, scroll;
            mainScroll = $ionicScrollDelegate.$getByHandle(mainScrollID).getScrollView();
            scroll = $ionicScrollDelegate.$getByHandle(scrollID).getScrollView();

            scroll.__container.removeEventListener('touchstart', scroll.touchStart);
            scroll.touchStart = function (e) {
              var startY;
              scroll.startCoordinates = ionic.tap.pointerCoord(e);
              if (ionic.tap.ignoreScrollStart(e)) {
                return;
              }
              scroll.__isDown = true;
              if (ionic.tap.containsOrIsTextInput(e.target) || e.target.tagName === 'SELECT') {
                scroll.__hasStarted = false;
                return;
              }
              scroll.__isSelectable = true;
              scroll.__enableScrollY = true;
              scroll.__hasStarted = true;
              scroll.doTouchStart(getEventTouches(e), e.timeStamp);
              startY = mainScroll.__scrollTop;

              $timeout((function () {
                var animate, yMovement;
                yMovement = startY - mainScroll.__scrollTop;
                if (scroll.__isDragging && yMovement < 2.0 && yMovement > -2.0) {
                  mainScroll.__isTracking = false;
                  mainScroll.doTouchEnd();
                  animate = false;
                  return mainScroll.scrollTo(0, startY, animate);
                } else {
                  // return scroll.doTouchEnd();
                }
              }), 100);
            };
            scroll.__container.addEventListener('touchstart', scroll.touchStart);
          };
          $timeout(function () { fixHorizontalAndVerticalScroll(); });
        }
      };
    }

    return HorizontalScrollFix;

  })();

  angular.module('PruForce').directive('horizontalScrollFix', ['$timeout', '$ionicScrollDelegate', HorizontalScrollFix]);

}).call(this);


