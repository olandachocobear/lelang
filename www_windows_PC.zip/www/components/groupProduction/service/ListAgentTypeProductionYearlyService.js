﻿angular.module('PruForce.services')

	.service('ListAgentTypeProductionYearlyService', function (DataFactory, $q) {
		function invoke(agentNumberPolis, pruforceId) {

			var req = {
                adapter: "HTTPAdapter3",
                procedure: "findAllAgentTypeProductionYearly",
                method: WLResourceRequest.POST,
				parameters: { "params": "['" + agentNumberPolis + "','" + pruforceId + "']" }
			};


			AppsLog.log("Request 1 polis  :" + agentNumberPolis);
			AppsLog.log("Request 2 polis :" + pruforceId);

			var deferred = $q.defer();

			DataFactory.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invoke: invoke
		}
	});