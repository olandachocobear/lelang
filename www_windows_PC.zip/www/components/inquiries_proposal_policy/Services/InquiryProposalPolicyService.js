﻿/**
 * 
 */
angular.module('PruForce.services')
.service('InquiryProposalPolicyService', function(DataFactory, $q,$rootScope){
	
	function invokeUnit(filterBy,orderBy,page, size, salesforceId, agentNumber,type){
		var req = {
				adapter : "HTTPAdapterInquiry",
				procedure : "findUnitProposalPolicy",
				method: WLResourceRequest.POST,
     			parameters : {"params":"['"+filterBy+"','"+orderBy+"',"+page+","+size+",'"+salesforceId+"','"+agentNumber+"','"+type+"']"}
			};
		
	    var deferred = $q.defer();

		DataFactory.invoke(req,true)
	    .then(function (res) {
        	deferred.resolve(res);
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
	}
	
	function invokeUnitStatus(salesforceId, agentNumber){
		var req = {
				adapter : "HTTPAdapterInquiry",
				procedure : "findFilterUnitProposalPolicy",
				method: WLResourceRequest.POST,
     			parameters : {"params":"['"+salesforceId+"','"+agentNumber+"']"}
			};
		
	    var deferred = $q.defer();
	    
		DataFactory.invoke(req,true)
	    .then(function (res) {
        	deferred.resolve(res);
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
		
	}
	
	function invokeListProposalPolicy(agentNumber,pruforceId,agentCode,page, size, searchWords, sortBy, statusList, type, PageType){
		var req = {
				adapter : "HTTPAdapterInquiry",
				procedure : "findListProposalPolicy",
				method: WLResourceRequest.POST,
     			parameters : {"params":"['"+agentNumber+"','"+pruforceId+"','"+agentCode+"',"+page+","+size+",'"+searchWords+"','"+sortBy+"',"+statusList+",'"+type+"','"+PageType+"']"}
			};
		
	    var deferred = $q.defer();

		DataFactory.invoke(req,true)
	    .then(function (res) {
        	deferred.resolve(res);
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
	}
	
	function invokeFilterListProposalPolicy(pruforceId,agentNumber,agentCode, statusList, type,pageType){
		var req = {
				adapter : "HTTPAdapterInquiry",
				procedure : "findFilterListProposalPolicy",
				method: WLResourceRequest.POST,
     			parameters : {"params":"['"+pruforceId+"','"+agentNumber+"','"+agentCode+"',"+statusList+",'"+type+"','"+pageType+"']"}
			};
		
	    var deferred = $q.defer();

		DataFactory.invoke(req,true)
	    .then(function (res) {
        	deferred.resolve(res);
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
	}
	
	/*Proposal Policy Detail*/

	function invokefindTotalProposalPolicyGraph(agentNumber,pruforceId,agentCode,type,pageType){
		var req = {
				adapter : "HTTPAdapterInquiry",
				procedure : "findTotalProposalPolicyGraph",
				method: WLResourceRequest.POST,
     			parameters : {"params":"['"+agentNumber+"','"+pruforceId+"','"+agentCode+"','"+type+"','"+pageType+"']"}
			};
		
	    var deferred = $q.defer();

		DataFactory.invoke(req,true)
	    .then(function (res) {
        	deferred.resolve(res);
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
	}
	
	function invokefindPersonalDataProposalPolicy(agentNumber,pruforceId,policyNumber,agentCode,pageType){
		var req = {
				adapter : "HTTPAdapterInquiry",
				procedure : "findPersonalDataProposalPolicy",
				method: WLResourceRequest.POST,
     			parameters : {"params":"['"+agentNumber+"','"+pruforceId+"','"+policyNumber+"','"+agentCode+"','"+pageType+"']"}
			};
		
	    var deferred = $q.defer();

		DataFactory.invoke(req,true)
	    .then(function (res) {
        	//temporary code, because can't get data when agent changing the leader.
        	if(res.invocationResult.statusCode == 200){
        		deferred.resolve(res);
            }else{
				deferred.reject(res);
				if(res.invocationResult.message == "data not found"){
					$rootScope.AlertDialog('Rincian Polis tidak dapat dilihat terkait adanya proses perubahan manajer keagenan.');
				}
            }
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
	}
	
	function invokefindProposalPolicyData(agentNumber,pruforceId,policyNumber,type,agentCode,pageType){
		var req = {
				adapter : "HTTPAdapterInquiry",
				procedure : "findProposalPolicyData",
				method: WLResourceRequest.POST,
     			parameters : {"params":"['"+agentNumber+"','"+pruforceId+"','"+policyNumber+"', '"+type+"','"+agentCode+"','"+pageType+"']"}
			};
		
	    var deferred = $q.defer();

		DataFactory.invoke(req,true)
	    .then(function (res) {
        	deferred.resolve(res);
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
	}

	
	function invokefindPremiumDataProposalPolicy(agentNumber,pruforceId,policyNumber,type,agentCode,pageType){
		var req = {
				adapter : "HTTPAdapterInquiry",
				procedure : "findPremiumDataProposalPolicy",
				method: WLResourceRequest.POST,
     			parameters : {"params":"['"+agentNumber+"','"+pruforceId+"','"+policyNumber+"', '"+type+"','"+agentCode+"','"+pageType+"']"}
			};
		
	    var deferred = $q.defer();

		DataFactory.invoke(req,true)
	    .then(function (res) {
        	deferred.resolve(res);
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
	}
	
	function invokefindFundAllocationProposalPolicy(agentNumber,policyNumber,pruforceId,agentCode,pageType){
		var req = {
				adapter : "HTTPAdapterInquiry",
				procedure : "findFundAllocationProposalPolicy",
				method: WLResourceRequest.POST,
     			parameters : {"params":"['"+agentNumber+"','"+policyNumber+"','"+pruforceId+"','"+agentCode+"','"+pageType+"']"}
			};
		
	    var deferred = $q.defer();

		DataFactory.invoke(req,true)
	    .then(function (res) {
        	deferred.resolve(res);
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
	}
	
	function invokefindProductListDataProposalPolicy(agentNumber,pruforceId,policyNumber,type,agentCode,pageType){
		var req = {
				adapter : "HTTPAdapterInquiry",
				procedure : "findProductListDataProposalPolicy",
				method: WLResourceRequest.POST,
     			parameters : {"params":"['"+agentNumber+"','"+pruforceId+"','"+policyNumber+"','"+type+"','"+agentCode+"','"+pageType+"']"}
			};
		
	    var deferred = $q.defer();

		DataFactory.invoke(req,true)
	    .then(function (res) {
        	deferred.resolve(res);
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
	}
	
	function invokefindSubstandardProposalPolicyDetail(agentNumber,pruforceId,policyNumber,agentCode,pageType){
		var req = {
				adapter : "HTTPAdapterInquiry",
				procedure : "findSubstandardProposalPolicyDetail",
				method: WLResourceRequest.POST,
     			parameters : {"params":"['"+agentNumber+"','"+pruforceId+"','"+policyNumber+"','"+agentCode+"','"+pageType+"']"}
			};
		
	    var deferred = $q.defer();

		DataFactory.invoke(req,true)
	    .then(function (res) {
        	deferred.resolve(res);
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
	}
	
	function invokeAllocation(agentNumber,policyNumber,pruforceId){
		var req = {
				adapter : "HTTPAdapterInquiry",
				procedure : "findFundAllocationPolicy",
				method: WLResourceRequest.POST,
     			parameters : {"params":"['"+agentNumber+"','"+policyNumber+"','"+pruforceId+"']"}
			};
		
	    var deferred = $q.defer();
		
	    DataFactory.invoke(req,true)
	    .then(function (res) {
        	deferred.resolve(res);
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
	}
	
	function invokeHolder(agentNumber,policyNumber,pruforceId){
		var req = {
				adapter : "HTTPAdapterInquiry",
				procedure : "findFundHoldingPolicy",
				method: WLResourceRequest.POST,
     			parameters : {"params":"['"+agentNumber+"','"+policyNumber+"','"+pruforceId+"']"}
			};
		
	    var deferred = $q.defer();
		
	    DataFactory.invoke(req,true)
	    .then(function (res) {
        	deferred.resolve(res);
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
	}


	
	return {
		invokeUnit : invokeUnit,
		invokeUnitStatus : invokeUnitStatus,
		invokeListProposalPolicy : invokeListProposalPolicy,
		invokeFilterListProposalPolicy : invokeFilterListProposalPolicy,
		invokefindTotalProposalPolicyGraph : invokefindTotalProposalPolicyGraph,
		invokefindPersonalDataProposalPolicy : invokefindPersonalDataProposalPolicy,
		invokefindProposalPolicyData : invokefindProposalPolicyData,
		invokefindPremiumDataProposalPolicy : invokefindPremiumDataProposalPolicy,
		invokefindFundAllocationProposalPolicy : invokefindFundAllocationProposalPolicy,
		invokefindProductListDataProposalPolicy : invokefindProductListDataProposalPolicy,
		invokefindSubstandardProposalPolicyDetail : invokefindSubstandardProposalPolicyDetail,
		invokeAllocation: invokeAllocation,
		invokeHolder: invokeHolder
	}
});
