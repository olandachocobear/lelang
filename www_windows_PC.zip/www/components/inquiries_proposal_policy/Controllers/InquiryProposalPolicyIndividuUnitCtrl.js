﻿angular.module('PruForce.controllers')
.controller('InquiryProposalPolicyIndividuUnitCtrl', function($scope, $rootScope,$ionicLoading, $http, $state, $filter, $ionicPopup, $stateParams, InquiryProposalPolicyService) {
	AppsLog.log("START >> InquiryProposalPolicyIndividuUnitCtrl " + new Date());
	AnalyticsLog.logPage("prudential.inquiry.proposalpolicy.unit");
	var sizeIndividu = 30;
	var pageIndividu = 1;
	var searchByIndividu ='';
	var searchValIndividu ='';
	var searchBy2Individu ='';
	var searchVal2Individu ='';
	var orderByIndividu ='';
	var directionIndividu ='';
	$scope.transaction = [];
	var ListProposalPolicy = [];
	var ListProposalPolicyAfterAdd = [];
	$scope.noMoreItemsAvailable = false;
	$scope.numberOfItemsToDisplay = 30;
	var BirthdayTypeShow;
	var ListClientStatus = [];
	var TypeState = '';

	
	$scope.policyHolderNames={
	data:[
		    {id:0,name: $filter('translate')('DEFAULT_SORT')},
			{id:1,name: ($stateParams.Type == "1")?$filter('translate')('ASC_PROPOSAL'):$filter('translate')('ASC_POLICY')},
			{id:2,name: ($stateParams.Type == "1")?$filter('translate')('DESC_PROPOSAL'):$filter('translate')('DESC_POLICY')}
	]
	};
	
	$scope.policyStatusData={
	data:[
	      	{id:0,name: $filter('translate')('DEFAULT_SORT')},
	      	{id:1,name: 'In Force'}]
	};
	
	$scope.selected = $scope.policyStatusData.data[0];
	$scope.sortItem = { onRequest: $scope.policyHolderNames.data[0]};
	
	$scope.loadMore = function() {
		AppsLog.log("Enter Loadmore");
		pageIndividu += 1;
		$scope.showSpinner= true;
		getDataFromService();
		$scope.noMoreItemsAvailable= false;
		$scope.$broadcast('scroll.infiniteScrollComplete');
	};
	
	$scope.changePage = function(agentNumber) {
		var stateInquiriesList = 'inquiries_list_proposal_policy';
		if ($rootScope.pd) {
			if ($rootScope.UnitByAgentType == true) {
				stateInquiriesList = 'pd_inquiries_list_proposal_policy';
			}
		}
	     $state.go(stateInquiriesList, {AgentNumber: agentNumber, Flag : $stateParams.Type});
	}
	
	$scope.GoSearching_GoFiltering = function() {
		$ionicLoading.show();
		ListProposalPolicy = [];
		sizeIndividu = 30;
		pageIndividu = 1;
		searchValIndividu = ($scope.transaction.searchString==undefined)?"":$scope.transaction.searchString.replace(/['|"|\\]/g, "\\$&");
		searchByIndividu = '';
		if ($scope.filterItem.onRequest == $filter('translate')('SHOW_ALL')) {
			searchByIndividu = '';
		} else {
			searchVal2Individu = $scope.filterItem.onRequest.key;
		}
		
		if ($scope.sortItem.onRequest.id === 0) {
			$scope.descSorted = false;
			orderByIndividu = 'asc';
		} else if ($scope.sortItem.onRequest.id === 1) {
			$scope.descSorted = false;
			$scope.policyOption = '';
			orderByIndividu = 'asc';
		} else {
			$scope.descSorted = false;
			orderByIndividu = 'desc';
		}	
		if (searchValIndividu == undefined) {
			searchValIndividu = '';
		}
		
		
		AppsLog.log("List Request 1 :" + searchByIndividu);
		AppsLog.log("List Request 2 :" + searchValIndividu);
		AppsLog.log("List Request 3 :" + pageIndividu);
		AppsLog.log("List Request 4 :" + sizeIndividu);
		AppsLog.log("List Request 5 :" + orderByIndividu);
		AppsLog.log("List Request 6 :" + directionIndividu);
		AppsLog.log("List Request 7 :" + searchBy2Individu);
		AppsLog.log("List Request 8 :" + searchVal2Individu);
		$scope.noMoreItemsAvailable= false;
		getDataFromService();
	}
	
	function getDataFromService() {
		InquiryProposalPolicyService.invokeUnit(searchVal2Individu, orderByIndividu, pageIndividu, sizeIndividu, $rootScope.username,$rootScope.agent.code, TypeState)
			.then(function(res) {
				getProposalPolicySuccess(res);
			});
	}
		
	$scope.init = function(ProposalPolicyUnit,ProposalPolicyUnitStatus, Type){
		getProposalPolicySuccess(ProposalPolicyUnit);
		getStatusProposalPolicy(ProposalPolicyUnitStatus);
		TypeState = (Type === "1") ? "proposal" : "policy";
		
	};
	
	function getStatusProposalPolicy(result){	
		
		if(result.length != 0)
		{
			$scope.listPolisStatus = result;
			$scope.filterItem = {
                    onRequest: $scope.listPolisStatus[0]
            }
		}
     }
		
	function getProposalPolicySuccess(result) {
		if (result.invocationResult.isSuccessful){
			var momentDate;
			
			if(result.invocationResult.array != null){
				if (ListProposalPolicy.length == 0) {
					ListProposalPolicy = [];
					for (var i = 0; i < result.invocationResult.array.length; i++){
						var dt = {};
								
						dt.clientName = result.invocationResult.array[i].clientName;
						dt.total = result.invocationResult.array[i].total;
						dt.agentNumber = result.invocationResult.array[i].agentNumber;
						dt.agentType = result.invocationResult.array[i].agentType;
						
						
						ListProposalPolicy[i] = dt;
						pageIndividu = 1;
						var retrieveDate2 = new Date(result.retrieveDate);
						momentDate = moment(retrieveDate2).format('LLLL');
						$scope.lastUpdate = momentDate;	
					}
				} else
					{
					for (var i = 0; i < result.invocationResult.array.length; i++){
						var dt = {};
								
						dt.clientName = result.invocationResult.array[i].clientName;
						dt.total = result.invocationResult.array[i].total;
						dt.agentNumber = result.invocationResult.array[i].agentNumber;
						dt.agentType = result.invocationResult.array[i].agentType;
						
						ListProposalPolicyAfterAdd[i] = dt; 
						ListProposalPolicy.push(ListProposalPolicyAfterAdd[i]);
						$scope.numberOfItemsToDisplay += ListProposalPolicyAfterAdd.length;
						var retrieveDate2 = new Date(result.retrieveDate);
						momentDate = moment(retrieveDate2).format('LLLL');
						$scope.lastUpdate = momentDate;	
					}
					}
			}
			$scope.ListProposalPolicy = ListProposalPolicy;
			$ionicLoading.hide();
			$scope.showSpinner = false;
			$scope.noMoreItemsAvailable= false;
			if(result.invocationResult.statusCode==500) {
				$scope.showSpinner = false;
				$ionicLoading.hide();
				$scope.noMoreItemsAvailable= true;
				AppsLog.log("No data found1. Please try again later!");
			}
		} else if(result.invocationResult.statusCode==500) {
			$scope.showSpinner = false;
			$ionicLoading.hide();
			$scope.noMoreItemsAvailable= true;
			AppsLog.log("No data found2. Please try again later!");
		} else {
			AppsLog.log("No data found. Please try again later!");
 		}
		
		AppsLog.log("END >> getBirthdayListTodoDailySuccess " + new Date());
		}
});