﻿angular.module('PruForce.controllers')
.controller("InquiryProposalPolicyDetailCtrl", function($scope,$state,$stateParams,LastUpdateProp,ProposalDetailData,PolicyDetailData,PremiumDetailData,ProposalSubstandard,ProductListData,FundAllocationProposal,FundHolder,$filter) {	
	AnalyticsLog.logPage("prudential.inquiry.proposalpolicy.detail");
	AppsLog.log("Start InquiryProposalPolicyDetailCtrl >>> ");
	
	
	$scope.HeaderTitle = ($stateParams.Type == "1") ? $filter('translate')('PROPOSAL_DETAIL') : $filter('translate')('POLICY_DETAILS');
	
	$scope.init = function(){
 		getMyProposalPersonalDataSuccess(ProposalDetailData);
 		getDataPolicyDetailSuccess(PolicyDetailData);
 		getDataPremiumDetailSuccess(PremiumDetailData);
 		getDataProductListPolicySuccess(ProductListData);
 		getMyProposalFundAllocationSuccess(FundAllocationProposal);
 		getMyProposalLastUpdateSuccess(LastUpdateProp);
 		
 		if($stateParams.Type == "2"){
 			getMyPolicyFundHoldingSuccess(FundHolder);
 			$scope.JustShowOnPolicy = true;
 		}
 		
 		if($stateParams.Type == "1"){
 			$scope.JustShowOnProposal = true;
 		}
 		
 		accordionInit();
	}
	
	$scope.init();
	
	$scope.changePage = function(policyNumber,productCode,lifeNumber) {
	    $state.go('inquiries_policy_details_product_details', {policyNumber:policyNumber, productCode: productCode, lifeNumber:lifeNumber});
	}
	
	$scope.goToFollowUpDetail = function(policyNum) {
		var Type = ($stateParams.Type == "1") ? "proposal" : "policy";
	    $state.go('inquiries_policy_details_follow_up', {policyNumber: policyNum, Type:Type, AgentNumber:$stateParams.agentNumber, PageType:$stateParams.PageType});
	}
	
	//Last Update
	function getMyProposalLastUpdateSuccess(result){
		  if (result.invocationResult.isSuccessful){
			  var lastUpdateProp = result.invocationResult.latest; 		
			  var lastUpdate = moment(lastUpdateProp).format('LLLL');
				$scope.lastUpdateProp = lastUpdate;		  
			  
				}
		  
	}
	
	//Personal Data
	function getMyProposalPersonalDataSuccess(result) {		
	    if (result.invocationResult.isSuccessful){		    
	    		$scope.proposalNumber = result.invocationResult.proposalNumber; 
	    		$scope.policyNumber = result.invocationResult.policyNumber;	
	    		$scope.policyHolderName = result.invocationResult.policyHolderName; 
	    		$scope.idNumber = result.invocationResult.idNumber;	
	    		$scope.address1 = result.invocationResult.address1; 
	    		$scope.address2 = result.invocationResult.address2;	
	    		$scope.address3 = result.invocationResult.address3;	
	    		$scope.address4 = result.invocationResult.address4;	
	    		$scope.address5 = result.invocationResult.address5;	
	    		$scope.email = result.invocationResult.email;
	    		$scope.mobilePhone = result.invocationResult.mobilePhone;	
	    		$scope.homePhone = result.invocationResult.homePhone;	
	    		$scope.officePhone = result.invocationResult.officePhone;    		
	    }

    else {	    	
        AppsLog.log("No data found. Please try again later!");
    }
    }
	
	//Policy Detail
	function getDataPolicyDetailSuccess(result) {
	    if (result.invocationResult.isSuccessful){
	    	
	    		$scope.product = result.invocationResult.product;
	    		
	    		if(result.invocationResult.product != null){
	    			var splitProductName = (result.invocationResult.product).split(" ");
		    		$scope.productNameFirst = result.invocationResult.product.substring(0,3);
		    		$scope.productNameMid = result.invocationResult.product.substring(3,splitProductName[0].length);
		    		$scope.productNameLast = result.invocationResult.product.substring(splitProductName[0].length,result.invocationResult.product.length);
	    		}
	    		
	    		$scope.mainLifeAssured = result.invocationResult.mainLifeAssured;
				$scope.proposalReceivedDate = moment(result.invocationResult.proposalReceivedDate).format('LL');
	    		$scope.status = result.invocationResult.status;
	    		var additionalLifeAssured = [];
				additionalLifeAssured = result.invocationResult.additionalLifeAssured;
				$scope.additionalLifeAssured = additionalLifeAssured;
				
	    		$scope.policyDeliveryDate = moment(result.invocationResult.policyDeliveryDate).format('LL');
	    		$scope.policyRiskDate = moment(result.invocationResult.policyRiskDate).format('LL');
				$scope.premiumStatus = result.invocationResult.premiumStatus;
	    } else {
            AppsLog.log("No data found. Please try again later!");
        }
	 }
	
	//Premium Detail
	function getDataPremiumDetailSuccess(result) {
	    if (result.invocationResult.isSuccessful){    	
	    		$scope.coverageDebt = (result.invocationResult.coverageDebt != null ) ? result.invocationResult.coverageDebt.formatMoney(2, '.', ',') : "0.00";
	    		$scope.currency = result.invocationResult.currency;
	    		$scope.currencySymbol = result.invocationResult.currencySymbol;
	    		

	    		
	    		$scope.paymentFrequency = result.invocationResult.paymentFrequency;
	    		$scope.paymentMethod = result.invocationResult.paymentMethod;
	    		$scope.payor = result.invocationResult.payor;
				$scope.premiumDueDate = moment(result.invocationResult.premiumDueDate).format('LL');
				$scope.instalmentPremium = (result.invocationResult.instalmentPremium != null ) ? result.invocationResult.instalmentPremium.formatMoney(2, '.', ',') : "0.00";
				$scope.singlePremium = (result.invocationResult.instalmentPremium != null ) ? result.invocationResult.singlePremium.formatMoney(2, '.', ',') : "0.00";
				$scope.suspendAmountForTopUp = (result.invocationResult.suspendAmountForTopUp != null ) ? result.invocationResult.suspendAmountForTopUp.formatMoney(2, '.', ',') : "0.00";
				$scope.suspendAmountPremium = (result.invocationResult.suspendAmountPremium != null ) ? result.invocationResult.suspendAmountPremium.formatMoney(2, '.', ',') : "0.00";
				
				
				
	    } else {
            AppsLog.log("No data found. Please try again later!");
        }
    }

	//Product List Data
	function getDataProductListPolicySuccess(result) {
		
		ListProposal = [];
		
		if(result.invocationResult.array != null){
			for (var i = 0; i < result.invocationResult.array.length; i++){
				var dt = {};
				dt.id = result.invocationResult.array[i].id;
				dt.name = result.invocationResult.array[i].name;
				dt.lifeNumber = result.invocationResult.array[i].lifeNumber;
				
				if(result.invocationResult.array[i].name != null){
					var splitProductName = (result.invocationResult.array[i].name).split(" ");
					dt.productNameFirst = (result.invocationResult.array[i].name).substring(0,3);
					dt.productNameMid = (result.invocationResult.array[i].name).substring(3,splitProductName[0].length);
					dt.productNameLast = (result.invocationResult.array[i].name).substring(splitProductName[0].length,(result.invocationResult.array[i].name).length);
				}
				
				ListProposal[i] = dt;
				
				AppsLog.log("value product list");
				AppsLog.log(ListProposal[i]);
			}		
		}	
		$scope.ListProposal = ListProposal;
    }
	
	//FundAllocation
	function getMyProposalFundAllocationSuccess(result) {
		    if (result.invocationResult.isSuccessful){
		    	ListFundAllocation = [];
		    	ChartData = [];
				AppsLog.log("test proposal fundallocation"+result);
				if(result.invocationResult.array!=null){
					for (var i = 0; i < result.invocationResult.array.length; i++){
						var dt = {};
						var data ={};
						
						dt.fundPercentage = result.invocationResult.array[i].fundPercentage;
						dt.fundType = result.invocationResult.array[i].key2;
						dt.fundName = result.invocationResult.array[i].fundName;
						ListFundAllocation[i] = dt;
						
					}
					$scope.ListFundAllocation = ListFundAllocation;
				}
				else{
					ListFundAllocation = [];
					$scope.ListFundAllocation = ListFundAllocation;
				}
		    }
		    else {
		    	ListFundAllocation = [];
				$scope.ListFundAllocation = ListFundAllocation;
	            AppsLog.log("No data found. Please try again later!");
	        }
	    }
	
	//FundHolding
	function getMyPolicyFundHoldingSuccess(result) {
		
	    if (result.invocationResult.statusCode == 200){
	    	
	    	ListFundHolding = [];
	    	ChartData = [];
			AppsLog.log("test policy inforce"+result);
			if(result.invocationResult.array!=null){
				for (var i = 0; i < result.invocationResult.array.length; i++){
					var dt = {};
					var data ={};
					
					dt.fundPercentage = result.invocationResult.array[i].fundPercentage;
					dt.fundType = result.invocationResult.array[i].fundType;
					dt.unitValue = result.invocationResult.array[i].unitValue;
					dt.unitValueSeparator = (dt.unitValue).formatMoney(5, '.', ','); 
					dt.fundName = result.invocationResult.array[i].fundName;
					dt.unitPrice = result.invocationResult.array[i].unitPrice;
					dt.unitPriceSeparator = (dt.unitPrice).formatMoney(5, '.', ','); 
					dt.pricingDate = result.invocationResult.array[i].pricingDate;
					dt.pricingDateFormat = moment(dt.pricingDate).format('LL');
					dt.unitBalance = result.invocationResult.array[i].unitBalance;
					dt.unitBalanceSeparator = (dt.unitBalance).formatMoney(5, '.', ','); 
					dt.currencySymbol = result.invocationResult.array[i].currencySymbol;
					AppsLog.log("currencySymbol"+dt.currencySymbol);
					dt.value = result.invocationResult.array[i].fundPercentage;
					ListFundHolding[i] = dt;
				}
				$scope.ListFundHolding = ListFundHolding;
			}else{
				ListFundHolding = [];
				$scope.ListFundHolding = ListFundHolding;
			}
	    }else {
	    	ListFundHolding = [];
			$scope.ListFundHolding = ListFundHolding;
            AppsLog.log("No data found. Please try again later!");
        }
    }
	

	function accordionInit(){
		AppsLog.log("test accordian css");
		var accordions = $(".list-info-accordion");

		$.each(accordions, function( index, value ) {
			var accordionBody = $(value).find(".accordion-body");		 
			AppsLog.log("test accordian css2");
			accordionBody.attr("style", "margin-top: -" + accordionBody.height() + "px;")

		});
	}

	$scope.collapseAccordion = function(e){
		var self = $(e.toElement);
		var accordion = self.parents(".list-info-accordion");
		var accordionBody = accordion.find(".accordion-body");

		if(accordion.hasClass("collapsed")){
			accordion.removeClass("collapsed");
			accordionBody.attr("style", "margin-top: -" + accordionBody.height() + "px;");
		}else{
			accordion.addClass("collapsed");
			accordionBody.css("margin-top", 0);

		}
	}
})