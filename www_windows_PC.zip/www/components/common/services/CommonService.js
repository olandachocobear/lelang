﻿angular.module('PruForce.services')
	.service('CommonService', function (DataFactory, $q, $cordovaFile, $cordovaFileTransfer, $cordovaFileOpener2) {
		function invokeFileBase64(fileName,module) {

			var req = {
				adapter: "HTTPAdapter"+module[0].toUpperCase() + module.substr(1),
				procedure: "getFileBase64",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + fileName + "','" + module + "']" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});
			return deferred.promise;
		}

		function base64toBlob(base64Data, contentType, sliceSize) {
			contentType = contentType || '';
			sliceSize = sliceSize || 512;

			var byteCharacters = atob(base64Data);
			var byteArrays = [];

			for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
				var slice = byteCharacters.slice(offset, offset + sliceSize);

				var byteNumbers = new Array(slice.length);
				for (var i = 0; i < slice.length; i++) {
					byteNumbers[i] = slice.charCodeAt(i);
				}

				var byteArray = new Uint8Array(byteNumbers);

				byteArrays.push(byteArray);
			}

			var blob = new Blob(byteArrays, { type: contentType });
			return blob;
		}

		function savebase64AsPDF(folderpath, filename, content, contentType, successFunction, errorFunction) {
			var DataBlob = base64toBlob(content, contentType);
			return saveBlobAsPDF(folderpath, filename, DataBlob, contentType, successFunction, errorFunction);
		}

		function saveBlobAsPDF(folderpath, filename, DataBlob, contentType, successFunction, errorFunction) {
			return window.resolveLocalFileSystemURL(folderpath, function (dir) {
				dir.getFile(filename, { create: true }, function (file) {
					file.createWriter(function (fileWriter) {
						fileWriter.write(DataBlob);
						if (typeof successFunction == 'function') {
							successFunction();
						} else{
							alert('File "' + filename + '" saved to ' + folderpath);
						}
					}, function () {
						if (typeof errorFunction == 'function') {
							alert('Unable to save file in path ' + folderpath);
						}
					});
				});
			}); 
		}

		function openFilePdf(fileName, mimeType, folderPath) {
			return openFile(fileName, mimeType, folderPath).then(
				function (success) {

				}, function (error) {
				});
		}

		function openFile(fileName, mimeType, folderPath) {
			return $cordovaFile.checkFile(folderPath, fileName).then(
				function (success) {
					var filePath = pathJoin(folderpath, fileName).replace('file:', '');
					return $cordovaFileOpener2.open(filePath, mimeType);
				}, function (error) {
				})
		}

		function downloadFile(url, fileName, folderPath, successFunction, errorFunction) {
			return checkDir([cordova.file.externalDataDirectory, folderPath]).then(
				function (success) {
					var targetPath = pathJoin([cordova.file.externalDataDirectory, folderPath, fileName]);
					var trustHosts = true;
					var options = {};
					return $cordovaFileTransfer.download(url, targetPath, options, trustHosts)
						.then(function (result) {
							if (typeof successFunction == 'function') {
								successFunction();
							}
						}, function (err) {
							if (typeof errorFunction == 'function') {
								errorFunction(err);
							}
						}, function (progress) {
							$timeout(function () {
							});
						});
				}, function (error) {
					if (typeof errorFunction == 'function') {
						errorFunction(err);
					}
				});
		}

		function pathJoin(parts, sep) {
			var separator = sep || '/';
			var replace = new RegExp(separator + '{1,}', 'g');
			return parts.join(separator).replace(replace, separator);
		}

		function getPruforceFolder() {
			var env = WL.Client.getEnvironment();
			if (env === WL.Environment.IPHONE || env === WL.Environment.IPAD) {
				return cordova.file.documentsDirectory;
			} else if (env === WL.Environment.ANDROID) {
				return cordova.file.externalRootDirectory;
			}
		}

		function checkDir(parts, rootPath) {
			if (parts.length <= 0) return;

			if (angular.isUndefined(rootPath)) { rootPath = parts.shift(); }

			var nextPath = parts.shift();
			if (angular.isUndefined(nextPath)) { return }

			var pathJoin = pathJoin([rootPath, nextPath]);

			return $cordovaFile.checkDir(pathJoin).then(function (success) {
				return checkDir(parts, pathJoin);
			}, function (error) {
				return $cordovaFile.createDir(rootPath, nextPath, true).then(function (success) {
					return checkDir(parts, pathJoin);
				}, function (error) {
				});
			});
		}

		//data:image/jpeg;base64,
		return {
			invokeFileBase64: invokeFileBase64,
			savebase64AsPDF: savebase64AsPDF,
			saveBlobAsPDF: saveBlobAsPDF,
			getPruforceFolder: getPruforceFolder
		}
	});

