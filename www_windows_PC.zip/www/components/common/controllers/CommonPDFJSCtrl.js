﻿(function () {
    'use strict';

    angular.module('PruForce.controllers')
        .controller('CommonPDFJSCtrl', function ($rootScope, $scope, $ionicLoading, $state, $stateParams, $window, CommonService, PDFBase64, $ionicPopup, $filter, $sce, $translate, $ionicScrollDelegate) {

            if (!PDFJS || !PDFJS.PDFViewer || !PDFJS.getDocument) {
                alert('Required Library Not Found');
            }
            
            $ionicLoading.hide();

            $scope.fileName = ($stateParams.fileName ? $stateParams.fileName : "File");
            $scope.originalFileName = ($stateParams.originalFileName ? $stateParams.originalFileName : "File");
            $scope.pageTitle = ($stateParams.pageTitle ? $stateParams.pageTitle : "GENERAL");
            $scope.originalFileName = generateFileName($scope.originalFileName);
            $scope.folderPath = CommonService.getPruforceFolder();
            var pageFit = angular.isUndefined($stateParams.pageFit) ? true : false;

            var pdfRenderTask = null;
            var pdfDocument = null;
            var pdfViewer = null;
            var pdfHistory = null;
            var pdfLinkService = null;
            var pdfPageView = null;
            var pdfButton = null;

            var loadingBar = null;
            var container = null;
            var loadingPercentage = 0;

            var DEFAULT_SCALE_DELTA = 1.1;
            var MIN_SCALE = 1.0;
            var MAX_SCALE = 2.0;
            var scale = 1.0;
            var scaleCss = 1;

            PDFJS.disableWorker = true;
            PDFJS.disableTextLayer = true;
            PDFJS.maxImageSize = -1;

            $scope.pageCount = 0;
            $scope.pageToDisplay = 1;
            var displayedPage = $scope.pageToDisplay;

            var scrollView = null;
            /*
            implement di ion-scroll
            on-release="onRelease()"       
            */
            $scope.onRelease = function(){
                return;
                /*
                var match = $(scrollView)[0].style.transform.match(/scale\((.+)\)/);
                if(match[1]){
                    if(match[1] != scaleCss){
                        
                        scaleCss = match[1];
                        scale = scaleCss * MIN_SCALE * 0.8;
                        if(scale > MAX_SCALE){
                            scale = MAX_SCALE;
                        } else if (scale < MIN_SCALE){
                            scale = MIN_SCALE;
                        }
                        renderPage($scope.pageToDisplay);
                    }
                }*/
            }     
            /*
            function resizeScaleCss(){
                var oldTransform = $(angular.element(".pdf-js-view").find(".scroll"))[0].style.transform;
                scaleCss = scale / (MIN_SCALE * 0.8);
                var newTransform = oldTransform.replace(oldTransform.match(/scale\(.+\)/),"scale(" + scaleCss + ")");
            }
            */

            $scope.goPrevious = function () {
                if (displayedPage <= 1) {
                    return;
                }
                $scope.pageToDisplay = parseInt(displayedPage) - 1;
            };

            $scope.goNext = function () {
                if (displayedPage >= pdfDocument.numPages) {
                    return;
                }
                $scope.pageToDisplay = parseInt(displayedPage) + 1;
            };

            $scope.zoomIn = function () {
                pageFit = false;
                if(scale == MAX_SCALE) return scale;
                var MAX_PIXEL = 16777216; /* based on device ipad, maximum canvas size (width * height) */
                if(pdfPageView.canvas.width * pdfPageView.canvas.height * 1.153 > MAX_PIXEL){ /* 1.153 perhitungan kira-kira besar next scale */
                    return scale;
                }
                var newScale = parseFloat(scale) + 0.2;
                scale = newScale > MAX_SCALE ? MAX_SCALE : newScale;
                renderPage(displayedPage);
                return scale;
            };

            $scope.zoomOut = function () {
                pageFit = false;
                if(scale == MIN_SCALE) return scale;
                var newScale = parseFloat(scale) - 0.2;
                scale = newScale > MIN_SCALE ? newScale : MIN_SCALE;
                renderPage(displayedPage);
                return scale;
            };

            $scope.fit = function () {
                pageFit = true;
                renderPage(displayedPage);
            }

            var backingScale = function (canvas) {
                var ctx = canvas.getContext('2d');
                var dpr = $window.devicePixelRatio || 1;
                var bsr = ctx.webkitBackingStorePixelRatio ||
                    ctx.mozBackingStorePixelRatio ||
                    ctx.msBackingStorePixelRatio ||
                    ctx.oBackingStorePixelRatio ||
                    ctx.backingStorePixelRatio || 1;

                return dpr / bsr;
            };

            var setCanvasDimensions = function (canvas, w, h) {
                var ratio = backingScale(canvas);
                canvas.width = Math.floor(w * ratio);
                canvas.height = Math.floor(h * ratio);
                canvas.style.width = Math.floor(w) + 'px';
                canvas.style.height = Math.floor(h) + 'px';
                canvas.getContext('2d').setTransform(ratio, 0, 0, ratio, 0, 0);
                return canvas;
            };

            var initUI = function () {
                container = document.getElementById('viewerContainer');

                $scope.$watch('pageToDisplay', function (newVal, oldVal) {
                    if (pdfDocument !== null && newVal > 0) {
                        if($scope.pageToDisplay > pdfDocument.numPages) { return; }
                        displayedPage = newVal;
                        renderPage(displayedPage);
                    }
                });
                /*
                var linkService = new PDFJS.PDFLinkService();
                pdfLinkService = linkService;

                var viewer = new PDFJS.PDFViewer({
                    container: container,
                    linkService: linkService
                });
                pdfViewer = viewer;
                linkService.setViewer(viewer);

                pdfHistory = new PDFJS.PDFHistory({
                    linkService: linkService
                });
                linkService.setHistory(pdfHistory);
                */
            }

            /*
            var renderPDF = function () {
                if (pdfRenderTask) {
                    pdfRenderTask._internalRenderTask.cancel();
                }

                var loadingTask = PDFJS.getDocument({ data: pdfData });
                pdfRenderTask = loadingTask;

                loadingTask.onProgress = function (progressData) {
                    var percent = Math.round((progressData.loaded / progressData.total) * 100);
                    // Updating the bar if value increases.
                    if (percent > this.loadingBar.percent || isNaN(percent)) {
                        this.loadingPercentage = percent;
                    }
                };

                return loadingTask.promise.then(function (pdfDocument) {
                    pdfDocument = pdfDocument;

                    $scope.pageCount = pdfDocument.numPages;

                    pdfViewer.setDocument(pdfDocument);
                    pdfLinkService.setDocument(pdfDocument);
                    pdfHistory.initialize(pdfDocument.fingerprint);

                }, function (exception) {
                    console.log(exception);
                });

            }
            */

            var renderPage = function (num, redrawCanvas) {
                if (pdfRenderTask) {
                    pdfRenderTask._internalRenderTask.cancel();
                }

                if(pdfButton){
                    pdfButton.children(".pageUp").toggleClass("disabled", displayedPage <= 1);
                    pdfButton.children(".pageDown").toggleClass("disabled", displayedPage > 1);
                    pdfButton.children(".zoomOut").toggleClass("disabled", scale == MIN_SCALE);
                    pdfButton.children(".zoomIn").toggleClass("disabled", scale == MAX_SCALE);
                }

                return pdfDocument.getPage(num).then(function (page) {
                    if (!pdfPageView) {
                        pdfPageView = new PDFJS.PDFPageView({
                            container: container,
                            id: num,
                            scale: 1,
                            defaultViewport: page.getViewport(1),
                        });
                        pdfPageView.setPdfPage(page);
                        
                        scrollView = angular.element(".pdf-js-view").find(".scroll");
                    }
                    if(redrawCanvas){
                        var desiredWidth = container.offsetWidth;
                        MIN_SCALE = scale = (container.offsetWidth / pdfPageView.viewport.width) * scale;
                        MAX_SCALE = scale * 2.0;
                        pdfPageView.scale = scale;
                        pdfPageView.viewport.width = desiredWidth;
                        pdfPageView.draw();
                    }
                    $scope.pageToDisplay = num;
                    pdfPageView.scale = scale;;
                    pdfPageView.setPdfPage(page);
                    return pdfPageView.draw();
                });
            }

            $( window ).resize(function() {
                renderPage(displayedPage, true);
		        $ionicScrollDelegate.scrollTop();
            });

            function generateFileName(originalFileName){
                var uid = (new Date().getTime()).toString(36);
                var extPosition = originalFileName.indexOf(".pdf");
                if(extPosition){
                    originalFileName = originalFileName.slice(0, extPosition) + "-" + uid + originalFileName.slice(extPosition);
                } else {
                    originalFileName += "-" + uid;
                }
                return originalFileName
            }

            $scope.downloadPDF = function () {
                try{
                    CommonService.savebase64AsPDF($scope.folderPath, $scope.originalFileName, PDFBase64, "application/pdf", function () { showSavePopUp() });
                }catch(e){
                    alert('failed to save PDF');
                }
            }

            var showSavePopUp = function () {

                var popUpButton3 = $(".popup-container .popup .popup-head h3");
                popUpButton3.css("line-height", "21px");
                popUpButton3.css("color", "#fff");
                popUpButton3.css("font-style", "italic");
                popUpButton3.css("font-size", "16px");

                var popUpButton4 = $(".popup-container .popup-buttons");
                popUpButton4.css("visibility", "hidden");
                popUpButton4.css("height", "0");
                popUpButton4.css("min-height", "0");

                var popUpButton5 = $(".popup-container .list-info");
                popUpButton5.css("border-bottom", "solid 1px #e5e5e5");

                var popUpButton6 = $(".popup-container .popup .popup-body");
                popUpButton6.css("overflow-y", "scroll");
                popUpButton6.css("overflow-x", "hidden");
                popUpButton6.css("-webkit-overflow-scrolling", "touch");

                var popUpButton7 = $(".popup-container .content p");
                popUpButton7.css("font-style", "normal");
                var alertPopup = $ionicPopup.alert({
                    // title: $filter('translate')('CONTEST.PDF_SAVED_TITLE'),
                    template: $translate.instant('CONTEST.PDF_SAVED_MESSAGE', {fileName: $scope.originalFileName, folderPath: $scope.folderPath}),
                    cssClass: 'pru-white-alert without-header pru-logo-text',
                });
                var popUpButton0 = $(".popup-container");
                popUpButton0.css("background-color", "rgba(0, 0, 0, 0.7)");
                popUpButton0.css("z-index", "2000");
                var popUpButton01 = $(".popup-container .popup");
                popUpButton01.css("width", "88vw");
                popUpButton01.css("margin-top", "86px"); 
                popUpButton01.css("margin-bottom", "56px");
                popUpButton01.css("background-color", "rgba(255, 255, 255, 1)");
                var popUpButton1 = $(".popup-container .popup .popup-head");
                	   popUpButton1.css("height", "4em");
                	   popUpButton1.css("height", "85px");
                popUpButton1.css("background-color", "#ff0000");
                var popUpButton = $(".popup-container .popup-buttons");
                popUpButton.css("visibility", "visible");
                popUpButton.css("min-height", "65px");
                var popUpButton2 = $(".popup-container .popup .popup-body");
                popUpButton2.css("padding", "5vw");
                popUpButton2.css("overflow", "auto");

                alertPopup.then(function (res) {
                });
            }

            angular.element(document).ready(function () {
                initUI();
                //renderPDF();
                var pdfData = atob(PDFBase64);
                if (pdfData == null || pdfData == "") {
                    alert("File download failed, file not found");
                } else {
                    PDFJS.getDocument({ data: pdfData }).then(function getPdf(pdf) {
                        pdfDocument = pdf;

                        $scope.pageCount = pdfDocument.numPages;

                        //pdfButton = $(".pdf-js-button");

                        renderPage(displayedPage, true);
                    });
                }
            });
        })

})()