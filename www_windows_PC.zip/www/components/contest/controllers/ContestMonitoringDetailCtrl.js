﻿angular.module('PruForce.controllers')
	.controller('ContestMonitoringDetailCtrl', function ($scope, $rootScope, $ionicLoading, $translate, $state, $interval, $http, $filter, $sce, ContestMonitoringDetail, ContestLastUpdate, CommonService) {
		AnalyticsLog.logPage("prudential.contest.monitoring.detail");

		$scope.goBackContest = function () {
			if ($state.current.name == 'contest_monitoring_detail') {
				$rootScope.goBack();
			}
		}

		$scope.getDataContestMonitoringDetailSuccess = getDataContestMonitoringDetailSuccess;
		$scope.showSpinnerImages = true;

		updateLastUpdate(ContestLastUpdate);
		$scope.updateLastUpdate = updateLastUpdate;
		getDataContestMonitoringDetailSuccess(ContestMonitoringDetail);

		var options = {
			location: 'yes'
		};

		$scope.openPdf = function (name, originalName) {
			$ionicLoading.show();
			$state.go('common_pdfjs', { fileName: name, originalFileName: originalName, module: "contest", pageTitle: "CONDITIONS_CONTEST", pageLogId: "prudential.contest.pdftermncondition" });
		}

		$scope.changePageProposalList = function (id) {
			$state.go('contest_proposal_list', { contestCode: id });
		}

		function resizeIframe(obj) {
			obj.style.height = obj.contentWindow.document.body.scrollHeight + 'px';
		}

		$scope.changePagePolicyList = function (id) {
			$state.go('contest_policy_list', { contestCode: id });
		}

		function getDataContestMonitoringDetailSuccess(result) {

			ContestMonitoringDetail = [];
			ListAllSingleContest = [];

			var dueDateTemp, dueDateTemp2;

			var currentDate;
			var timeDiff;
			var diffDays;
			var progressSingle;

			if (result.invocationResult.isSuccessful) {
				var dt = {};

				dt.contest = result.invocationResult.contest;
				dueDateTemp = new Date(result.invocationResult.contest.dueDate);
				dueDateTemp2 = moment(dueDateTemp).format('LL');

				currentDate = new Date();
				var diffDays = 0;
				if (!dueDateTemp.isSameDateAs(currentDate)) {
					var timeDiff = Math.abs(dueDateTemp.getTime() - currentDate.getTime());
					diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
				}
				if (diffDays == 0) {
					diffDays = $filter("translate")("CONTEST.TODAY");
				}
				else if (diffDays == 1) {
					diffDays = $filter("translate")("CONTEST.TOMORROW");
				} else {
					diffDays = dueDateTemp2;
				}

				dt.contest.periodEndDiff = diffDays;
				dt.contest.dueDate = dueDateTemp2;

				dt.contest.flyers = result.invocationResult.contest.flyers;

				var flyers = (dt.contest.flyers != null && dt.contest.flyers.indexOf("|")) ? dt.contest.flyers.split("|") : null;
				dt.contest.flyersName = flyers ? flyers[0] : "image";
				dt.contest.flyersFileName = flyers ? flyers[1] : "";
				CommonService.invokeFileBase64(dt.contest.flyersFileName, 'contest').then(
					function (response) {
						if (response.invocationResult.isSuccessful) {
							dt.contest.flyersBase64 = "data:image/jpeg;base64," + response.invocationResult.content;
						}
						$scope.showSpinnerImages = false;
					}, function (error) {
						$scope.showSpinnerImages = false;
					});

				if (dt.contest.overall == null) {

					progressSingle = (dt.contest.completedTask / dt.contest.totalTask) * 100;
					dt.contest.overall = {};
					dt.contest.overall.lineStatus = "nothave";
					dt.contest.overall.progress = progressSingle;
					dt.contest.overall.spinner = $filter('formatNumber')(progressSingle, 0);
				}
				else {
					dt.contest.overall.spinner = $filter('formatNumber')(dt.contest.overall.progress, 0);
					dt.contest.overall.lineStatus = "have";
				}

				dt.contest.params = angular.copy(result.invocationResult.contest.params);

				angular.forEach(dt.contest.params, function (value, key) {
					if (dt.contest.params[key].lapseZone == "0") {
						dt.contest.params[key].progType = "prog-red prog-red";
					}
					else if (dt.contest.params[key].lapseZone == "1") {
						dt.contest.params[key].progType = "prog-gold prog-gold";
					}
					else {
						dt.contest.params[key].progType = "prog";
					}

					if (dt.contest.params[key].percentage != undefined || dt.contest.params[key].percentage != null) {
						dt.contest.params[key].percentageRound = $filter('formatNumber')(dt.contest.params[key].percentage, 0);
						dt.contest.params[key].percentage = $filter('formatNumber')(dt.contest.params[key].percentage, 1);
					}

					dt.contest.params[key].subtitle = $sce.trustAsHtml($translate.instant(dt.contest.params[key].subtitle, dt.contest.params[key]));
				});

				dt.contestDescription = $sce.trustAsHtml(result.invocationResult.contestDescription);
				dt.awardsDescription = $sce.trustAsHtml(result.invocationResult.awardsDescription);
				dt.termCondition = $sce.trustAsHtml(result.invocationResult.termCondition);
				dt.termConditionPdf = result.invocationResult.termConditionPdf;

				var termConditionPdf = (result.invocationResult.termConditionPdf != null && result.invocationResult.termConditionPdf.indexOf("|")) ? result.invocationResult.termConditionPdf.split("|") : null;
				dt.termConditionPdfName = termConditionPdf ? termConditionPdf[0] : "image";
				dt.termConditionPdfFileName = termConditionPdf ? termConditionPdf[1] : "";

				ContestMonitoringDetail = dt;

				$scope.ContestMonitoringDetail = ContestMonitoringDetail;
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}

		function updateLastUpdate(result) {
			if (result.invocationResult.isSuccessful) {
				$scope.lastUpdate = '';
				if (result.invocationResult.lastUpdate != null) {
					var lastUpdateDateTemp = new Date(result.invocationResult.lastUpdate);
					$scope.lastUpdate = moment(lastUpdateDateTemp).format('LL');
				}
			}
		}

		function getDataAllBigContestListFailed(result) {
			AppsLog.log("Load Data Failed, Please Check Your Connection");
		}


		$scope.accordionWidgetCollapse = function (e) {
			var self = $(e.toElement);
			var accordion = self.parents(".widget-policy");
			var accordionBody = accordion.find(".list-info, .list-info-contest");

			if (accordion.hasClass("collapse1")) {
				accordion.removeClass("collapse1");
				accordionBody.attr("style", "margin-top: -" + (accordionBody.height() + 15) + "px;");
			} else {
				accordion.addClass("collapse1");
				accordionBody.css("margin-top", "0px");
				accordionBody.css("padding-top", "12px");
			}
		}

		$scope.accordionWidgetCollapseDesc = function (e) {
			var self = $(e.toElement);
			var accordion = self.parents(".widget-policy");
			var accordionBody = accordion.find(".list-info, .list-info-contest");

			if (accordion.hasClass("collapse1")) {
				accordion.removeClass("collapse1");
				accordionBody.attr("style", "margin-top: -" + (accordionBody.height() + 15) + "px;");
			} else {
				accordion.addClass("collapse1");
				accordionBody.css("margin-top", "0px");
				accordionBody.css("padding-top", "45px");
			}
		}

		function init() {
			setTimeout(function () {
				for (var i = 0; i < $(".tab-item").length; i++) {
					$($(".tab-item")[i]).attr("data-position-left", ($($(".tab-item")[i]).position().left - 20));
				}
			}, 100)
		}

		$scope.accordionInit = function () {
			var accordions = $(".list-info-accordion");

			$.each(accordions, function (index, value) {
				var accordionBody = $(value).find(".accordion-body");

				if (!$(value).hasClass("collapsed")) {
					accordionBody.attr("style", "margin-top: -" + accordionBody.height() + "px;")
				}
			});
		}

		$scope.accordionWidgetInit = function () {
			var accordionsWidget = $(".widget-policy");

			$.each(accordionsWidget, function (index, value) {
				var accordionBody = $(value).find(".list-info, .list-info-contest");

				if (!$(value).hasClass("collapse1")) {
					accordionBody.attr("style", "margin-top: -" + (accordionBody.height() + 15) + "px;");
				}
			});
		}

		angular.element(document).ready(function () {
			$ionicLoading.hide();
			init();
			$scope.accordionInit();
			$scope.accordionWidgetInit();
		});


	})