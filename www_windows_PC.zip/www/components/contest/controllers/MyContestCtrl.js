﻿angular.module('PruForce.controllers')
	.controller('MyContestCtrl', function ($scope, $state, $interval, $http, $filter, $sce, $rootScope, $ionicLoading, AllMyContestService, $translate, $ionicHistory) {
		AnalyticsLog.logPage("prudential.contest.mycontest.all");

		$rootScope.page = 0;
		$rootScope.noMoreItemsAvailable = false;
		$rootScope.numberOfItemsToDisplay = $rootScope.size;
		$rootScope.inProgress = false;
		// $ionicLoading.show();

		$scope.ListAllMyContests = [];
		$scope.showSpinner = true;
		$scope.error500 = false;

		var extraCreditFlag = 0;

		$scope.refreshPage = function () {
			$scope.error500 = false;
		}

		$scope.loadMore = function () {
			if (!$rootScope.inProgress) {
				$rootScope.inProgress = true;
				$rootScope.page += 1;
				$scope.showSpinner = true;
				getDataFromService();
			}
			$rootScope.noMoreItemsAvailable = false;
			$scope.$broadcast('scroll.infiniteScrollComplete');
		};

		$scope.MoreItemsAvailable = function () {
			return !$rootScope.noMoreItemsAvailable;
		};

		function getDataFromService() {
			AllMyContestService.invoke($rootScope.username, $rootScope.agent.code, $rootScope.agent.agentType, $rootScope.size, $rootScope.page).then(function (res) {
				getDataAllMyContestListSuccess(res);
			}, function (error) {
				$scope.error500 = true;
				$rootScope.inProgress = false;
				$scope.showSpinner = false;
				$rootScope.page -= 1;
				AppsLog.log(error);
			});
		}

		function getDataAllMyContestListSuccess(result) {

			var periodStartTemp, periodEndTemp;
			var progressSingle;
			var percentageChildTemp;

			if (result.invocationResult.isSuccessful) {
				if (result.invocationResult.array != null) {
					if (result.invocationResult.array.length > 0) {
						for (var i = 0; i < result.invocationResult.array.length; i++) {
							var dt = {};

							dt.contestCode = result.invocationResult.array[i].contestCode;
							dt.contestName = result.invocationResult.array[i].contestName;
							periodStartTemp = new Date(result.invocationResult.array[i].periodStart);
							dt.periodStart = moment(periodStartTemp).format('LL');
							periodEndTemp = new Date(result.invocationResult.array[i].periodEnd);
							dt.periodEnd = moment(periodEndTemp).format('LL');
							dt.extraCreditFlag = result.invocationResult.array[i].extraCreditFlag;
							dt.completedTask = result.invocationResult.array[i].completedTask;
							dt.totalTask = result.invocationResult.array[i].totalTask;
							dt.orphan = result.invocationResult.array[i].orphan;
							dt.overall = result.invocationResult.array[i].overall;

							if (dt.overall == null) {
								progressSingle = (dt.completedTask / dt.totalTask) * 100;
								dt.overall = {};
								dt.overall.lineStatus = "nothave";
								dt.overall.progress = $filter('formatNumber')(progressSingle, 1);
							}
							else {
								dt.overall.lineStatus = "have";
							}

							dt.overall.spinner = $filter('formatNumber')(dt.overall.progress, 0);

							dt.params = angular.copy(result.invocationResult.array[i].params);

							angular.forEach(dt.params, function (value, key) {
								if (dt.params[key].percentage != undefined || dt.params[key].percentage != null) {
									dt.params[key].percentageRound = $filter('formatNumber')(dt.params[key].percentage, 0);
									percentageChildTemp = dt.params[key].percentage;
									dt.params[key].percentage = $filter('formatNumber')(percentageChildTemp, 1);
								}
								dt.params[key].subtitle = $sce.trustAsHtml($translate.instant(dt.params[key].subtitle, dt.params[key]));

							});

							$scope.ListAllMyContests.push(dt);
						}

						$scope.numberOfItemsToDisplay = $scope.ListAllMyContests.length;

						if ($scope.ListAllMyContests.length == 0) {
							$rootScope.noMoreItemsAvailable = true;
						}
					} else {
						$rootScope.noMoreItemsAvailable = true;
					}
				}

				if (result.invocationResult.error == 500 || result.invocationResult.statusCode == 500) {
					$rootScope.noMoreItemsAvailable = true;
					AppsLog.log("No data found. Please try again later!");
					$scope.error500 = true;
				}

			} else {
				if (result.invocationResult.error == 500 || result.invocationResult.statusCode == 500) {
					AppsLog.log("Load Data Failed, Please Check Your Connection");
					$scope.error500 = true;
				} else {
					AppsLog.log("No data found. Please try again later!");
				}
				$rootScope.noMoreItemsAvailable = true;
			}

			$rootScope.inProgress = false;
			$scope.showSpinner = false;
			$ionicLoading.hide();
		}

		function getDataAllMyContestListFailed(result) {
			AppsLog.log("Load Data Failed, Please Check Your Connection");
		}

		$scope.changePageMyContestDetail = function (id) {
			$state.go('my_contest_detail', { contestCode: id });
		}

		$scope.changePageMyContestExtraCredit = function (id) {
			$state.go('contest_extra_credit', { contestCode: id });
		}

		$scope.$on('$stateChangeSuccess', function () {
			$scope.loadMore();
		});

		function changePageSize() {
			var tabList = document.getElementsByClassName('tabList');
			if (tabList[0]) {
				tabList[0].style.minHeight = (window.innerHeight - 100) + "px";
			}
		}

		angular.element(document).ready(function () {
			changePageSize();
		});

		$(window).resize(function () {
			changePageSize();
		});

	})