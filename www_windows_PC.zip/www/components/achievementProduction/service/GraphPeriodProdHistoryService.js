﻿angular.module('PruForce.services')

	.service('GraphPeriodProdHistoryService', function (DataFactory, $q) {
		function invoke(pruforceId, agentCode, type) {

			var procedureName;
			if (type == "individu") {
				procedureName = "findProductionGraphPeriodIndividu";
			} else {
				procedureName = "findProductionGraphPeriodUnit";
			}

			var req = {
				adapter: "HTTPAdapter3",
				procedure: procedureName,
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + pruforceId + "','" + agentCode + "','" + type + "']" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, false)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invoke: invoke
		}

	});

