﻿angular.module('PruForce.controllers')

	.controller('ProductionGraphDataCtrl', function ($scope, $rootScope, $http, $filter, GraphPeriodProdHistoryService) {

		$scope.init = function (DataProductionGraphUnit, LastUpdateInit) {
			getDataProductionGraphIndividuListSuccess(DataProductionGraphUnit);
			getLastUpdateSuccess(LastUpdateInit);

		};

		GraphPeriodProdHistoryService.invoke($rootScope.username, $rootScope.agent.code, "individu").then(function (res) {
			getGraphPeriodProdHistoryIndividuListSuccess(res);
		});

		$scope.statusHistory = false;

		function getDataProductionGraphIndividuListSuccess(result) {
			if (result.invocationResult.isSuccessful && result.invocationResult.statusCode == 200) {
				$scope.statusHistory = true;
				ListProdIndividuData = [];
				if (result.invocationResult != null || result.invocationResult.array.length != 0) {
					$scope.flagShow = true;
					var periodMonthYear = [];
					var apeNet = [];
					ListDataInd = [];
					for (var i = 0; i < result.invocationResult.array.length; i++) {

						var dt = {};

						apeNetShow = result.invocationResult.array[i].apeNet;
						dt.apeNetShow = Number(apeNetShow).formatMoney(2, '.', ',');

						var month = result.invocationResult.array[i].periodMonth;
						(month.length < 2) ? month = "0" + month : month;
						var inputDate = result.invocationResult.array[i].periodYear + "-" + month + "-01";
						dt.periodMonthYear = moment(inputDate).format('MMM YY');
						ListDataInd[i] = dt;

						periodMonthYear.push(moment(inputDate).format('MMM YY'));

						apeNet.push(Number(result.invocationResult.array[i].apeNet / 1000000).formatMoney(2, '.', ','));
					}

					$scope.dataProductionIndividu = {
						labels: periodMonthYear,
						datasets: [
							{
								label: "My First dataset",
								fillColor: "rgba(0,0,0,0)",
								strokeColor: "#f00",
								highlightFill: "rgba(220,220,220,0.75)",
								highlightStroke: "rgba(220,220,220,1)",
								data: apeNet
							}
						]
					};
					AppsLog.log("apeNetShow: " + dt.apeNetShow);
					$scope.ListDataInd = ListDataInd;
				}

			} else {
				$scope.statusHistory = false;
				AppsLog.log("No data found. Please try again later!");
			}
		}

		function getGraphPeriodProdHistoryIndividuListSuccess(result) {
			if (result.invocationResult.statusCode == 200) {
				$scope.max = moment("01 " + result.invocationResult.max).format('MMMM YYYY');
				$scope.min = moment("01 " + result.invocationResult.min).format('MMMM YYYY');
			} else {
				AppsLog.log("No data found. Please try again later!");
				$scope.successResult = false;
			}
		}

		$scope.optionsProductionIndividu = {
			scaleFontStyle: "normal",
			scaleFontColor: "#4b79bc",
			responsive: true,
			scaleBeginAtZero: false,
			scaleShowGridLines: false,
			scaleGridLineColor: "rgba(0,0,0,.05)",
			scaleGridLineWidth: 2,
			scaleShowHorizontalLines: true,
			scaleShowVerticalLines: true,
			barShowStroke: true,
			barStrokeWidth: 1,
			barValueSpacing: 2,
			barDatasetSpacing: 1,
			legendTemplate: false,
			showTooltips: false,
			scales: {
				yAxes: [{
					scaleLabel: {
						display: true,
						labelString: 'Testing 2'
					}
				}],
				xAxes: [{
					scaleLabel: {
						display: true,
						labelString: 'Testing 1'
					}
				}]
			}
		};


		function getLastUpdateSuccess(result) {
			if (result.invocationResult.statusCode == 200) {
				var lastUpdate = result.invocationResult.latest;
				var lastUpdateConv = moment(lastUpdate).format('LLLL');
				$scope.lastUpdateConv = lastUpdateConv;
			} else {
				$scope.successResult = false;
			}
		}

	})