﻿/**
 * 
 */

//Achievement Production Individu Controller
angular.module('PruForce.controllers')
	.controller('AchievementProductionCtrl', function ($scope, $rootScope, $http, AchievementProductionIndividuService, AchievementProductionUnitService, $q) {
		AppsLog.log("START >> AchievementProdIndividuCtrl " + new Date());
		console.log("Agen Type : " + $rootScope.agent_channelType);

		AnalyticsLog.logPage("prudential.production.inq");

		//PD Production
		$scope.APE_TITLE = $rootScope.pd? 'APE':'APE NET';

		$scope.goToDetailIndividu = function (params) {
			if (params == 'mtd') {
				if ($rootScope.pd) {
					$state.go("detail_individu_transaction_pd", { "type": "mtd" });
				} else {
					$state.go("detail_individu_transaction", { "type": "mtd" });
				}
			} else {
				if ($rootScope.pd) {
					$state.go("detail_individu_transaction_pd", { "type": "ytd" });
				} else {
					$state.go("detail_individu_transaction", { "type": "ytd" });
				}
			}
		}

		$scope.goToDetailGroup = function (params) {
			if (params == 'mtd') {
				if ($rootScope.pd) {
					$state.go("group_production_pd", { "type": "mtd" });
				} else {
					$state.go("group_production", { "type": "mtd" });
				}
			} else {
				if ($rootScope.pd) {
					$state.go("group_production_pd", { "type": "ytd" });
				} else {
					$state.go("group_production", { "type": "ytd" });
				}
			}
		}//end pd

		$scope.AchievementProductionIndividuService = AchievementProductionIndividuService;
		$scope.AchievementProductionUnitService = AchievementProductionUnitService;
		$scope.loading = true;
		$scope.loadingSmall = true;
		$scope.successCall = true;
		$scope.successResult = true;

		var dataOffline = false;
		var dataOnline = false;
		var dataResult = false;

		$scope.init = function () {
			$scope.loading = true;
			$scope.loadingSmall = true;
			$scope.successCall = true;
			$scope.successResult = true;

			AchievementProductionIndividuService.invoke($rootScope.agent.code, $rootScope.username, true)
				.then(function (res) {
					getDataAchievementIndividuListSuccess(res);
					$scope.loading = (dataOffline) ? false : true;
					dataOffline = true;
				});

			AchievementProductionUnitService.invoke($rootScope.agent.code, $rootScope.username, true)
				.then(function (res) {
					getDataAchievementUnitListSuccess(res);
					$scope.loading = (dataOffline) ? false : true;
					dataOffline = true;
				});
		};

		collection = JsonStoreConfig['findAchievementProductionIndividu'];
		$scope.$on(collection.JSONSTORE_NAME, function (event, args) {
			$scope.successCall = (args.status == "success") ? true : false;
			var qAchievementProductionIndividuService = AchievementProductionIndividuService.invoke($rootScope.agent.code, $rootScope.username, false)
				.then(function (res) {
					getDataAchievementIndividuListSuccess(res);
				});

			$q.all([qAchievementProductionIndividuService]).then(function () {
				if (dataOnline) {
					$scope.loading = false;
					$scope.loadingSmall = false;
				}
				dataOnline = true;
			});
		});

		collection = JsonStoreConfig['findAchievementProductionUnit'];
		$scope.$on(collection.JSONSTORE_NAME, function (event, args) {
			$scope.successCall = (args.status == "success") ? true : false;

			var qAchievementProductionUnitService = AchievementProductionUnitService.invoke($rootScope.agent.code, $rootScope.username, false)
				.then(function (res) {
					getDataAchievementUnitListSuccess(res);
				});

			$q.all([qAchievementProductionUnitService]).then(function () {
				if (dataOnline) {
					$scope.loading = false;
					$scope.loadingSmall = false;
				}
				dataOnline = true;
			});
		});

		$scope.init();

		function getDataAchievementIndividuListSuccess(result) {
			if (result.invocationResult.statusCode == 200) {
				var Dot = ".";
				var insertPosition = 15;

				try {
					//get data from server
					var APENET = result.invocationResult.APENET;
					var TOTALAPE = result.invocationResult.TOTALAPE;


					//insert dot
					var APENETdot = [APENET.slice(0, insertPosition), Dot, APENET.slice(insertPosition)].join('');
					var TOTALAPEdot = [TOTALAPE.slice(0, insertPosition), Dot, TOTALAPE.slice(insertPosition)].join('');

					//substring data
					var mAPENET = APENETdot.substring(0, 18);
					$scope.mAPENETIndv = (APENETdot.substring(18, 19) == "+") ? "" : "-";
					var yAPENET = TOTALAPEdot.substring(0, 18);
					$scope.yAPENETIndv = (TOTALAPEdot.substring(18, 19) == "+") ? "" : "-";

					//convert data to number
					var mtdAPENET = Number(mAPENET);
					var ytdAPENET = Number(yAPENET);

					var retrieveDate2 = new Date(result.retrieveDate);
					var momentDate = moment(retrieveDate2).format('LLLL');
					$scope.lastUpdate = momentDate;

					//convert to format money
					$scope.APENETMTDINDIVIDU = mtdAPENET.formatMoney(2, '.', ',');
					$scope.APENETYTDINDIVIDU = ytdAPENET.formatMoney(2, '.', ',');


					//substring data
					$scope.mAPENETStatIndv = APENETdot.substring(18, 19);
					$scope.yAPENETStatIndv = TOTALAPEdot.substring(18, 19);
				} catch (e) {
					AppsLog.log("msg error : ", e);
					$scope.successResult = false;
				}
				$scope.$apply();
			} else {
				AppsLog.log("No data found. Please try again later!");
				if (dataResult) {
					$scope.successResult = false;
				}
				dataResult = true;
			}
		}

		function getDataAchievementUnitListSuccess(result) {

			if (result.invocationResult.statusCode == 200) {
				if (result.invocationResult != null) {
					var Dot = ".";
					var insertPosition = 15;

					try {
						//get data from server
						var APENET = result.invocationResult.APENET;
						var TOTALAPE = result.invocationResult.TOTALAPE;

						var retrieveDate2 = new Date(result.retrieveDate);
						var momentDate = moment(retrieveDate2).format('LLLL');
						$scope.lastUpdate = momentDate;

						var APENETdot = [APENET.slice(0, insertPosition), Dot, APENET.slice(insertPosition)].join('');
						var TOTALAPEdot = [TOTALAPE.slice(0, insertPosition), Dot, TOTALAPE.slice(insertPosition)].join('');

						//substring data
						var mAPENET = APENETdot.substring(0, 18);
						$scope.mAPENET = (APENETdot.substring(18, 19) == "+") ? "" : "-";
						var yAPENET = TOTALAPEdot.substring(0, 18);
						$scope.yAPENET = (TOTALAPEdot.substring(18, 19) == "+") ? "" : "-";

						//convert data to number
						var mtdAPENET = Number(mAPENET);
						var ytdAPENET = Number(yAPENET);

						//convert to format money
						$scope.APENETMTDUNIT = mtdAPENET.formatMoney(2, '.', ',');
						$scope.APENETYTDUNIT = ytdAPENET.formatMoney(2, '.', ',');
					} catch (e) {
						AppsLog.log("msg error : ", e);
						$scope.successResult = false;
					}

					$scope.$apply();
				}
			} else {
				AppsLog.log("No data found. Please try again later!");
				if (dataResult) {
					$scope.successResult = false;
				}
				dataResult = true;
			}
		}
		AppsLog.log("END >> AchievementProdIndividuCtrl " + new Date());
	})