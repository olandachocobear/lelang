﻿angular.module('PruForce.controllers')
	.controller('BonusTahun3FollowUpPolisResult', function ($scope, $rootScope, $ionicLoading, $filter, BonusTahun3FollowUpPolisResultService, DataPolicyList) {
		AnalyticsLog.logPage("prudential.Bonus3+.BonusTahun3FollowUpPolis");
		var sizePolicy = 30;
		var pagePolicy = 1;
		var filterBy = '';
		var sortBy = '';
		var sortDir = '';
		var searchString = '';
		var periodFrom = '';
		var periodTo = '';
		$scope.transaction = [];
		var listPolicyAll = [];
		var listPolicyAfterAdd = [];
		$scope.noMoreItemsAvailable = false;
		$scope.numberOfItemsToDisplay = 30;
		$scope.filterBy = {
			data: [{
				id: 0,
				name: 'Show All',
				value: 'show all',
				group: ''
			}, {
					id: 1,
					name: 'Auto Debet',
					value: 'autoDebet',
					group: 'Metode Pembayaran'
				}, {
					id: 2,
					name: 'Cash',
					value: 'cash',
					group: 'Metode Pembayaran'
				}, {
					id: 3,
					name: 'In Force',
					value: 'inForce',
					group: 'Status Polis'
				}, {
					id: 4,
					name: 'Lapsed',
					value: 'lapsed',
					group: 'Status Polis'
				}, {
					id: 5,
					name: 'Premium Holiday',
					value: 'premiumHoliday',
					group: 'Metode Pembayaran'
				}]
		};
		$scope.sortBy = {
			data: [{
				id: 0,
				name: 'Sort By',
				value: 'sort by',
				sortdir: 'asc'
			}, {
					id: 1,
					name: $filter('translate')('NEWEST_DUE_DATE'),
					value: 'dueDate',
					sortdir: 'desc'
				}, {
					id: 2,
					name: $filter('translate')('OLDEST_DUE_DATE'),
					value: 'dueDate',
					sortdir: 'asc'
				}, {
					id: 3,
					name: $filter('translate')('PAYMENT_FREQUENCY'),
					value: 'paymentFrequency',
					sortdir: 'asc'
				}, {
					id: 4,
					name: $filter('translate')('PAYMENT_TYPE'),
					value: 'paymentType',
					sortdir: 'asc'
				}, {
					id: 5,
					name: $filter('translate')('POLICY_NAME'),
					value: '',
					sortdir: 'asc'
				}, {
					id: 6,
					name: $filter('translate')('POLICY_NUMBER'),
					value: 'policyNumber',
					sortdir: 'asc'
				}, {
					id: 7,
					name: $filter('translate')('HIGHEST_PREMIUM_AMOUNT'),
					value: 'premiumAmount',
					sortdir: 'desc'
				}, {
					id: 8,
					name: $filter('translate')('SMALLEST_PREMIUM_AMOUNT'),
					value: 'premiumAmount',
					sortdir: 'asc'
				}]
		};
		$scope.filterItem = {
			onRequest: $scope.filterBy.data[0]
		};
		$scope.sortItem = {
			onRequest: $scope.sortBy.data[0]
		};

		var dateNow = new Date();
		$scope.dateBefore = [];
		$scope.dateAfter = [];
		var temp = moment(dateNow).format('LLLL');
		var temp2 = temp.split(" ");
		if (temp2[2].indexOf(",") > -1) {
			$scope.dateAfter.push({ value: dateNow.getFullYear() + "-" + ("0" + (dateNow.getMonth() + 1)).slice(-2), name: temp2[1] + " " + temp2[3] });
			$scope.dateBefore.push({ value: dateNow.getFullYear() + "-" + ("0" + (dateNow.getMonth() + 1)).slice(-2), name: temp2[1] + " " + temp2[3] });
		} else {
			$scope.dateAfter.push({ value: dateNow.getFullYear() + "-" + ("0" + (dateNow.getMonth() + 1)).slice(-2), name: temp2[2] + " " + temp2[3] });
			$scope.dateBefore.push({ value: dateNow.getFullYear() + "-" + ("0" + (dateNow.getMonth() + 1)).slice(-2), name: temp2[2] + " " + temp2[3] });
		}
		for (var i = 1; i < 6; i++) {
			if (i === 1) {
				dateNow.setMonth(dateNow.getMonth() + 1);
				var temp = moment(dateNow).format('LLLL');
				var temp2 = temp.split(" ");
				if (temp2[2].indexOf(",") > -1) {
					$scope.dateAfter.push({ value: dateNow.getFullYear() + "-" + ("0" + (dateNow.getMonth() + 1)).slice(-2), name: temp2[1] + " " + temp2[3] });
				} else {
					$scope.dateAfter.push({ value: dateNow.getFullYear() + "-" + ("0" + (dateNow.getMonth() + 1)).slice(-2), name: temp2[2] + " " + temp2[3] });
				}
				dateNow.setMonth(dateNow.getMonth() - 2);
				var temp = moment(dateNow).format('LLLL');
				var temp2 = temp.split(" ");
				if (temp2[2].indexOf(",") > -1) {
					$scope.dateBefore.push({ value: dateNow.getFullYear() + "-" + ("0" + (dateNow.getMonth() + 1)).slice(-2), name: temp2[1] + " " + temp2[3] });
				} else {
					$scope.dateBefore.push({ value: dateNow.getFullYear() + "-" + ("0" + (dateNow.getMonth() + 1)).slice(-2), name: temp2[2] + " " + temp2[3] });
				}
			} else {
				dateNow.setMonth(dateNow.getMonth() - 1);
				var temp = moment(dateNow).format('LLLL');
				var temp2 = temp.split(" ");
				if (temp2[2].indexOf(",") > -1) {
					$scope.dateBefore.push({ value: dateNow.getFullYear() + "-" + ("0" + (dateNow.getMonth() + 1)).slice(-2), name: temp2[1] + " " + temp2[3] });
				} else {
					$scope.dateBefore.push({ value: dateNow.getFullYear() + "-" + ("0" + (dateNow.getMonth() + 1)).slice(-2), name: temp2[2] + " " + temp2[3] });
				}
			}
		}
		$scope.dateBeforeItem = {
			onRequest: $scope.dateBefore[0]
		};
		$scope.dateAfterItem = {
			onRequest: $scope.dateAfter[0]
		};

		getListPolisStatusSuccess(DataPolicyList);

		$scope.loadMore = function () {
			pagePolicy += 1;
			searchString = ($scope.transaction.searchString == undefined) ? "" : $scope.transaction.searchString.replace(/['|"|\\]/g, "\\$&");
			if ($scope.sortItem.onRequest.id === 0) {
				sortBy = '';
			} else {
				sortBy = $scope.sortItem.onRequest.value;
			}
			if ($scope.filterItem.onRequest.id === 0) {
				filterBy = '';
			} else {
				filterBy = $scope.filterItem.onRequest.value;
			}
			if (searchString == undefined) {
				searchString = '';
			}
			sortDir = $scope.sortItem.onRequest.sortdir;
			periodFrom = $scope.dateBeforeItem.onRequest.value;
			periodTo = $scope.dateAfterItem.onRequest.value;
			getDataFromService();
			$scope.noMoreItemsAvailable = false;
		};

		$scope.goSearching = function () {
			$ionicLoading.show();
			listPolicyAll = [];
			sizePolicy = 30;
			pagePolicy = 1;
			searchString = ($scope.transaction.searchString == undefined) ? "" : $scope.transaction.searchString.replace(/['|"|\\]/g, "\\$&");
			if ($scope.sortItem.onRequest.id === 0) {
				sortBy = '';
			} else {
				sortBy = $scope.sortItem.onRequest.value;
			}
			if ($scope.filterItem.onRequest.id === 0) {
				filterBy = '';
			} else {
				filterBy = $scope.filterItem.onRequest.value;
			}
			if (searchString == undefined) {
				searchString = '';
			}
			sortDir = $scope.sortItem.onRequest.sortdir;
			periodFrom = $scope.dateBeforeItem.onRequest.value;
			periodTo = $scope.dateAfterItem.onRequest.value;
			$scope.noMoreItemsAvailable = false;
			getDataFromService();
		}

		function getDataFromService() {
			BonusTahun3FollowUpPolisResultService.invoke($rootScope.username, $rootScope.agent.code, $rootScope.agent.code, filterBy, searchString, periodFrom, periodTo, sortBy, sortDir, sizePolicy, pagePolicy).then(function (res) {
				getListPolisStatusSuccess(res);
			});
		}

		function getListPolisStatusSuccess(result) {
			if (result.invocationResult.isSuccessful) {
				var policyHolderNameTemp;
				if (result.invocationResult.array != null) {
					if (listPolicyAll.length == 0) {
						listPolicyAll = [];
						for (var i = 0; i < result.invocationResult.array.length; i++) {
							var data = {};
							var policyHolderName = result.invocationResult.array[i].policyHolderName;

							if (policyHolderName == null) {
								policyHolderNameTemp = "";
							} else {
								policyHolderNameTemp = policyHolderName;
							}

							var premiumAmount = Number(result.invocationResult.array[i].premiumAmount);

							var splitProductName = (result.invocationResult.array[i].productName).split(" ");

							data.paymentType = result.invocationResult.array[i].paymentType;
							data.policyHolderName = policyHolderNameTemp;
							data.policyNumber = result.invocationResult.array[i].policyNumber;
							data.paymentFrequency = result.invocationResult.array[i].paymentFrequency;
							data.premiumAmount = premiumAmount.formatMoney(2, '.', ',');
							data.policyStatus = result.invocationResult.array[i].policyStatus;
							data.dueDate = moment(result.invocationResult.array[i].dueDate).format('LL');
							data.occDate = moment(result.invocationResult.array[i].occDate).format('LL');
							data.productNameFirst = result.invocationResult.array[i].productName.substring(0, 3);
							data.productNameMid = result.invocationResult.array[i].productName.substring(3, splitProductName[0].length);
							data.productNameLast = result.invocationResult.array[i].productName.substring(splitProductName[0].length, result.invocationResult.array[i].productName.length);
							data.status = result.invocationResult.array[i].status;
							data.currency = result.invocationResult.array[i].currency;
							listPolicyAll[i] = data;
							pagePolicy = 1;
						}
					} else {
						for (var i = 0; i < result.invocationResult.array.length; i++) {
							var data = {};
							var policyHolderName = result.invocationResult.array[i].policyHolderName;

							if (policyHolderName == null) {
								policyHolderNameTemp = "";
							} else {
								policyHolderNameTemp = policyHolderName;
							}

							var premiumAmount = Number(result.invocationResult.array[i].premiumAmount);

							var splitProductName = (result.invocationResult.array[i].productName).split(" ");

							data.paymentType = result.invocationResult.array[i].paymentType;
							data.policyHolderName = policyHolderNameTemp;
							data.policyNumber = result.invocationResult.array[i].policyNumber;
							data.paymentFrequency = result.invocationResult.array[i].paymentFrequency;
							data.premiumAmount = premiumAmount.formatMoney(2, '.', ',');
							data.policyStatus = result.invocationResult.array[i].policyStatus;
							data.dueDate = moment(result.invocationResult.array[i].dueDate).format('LL');
							data.occDate = moment(result.invocationResult.array[i].occDate).format('LL');
							data.productNameFirst = result.invocationResult.array[i].productName.substring(0, 3);
							data.productNameMid = result.invocationResult.array[i].productName.substring(3, splitProductName[0].length);
							data.productNameLast = result.invocationResult.array[i].productName.substring(splitProductName[0].length, result.invocationResult.array[i].productName.length);
							data.status = result.invocationResult.array[i].status;
							listPolicyAfterAdd[i] = data;
							listPolicyAll.push(listPolicyAfterAdd[i]);
							$scope.numberOfItemsToDisplay += listPolicyAfterAdd.length;
						}
					}
				}

				$scope.dataPolicy = listPolicyAll;

				$ionicLoading.hide();
				$scope.noMoreItemsAvailable = false;
				$scope.$broadcast('scroll.infiniteScrollComplete');
				if (result.invocationResult.statusCode == 500) {
					$ionicLoading.hide();
					$scope.noMoreItemsAvailable = true;
					AppsLog.log("No data found1. Please try again later!");
				}
			} else if (result.invocationResult.statusCode == 500) {
				$scope.showLoading = false;
				$ionicLoading.hide();
				$scope.noMoreItemsAvailable = true;
				AppsLog.log("No data found2. Please try again later!");
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}
		$scope.agentNumber = $rootScope.agent.code;
	})