﻿angular.module('PruForce.services')
	.service('AchievementLoyaltyListMonthService', function (DataFactory2, $q) {
		function invoke(salesforceId, agentCode) {

			AppsLog.log("salesforceId" + salesforceId + agentCode);

			var req = {
				adapter: "HTTPAdapter3",
				procedure: "findPolicyListMonth",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + salesforceId + "','" + agentCode + "']" }
			};

			var deferred = $q.defer();

			DataFactory2.invoke(req)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invoke: invoke
		}
	});