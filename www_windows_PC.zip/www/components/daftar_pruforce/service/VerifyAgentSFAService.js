﻿angular.module('PruForce.services')

	.service('VerifyAgentSFAService', function (AOBResources, $q) {

		function invoke(agentcode_sfaId, password) {
			var req = {
				adapter: "HTTPAdapterAuth",
				procedure: "loginAgent",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + agentcode_sfaId + "','" + password + "']" }
			};

			var deferred = $q.defer();

			AOBResources.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invoke: invoke
		}
	});

