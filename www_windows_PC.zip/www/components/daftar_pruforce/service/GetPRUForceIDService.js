﻿angular.module('PruForce.services')

	.service('GetPRUForceIDService', function (AOBResources, $q) {

		function invoke(agentCode, npaNumber) {
			var req = {
				adapter: "HTTPAdapterAuth",
				procedure: "getIDpruforceid",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + agentCode + "','" + npaNumber + "']" }
			};

			var deferred = $q.defer();

			AOBResources.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invoke: invoke
		}
	});