﻿angular.module('PruForce.controllers')

	.controller('CandidateDaftarPRUForceIDCtrl', function ($scope, $translate, $filter, $state, $rootScope, $localStorage, $ionicPopup, $ionicLoading, CandidateVerifyingDataService, GetPRUForceIDService) {


		$scope.initModel = {};

		$scope.VerifyDaftar = function () {
			if ($scope.initModel.npa == undefined || $scope.initModel.nama == undefined || $scope.initModel.idcardno == undefined) {
				$rootScope.AlertDialog($filter('translate')('PRU_05'));
			} else {
				AnalyticsLog.logPage("Candidate.Verify.Daftar");
				$ionicLoading.show();
				$rootScope.candidate.npa = $scope.initModel.npa;
				$rootScope.candidate.name = $scope.initModel.nama;
				$rootScope.candidate.idcardno = $scope.initModel.idcardno;
				var checksalesforceidflag = "Y";
				$rootScope.candidate.checksalesforceidflag = checksalesforceidflag;
				CandidateVerifyingDataService.invoke($scope.initModel.npa, $scope.initModel.nama, $scope.initModel.idcardno, checksalesforceidflag).then(function (res) {
					VerifyDaftarSuccess(res);
				});
			}

		}
		function VerifyDaftarSuccess(res) {
			if (res.invocationResult.respCode == 200) {
				AnalyticsLog.logPage("Candidate.Daftar.PruforceID");
				var agentCode = "";
				GetPRUForceIDService.invoke(agentCode, $scope.initModel.npa).then(function (res) {
					GetPRUForceIDSuccess(res);
				});
			} else {
				$ionicLoading.hide();
				$rootScope.AlertDialog($filter('translate')('PRU_24'));
			}

		}

		function GetPRUForceIDSuccess(res) {
			var RespCode = res.invocationResult.errorCode;
			var message = res.invocationResult.errorMessage;
			if (RespCode == 000000) {
				$ionicLoading.hide();
				$rootScope.AlertDialog($filter('translate')('PRU_20'));
			} else {
				$ionicLoading.hide();
				$state.go("verifikasi-sms", { 'smsType': 'DaftarPRUForceID', 'userType': 'candidate' });
			}
		}
	})