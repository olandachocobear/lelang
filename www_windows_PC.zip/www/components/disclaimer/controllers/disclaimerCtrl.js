﻿angular.module('PruForce.controllers')
    .controller('disclaimerCtrl', function ($scope, $state, $rootScope, UpdateDisclaimerConfigService) {
		AppsLog.log("disclaimer >>> ");

        $scope.notChecked = false;

		$scope.$watch('notChecked', function () {

			if ($scope.notChecked) {
				$rootScope.alertPopup.close();

				UpdateDisclaimerConfigService.update($rootScope.userLoginName).then(function (res) {
					AppsLog.log("update disclaimer berhasil");
					AppsLog.log(res);
				}, function (error) {
					AppsLog.log("Error");
					AppsLog.log(error);
				}
				);

			}

		});
    })