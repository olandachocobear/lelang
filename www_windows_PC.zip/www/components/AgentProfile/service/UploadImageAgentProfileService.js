﻿angular.module('PruForce.services')
	.service('UploadImageAgentProfileService', function (DataFactory, $q) {
		AppsLog.log("masuk service 1");
		var module = "agentProfile";
		function invoke(agentNumber, pruforceId, agentCode, fileName, file) {
			AppsLog.log("masuk service 2");
			var module = "agentProfile";
			var req = {
				adapter: "HTTPAdapterInquiry",
				procedure: "UploadGambarAgentProfile",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + agentNumber + "','" + pruforceId + "','" + agentCode + "','" + fileName + "','" + module + "','" + file + "']" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
					AppsLog.log("hasil invoke dalam service");
					AppsLog.log(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invoke: invoke
		}
	});

