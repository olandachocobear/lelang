﻿angular.module('PruForce.services')
	.service('AgentProfileService', function (DataFactory, $q) {
		AppsLog.log("masuk service");
		function invoke(agentNumber, pruforceId) {
			AppsLog.log("masuk service 2");
			var req = {
				adapter: "HTTPAdapterInquiry",
				procedure: "findProfileByAgentNumber",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + agentNumber + "','" + pruforceId + "']" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, false)
				.then(function (res) {
					deferred.resolve(res);
					AppsLog.log("hasil invoke dalam service");
					AppsLog.log(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invoke: invoke
		}
	});

