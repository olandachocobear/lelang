﻿angular.module('PruForce.controllers')

    .controller('AAJIAgentCtrl', function ($scope, $state, $jrCrop, $translate, $filter, $ionicLoading, AAJICity, $rootScope, $ionicModal, $ionicPopup, $stateParams, CheckAAJICountLocalService, GetAAJIScheduleService, SubmitAAJIAgentService, CheckAAJIService, SupportDocAgentService, UpdateInboxService, GetAplicationPackService, InboxService, SubmitNotifByUserService) {

        $scope.AAJI = {};
        $scope.AAJI.location = {};
        $scope.AAJI.choosed = {};
        $scope.flagReadOnly = $stateParams.flagReadOnly;
        $scope.isExpanded = false;
        $scope.Location = [];
        $scope.formValidasi = {};

        if ($scope.flagReadOnly) {
            $scope.isExpanded = true;
            $scope.AAJI.location = $rootScope.candidate.aajiSchedule[0].sch[0].loc;
            $scope.Location.push($rootScope.candidate.aajiSchedule[0].sch[0].loc);
            $scope.aajiSchedule = $rootScope.candidate.aajiSchedule;
        } else {
            AAJICityList(AAJICity);
            function AAJICityList(result) {
                for (var i = 0; i < result.invocationResult.array.length; i++) {
                    $scope.Location.push(result.invocationResult.array[i].aajiexamlocation);
                };
            }
        }

        $scope.showConfirm = function (id, date) {
            var confirmPopup = $ionicPopup.confirm({
                title: "<strong>PRU</strong><em>force</em>",
                template: $filter('translate')('PRU_88'),
                cssClass: 'pru-white-alert without-header popup-large pru-logo-text button-side-duo',

                buttons: [{
                    text: $filter('translate')('NO'),
                    type: 'button-assertive',

                    onTap: function (e) { }
                },
                    {
                        text: $filter('translate')('YES'),
                        type: 'button-assertive',
                        onTap: function () {
                            for (var i = 0; i < $scope.aajiSchedule.length; i++) {
                                for (var j = 0; j < $scope.aajiSchedule[i].sch.length; j++) {
                                    var schId = $scope.aajiSchedule[i].sch[j].id;
                                    if (schId != id) {
                                        $scope["choosingAaji" + schId] = false;
                                    }
                                }
                            }
                            $scope["choosingAaji" + id] = true;
                            $scope.AAJI.choosed.id = id;
                            $scope.AAJI.choosed.date = date;
                        }
                    }]
            });
        };

        $scope.getScheduleAAJI = function (city) {
            AnalyticsLog.logPage("Get.Schedule.AAJI");
            var dateNow = new Date();
            var today = $filter('date')(dateNow, 'yyyy-MM-dd');
            GetAAJIScheduleService.invoke(city).then(
                function (result) {
                    $scope.aajiSchedule = result;
                    $ionicLoading.hide();
                },
                function (error) {
                    AppsLog.log(error);
                }
            );
        }

        $scope.changeAAJILocation = function () {
            AnalyticsLog.logPage("Change.AAJI.Location");
            if ($scope.AAJI.location == "0") {
                delete $scope.AAJI.location;
            } else {
                $scope.getScheduleAAJI($scope.AAJI.location);
            }
        }

        $scope.chooseAajiSchedule = function (e, id, date) {
            var choosedSch = document.getElementsByClassName("choosed").length;
            if (choosedSch <= 0) {
                $scope.AAJI.choosed.id = id;
                $scope.AAJI.choosed.date = date;
                $scope["choosingAaji" + id] = true;
            } else {
                if (!$scope["choosingAaji" + id]) {
                    $scope.showConfirm(id, date);
                } else {
                    $scope["choosingAaji" + id] = false;
                    delete $scope.AAJI.choosed.id;
                }
            }
        }

        $scope.image = {};
        $scope.image.bukti = {};

        $scope.showCropper = function (image, uploadTo, widthCropper, heightCropper) {
            var dataModel = uploadTo.split(".");
            $jrCrop.crop({
                url: image,
                width: widthCropper,
                height: heightCropper,
                cancelText: $filter('translate')('CANCEL'),
                chooseText: $filter('translate')('CROP'),
                allowRotation: true,
                buttonLocation: 'footer',
            }).then(function (canvas) {
                $scope[dataModel[0]][dataModel[1]][dataModel[2]] = canvas.toDataURL();
            });
        };

        $scope.submitAAJI = function (validation) {
            if ($scope.AAJI.choosed.id == undefined) {
                $rootScope.AlertDialog($filter('translate')('PRU_89'));
            } else if ($scope.image.bukti.bayar == undefined || $scope.image.bukti.bayar == null || $scope.image.bukti.bayar == "undefined" || $scope.image.bukti.bayar == '') {
                if (validation) {
                    $rootScope.AlertDialog($filter('translate')('MSG_UPLOAD_PHOTO'));
                } else {
                    $ionicLoading.show();
                    $scope.mandatoryImage = false;
                    CheckAAJI();
                }
            } else {
                $ionicLoading.show();
                $scope.mandatoryImage = true;
                CheckAAJI();
            }
        }

        function CheckAAJI() {
            CheckAAJICountLocalService.invoke(new Date($scope.AAJI.choosed.date)).then(function (res) {
                var count = res;
                var date = new Date();
                var currentHour = date.getHours();
                var scheduleId = $scope.AAJI.choosed.id;
                if (currentHour >= 11) {
                    if (count >= 6 && count <= 15) {
                        CheckAAJIService.invokeByCandidate(scheduleId).then(function (res) {
                            checkAAJISuccess(res);
                        });
                    } else {
                        $ionicLoading.hide();
                        $rootScope.AlertDialog($filter('translate')('PRU_54'));
                    }

                } else {
                    if (count >= 5 && count <= 15) {
                        CheckAAJIService.invokeByCandidate(scheduleId).then(function (res) {
                            checkAAJISuccess(res);
                        });
                    } else {
                        $ionicLoading.hide();
                        $rootScope.AlertDialog($filter('translate')('PRU_55'));
                    }
                }
            });


        }

        function checkAAJISuccess(res) {
            var aajiexamquota = res.invocationResult.aajiexamquota;
            var reserved = res.invocationResult.reserved;
            var isvalidexpireddate = res.invocationResult.isvalidexpireddate;
            var isvalidexamdate = res.invocationResult.isvalidexamdate;

            if (reserved == null) {
                reserved = 0;
            }
            if (!isvalidexpireddate) {
                $rootScope.AlertDialog($filter('translate')('PRU_61'));
            }
            else if (!isvalidexamdate) {
                $rootScope.AlertDialog($filter('translate')('PRU_58'));
            }
            else if (reserved >= aajiexamquota) {
                $rootScope.AlertDialog($filter('translate')('PRU_59'));
            }
            else {
                SubmitUjianAAJI();
            }

        }

        function SubmitUjianAAJI() {
            var aajiexamdate = $filter('date')(new Date($scope.AAJI.choosed.date), 'yyyy-MM-dd').toString();
            var ajischeduleid = $scope.AAJI.choosed.id;
            if ($rootScope.agent.userType == 'candidate') {
                CheckAAJIService.changeAAJIRegistration(ajischeduleid, $rootScope.inbox.userid, '', aajiexamdate).then(function (res) {
                    if (res.invocationResult.respCode == 200) {
                        if ($scope.mandatoryImage) {
                            UploadAgentSupportDoc();
                        } else {
                            submitNotificationToSender();
                        }
                    } else {
                        $ionicLoading.hide();
                        $rootScope.AlertDialog($filter('translate')('PRU_44'));
                    }
                });
            } else {
                var aajistatusagent = 'retaker';
                CheckAAJIService.submitAAJIRegistration(ajischeduleid, '', $rootScope.agent.code, aajiexamdate, aajistatusagent).then(function (res) {
                    if (res.invocationResult.respCode == 200) {
                        if ($scope.mandatoryImage) {
                            UploadAgentSupportDoc();
                        } else {
                            submitNotificationToSender();
                        }
                    } else {
                        $ionicLoading.hide();
                        $rootScope.AlertDialog($filter('translate')('PRU_44'));
                    }
                });
            }

        }

        function UploadAgentSupportDoc() {
            var imageBase64 = getSubstringImage($scope.image.bukti.bayar);
            SupportDocAgentService.invoke($rootScope.agent.code, 'JPG', 'Bukti Bayar', imageBase64).then(function (res) {
                if (res.invocationResult.respCode == 200) {
                    if ($rootScope.agent.userType == 'candidate') {
                        submitNotificationToSender();
                    } else {
                        if ($rootScope.inbox.reqId == "AAJI") {
                            UpdateInboxService.invoke($rootScope.inbox.idInbox).then(function (res) {
                                if (res.invocationResult.statusCode == 200) {
                                    InboxService.invoke($rootScope.inbox.userid).then(function (res) {
                                        $ionicLoading.hide();
                                        $rootScope.inbox.Length = res.invocationResult.array.length;
                                        $rootScope.DialogEvents($filter('translate')('PRU_56'), "home-menu.agent");
                                    });
                                } else {
                                    $rootScope.DialogEvents($filter('translate')('PRU_97'), "home-menu.agent");
                                }
                            });
                        } else {
                            $ionicLoading.hide();
                            $rootScope.MenuList.AAJIAGENT = false;
                            $rootScope.DialogEvents($filter('translate')('PRU_56'), "home-menu.agent");
                        }

                    }
                } else {
                    $ionicLoading.hide();
                    $rootScope.AlertDialog($filter('translate')('PRU_44'));
                }
            });
        }

        function getSubstringImage(base64Image) {
            var subStringImage;
            subStringImage = base64Image.substring(22, base64Image.length);
            return subStringImage;
        }

        function submitNotificationToSender() {
            /*eventId for sign is 99583 (this based on back office) */
            var eventId = 99583;
            var payload = {};
            payload.reqId = 'sign';
            payload.npa = $rootScope.inbox.userid;
            payload.docList = 'From Candidate';
            payload.candidatename = $rootScope.userLoginName;

            SubmitNotifByUserService.invoke($rootScope.inbox.senderNotif, eventId, pushNotifToken, payload).then(function (res) {
                if (res.invocationResult.isSuccessful) {
                    updateInbox();
                } else {
                    $ionicLoading.hide();
                    $rootScope.AlertDialog($filter('translate')('PRU_44'));
                }
            });
        }

        function updateInbox() {
            UpdateInboxService.invoke($rootScope.inbox.idInbox).then(function (res) {
                $ionicLoading.hide();
                if (res.invocationResult.statusCode == 200) {
                    if ($rootScope.agent.userType == 'candidate') {
                        $rootScope.DialogEvents($filter('translate')('PRU_56'), "home-menu.candidate");
                    } else {
                        $rootScope.DialogEvents($filter('translate')('PRU_56'), "home-menu.agent");
                    }
                } else {
                    if ($rootScope.agent.userType == 'candidate') {
                        $rootScope.DialogEvents($filter('translate')('PRU_97'), "home-menu.candidate");
                    } else {
                        $rootScope.DialogEvents($filter('translate')('PRU_97'), "home-menu.agent");
                    }
                }
            });
        }
    })