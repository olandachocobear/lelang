﻿angular.module('PruForce.services')

	.service('CheckIDEmailService', function (AOBResources, $q) {

		function invoke(username, userType) {
			var req = {
				adapter: "HTTPAdapterAuth",
				procedure: "checkVerifikasiEmail",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + username + "','" + userType + "']" }
			};

			var deferred = $q.defer();

			AOBResources.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invoke: invoke,
		}
	});

