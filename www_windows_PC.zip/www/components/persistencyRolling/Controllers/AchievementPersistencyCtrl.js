﻿/**
 * 
 */

angular.module('PruForce.controllers').controller('AchievementPersistencyCtrl', function ($scope, $state, $interval, $http, $filter, ListDataPersistency, ListDataHistory, $localStorage) {
	AnalyticsLog.logPage("prudential.persistency.landing");
	var size = 30;
	var page = 1;
	var searchBy = "";
	var searchVal = "";
	var searchBy2 = "";
	var searchVal2 = "";
	var orderBy = "";
	var direction = "asc";
	var persistencyCode = "I";

	var listDataAll = [];
	var listDataAllAfterAdd = [];

	function setListDataHistory(result) {
		if (result.invocationResult.isSuccessful) {
			$scope.IndividuHistory = result.invocationResult.Individu;
			$scope.UnitHistory = result.invocationResult.Unit;
			$scope.GroupHistory = result.invocationResult.Group;
			$scope.statusIndividuHistory = false;
			$scope.statusUnitHistory = false;
			$scope.statusGroupHistory = false;
			for (var i = 0; i < $scope.IndividuHistory.length; i++) {
				if ($scope.IndividuHistory[i].totalPrsctyApiCurrent > -1) {
					$scope.statusIndividuHistory = true;
				}
				if ($scope.IndividuHistory[i].totalPrsctyApiRolling > -1) {
					$scope.statusIndividuHistory = true;
				}
			}
			for (var i = 0; i < $scope.UnitHistory.length; i++) {
				if ($scope.UnitHistory[i].totalPrsctyApiCurrent > -1) {
					$scope.statusUnitHistory = true;
				}
				if ($scope.UnitHistory[i].totalPrsctyApiRolling > -1) {
					$scope.statusUnitHistory = true;
				}
			}
			for (var i = 0; i < $scope.GroupHistory.length; i++) {
				if ($scope.GroupHistory[i].totalPrsctyApiCurrent > -1) {
					$scope.statusGroupHistory = true;
				}
				if ($scope.GroupHistory[i].totalPrsctyApiRolling > -1) {
					$scope.statusGroupHistory = true;
				}
			}

			var IndividuMonth = [];
			var IndividuCurrent = [];
			var IndividuRolling = [];
			for (var i = 0; i < $scope.IndividuHistory.length; i++) {
				IndividuMonth.push($scope.formatDateTime($scope.IndividuHistory[i].period));
				IndividuCurrent.push($scope.IndividuHistory[i].totalPrsctyApiCurrent);
				IndividuRolling.push($scope.IndividuHistory[i].totalPrsctyApiRolling);

				$scope.dataPersistensiIndividu = {
					labels: IndividuMonth,
					datasets: [{
						label: "Persistensi Saat ini",
						fillColor: "rgba(0,0,0,0)",
						strokeColor: "#f00",
						highlightFill: "rgba(220,220,220,0.75)",
						highlightStroke: "rgba(220,220,220,1)",
						pointColor: '#f00',
						pointStrokeColor: '#fff',
						data: IndividuCurrent
					}, {
							label: "Rolling Persistensi",
							fillColor: "rgba(0,0,0,0)",
							strokeColor: "#48752a",
							highlightFill: "rgba(220,220,220,0.75)",
							highlightStroke: "rgba(220,220,220,1)",
							pointColor: '#48752a',
							pointStrokeColor: '#fff',
							data: IndividuRolling
						}]
				};

				$scope.dataPersistensiIndividuPD = {
					labels: IndividuMonth,
					datasets: [{
						label: "Persistensi Saat ini",
						fillColor: "rgba(0,0,0,0)",
						strokeColor: "#f00",
						highlightFill: "rgba(220,220,220,0.75)",
						highlightStroke: "rgba(220,220,220,1)",
						pointColor: '#f00',
						pointStrokeColor: '#fff',
						data: IndividuCurrent
					}]
				};
			}

			var UnitMonth = [];
			var UnitCurrent = [];
			var UnitRolling = [];
			for (var i = 0; i < $scope.UnitHistory.length; i++) {
				UnitMonth.push($scope.formatDateTime($scope.UnitHistory[i].period));
				UnitCurrent.push($scope.UnitHistory[i].totalPrsctyApiCurrent);
				UnitRolling.push($scope.UnitHistory[i].totalPrsctyApiRolling);

				$scope.dataPersistensiUnit = {
					labels: UnitMonth,
					datasets: [{
						label: "Persistensi Saat ini",
						fillColor: "rgba(0,0,0,0)",
						strokeColor: "#f00",
						highlightFill: "rgba(220,220,220,0.75)",
						highlightStroke: "rgba(220,220,220,1)",
						pointColor: '#f00',
						pointStrokeColor: '#fff',
						data: UnitCurrent
					}, {
							label: "Rolling Persistensi",
							fillColor: "rgba(0,0,0,0)",
							strokeColor: "#48752a",
							highlightFill: "rgba(220,220,220,0.75)",
							highlightStroke: "rgba(220,220,220,1)",
							pointColor: '#48752a',
							pointStrokeColor: '#fff',
							data: UnitRolling
						}]
				};

				$scope.dataPersistensiUnitPD = {
					labels: UnitMonth,
					datasets: [{
						label: "Persistensi Saat ini",
						fillColor: "rgba(0,0,0,0)",
						strokeColor: "#f00",
						highlightFill: "rgba(220,220,220,0.75)",
						highlightStroke: "rgba(220,220,220,1)",
						pointColor: '#f00',
						pointStrokeColor: '#fff',
						data: UnitCurrent
					}]
				};
			}

			var GroupMonth = [];
			var GroupCurrent = [];
			var GroupRolling = [];
			for (var i = 0; i < $scope.GroupHistory.length; i++) {
				GroupMonth.push($scope.formatDateTime($scope.GroupHistory[i].period));
				GroupCurrent.push($scope.GroupHistory[i].totalPrsctyApiCurrent);
				GroupRolling.push($scope.GroupHistory[i].totalPrsctyApiRolling);

				$scope.dataPersistensiGroup = {
					labels: GroupMonth,
					datasets: [{
						label: "Persistensi Saat ini",
						fillColor: "rgba(0,0,0,0)",
						strokeColor: "#f00",
						highlightFill: "rgba(220,220,220,0.75)",
						highlightStroke: "rgba(220,220,220,1)",
						pointColor: '#f00',
						pointStrokeColor: '#fff',
						data: GroupCurrent
					}, {
							label: "Rolling Persistensi",
							fillColor: "rgba(0,0,0,0)",
							strokeColor: "#48752a",
							highlightFill: "rgba(220,220,220,0.75)",
							highlightStroke: "rgba(220,220,220,1)",
							pointColor: '#48752a',
							pointStrokeColor: '#fff',
							data: GroupRolling
						}]
				};

				$scope.dataPersistensiGroupPD = {
					labels: GroupMonth,
					datasets: [{
						label: "Persistensi Saat ini",
						fillColor: "rgba(0,0,0,0)",
						strokeColor: "#f00",
						highlightFill: "rgba(220,220,220,0.75)",
						highlightStroke: "rgba(220,220,220,1)",
						pointColor: '#f00',
						pointStrokeColor: '#fff',
						data: GroupCurrent
					}]
				};
			}
		}
	}

	$scope.optionsPersistensiIndividu = {
		scaleOverride: true,
		scaleSteps: 10,
		scaleStepWidth: 10,
		scaleStartValue: 0,
		scaleFontStyle: "normal",
		scaleFontColor: "#636363",
		responsive: true,
		scaleBeginAtZero: true,
		scaleShowGridLines: false,
		scaleGridLineColor: "#636363",
		scaleGridLineWidth: 2,
		scaleShowHorizontalLines: true,
		scaleShowVerticalLines: true,
		barShowStroke: true,
		barStrokeWidth: 1,
		barValueSpacing: 2,
		barDatasetSpacing: 1,
		legendTemplate: true,
		pointHitDetectionRadius: 1,
		showTooltips: false
	};

	function setListData(result) {
		$scope.data = result.invocationResult;
		if (result.invocationResult.statusCode == 200) {
			var Individu = result.invocationResult.Individu;
			var Unit = result.invocationResult.Unit;
			var Group = result.invocationResult.Group;

			var retrieveDate = new Date(result.invocationResult.date);
			momentDate = moment(retrieveDate).format('LLLL');
			$scope.lastUpdate = momentDate == "Invalid date" ? "" : momentDate;

			$scope.chartOptions = {
				chart: {
					type: 'solidgauge'
				},

				title: null,
				pane: {
					center: ['50%', '85%'],
					size: '100%',
					startAngle: -90,
					endAngle: 90,
					background: {
						backgroundColor: (Highcharts.theme && Highcharts.theme.background2)
						|| '#EEE',
						innerRadius: '60%',
						outerRadius: '100%',
						shape: 'arc'
					}
				},

				tooltip: {
					enabled: false
				},

				yAxis: {
					min: 0,
					max: 100,
					title: {
						text: 'Speed'
					},
					lineWidth: 0,
					minorTickInterval: null,
					tickAmount: 2,
					title: {
						y: -70
					},
					labels: {
						y: 16
					}
				},

				plotOptions: {
					solidgauge: {
						dataLabels: {
							y: 5,
							borderWidth: 0,
							useHTML: true
						}
					}
				},

				credits: {
					enabled: false
				}
			};

			var valueChart = Individu.totalApiCurrent;
			var formatLabel = (valueChart > -1) ? '<div style="text-align:center"><span style="font-size:25px;color:#636363">' + valueChart + '%</span></div>' : '<div style="text-align:center"><span style="font-size:25px;color:#636363">N/A</span></div>';
			$scope.persistensiSeriesIndividu = {
				series: [{
					name: 'Speed',
					data: [{
						color: {
							linearGradient: [0, 0, 124, 0],
							stops: [
								[0.1, '#FF0000'],
								[0.5, '#DDDF0D'],
								[0.9, '#55BF3B']
							]
						},
						y: valueChart
					}],
					dataLabels: {
						format: formatLabel

					},
					tooltip: {
						valueSuffix: ' km/h'
					}
				}]
			}

			valueChart = Individu.totalApiRolling;
			formatLabel = (valueChart > -1) ? '<div style="text-align:center"><span style="font-size:25px;color:#636363">' + valueChart + '%</span></div>' : '<div style="text-align:center"><span style="font-size:25px;color:#636363">N/A</span></div>';
			$scope.rollingSeriesIndividu = {
				series: [{
					name: 'Speed',
					data: [{
						color: {
							linearGradient: [0, 0, 124, 0],
							stops: [
								[0.1, '#FF0000'],
								[0.5, '#DDDF0D'],
								[0.9, '#55BF3B']
							]
						},
						y: valueChart
					}],
					dataLabels: {
						format: formatLabel

					},
					tooltip: {
						valueSuffix: ' km/h'
					}
				}]
			}

			valueChart = Unit.totalApiCurrent;
			formatLabel = (valueChart > -1) ? '<div style="text-align:center"><span style="font-size:25px;color:#636363">' + valueChart + '%</span></div>' : '<div style="text-align:center"><span style="font-size:25px;color:#636363">N/A</span></div>';
			$scope.persistensiSeriesUnit = {
				series: [{
					name: 'Speed',
					data: [{
						color: {
							linearGradient: [0, 0, 124, 0],
							stops: [
								[0.1, '#FF0000'],
								[0.5, '#DDDF0D'],
								[0.9, '#55BF3B']
							]
						},
						y: valueChart
					}],
					dataLabels: {
						format: formatLabel
					},
					tooltip: {
						valueSuffix: ' km/h'
					}
				}]
			}

			valueChart = Unit.totalApiRolling;
			formatLabel = (valueChart > -1) ? '<div style="text-align:center"><span style="font-size:25px;color:#636363">' + valueChart + '%</span></div>' : '<div style="text-align:center"><span style="font-size:25px;color:#636363">N/A</span></div>';
			$scope.rollingSeriesUnit = {
				series: [{
					name: 'Speed',
					data: [{
						color: {
							linearGradient: [0, 0, 124, 0],
							stops: [
								[0.1, '#FF0000'],
								[0.5, '#DDDF0D'],
								[0.9, '#55BF3B']
							]
						},
						y: valueChart
					}],
					dataLabels: {
						format: formatLabel
					},
					tooltip: {
						valueSuffix: ' km/h'
					}
				}]
			}

			valueChart = Group.totalApiCurrent;
			formatLabel = (valueChart > -1) ? '<div style="text-align:center"><span style="font-size:25px;color:#636363">' + valueChart + '%</span></div>' : '<div style="text-align:center"><span style="font-size:25px;color:#636363">N/A</span></div>';
			$scope.persistensiSeriesGroup = {
				series: [{
					name: 'Speed',
					data: [{
						color: {
							linearGradient: [0, 0, 124, 0],
							stops: [
								[0.1, '#FF0000'],
								[0.5, '#DDDF0D'],
								[0.9, '#55BF3B']
							]
						},
						y: valueChart
					}],
					dataLabels: {
						format: formatLabel
					},
					tooltip: {
						valueSuffix: ' km/h'
					}
				}]
			}

			valueChart = Group.totalApiRolling;
			formatLabel = (valueChart > -1) ? '<div style="text-align:center"><span style="font-size:25px;color:#636363">' + valueChart + '%</span></div>' : '<div style="text-align:center"><span style="font-size:25px;color:#636363">N/A</span></div>';
			$scope.rollingSeriesGroup = {
				series: [{
					name: 'Speed',
					data: [{
						color: {
							linearGradient: [0, 0, 124, 0],
							stops: [
								[0.1, '#FF0000'],
								[0.5, '#DDDF0D'],
								[0.9, '#55BF3B']
							]
						},
						y: valueChart
					}],
					dataLabels: {
						format: formatLabel
					},
					tooltip: {
						valueSuffix: ' km/h'
					}
				}]
			}
			$scope.chartDataPersistensiIndividu = $.extend(
				$scope.persistensiSeriesIndividu, $scope.chartOptions);
			$scope.chartDataRollingIndividu = $.extend(
				$scope.rollingSeriesIndividu, $scope.chartOptions);
			$scope.chartDataPersistensiUnit = $.extend(
				$scope.persistensiSeriesUnit, $scope.chartOptions);
			$scope.chartDataRollingUnit = $.extend(
				$scope.rollingSeriesUnit, $scope.chartOptions);
			$scope.chartDataPersistensiGroup = $.extend(
				$scope.persistensiSeriesGroup, $scope.chartOptions);
			$scope.chartDataRollingGroup = $.extend(
				$scope.rollingSeriesGroup, $scope.chartOptions);

		}
	}

	setListDataHistory(ListDataHistory);
	setListData(ListDataPersistency);

	$scope.persistencyTabs = [{
		title: 'SAAT INI',
		url: 'persistency-mtd'
	}, {
			title: 'RIWAYAT',
			url: 'riwayat'
		}
	];
	$scope.currentpersistencyTab = localStorage.getItem('currentTabPersistency');

	$scope.onClickTab = function (persistencyTab) {
		$scope.currentpersistencyTab = persistencyTab.url;
       	localStorage.setItem('currentTabPersistency', $scope.currentpersistencyTab);
	}

	$scope.isActiveTab = function (persistencyTabUrl) {
		return persistencyTabUrl == $scope.currentpersistencyTab;
	}
	
	localStorage.setItem('currentTabPersistencyList', 'components/persistencyRolling/achievement_persistency_list_old.html');
})