﻿/**
 * 
 */

angular.module('PruForce.controllers').controller('AchievementPersistencyListCtrl', function ($scope, $rootScope, $ionicLoading, $state, $stateParams, $interval, $http, $filter, ListDataCurrent, ListFilterCurrent, ListDataRolling, ListFilterRolling, AchievementPersistencyListService) {
	AnalyticsLog.logPage("prudential.persistency.list");
	$scope.ListDataCurrent = ListDataCurrent;
	$scope.ListFilterCurrent = ListFilterCurrent;
	$scope.ListDataRolling = ListDataRolling;
	$scope.ListFilterRolling = ListFilterRolling;

	$scope.titlePersitencyList = $stateParams.persistency_code == "U" ? "TITLE_UNIT_PERSISTENCY_POLICY" : "TITLE_INDIVIDU_PERSISTENCY_POLICY";

	$scope.achievementTabs = [{
		title: $filter('translate')('OLD_PERSISTENCY'),
		url: 'components/persistencyRolling/achievement_persistency_list_old.html'
	}, {
			title: $filter('translate')('ROLLING_PERSISTENCY'),
			url: 'components/persistencyRolling/achievement_persistency_list_rolling.html'
		}];
	$scope.currentachievementTab = localStorage.getItem('currentTabPersistencyList');

	$scope.onClickTab = function (achievementTab) {
		$scope.currentachievementTab = achievementTab.url;
       	localStorage.setItem('currentTabPersistencyList', $scope.currentachievementTab);
	}

	$scope.isActiveTab = function (achievementTabUrl) {
		return achievementTabUrl == $scope.currentachievementTab;
	}

})