Framework7.prototype.plugins.angular = function(app, params) {
  function compile(newPage) {
    console.log('aw')
    try {
      var $page = $(newPage);
      var injector = angular.element("[ng-app]").injector();
     
      var $compile = injector.get("$compile");
      
      var $timeout = injector.get("$timeout");
      var $scope = injector.get("$rootScope");

      $scope = $scope.$$childHead;
      $timeout(function() {
        console.log('compilee')
        $compile($page)($scope);
        
      })
    } catch (e) {
      //console.error("Some Error Occured While Compiling The Template", e);
    }
  }

  function removeOldPage(pageData){
    var $oldPage =  $(".views .view .pages .page").not( $(pageData.container));
    if( $oldPage.length > 0){
      var controllerName = $oldPage.attr("ng-controller");
      console.log($oldPage)
      
      var $scope = angular.element('[ng-controller='+controllerName+']').scope();
      console.log ($scope)
      if($scope){
        $scope.$destroy();
        $oldPage.remove();
      }
    }
  }

  return {
    hooks: {
      pageInit: function(pageData) {
        console.log('page Init')
        console.log(pageData)
        compile(pageData.container);
      },
      pageAfterAnimation  : function(pageData){
        console.log('page destroy~')
        removeOldPage(pageData);
      }
    }
  }
};