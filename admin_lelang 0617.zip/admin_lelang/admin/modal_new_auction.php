

	  <div class="modal fade" id="new" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
                                <h4 class="modal-title custom_align" id="Heading">
									Create New Auction
								</h4>
                            </div>
            
							<div class="modal-body">
                                <div class="form-group">
								        <dt>Auction Name:</dt>
                                    <input class="form-control " type="text" placeholder="Auction Name"></div>
<!--                            <div class="form-group">
                                    <input class="form-control " type="text" placeholder="Hashtags, e.g: #gundam; #hottoys; #dragonball"></div> -->

<div id="oneline-searchbox" class="oneline-searchbox " data-selenium="searchBox">

 <div class=row>
    <dl class="form-group  col-md-6 ">
        <dt>Start Date:</dt>
        <dd>

            <input id=startDate class="form-control oneline-checkin checkin-input date-input hasDatepicker " data-id=range data-date="2017-03-26" type="text">
            <i class="icon icon-calendar"></i>
        </dd>
    </dl>
    <dl class="form-group col-md-6 ">
        <dt>End Date:</dt>
        <dd>
            
            <input id=endDate class="form-control oneline-checkout checkout-input date-input hasDatepicker flatpickr" disabled style=background-color:#f0f0f0 data-date="2017-03-27" type="text">
            <i class="icon icon-calendar"></i>
        </dd>
    </dl>
  </div>

</div>								


<div class=row>
	<div class="col-md-6">
		<dt>at: </dt>
		<div class="form-group ">
			<div class="form-inline">
				<input type="text" class="form-control" id="timeStart" value="" data-default="20:48">
<!-- 				<button class="btn btn-info" type="button" id="button-a">Pick your time</button> -->

			</div>
		</div>
	</div>

	<div class="col-md-6">
		<dt>at: </dt>
		<div class="form-group ">
			<div class="form-inline">
				<input type="text" class="form-control" id="timeEnd" value="" data-default="20:48">
<!-- 				<button class="btn btn-info" type="button" id="button-a">Pick your time</button> -->

			</div>
		</div>
	</div>

</div>

<br>
<!-- 
								<div class="form-group">
								<dt>Auction rules, or additional informations:</dt>
                                    <textarea rows="2" class="form-control" placeholder="Auction explanation and description ..."></textarea>
                                </div>
 -->

								<div class=form-group>
								      <input type="file" name="files[]" id="filer_input" multiple="multiple">
									  
									  <div class=error style=margin-left:20.5%;margin-top:-14px>*) max file size 2MB.</div>
								</div>

                            </div>
                            <div class="modal-footer ">
                                <button type="button" class="btn btn-info" data-dismiss="modal">
                                    <span class="glyphicon glyphicon-ok-sign"></span>
                                    Cancel
                                </button>
                            </div>
                        </div>
		<!-- /.modal-content --> </div>
	  <!-- /.modal-dialog --> </div>


