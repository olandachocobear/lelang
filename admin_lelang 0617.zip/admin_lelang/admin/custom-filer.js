
// File Upload Controls..

$(document).ready(function() {
	
	// DECLARE VAR for number of Files uploaded...
	var number_of_files=0;


	// DECLARE FILER OPTIONS..

	// Previously, item :
	/*
		<li class="jFiler-item" style="width:49%">\
						<div class="jFiler-item-container">\
							<div class="jFiler-item-inner">\
								<div class="jFiler-item-thumb">\
									<div class="jFiler-item-status"></div>\
									<div class="jFiler-item-thumb-overlay">\
										<div class="jFiler-item-info">\
											<div style="display:table-cell;vertical-align: middle;">\
												<span class="jFiler-item-title"><b title="{{fi-name}}">{{fi-name}}</b></span>\
												<span class="jFiler-item-others">{{fi-size2}}</span>\
											</div>\
										</div>\
									</div>\
									{{fi-image}}\
								</div>\
								<div class="jFiler-item-assets jFiler-row">\
									<ul class="list-inline pull-left">\
										<li>{{fi-progressBar}}</li>\
									</ul>\
									<ul class="list-inline pull-right">\
										<li><a class="icon-jfi-trash jFiler-item-trash-action"></a></li>\
									</ul>\
								</div>\
							</div>\
						</div>\
					</li>
	*/

	filer_default_opts = {
		changeInput2: '<div class="jFiler-input-dragDrop"><div class="jFiler-input-inner"><div class="jFiler-input-icon"><i class="icon-jfi-cloud-up-o"></i></div><div class="jFiler-input-text"><h3>Drag&Drop files here</h3> <span style="display:inline-block; margin: 15px 0">or</span></div><a class="jFiler-input-choose-btn btn-custom blue-light">Browse Files</a></div></div>',
		templates: {
			box: '<ul class="jFiler-items-list jFiler-items-grid"></ul>',
			item: '				<li class="jFiler-item" style="width:49%">\
						<div class="jFiler-item-container">\
								<div class="jFiler-item-thumb">\
									{{fi-image}}\
								</div>\
								<div class="jFiler-item-assets jFiler-row">\
									<ul class="list-inline pull-left">\
										<li>{{fi-progressBar}}</li>\
									</ul>\
									<ul class="list-inline pull-right">\
										<li><a class="icon-jfi-trash jFiler-item-trash-action"></a></li>\
									</ul>\
								</div>\
						</div>\
					</li>',
			itemAppend: '<li class="jFiler-item" style="width:49%">\
							<div class="jFiler-item-container">\
								<div class="jFiler-item-inner">\
									<div class="jFiler-item-thumb">\
										<div class="jFiler-item-status"></div>\
										<div class="jFiler-item-thumb-overlay">\
											<div class="jFiler-item-info">\
												<div style="display:table-cell;vertical-align: middle;">\
													<span class="jFiler-item-title"><b title="{{fi-name}}">{{fi-name}}</b></span>\
													<span class="jFiler-item-others">{{fi-size2}}</span>\
												</div>\
											</div>\
										</div>\
										{{fi-image}}\
									</div>\
									<div class="jFiler-item-assets jFiler-row">\
										<ul class="list-inline pull-left">\
											<li><span class="jFiler-item-others">{{fi-icon}}</span></li>\
										</ul>\
										<ul class="list-inline pull-right">\
											<li><a class="icon-jfi-trash jFiler-item-trash-action"></a></li>\
										</ul>\
									</div>\
								</div>\
							</div>\
						</li>',
			progressBar: '<div class="bar"></div>',
			itemAppendToEnd: false,
			removeConfirmation: true,
			_selectors: {
				list: '.jFiler-items-list',
				item: '.jFiler-item',
				progressBar: '.bar',
				remove: '.jFiler-item-trash-action'
			}
		},
		dragDrop: {    dragEnter: null, //A function that is fired when a dragged element enters the input. {Function}
    dragLeave: null, //A function that is fired when a dragged element leaves the input. {Function}
    drop: null, //A function that is fired when a dragged element is dropped on a valid drop target. {Function}
    dragContainer: null //Drag container {String}
	},
		uploadFile: {
			url: "./upload-items.php",
			data: {},
			type: 'POST',
			enctype: 'multipart/form-data',
			beforeSend: function(el){

				number_of_files++;
				console.log(number_of_files);
			},
			success: function(data, el){
				
				var parent = el.find(".jFiler-jProgressBar").parent();
								
				el.find(".jFiler-jProgressBar").fadeOut("slow", function(){
					$("<div class=\"jFiler-item-others text-success\"><i class=\"icon-jfi-check-circle\"></i> Success</div>").hide().appendTo(parent).fadeIn("slow");
				});


				//updating Database with whole pic and thumbnail pic...
					var img = el.find(".jFiler-item-thumb-image")
					setTimeout(function(){
						console.log($(img).find('img').attr("src"));
					}, 1000);

				console.log(data);
				
				number_of_files--;
				console.log('Done - ' + number_of_files + ' left')
				
				if (number_of_files==0)
				{
					alert("Done!");
					
				}
			},
			error: function(el){
				var parent = el.find(".jFiler-jProgressBar").parent();
				el.find(".jFiler-jProgressBar").fadeOut("slow", function(){
					$("<div class=\"jFiler-item-others text-error\"><i class=\"icon-jfi-minus-circle\"></i> Error</div>").hide().appendTo(parent).fadeIn("slow");
				});
			},
			statusCode: null,
			onProgress: null,
			onComplete: null
		}
	};
		 
	// FILER INITIATION..

	$('#filer_input').filer({
        changeInput: filer_default_opts.changeInput2,
        showThumbs: true,
        theme: "dragdropbox",

        templates: filer_default_opts.templates,
        dragDrop: filer_default_opts.dragDrop,
        uploadFile: filer_default_opts.uploadFile
	});       

});
	