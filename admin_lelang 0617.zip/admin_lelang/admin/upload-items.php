<?php
    include('../assets/vendors/jQuery.filer/php/class.uploader.php');
	
    // initialize the FileUploader
    $FileUploader = new Uploader ();
	
    // call to upload the files
    $upload = $FileUploader->upload($_FILES['files'],array(

		// Options will go here
			'limit' => 20,
			'uploadDir' => './uploads/',
    ));
	
    if($upload['isSuccess']) {
        // get the uploaded files
        $files = $upload['data'];
		
		//json_encode($files);
		echo $files['metas'][0]['name'];
    }
	else
		echo $upload['hasWarnings'] . " - " . $upload['hasErrors'];

    if($upload['hasWarnings']) {
        // get the warnings
        $warnings = $upload['warnings'];
    };

?>