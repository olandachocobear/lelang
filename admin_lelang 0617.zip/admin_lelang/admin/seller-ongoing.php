<!DOCTYPE html>
<html>

<!-- Mirrored from chandraadmin.com/admin/form_editors by HTTrack Website Copier/3.x [XR&CO'2010], Wed, 08 Mar 2017 05:52:01 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="UTF-8">
    <title>
        Form Editors             | Chandra Admin Template
        

    </title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
    <!-- global css -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <link href="../assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="../assets/css/custom_css/chandra.css" rel="stylesheet" type="text/css"/>
    <link href="../assets/css/custom_css/metisMenu.css"  rel="stylesheet" type="text/css"/>
    <link href="../assets/css/custom_css/panel.css" rel="stylesheet" type="text/css" />
    <!-- end of global css -->
    <!--page level css-->
        <link href="../assets/vendors/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
    <link href="../assets/vendors/summernote/summernote.css" rel="stylesheet" media="screen" type="text/css" >
	<link href="../assets/vendors/jquery.filer/css/jquery.filer.css" type="text/css" rel="stylesheet" />
<link href="../assets/vendors/jquery.filer/css/themes/jquery.filer-dragdropbox-theme.css" type="text/css" rel="stylesheet" />
<!-- <link href="./datepicker.css" type="text/css" rel="stylesheet" /> -->
<!-- <link href="./datepicker2.css" type="text/css" rel="stylesheet" /> -->

<link rel="stylesheet" href="../assets/vendors/flatpickr/flatpickr.css">

<link href="../assets/vendors/clockpicker/bootstrap-clockpicker.css" rel="stylesheet" type="text/css"/>

        <!--end of page level css-->
</head>
<body class="skin-chandra">
    <!-- header logo: style can be found in header-->
	<?php include("header.php");?>

	<div class="wrapper row-offcanvas row-offcanvas-left">
        
		<!--  Menu  -->
		<?php include("menu.php");?>

        <aside class="right-side right-padding">

            <!-- Notifications -->
            
            <!-- Content -->
                <section class="content-header">
                    <!--section starts-->
                    <h1>Ongoing Auctions</h1>
					<br>
                </section>
                <!--section ends-->
                <section class="content">
                    <!--main content-->
                    <!-- /.box -->
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <h3 class="panel-title">
                                        <i class="fa fa-fw fa-file-text-o"></i>
                                        List of Lelang Yang Sedang Aktif
                                    </h3>
                                    <span class="pull-right">
                                        <i class="fa fa-fw fa-chevron-up clickable"></i>
                                    </span>
                                </div>

                                <div class="panel-body">

									<table id="myTable" class="table table-sm table-bordered table-hover table-striped" width="97%" cellspacing="0">
									<div class="dataTables_length" id="myTable_length" style=float:right>
										<label id=Sync_date>Last Items Added: 27 Mar 2017 18:30</label>
									</div>

									<div class="dataTables_filter" id="myTable_filter">
										<button id=sendBtn class='btn btn-gray' data-title="New" data-toggle="modal" data-target="#new" data-placement="top" >
											<i class="fa fa-fw fa-plus"></i> New</button>
										<!-- <button id=countBtn class='btn btn-gray' style=margin-left:-40px;display:inline-block>
											<i class="material-icons md-24" >calc</i> Count
										</button> -->
									</div>
											<thead>
												<tr>
													<th>ID #</th>
													<th>Auction Name</th>
													<th>Auctioneer</th>
													<th>Items Listed</th>
													<th>Hashtags</th>
													<th>Start Date</th>
													<th>End Date</th>
													<th>Action</th>
												</tr>
											</thead>
										</table>
                                </div>

                            </div>
                        </div>
                    </div>

<!-- 					
					<div class="row">
					                        <div class="col-lg-12">
					                            <div class="panel panel-primary">
					                                <div class="panel-heading">
					                                    <h3 class="panel-title">
					                                        <i class="fa fa-fw fa-file-text-o"></i>
					                                        Summernote Editor
					                                    </h3>
					                                    <span class="pull-right">
					                                        <i class="fa fa-fw fa-times removepanel clickable"></i>
					                                        <i class="fa fa-fw fa-chevron-up clickable"></i>
					                                    </span>
					                                </div>
					                                <div class="panel-body">
					                                    <form>
					                                        <textarea class="summernote edi-css" placeholder="Place some text here"></textarea>
					                                    </form>
					                                </div>
					                            </div>
					                        </div>
					                    </div>
					                    <div class="row">
					                        <div class="col-lg-12">
					                            <div class="panel panel-primary">
					                                <div class="panel-heading">
					                                    <h3 class="panel-title">
					                                        <i class="fa fa-fw fa-file-text-o"></i>
					                                        CKEditor
					                                    </h3>
					                                    <span class="pull-right">
					                                        <i class="fa fa-fw fa-times removepanel clickable"></i>
					                                        <i class="fa fa-fw fa-chevron-up clickable"></i>
					                                    </span>
					                                </div>
					                                <div class="bootstrap-admin-panel-content">
					                                    <textarea id="ckeditor_full"></textarea>
					                                </div>
					                            </div>
					                        </div>
					                    </div>
					 -->  
		
					<!-- MODAL NEW AUCTION -->
					<?php include("modal_new_auction.php");?>

					 <div class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <h3 class="panel-title">
                                        <i class="fa fa-fw fa-file-text-o"></i>
                                        Tutorial Penggunaan
                                    </h3>
                                    <span class="pull-right">
                                        <i class="fa fa-fw fa-times removepanel clickable"></i>
                                        <i class="fa fa-fw fa-chevron-up clickable"></i>
                                    </span>
                                </div>
                                <div class="bootstrap-admin-panel-content">
                                    <div contenteditable="true" class="right-padding text-info">
                                        <p>
                                            Lorem ipsum dolor sit amet enim. Etiam ullamcorper. Suspendisse a pellentesque dui, non felis. Maecenas malesuada elit lectus felis, malesuada ultricies.
                                        </p>
                                        <p>
                                            Curabitur et ligula. Ut molestie a, ultricies porta urna. Vestibulum commodo volutpat a, convallis ac, laoreet enim. Phasellus fermentum in, dolor. Pellentesque facilisis. Nulla imperdiet sit amet magna. Vestibulum dapibus, mauris nec malesuada fames ac.
                                        </p>
                                        <p>
                                            Fusce vitae porttitor a, euismod convallis nisl, blandit risus tortor, pretium. Vehicula vitae, imperdiet vel, ornare enim vel sodales rutrum
                                        </p>
                                    </div>
                                    <div contenteditable="true" class="right-padding text-danger">
                                        <p>
                                            Pellentesque nunc. Donec suscipit erat. Pellentesque habitant morbi tristique ullamcorper.
                                        </p>
                                        <p>Mauris mattis feugiat lectus nec mauris. Nullam vitae ante.</p>

                                        <p>
                                            In hac habitasse platea dictumst. Praesent wisi accumsan sit amet nibh. Maecenas orci luctus a, lacinia quam sem, posuere commodo, odio condimentum tempor, pede semper risus. Suspendisse pede. In hac habitasse platea dictumst. Nam sed laoreet sit amet erat. Integer.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </section>
                <!-- /.content --> 
            <!-- /.content -->
        </aside>
        <!-- /.right-side -->
    </div>
    <!-- /.right-side -->
    <!-- ./wrapper -->
    <!-- global js -->
    <script src="../assets/js/jquery-1.11.1.min.js" type="text/javascript"></script>
        <script src="../assets/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="../assets/js/custom_js/app.js" type="text/javascript"></script>
    <script src="../assets/js/custom_js/metisMenu.js" type="text/javascript"></script>
    <script src="../assets/js/custom_js/rightside_bar.js" type="text/javascript"></script>
    <!-- end of page level js -->
    <!-- begin page level js -->
            <!-- Bootstrap WYSIHTML5 -->
        <script src="../assets/vendors/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
        <script src="../assets/vendors/ckeditor/ckeditor.js" type="text/javascript" ></script>
        <script src="../assets/vendors/ckeditor/adapters/jquery.js" type="text/javascript" ></script>
        <script src="../assets/vendors/bootstrap-wysihtml5/wysihtml5.js" type="text/javascript" ></script>
        <script src="../assets/vendors/summernote/summernote.min.js" type="text/javascript" ></script>
        <script src="../assets/js/custom_js/form_editors.js" type="text/javascript"></script>

	<script src="../assets/vendors/datatables/jquery.dataTables.js"></script>
	<script src="../assets/vendors/datatables/dataTables.bootstrap.js"></script>

<script src="../assets/vendors/jquery.filer/js/jquery.filer.min.js"></script>
<script src='./custom-filer.js'></script>

<script src="../assets/vendors/flatpickr/flatpickr.js"></script>

<script src="../assets/vendors/clockpicker/bootstrap-clockpicker.min.js" type="text/javascript"></script>

            <!-- end page level js -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','../../www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-55155405-1', 'auto');
  ga('send', 'pageview');


// Data tables...
$(document).ready(function(){
    var table = $('#myTable').DataTable({
		dom: 'tB<"bottom"p>i',
		ajax: 'datatables-source.json',
		searching: true,
		lengthChange: false,
            "scrollY": "200px",
            "paging": false,
            "bFilter": false,
		pageLength: 10,
		columnDefs: [ 
			/*{
				orderable: false,
				className: 'select-checkbox',
				targets:   0
	        }, */
			{
				orderable: false,
				visible: true,
				targets:   0
	        }, 
			{
				orderable: true,
				visible: true,
				targets:   6
	        },
			{
				orderable: false,
				visible: true,
				targets:   5
	        },
			{
				orderable: false,
				visible: true,
				targets:   5
	        },
			{
				orderable: false,
				visible: true,
				targets:   5
	        },
			{
				orderable: false,
				visible: true,
				targets:   5
	        },
			{
				orderable: false,
				visible: true,
				targets:   5
	        }
		]
        /* 
		// IF I NEED THE CHECKBOX CAPABILITY..
		select: {
            style: 'multi',
            selector: 'td:first-child, td:nth-child(2), td:nth-child(3), td:nth-child(4)'
        }, 
		
		buttons: [
					{
						text: 'Select all',
						action: function () {
							table.rows().select();
						}
					},
					{
						text: 'Select none',
						action: function () {
							table.rows().deselect();
						}
					}
				]
		*/
	});


	//flatpicker
	//flatpickr(".flatpickr");
	flatpickr("#startDate", {
		mode: "range", 
		onChange: function(selectedDates, dateStr, instance) {
			console.log( "pickr left-pos: " + $(".flatpickr-calendar").css('left') + "px")
			console.log( "endDate left-pos: " + $("#endDate").offset().left + "px")

			console.log( "pickr left-pos: " + $(".flatpickr-calendar").css('top') + "px")
			console.log( "endDate left-pos: " + $("#endDate").offset().top + "px")

			$(".flatpickr-calendar").css('left', $("#endDate").offset().left);
			$(".flatpickr-calendar").css('top', $("#endDate").offset().top + 40);

			if (dateStr.indexOf ('to') > -1)
			{	
				var dates = dateStr.split('to');
				
				$("#startDate").val(dates[0])
				$("#endDate").val(dates[1])
	
			}
		}
	});

	// clockPicker
	$('#timeStart').clockpicker({
		autoclose: true
	});

	$('#timeEnd').clockpicker({
		autoclose: true
	});

});

</script>
</body>

<!-- Mirrored from chandraadmin.com/admin/form_editors by HTTrack Website Copier/3.x [XR&CO'2010], Wed, 08 Mar 2017 05:52:07 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
</html>