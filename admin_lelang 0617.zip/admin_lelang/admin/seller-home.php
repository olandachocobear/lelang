<!DOCTYPE html>
<html>

<!-- Mirrored from chandraadmin.com/admin/form_editors by HTTrack Website Copier/3.x [XR&CO'2010], Wed, 08 Mar 2017 05:52:01 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="UTF-8">
    <title>
        Form Editors             | Chandra Admin Template
        

    </title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
    <!-- global css -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <link href="../assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="../assets/css/custom_css/chandra.css" rel="stylesheet" type="text/css"/>
    <link href="../assets/css/custom_css/metisMenu.css"  rel="stylesheet" type="text/css"/>
    <link href="../assets/css/custom_css/panel.css" rel="stylesheet" type="text/css" />
    <!-- end of global css -->
    <!--page level css-->
        <link href="../assets/vendors/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
    <link href="../assets/vendors/summernote/summernote.css" rel="stylesheet" media="screen" type="text/css" >
        <!--end of page level css-->
</head>
<body class="skin-chandra">
    <!-- header logo: style can be found in header-->
	<?php include("header.php");?>

	<div class="wrapper row-offcanvas row-offcanvas-left">
        
		<!--  Menu  -->
		<?php include("menu.php");?>

        <aside class="right-side right-padding">

            <!-- Notifications -->
            
            <!-- Content -->
                <section class="content-header">
                    <!--section starts-->
                    <h1>Dashboard</h1>
                    <ol class="breadcrumb">
                        <li>
                            <a href="../admin.html">
                                <i class="fa fa-fw fa-home"></i>
                                Dashboard
                            </a>
                        </li>
                        <li>
                            <a href="#">Forms</a>
                        </li>
                        <li>
                            <a href="form_editors.html">Form Editors</a>
                        </li>
                    </ol>
                </section>
                <!--section ends-->
                <section class="content">
                    <!--main content-->
                    <!-- /.box -->
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <h3 class="panel-title">
                                        <i class="fa fa-fw fa-file-text-o"></i>
                                        Bootstrap WYSIHTML5
                                    </h3>
                                    <span class="pull-right">
                                        <i class="fa fa-fw fa-times removepanel clickable"></i>
                                        <i class="fa fa-fw fa-chevron-up clickable"></i>
                                    </span>
                                </div>

                                <div class="panel-body">
                                    <form>
                                        <textarea class="textarea edi-css" placeholder="Place some text here"></textarea>
                                    </form>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <h3 class="panel-title">
                                        <i class="fa fa-fw fa-file-text-o"></i>
                                        Summernote Editor
                                    </h3>
                                    <span class="pull-right">
                                        <i class="fa fa-fw fa-times removepanel clickable"></i>
                                        <i class="fa fa-fw fa-chevron-up clickable"></i>
                                    </span>
                                </div>
                                <div class="panel-body">
                                    <form>
                                        <textarea class="summernote edi-css" placeholder="Place some text here"></textarea>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <h3 class="panel-title">
                                        <i class="fa fa-fw fa-file-text-o"></i>
                                        CKEditor
                                    </h3>
                                    <span class="pull-right">
                                        <i class="fa fa-fw fa-times removepanel clickable"></i>
                                        <i class="fa fa-fw fa-chevron-up clickable"></i>
                                    </span>
                                </div>
                                <div class="bootstrap-admin-panel-content">
                                    <textarea id="ckeditor_full"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <h3 class="panel-title">
                                        <i class="fa fa-fw fa-file-text-o"></i>
                                        Inline Editor
                                    </h3>
                                    <span class="pull-right">
                                        <i class="fa fa-fw fa-times removepanel clickable"></i>
                                        <i class="fa fa-fw fa-chevron-up clickable"></i>
                                    </span>
                                </div>
                                <div class="bootstrap-admin-panel-content">
                                    <div contenteditable="true" class="right-padding text-info">
                                        <p>
                                            Lorem ipsum dolor sit amet enim. Etiam ullamcorper. Suspendisse a pellentesque dui, non felis. Maecenas malesuada elit lectus felis, malesuada ultricies.
                                        </p>
                                        <p>
                                            Curabitur et ligula. Ut molestie a, ultricies porta urna. Vestibulum commodo volutpat a, convallis ac, laoreet enim. Phasellus fermentum in, dolor. Pellentesque facilisis. Nulla imperdiet sit amet magna. Vestibulum dapibus, mauris nec malesuada fames ac.
                                        </p>
                                        <p>
                                            Fusce vitae porttitor a, euismod convallis nisl, blandit risus tortor, pretium. Vehicula vitae, imperdiet vel, ornare enim vel sodales rutrum
                                        </p>
                                    </div>
                                    <div contenteditable="true" class="right-padding text-danger">
                                        <p>
                                            Pellentesque nunc. Donec suscipit erat. Pellentesque habitant morbi tristique ullamcorper.
                                        </p>
                                        <p>Mauris mattis feugiat lectus nec mauris. Nullam vitae ante.</p>

                                        <p>
                                            In hac habitasse platea dictumst. Praesent wisi accumsan sit amet nibh. Maecenas orci luctus a, lacinia quam sem, posuere commodo, odio condimentum tempor, pede semper risus. Suspendisse pede. In hac habitasse platea dictumst. Nam sed laoreet sit amet erat. Integer.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </section>
                <!-- /.content --> 
            <!-- /.content -->
        </aside>
        <!-- /.right-side -->
    </div>
    <!-- /.right-side -->
    <!-- ./wrapper -->
    <!-- global js -->
    <script src="../assets/js/jquery-1.11.1.min.js" type="text/javascript"></script>
        <script src="../assets/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="../assets/js/custom_js/app.js" type="text/javascript"></script>
    <script src="../assets/js/custom_js/metisMenu.js" type="text/javascript"></script>
    <script src="../assets/js/custom_js/rightside_bar.js" type="text/javascript"></script>
    <!-- end of page level js -->
    <!-- begin page level js -->
            <!-- Bootstrap WYSIHTML5 -->
        <script src="../assets/vendors/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
        <script src="../assets/vendors/ckeditor/ckeditor.js" type="text/javascript" ></script>
        <script src="../assets/vendors/ckeditor/adapters/jquery.js" type="text/javascript" ></script>
        <script src="../assets/vendors/bootstrap-wysihtml5/wysihtml5.js" type="text/javascript" ></script>
        <script src="../assets/vendors/summernote/summernote.min.js" type="text/javascript" ></script>
        <script src="../assets/js/custom_js/form_editors.js" type="text/javascript"></script>
            <!-- end page level js -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','../../www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-55155405-1', 'auto');
  ga('send', 'pageview');

</script>    
</body>

<!-- Mirrored from chandraadmin.com/admin/form_editors by HTTrack Website Copier/3.x [XR&CO'2010], Wed, 08 Mar 2017 05:52:07 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
</html>