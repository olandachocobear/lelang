<!-- Left side column. contains the logo and sidebar -->
        <aside class="left-side sidebar-offcanvas">
            <!-- sidebar: style can be found in sidebar-->
            <section class="sidebar">
                <div id="menu" role="navigation">
                    <div class="nav_profile">
                        <div class="media profile-left">
                            <a class="pull-left profile-thumb" href="#">
                                                                    <img src="../uploads/users/up2tGbIr7a.jpg" alt="img" class="img-circle img-bor"/>
                                                            </a>
                            <div class="content-profile">
                                <h4 class="media-heading">
                                    Test ZDN1 Admin
                                </h4>
								<h5 style=color:silver;font-style:oblique>
									Fresh Oxeneer
								</h5>
                                <ul class="icon-list">
                                    <li>
                                        <a href="login.html">
                                            <i class="fa fa-fw fa-user"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="lockscreen.html">
                                            <i class="fa fa-fw fa-lock"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i class="fa fa-fw fa-gear"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="login.html">
                                            <i class="fa fa-fw fa-sign-out"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <ul class="navigation">
                        <li >
                            <a href="../admin.html">
                                <i class="menu-icon fa fa-fw fa-home"></i>
                                <span class="mm-text ">Home</span>
                            </a>
                        </li>
                        <li class="menu-dropdown  active">
                        <a href="#">
                            <i class="menu-icon fa fa-fw fa-paw"></i>
                            <span class="title">Auctions</span>
                            <span class="fa arrow"></span>
                        </a>
                        <ul class="sub-menu">
                            <li >
                                <a href="seller-ongoing.php">
                                    <i class="fa fa-fw fa-fire"></i>
                                    Ongoing Auctions
                                </a>
                            </li>
                            <li >
                                <a href="seller-finished.php">
                                    <i class="fa fa-fw fa-flag"></i>
                                    Finished Auctions
                                </a>
                            </li>
                            <li >
                                <a href="seller-draft.php">
                                    <i class="fa fa-fw fa-pencil-square-o"></i>
                                    Draft
                                </a>
                            </li>
                        </ul>
                    </li>
                        <li class="menu-dropdown ">
                            <a href="#">
                                <i class="menu-icon fa fa-files-o"></i>
                                <span>Invoices</span>
                                <span class="fa arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-area-chart"></i>
                                        Paid
                                    </a>
                                </li>
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-line-chart"></i>
                                        Open
                                    </a>
                                </li>
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-line-chart"></i>
                                        Closed
                                    </a>
                                </li>
                            </ul>
                        </li>
						<li>
                                    <a href="login.html">
                                        <i class="menu-icon fa fa-fw fa-user"></i>
                                        <span class="mm-text ">Settings</span>
                                    </a>
                        </li>
<!-- 
						<li class="menu-dropdown ">
                            <a href="#">
                                <i class="menu-icon fa fa-check-square"></i>
                                <span>Forms</span>
                                <span class="fa arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li >
                                    <a href="form_elements.html">
                                        <i class="fa fa-fw fa-fire"></i>
                                        Form Elements
                                    </a>
                                </li>
                                <li class=active>
                                    <a href="form_editors.html">
                                        <i class="fa fa-fw fa-file-text-o"></i>
                                        Form Editors
                                    </a>
                                </li>
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-warning"></i>
                                        Form Validations
                                    </a>
                                </li>
                                <li >
                                    <a href="form_layouts.html">
                                        <i class="fa fa-fw fa-fire"></i>
                                        Form Layouts
                                    </a>
                                </li>
                                <li >
                                    <a href="form_wizards.html">
                                        <i class="fa fa-fw fa-cog"></i>
                                        Form Wizards
                                    </a>
                                </li>
                                <li >
                                    <a href="x-editable.html">
                                        <i class="fa fa-fw fa-eyedropper"></i>
                                        X-editable
                                    </a>
                                </li>
                            </ul>
                        </li>

                        <li class="menu-dropdown ">
                            <a href="#">
                                <i class="menu-icon fa fa-desktop"></i>
                                <span>
                                    UI Features
                                </span>
                                <span class="fa arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li >
                                    <a href="general_components.html">
                                        <i class="fa fa-fw fa-plug"></i>
                                        General Components
                                    </a>
                                </li>
                                <li >
                                    <a href="pickers.html">
                                        <i class="fa fa-fw fa-paint-brush"></i>
                                        Pickers
                                    </a>
                                </li>
                                <li >
                                    <a href="buttons.html">
                                        <i class="fa fa-fw fa-delicious"></i>
                                        Buttons
                                    </a>
                                </li>
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-gift"></i>
                                        Panels
                                    </a>
                                </li>
                                <li >
                                    <a href="tabs_accordions.html">
                                        <i class="fa fa-fw fa-copy"></i>
                                        Tabs &amp; Accordions
                                    </a>
                                </li>
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-font"></i>
                                        Font Icons
                                    </a>
                                </li>
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-columns"></i>
                                        Grid Layout
                                    </a>
                                </li>
                                <li >
                                    <a href="tags_input.html">
                                        <i class="fa fa-fw fa-tag"></i>
                                        Tags Input
                                    </a>
                                </li>
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-navicon"></i>
                                        Nestable List
                                    </a>
                                </li>
                                <li >
                                    <a href="toastr_notifications.html">
                                        <i class="fa fa-fw fa-desktop"></i>
                                        Toastr Notifications
                                    </a>
                                </li>
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-rocket"></i>
                                        Session Timeout
                                    </a>
                                </li>
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-random"></i>
                                        Draggable Portlets
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="menu-dropdown ">
                            <a href="#">
                                <i class="menu-icon fa fa-briefcase"></i>
                                <span>
                                    UI Components
                                </span>
                                <span class="fa arrow"></span>
                            </a>
                            <ul class="sub-menu">

                                <li >
                                    <a href="timeline.html">
                                        <i class="fa fa-fw fa-clock-o"></i>
                                        Timeline
                                    </a>
                                </li>
                                <li >
                                    <a href="transitions.html">
                                        <i class="fa fa-fw fa-star-half-empty"></i>
                                        Transitions
                                    </a>
                                </li>
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-sun-o"></i>
                                        Circle Sliders
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="menu-dropdown ">
                            <a href="#">
                                <i class="menu-icon fa fa-table"></i>
                                <span>DataTables</span>
                                <span class="fa arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-tasks"></i>
                                        Simple tables
                                    </a>
                                </li>
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-database"></i>
                                        Data Tables
                                    </a>
                                </li>
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-table"></i>
                                        Advanced Tables
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li >
                            <a href="calendar.html">
                                <i class=" menu-icon fa fa-fw fa-calendar"></i>
                                <span>Calendar</span>
                                <small class="badge">4</small>
                            </a>
                        </li>
                        <li class="menu-dropdown ">
                            <a href="#">
                               <i class="fa fa-fw fa-envelope"></i> 
                                <span>Email</span>
                                <span class="fa arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-inbox"></i>
                                     Mail box
                                    </a>
                                </li>
                                <li >
                                    <a href="login.html">
                                       <i class="fa fa-pencil"></i>
                                        Compose Message
                                    </a>
                                </li>
                                 <li >
                                    <a href="login.html">
                                      <i class="fa fa-eye"></i>
                                        Single Mail
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li >
                            <a href="login.html">
                               <i class="fa fa-fw fa-list-ul"></i>
                                <span>Tasks</span>
                                <small class="badge">10</small>
                            </a>
                        </li>
                        <li class="menu-dropdown ">
                            <a href="#">
                                <i class="menu-icon fa fa-fw fa-photo"></i>
                                <span>Gallery</span>
                                <span class="fa arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-file-image-o"></i>
                                         Gallery
                                    </a>
                                </li>
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-file-image-o"></i>
                                        Masonry Gallery
                                    </a>
                                </li>
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-cloud-upload"></i>
                                        Multiple File Upload
                                    </a>
                                </li>
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-search"></i>
                                        Image Magnifier
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="menu-dropdown ">
                            <a href="#">
                                <i class="menu-icon  fa fa-fw fa-paw"></i>
                                <span>Users</span>
                                <span class="fa arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-users"></i>
                                        Users
                                    </a>
                                </li>
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-user"></i>
                                        Add New User
                                    </a>
                                </li>
                                <li >
                                    <a href="users/1.html">
                                        <i class="fa fa-fw fa-user"></i>
                                        User Profile
                                    </a>
                                </li>

                            </ul>
                        </li>
                        <li class="menu-dropdown ">
                            <a href="#">
                                <i class="menu-icon  fa fa-fw fa-users"></i>
                                <span>Groups</span>
                                <span class="fa arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-users"></i>
                                        Groups
                                    </a>
                                </li>
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-user"></i>
                                        Add New Group
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="menu-dropdown ">
                            <a href="#">
                                <i class="menu-icon fa fa-map-marker"></i>
                                <span>Maps</span>
                                <span class="fa arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-globe"></i>
                                        Google Maps
                                    </a>
                                </li>
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-map-marker"></i>
                                        Vector Maps
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="menu-dropdown ">
                            <a href="#">
                                <i class="menu-icon fa fa-files-o"></i>
                                <span>Pages</span>
                                <span class="fa arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-question"></i>
                                        FAQ
                                    </a>
                                </li>
                                <li>
                                    <a href="lockscreen.html">
                                        <i class="fa fa-fw fa-lock"></i>
                                        Lockscreen
                                    </a>
                                </li>
                                <li>
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-newspaper-o"></i>
                                        Invoice
                                    </a>
                                </li>
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-file-o"></i>
                                        Blank
                                    </a>
                                </li>
                                <li>
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-sign-in"></i>
                                        Login
                                    </a>
                                </li>
                                <li>
                                    <a href="register.html">
                                        <i class="fa fa-fw fa-sign-in"></i>
                                        Register
                                    </a>
                                </li>
                                <li>
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-unlink"></i>
                                        404 Error
                                    </a>
                                </li>
                                <li>
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-frown-o"></i>
                                        500 Error
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="menu-dropdown ">
                            <a href="#">
                                <i class="menu-icon fa fa-th"></i>
                                <span>Layouts</span>
                                <span class="fa arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-th-large"></i>
                                        Boxed Layout
                                    </a>
                                </li>
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-th-list"></i>
                                        Fixed Header
                                    </a>
                                </li>
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-th"></i>
                                        Boxed &amp; Fixed Header
                                    </a>
                                </li>
                                <li >
                                    <a href="login.html">
                                        <i class="fa fa-fw fa-indent"></i>
                                        Fixed Header &amp; Menu
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="menu-dropdown">
                            <a href="#">
                                <i class="menu-icon fa fa-sitemap"></i>
                                <span>
                                    Menu levels
                                </span>
                                <span class="fa arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li>
                                    <a href="#">
                                        <i class="fa fa-fw fa-sitemap"></i>
                                        Level 1
                                        <span class="fa arrow"></span>
                                    </a>
                                    <ul class="sub-menu sub-submenu">
                                        <li>
                                            <a href="#">
                                                <i class="fa fa-fw fa-sitemap"></i>
                                                Level 2
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <i class="fa fa-fw fa-sitemap"></i>
                                                Level 2
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <i class="fa fa-fw fa-sitemap"></i>
                                                Level 2
                                                <span class="fa arrow"></span>
                                            </a>
                                            <ul class="sub-menu sub-submenu">
                                                <li>
                                                    <a href="#">
                                                        <i class="fa fa-fw fa-sitemap"></i>
                                                        Level 3
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">
                                                        <i class="fa fa-fw fa-sitemap"></i>
                                                        Level 3
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#">
                                                        <i class="fa fa-fw fa-sitemap"></i>
                                                        Level 3
                                                        <span class="fa arrow"></span>
                                                    </a>
                                                    <ul class="sub-menu sub-submenu">
                                                        <li>
                                                            <a href="#">
                                                                <i class="fa fa-fw fa-sitemap"></i>
                                                                Level 4
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a href="#">
                                                                <i class="fa fa-fw fa-sitemap"></i>
                                                                Level 4
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a href="#">
                                                                <i class="fa fa-fw fa-sitemap"></i>
                                                                Level 4
                                                                <span class="fa arrow"></span>
                                                            </a>
                                                            <ul class="sub-menu sub-submenu">
                                                                <li>
                                                                    <a href="#">
                                                                        <i class="fa fa-fw fa-sitemap"></i>
                                                                        Level 5
                                                                    </a>
                                                                </li>
                                                                <li>
                                                                    <a href="#">
                                                                        <i class="fa fa-fw fa-sitemap"></i>
                                                                        Level 5
                                                                    </a>
                                                                </li>
                                                                <li>
                                                                    <a href="#">
                                                                        <i class="fa fa-fw fa-sitemap"></i>
                                                                        Level 5
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </li>
                                                    </ul>
                                                </li>
                                                <li>
                                                    <a href="#">
                                                        <i class="fa fa-fw fa-sitemap"></i>
                                                        Level 4
                                                    </a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <i class="fa fa-fw fa-sitemap"></i>
                                                Level 2
                                                <span class="fa arrow"></span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-fw fa-sitemap"></i>
                                        Level 1
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-fw fa-sitemap"></i>
                                        Level 1
                                        <span class="fa arrow"></span>
                                    </a>
                                    <ul class="sub-menu sub-submenu">
                                        <li>
                                            <a href="#">
                                                <i class="fa fa-fw fa-sitemap"></i>
                                                Level 2
                                                <span class="fa arrow"></span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <i class="fa fa-fw fa-sitemap"></i>
                                                Level 2
                                                <span class="fa arrow"></span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <i class="fa fa-fw fa-sitemap"></i>
                                                Level 2
                                                <span class="fa arrow"></span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                    </ul> -->
                    <!-- / .navigation -->

                </div>
                <!-- menu -->
            </section>
            <!-- /.sidebar -->
        </aside>