<?php
    include('../assets/vendors/jQuery.filer/php/class.fileuploader.php');
	
    // initialize the FileUploader
    $FileUploader = new FileUploader('files', array(
        // Options will go here
    ));
	
    // call to upload the files
    $upload = $FileUploader->upload();
	
    if($upload['isSuccess']) {
        // get the uploaded files
        $files = $upload['files'];
		//var_dump ($files);

		$list = $FileUploader->getFileList();
		var_dump($list);
		
    }
    if($upload['hasWarnings']) {
        // get the warnings
        $warnings = $upload['warnings'];
    };
?>
		