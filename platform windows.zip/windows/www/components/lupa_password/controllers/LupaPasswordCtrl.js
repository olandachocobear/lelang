﻿/**
 * 
 */
angular.module('PruForce.controllers')

    .controller('LupaPasswordCtrl', function ($scope, $translate, $filter, $rootScope, $state, $localStorage, $ionicPopup, SecurityQuestionService, $ionicLoading, VerifyForgetPasswordService) {

        $ionicLoading.hide();
        $scope.initModel = {};
        $scope.listQuestionAll = $rootScope.listQuestions;
        $scope.listSQ = {
            selected1: $rootScope.listQuestions[0].aobdescriptionind,
            selected2: $rootScope.listQuestions[3].aobdescriptionind
        };

        $scope.verifySQSubmit = function () {
            if ($scope.initModel.pruforceId == undefined || $scope.initModel.jawaban1 == undefined || $scope.initModel.jawaban2 == undefined) {
                $rootScope.AlertDialog($filter('translate')('PRU_05'));
            } else {
                $ionicLoading.show();
                VerifyForgetPasswordService.invoke($scope.listSQ.selected1, $scope.initModel.jawaban1, $scope.listSQ.selected2, $scope.initModel.jawaban2, $scope.initModel.pruforceId)
                    .then(function (res) {
                        VerifySecurityQuestionSuccess(res);
                    });
            }
        }

        function VerifySecurityQuestionSuccess(result) {
            $ionicLoading.hide();
            if (result.invocationResult.respCode == 200) {
                $rootScope.agent.pruforceId = $scope.initModel.pruforceId;
                $rootScope.temp.readOnly = true;
                $state.go("new-pass");
            } else {
                $rootScope.AlertDialog($filter('translate')('PRU_35'));
            }

        }

    })