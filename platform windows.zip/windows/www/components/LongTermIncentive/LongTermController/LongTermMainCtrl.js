﻿/**
 * 
 */

angular.module('PruForce.controllers')

.controller("LongTermMainCtrl", function ($scope, IncentiveSummary, IncentiveCurrentBalance) {
	
	AnalyticsLog.logPage("prudential.LongTermIncentive");
	
	$scope.IncentiveSummary = IncentiveSummary;
	$scope.IncentiveCurrentBalance = IncentiveCurrentBalance;
	
	$scope.collapseAccordion = function(e){
	    var self = $(e.toElement);
	    var accordion = self.parents(".list-info-accordion");
	    var accordionBody = accordion.find(".accordion-body");

	    if(accordion.hasClass("collapsed")){
	      accordion.removeClass("collapsed");
	      accordionBody.attr("style", "margin-top: -" + accordionBody.height() + "px;");
	    }
	    else{
	      accordion.addClass("collapsed");
	      accordionBody.css("margin-top", 0);
	    }
	 }
	
});