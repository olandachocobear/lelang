﻿
angular.module('PruForce.controllers')


.controller("ProductListDataCtrl", function($templateCache,$state, $scope, $http, ProductListDetailPolicy,LastUpdateProp) {
	AnalyticsLog.logPage("prudential.Policy.ProductListData");
	getMyProposalLastUpdateSuccess(LastUpdateProp);
	  function getMyProposalLastUpdateSuccess(result)
	  {
		  if (result.invocationResult.isSuccessful){
			  var lastUpdateProp = result.invocationResult.latest; 		
			  var lastUpdate = moment(lastUpdateProp).format('LLLL');
				$scope.lastUpdateProp = lastUpdate;		  
				}
	}

	getDataProductListSuccess(ProductListDetailPolicy);
	function getDataProductListSuccess(result) {
	    if (result.invocationResult.isSuccessful){		    
			var separator_premium = result.invocationResult.premium;
			if(separator_premium!=null){
				$scope.premium = (separator_premium).formatMoney(2, '.', ',');	
			}else{
				$scope.premium="0";
			}
			var riscdate = result.invocationResult.riskCessationDate;
			if(riscdate!=null)
				$scope.riskCessationDate = moment(riscdate).format('LL'); 
			else
				$scope.riskCessationDate = "";
			var pcdate = result.invocationResult.premiumCessationDate;
			if(pcdate !=null)
				$scope.premiumCessationDate = moment(pcdate).format('LL');	
			else
				$scope.premiumCessationDate = "";
    		$scope.productCode = result.invocationResult.productCode; 
    		$scope.lifeAssured = result.invocationResult.lifeAssured;	
			var separator_sumAssured = result.invocationResult.sumAssured;
			if(separator_sumAssured!=null){
				$scope.sumAssured = (separator_sumAssured).formatMoney(2, '.', ',');	
			}else{
				$scope.premium="0";
			}
			
			var singlePremium= result.invocationResult.singlePremium;
    		if(singlePremium==null)singlePremium=0;
   			$scope.singlePremium = (result.invocationResult.singlePremium).formatMoney(2, '.', ',');
			
    		$scope.productName = result.invocationResult.productName;
    		$scope.status = result.invocationResult.status;	
			$scope.premiumStatus = result.invocationResult.premiumStatus;	
			var rcdate = result.invocationResult.riskCommencementDate;
			if(rcdate!=null)
				$scope.riskCommencementDate = moment(rcdate).format('LL');	
			else
				$scope.riskCommencementDate = "";
			var tempSplitProductName = result.invocationResult.productName;
			
			if(tempSplitProductName!=null){
				var splitProductName = (result.invocationResult.productName).split(" ");
				$scope.productNameFirst = (result.invocationResult.productName).substring(0,3);
				$scope.productNameMid = (result.invocationResult.productName).substring(3,splitProductName[0].length);
				$scope.productNameLast = (result.invocationResult.productName).substring(splitProductName[0].length,(result.invocationResult.productName).length);
			}else{
				$scope.productNameFirst = "Detail";
				$scope.productNameMid = "Produk";
				$scope.productNameLast = "";
			}
			
			
			$scope.currencySymbol = result.invocationResult.currencySymbol;
		}

    }

    function getDataProductListFailed(result){
         AppsLog.log("Load Data Failed, Please Check Your Connection");
    }
})