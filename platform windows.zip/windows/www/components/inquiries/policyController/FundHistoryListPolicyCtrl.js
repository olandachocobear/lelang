﻿/**
 * 
 */
angular.module('PruForce.controllers')
    //update persistency
    .controller('FundHistoryListPolicyCtrl', function($scope, $rootScope,$ionicLoading, $http, $stateParams, $interval, $filter, ListFundHistoryPolicy, ListFilterHistoryFund, findPolicyMyPolicyFundHistoryFrontService) {
        AnalyticsLog.logPage("prudential.Policy.FundHistoryListPolicy");
        var sizeFundHistory = 30;
        var pageFundHistory = 1;
        var searchByFundHistory = '';
        var searchValFundHistory = '';
        var searchBy2FundHistory = '';
        var searchVal2FundHistory = '';
        var orderByFundHistory = '';
        var directionFundHistory = 'asc';
        $scope.transaction = [];
        var ListPolicyLapsedListAll = [];
        var ListPolicyLapsedListAllAfterAdd = [];
        $scope.noMoreItemsAvailable = true;
        $scope.numberOfItemsToDisplay = 30;
        var filterListFundHistory = '["T679", "T510", "T676", "T551", "T646", "T512"]';
        var directionHistory = 'asc';

        $scope.policyHolderNames = {
            data: [{
                id: 0,
                name: $filter('translate')('DEFAULT_SORT')
            },
            {
                id: 1,
                name: $filter('translate')('TRANSACTION_DATE_ASC')
            },
            {
                id: 2,
                name: $filter('translate')('TRANSACTION_DATE_DESC')
            },]
        };

        $scope.sortItem = {
            onRequest: $scope.policyHolderNames.data[0]
        };

        $scope.loadMore = function() {
            pageFundHistory += 1;
            $scope.showSpinner = true;
            getDataFromService();
            $scope.noMoreItemsAvailable = false;
            $scope.$broadcast('scroll.infiniteScrollComplete');
        };
        $scope.GoSearching_GoFiltering = function() {
            filterListFundHistory = [];
            $ionicLoading.show();
            ListPolicyLapsedListAll = [];
            sizeFundHistory = 30;
            pageFundHistory = 1;
            searchValFundHistory = ($scope.transaction.searchString==undefined)?"":$scope.transaction.searchString.replace(/['|"|\\]/g, "\\$&");
            searchByFundHistory = '';

            for(var i=0; i < $scope.filterItem.onRequest.value.length; i++){
                filterListFundHistory.push('"'+$scope.filterItem.onRequest.value[i]+'"');
            }
            filterListFundHistory = "["+filterListFundHistory+"]";

            if ($scope.sortItem.onRequest.id === 0) {
                $scope.descSorted = false;
                orderByFundHistory = '';
                directionHistory = 'asc';
            } else if ($scope.sortItem.onRequest.id === 1) {
                $scope.descSorted = false;
                $scope.policyOption = 'policyHolderName';
                orderByFundHistory = 'policyHolderName';
                directionHistory = 'asc';
            } else {
                $scope.descSorted = false;
                $scope.policyOption = 'policyNumber';
                orderByFundHistory = 'policyNumber';
                directionHistory = 'desc';
            }
            if (searchValFundHistory == undefined) {
                searchValFundHistory = '';
            }
            $scope.noMoreItemsAvailable = false;
            getDataFromService();
        }

        function getDataFromService() {
            findPolicyMyPolicyFundHistoryFrontService.invoke($rootScope.agent.code, $rootScope.username, $stateParams.policyNumber, pageFundHistory, sizeFundHistory, searchValFundHistory, orderByFundHistory, filterListFundHistory, directionHistory).then(function(res) {
                getDataPolicyListInforceSuccess(res);
            });
        }

        getDataPolicyListInforceSuccess(ListFundHistoryPolicy);
        function getDataPolicyListInforceSuccess(result) {
            if (result.invocationResult.isSuccessful) {
                var policyHolderNameTemp;
                $scope.showSpinner = false;
                if (result.invocationResult.array != null) {
                    if (ListPolicyLapsedListAll.length == 0) {
                        ListPolicyLapsedListAll = [];
                        for (var i = 0; i < result.invocationResult.array.length; i++) {
                            var dt = {};
                            var policyHolderName1 = result.invocationResult.array[i].policyHolderName;
                            if (policyHolderName1 == null) {
                                policyHolderNameTemp = "";
                            }
                            else {
                                policyHolderNameTemp = policyHolderName1;
                            }

                            var retrieveDate2 = new Date(result.invocationResult.array[i].transactionDate);
                            var momentDate = moment(retrieveDate2).format('LL');
                            dt.transactionDate = momentDate;
                            dt.amount = result.invocationResult.array[i].amount;
                            dt.amountSeparator = (dt.amount).formatMoney(5, '.', ',');
                            dt.unit = result.invocationResult.array[i].unit;
                            dt.unitSeparator = (dt.unit).formatMoney(5, '.', ',');
                            dt.transactionType = result.invocationResult.array[i].transactionType;
                            dt.fundType = result.invocationResult.array[i].fundType;
                            dt.currencySymbol = result.invocationResult.array[i].currencySymbol;
                            dt.fundTypeCode = result.invocationResult.array[i].fundTypeCode;
                            dt.pricedUsed = result.invocationResult.array[i].pricedUsed;
                            dt.pricedUsedSeparator = (dt.pricedUsed).formatMoney(5, '.', ',');
                            ListPolicyLapsedListAll[i] = dt;
                            pageFundHistory = 1;
                        }
                    } else {
                        for (var i = 0; i < result.invocationResult.array.length; i++) {
                            var dt = {};
                            var policyHolderName1 = result.invocationResult.array[i].policyHolderName;
                            if (policyHolderName1 == null) {
                                policyHolderNameTemp = "";
                            } else {
                                policyHolderNameTemp = policyHolderName1;
                            }
					
                            var retrieveDate2 = new Date(result.invocationResult.array[i].transactionDate);
                            var momentDate = moment(retrieveDate2).format('LL');
                            dt.transactionDate = momentDate;
                            dt.amount = result.invocationResult.array[i].amount;
                            dt.unit = result.invocationResult.array[i].unit;
                            dt.unitSeparator = (dt.unit).formatMoney(0, '.', ',');
                            dt.transactionType = result.invocationResult.array[i].transactionType;
                            dt.fundType = result.invocationResult.array[i].fundType;
                            dt.currencySymbol = result.invocationResult.array[i].currencySymbol;
                            dt.fundTypeCode = result.invocationResult.array[i].fundTypeCode;
                            dt.pricedUsed = result.invocationResult.array[i].pricedUsed;
                            dt.pricedUsedSeparator = (dt.pricedUsed).formatMoney(2, '.', ',');

                            ListPolicyLapsedListAllAfterAdd[i] = dt;
                            ListPolicyLapsedListAll.push(ListPolicyLapsedListAllAfterAdd[i]);
                            $scope.numberOfItemsToDisplay += ListPolicyLapsedListAllAfterAdd.length;
									
                        }
                    }
										
                }
                $scope.agentList = ListPolicyLapsedListAll;
                $ionicLoading.hide();
                $scope.noMoreItemsAvailable = false;
                if (result.invocationResult.statusCode == 500) {
                    $ionicLoading.hide();
                    $scope.noMoreItemsAvailable = true;
                    AppsLog.log("No data found1. Please try again later!");
                }
            } else if (result.invocationResult.statusCode == 500) {
                $scope.showLoading = false;
                $ionicLoading.hide();
                $scope.noMoreItemsAvailable = true;
                AppsLog.log("No data found2. Please try again later!");
            } else {
                AppsLog.log("No data found. Please try again later!");
            }
        }
        var retrieveDate2 = new Date(result.retrieveDate);
        var momentDate = moment(retrieveDate2).format('LLLL');
        $scope.lastUpdate = momentDate;

        function getDataPolicyListInforceFailed(result) {
            $ionicLoading.hide();
            AppsLog.log("Data FundHistory Failed, Please Check Your Connection");
        }

        getDataListFilterFund(ListFilterHistoryFund);
        function getDataListFilterFund(result) {
            if (result.invocationResult.isSuccessful) {
        		if (result.invocationResult.array != null) {     			

        			$scope.listFilterFund = [];
        			for(var i = 0 ; i < result.invocationResult.array.length; i++){
        				$scope.listFilterFund.push({name:result.invocationResult.array[i].name.replace("Show All",$filter('translate')('SHOW_ALL')),value:result.invocationResult.array[i].value});
                    }
                    $scope.filterItem = {
                        onRequest: $scope.listFilterFund[0]
                    }
        			
                }
            } else if (result.invocationResult.statusCode == 500) {
                $ionicLoading.hide();
                AppsLog.log("No data found2. Please try again later!");
            } else {
                AppsLog.log("No data found. Please try again later!");
            }
        }

    })















