﻿
angular.module('PruForce.controllers')
	.controller("FindClaimHistoryDeathCtrl", function ($scope, $rootScope, $state, $stateParams, findClaimHistoryDeathService) {
		$scope.accordionWidgetCollapse = function (e) {
			var self = $(e.toElement);
			var accordion = self.parents(".widget-policy");
			var accordionBody = accordion.find(".list-info");

			if (accordion.hasClass("collapse")) {
				accordion.removeClass("collapse");
				accordionBody.attr("style", "margin-top: -" + (accordionBody.height() + 15) + "px;");
				// accordionBody.css({"margin-bottom":"-18px"});
			} else {
				accordion.addClass("collapse");
				accordionBody.css("margin-top", "0px");
			}
		}
		$scope.initDeathClaim = function (res) {
			getMyDeathClaimHistorySuccess(res);
		};

		findClaimHistoryDeathService.invoke($rootScope.agent.code, $rootScope.username, $stateParams.policyNumber).then(function (result) {
			getMyDeathClaimHistorySuccess(result);

		});

		function getMyDeathClaimHistorySuccess(result) {

			if (result.invocationResult.isSuccessful) {
				//					$scope.approvedAmount = (result.invocationResult.approvedAmount).formatMoney(2, '.', ',');
				//					$scope.claimDecisionDate = result.invocationResult.claimDecisionDate;
				//					$scope.claimStatus = result.invocationResult.claimStatus;
				//					$scope.creationDate = result.invocationResult.creationDate;
				//					$scope.firstPaymentDate = result.invocationResult.firstPaymentDate;
				//					$scope.insuranceBenefit = result.invocationResult.insuranceBenefit;
				//					$scope.visibleDeathClaimHistory = true;

				$scope.visibleDeathClaimHistory = false;
				ListDataDeathClaim = [];
				for (var i = 0; i < result.invocationResult.array.length; i++) {

					var dt = {};
					dt.approvedAmount = (result.invocationResult.array[i].approvedAmount).formatMoney(2, '.', ',');
					dt.claimDecisionDate = moment(result.invocationResult.array[i].claimDecisionDate).format('LL');
					ListDataDeathClaim[i] = dt;
					$scope.visibleDeathClaimHistory = true;

				}
				$scope.ListDataDeathClaim = ListDataDeathClaim;
			}
			else if (result.invocationResult.statusCode == 500) {
				$scope.visibleDeathClaimHistory = false;
			} else {
				AppsLog.log("No data found. Please try again later!");
				$scope.visibleDeathClaimHistory = false;
			}
		}
		function getMyDeathClaimHistoryFailed(result) {
			AppsLog.log("Load Data Failed, Please Check Your Connection");
		}
	})