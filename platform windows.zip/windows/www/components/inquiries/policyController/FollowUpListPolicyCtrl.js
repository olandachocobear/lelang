﻿angular.module('PruForce.controllers')
    .controller("FollowUpListPolicyCtrl", function ($scope, $rootScope, $ionicLoading, $stateParams, $filter, $ionicPopup, ListFollowUpPolicy, FindFollowUpListPolicy, findFollowUpListPolicyService, findFollowUpTodoService, LastUpdate) {
        AnalyticsLog.logPage("prudential.Policy.FollowUpListPolicy");

        var sizeIndividu = 30;
        var pageIndividu = 1;
        var searchByIndividu = '';
        var searchValIndividu = '';
        var searchBy2Individu = '';
        var searchVal2Individu = "['L','I','M','P','O']";
        var orderByIndividu = '';
        var directionIndividu = 'asc';
        $scope.transaction = [];
        var ListFollowUpDetail = [];
        var ListFollowUpDetailAfterAdd = [];
        $scope.noMoreItemsAvailable = false;
        $scope.numberOfItemsToDisplay = 30;
        $scope.policyHolderNames = {
            data: [{
                id: 0,
                name: $filter('translate')('DEFAULT_SORT')
            }, {
                    id: 1,
                    name: $filter('translate')('FOLLOW_UP_DATE_ASC')
                }, {
                    id: 2,
                    name: $filter('translate')('FOLLOW_UP_DATE_DESC')
                }]
        };

        $scope.sortItem = {
            onRequest: $scope.policyHolderNames.data[0]
        };

        $scope.loadMore = function () {
            AppsLog.log("Enter Loadmore");
            pageIndividu += 1;
            $scope.showSpinner = true;
            $scope.noMoreItemsAvailable = false;
            getDataFromService();
            $scope.$broadcast('scroll.infiniteScrollComplete');
        };

        $scope.GoSearching_GoFiltering = function () {
            $ionicLoading.show();
            ListFollowUpDetail = [];
            sizeIndividu = 30;
            pageIndividu = 1;
            searchValIndividu = ($scope.transaction.searchString==undefined)?"":$scope.transaction.searchString.replace(/['|"|\\]/g, "\\$&");
            searchByIndividu = '';

            if ($scope.filterItem.onRequest.name == $filter('translate')('SHOW_ALL')) {
                searchVal2Individu = "['L','I','M','P','O']";
            } else {
                searchVal2Individu = "['"+$scope.filterItem.onRequest.value+"']";
            }
            if ($scope.sortItem.onRequest.id === 0) {
                $scope.descSorted = false;
                orderByIndividu = 'DESC';
            } else if ($scope.sortItem.onRequest.id === 1) {
                $scope.descSorted = false;
                $scope.policyOption = 'ASC';
                orderByIndividu = 'ASC';
            } else if ($scope.sortItem.onRequest.id === 2) {
                $scope.descSorted = false;
                $scope.policyOption = 'DESC';
                orderByIndividu = 'DESC';
            } else {
                $scope.descSorted = false;
                $scope.policyOption = 'DESC';
                orderByIndividu = 'DESC';
            }
            if (searchValIndividu == undefined) {
                searchValIndividu = '';
            }
            $scope.noMoreItemsAvailable = false;
            getDataFromService();
        }

         $rootScope.agentNumberClickByUser = $stateParams.AgentNumber;

        function getDataFromService() {
            if ($stateParams.Flag == "1") {
                findFollowUpTodoService.invoke(
                    $rootScope.agent.code,
                    $rootScope.username,
                    $stateParams.policyNumber, pageIndividu, sizeIndividu, orderByIndividu, "followUpDate", searchVal2Individu, $stateParams.Type, $stateParams.AgentNumber, $stateParams.PageType).then(
                    function (res) {
                        getFollowUpListPolicySucces(res);
                    },function(error){
                        $scope.showSpinner = false;
                        $scope.noMoreItemsAvailable = true;
                    });
            } else {
                findFollowUpListPolicyService.invoke(
                    $rootScope.agent.code,
                    $rootScope.username,
                    $stateParams.policyNumber, pageIndividu, sizeIndividu, orderByIndividu, "followUpDate", searchVal2Individu, $stateParams.Type, $stateParams.AgentNumber, $stateParams.PageType).then(
                    function (res) {
                        getFollowUpListPolicySucces(res);
                    },function(error){
                        $scope.showSpinner = false;
                        $scope.noMoreItemsAvailable = true;
                    });
            }
        }

        // PopUp Show Detail
        $scope.showDetails = function (clientNumber, clientName) {
            $scope.clientNumberPopUp = clientNumber;
            var alertPopup = $ionicPopup
                .alert({
                    title: clientName,
                    scope: $scope,
                    templateUrl: 'components/toDo/to_do_contact_details.html',
                    okText: $filter('translate')('CLOSE')
                });
        };

        //List Status
        getListFollowUpStatusSuccess(FindFollowUpListPolicy);
        setLastUpdate(LastUpdate);
        function setLastUpdate(result) {
            if (result.invocationResult.isSuccessful) {
                var lastUpdateProp = result.invocationResult.latest;
                var lastUpdate = moment(lastUpdateProp).format('LLLL');
                $scope.lastUpdate = lastUpdate;
            }
        }

        //Header Title
        if ($stateParams.Type == "BusinessPending" || $stateParams.Type === "Proposal") {
            $scope.HeaderTitle = "PROPOSAL";
        } else {
            $scope.HeaderTitle = "POLICY";
        }

        function getListFollowUpStatusSuccess(result) {
            if (result.invocationResult.isSuccessful) {
                if (result.invocationResult.array != null) {
                    $scope.listPolisStatus = [];
                    //$scope.listPolisStatus.push({"name" : $filter('translate')('SHOW_ALL'), "value":""});
                    for (var i = 0; i < result.invocationResult.array.length; i++) {
                        $scope.listPolisStatus.push({name:result.invocationResult.array[i].name.replace("Show All",$filter('translate')('SHOW_ALL')),value:result.invocationResult.array[i].value});
                    }
                    $scope.filterItem = {
                        onRequest: $scope.listPolisStatus[0]
                    }
                }
            } else if (result.invocationResult.statusCode == 500) {
                $ionicLoading.hide();
                AppsLog.log("No data found2. Please try again later!");
            } else {
                AppsLog.log("No data found. Please try again later!");
            }
        }

        getFollowUpListPolicySucces(ListFollowUpPolicy);

        function getFollowUpListPolicySucces(result) {
            if (result.invocationResult.isSuccessful) {
                var momentDate;
                if (result.invocationResult.array != null) {
                    if (ListFollowUpDetail.length == 0) {
                        ListFollowUpDetail = [];
                        for (var i = 0; i < result.invocationResult.array.length; i++) {
                            var dt = {};
                            var followUp = new Date(result.invocationResult.array[i].followUpDate);
                            momentFollowUp = moment(followUp).format('DD MMMM YYYY');

                            dt.Urutan = [i];
                            dt.followUpDate = momentFollowUp;
                            dt.lifeAssureds = result.invocationResult.array[i].lifeAssureds;
                            ListFollowUpDetail[i] = dt;

                            $scope.clientNumber = result.invocationResult.array[0].clientNumber;
                            $scope.clientName = result.invocationResult.array[0].clientName;
                            pageIndividu = 1;
                            // ngambil date
                            /*var retrieveDate2 = new Date(
                    result.retrieveDate);
                momentDate = moment(retrieveDate2)
                    .format('LLLL');
                            $scope.lastUpdate = momentDate;*/

                            if (result.invocationResult.array[0].clientNumber != "") {
                                AppsLog.log("client Number ada");
                                $scope.VisibleContact = true;
                            } else {
                                AppsLog.log("client Number tidak ada");
                                $scope.VisibleContact = false;
                            }
                        }
                    } else {
                        for (var i = 0; i < result.invocationResult.array.length; i++) {
                            var dt = {};

                            var followUp = new Date(
                                result.invocationResult.array[i].followUpDate);
                            momentFollowUp = moment(followUp)
                                .format('DD MMMM YYYY');

                            dt.Urutan = [i];
                            dt.followUpDate = momentFollowUp;
                            dt.lifeAssureds = result.invocationResult.array[i].lifeAssureds;
                            $scope.clientNumber = result.invocationResult.array[0].clientNumber;
                            $scope.clientName = result.invocationResult.array[0].clientName;

                            ListFollowUpDetailAfterAdd[i] = dt;
                            ListFollowUpDetail
                                .push(ListFollowUpDetailAfterAdd[i]);
                            $scope.numberOfItemsToDisplay += ListFollowUpDetailAfterAdd.length;
                            /*var retrieveDate2 = new Date(
                    result.retrieveDate);
                momentDate = moment(retrieveDate2)
                    .format('LLLL');
                            $scope.lastUpdate = momentDate;*/
                        }
                    }
                }
                $scope.ListFollowUpDetail = ListFollowUpDetail;
                $ionicLoading.hide();
                $scope.showSpinner = false;
                $scope.noMoreItemsAvailable = false;
                if (result.invocationResult.statusCode == 500) {
                    $scope.showSpinner = false;
                    $ionicLoading.hide();
                    $scope.noMoreItemsAvailable = true;
                }
            } else if (result.invocationResult.statusCode == 500) {
                $scope.showSpinner = false;
                $ionicLoading.hide();
                $scope.noMoreItemsAvailable = true;
            } else {
                $scope.showSpinner = false;
                $ionicLoading.hide();
                $scope.noMoreItemsAvailable = true;
                AppsLog.log("No data found. Please try again later!");
            }

        }
    })