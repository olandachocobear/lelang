﻿
angular.module('PruForce.controllers')


.controller("ClaimHistoryPolicyCtrl", function($scope,$state,NonDeathClaimHistory,PremiumClaimHistory,DeathClaimHistory,LastUpdateProp) {	
	
	AnalyticsLog.logPage("prudential.Policy.ClaimHistory");
	
	getMyProposalLastUpdateSuccess(LastUpdateProp);
	 function getMyProposalLastUpdateSuccess(result)
	  {
		  if (result.invocationResult.isSuccessful){
			  var lastUpdateProp = result.invocationResult.latest; 		
			  var lastUpdate = moment(lastUpdateProp).format('LLLL');
				$scope.lastUpdateProp = lastUpdate;		  
			  AppsLog.log("value date proposal policy by service"+$scope.lastUpdateProp);
				}
		  
	}
		$scope.NonDeathClaimHistory=NonDeathClaimHistory;
		$scope.PremiumClaimHistory=PremiumClaimHistory;
		$scope.DeathClaimHistory=DeathClaimHistory;
})