﻿/**
 * 
 */
angular.module('PruForce.services')
.service('TotalPolicyGraphService', function(DataFactoryOffline, $q){
	function invoke(agentNumber,pruforceId, callservice){
		var req = {
	            adapter : "HTTPAdapterInquiry",
	            procedure : "findTotalPolicyGraph",
	            method: WLResourceRequest.POST,
     			parameters : {"params":"['"+agentNumber+"','"+pruforceId+"']"}
        	};
		
	    var deferred = $q.defer();
	    DataFactoryOffline.invoke(req, callservice)
	    .then(function (res) {	    	
        	deferred.resolve(res);
	    }, function(error){
	       	deferred.reject(error);
	    });
		
		return deferred.promise;
	}
	
	return {
		invoke: invoke
	}
});

