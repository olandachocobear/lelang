﻿/**
 * 
 */
angular.module('PruForce.services')
.service('ProposalByClientNumberService', function(DataFactory, $q){
	function invoke(clientNumberClick, pruforceId, agentCode){
		var req = {
				adapter : "HTTPAdapterInquiry",
				procedure : "findProposalListByClientNumber",
				method: WLResourceRequest.POST,
				parameters : {"params":"['"+clientNumberClick+"','"+pruforceId+"','"+agentCode+"']"}
			};
		
	    var deferred = $q.defer();
		
		DataFactory.invoke(req,true)
	    .then(function (res) {
        	deferred.resolve(res);
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
	}
	
	return {
		invoke: invoke
	}
});

