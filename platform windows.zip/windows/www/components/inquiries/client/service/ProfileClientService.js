﻿/**
 * 
 */
angular.module('PruForce.services')
.service('ProfileClientService', function(DataFactory, $q){
	var resultForPassingData = null;
	function invoke(clientNumberClick, pruforceId, agentCode, agentnumber, pagetype){
	    var req = {
	            adapter : "HTTPAdapterInquiry",
	            procedure : "findProfileClientByAgentNumber",
	           	method: WLResourceRequest.POST,
				parameters : {"params":"['"+clientNumberClick+"','"+pruforceId+"','"+agentCode+"','"+agentnumber+"','"+pagetype+"']"}
			};
		
	    var deferred = $q.defer();
		
		DataFactory.invoke(req,true)
	    .then(function (res) {
	    	AppsLog.log("MASUK APA TIDAK 1"+JSON.stringify(res));
        	deferred.resolve(res);
        	resultForPassingData = res;
	    }, function(error){
	    	AppsLog.log("MASUK APA TIDAK 2");
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
	}
	
	return {
		invoke: invoke
	}
	
	
	function getData(){
		AppsLog.log("masuk gak men"+resultForPassingData);
		return resultForPassingData;
	}
});

