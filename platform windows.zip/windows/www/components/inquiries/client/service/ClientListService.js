﻿/**
 * 
 */
angular.module('PruForce.services')
.service('ClientListService', function(DataFactory, $q){
	function invoke(agentNumberClient, pageClient, sizeClient, searchByClient, pruforceId, agentCode){
	    var req = {
	            adapter : "HTTPAdapterInquiry",
	            procedure : "findListClientByAgentNumber",
	            method: WLResourceRequest.POST,
				parameters : {"params":"['"+agentNumberClient+"',"+pageClient+","+sizeClient+",'"+searchByClient+"','"+pruforceId+"','"+agentCode+"']"}
			};
		
	    var deferred = $q.defer();
		
		DataFactory.invoke(req,true)
	    .then(function (res) {
        	deferred.resolve(res);
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
	}
	
	return {
		invoke: invoke
	}
});

