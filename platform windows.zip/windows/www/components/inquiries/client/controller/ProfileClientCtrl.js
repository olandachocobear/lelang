﻿/**
 * 
 */

angular.module('PruForce.controllers')
	.controller('ProfileClientCtrl', function ($scope, $http, LastUpdateClientService, ProfileClientService, $rootScope) {
		$scope.getDataClientProfileSuccess = getDataClientProfileSuccess;
		$scope.init = function (ProfileClientData) {
			getDataClientProfileSuccess(ProfileClientData, false);
		};
		$scope.getDataProfile = function (clientNumber) {
			LastUpdateClientService.invoke($rootScope.username, $rootScope.agent.code).then(function (res) {
				getDataClientProfileSuccess(res, true);
			});
			ProfileClientService.invoke(clientNumber, $rootScope.username, $rootScope.agent.code, ($rootScope.agentNumberClickByUser == 0) ? $rootScope.agent.code : $rootScope.agentNumberClickByUser, ($rootScope.agentNumberClickByUser == 0) ? "individu" : "unit").then(function (res) {
				getDataClientProfileSuccess(res, false);
			});
		}

		$scope.triggerEmail = function (emailAddress) {
			window.location.href = 'mailto:' + emailAddress;
		}

		function getDataClientProfileSuccess(result, flagForLastUpdate) {
			// if (result.invocationResult.isSuccessful) {
			if (flagForLastUpdate) {
				var lastUpdateClient = result.invocationResult.latest;
				var lastUpdate = moment(lastUpdateClient).format('LLLL');
				$scope.lastUpdateProfileClient = lastUpdate;
			} else {
				$scope.clientNumber = result.invocationResult.clientNumber;
				$scope.idNumber = result.invocationResult.idNumber;
				$scope.clientName = result.invocationResult.clientName;
				$scope.nationality = result.invocationResult.nationality;
				$scope.religion = result.invocationResult.religion;
				if (result.invocationResult.dateOfBirth != undefined && result.invocationResult.dateOfBirth != '') {
					$scope.dateOfBirth = moment(result.invocationResult.dateOfBirth).format('LL');
				}
				$scope.maritalStatus = result.invocationResult.maritalStatus;
				$scope.gender = result.invocationResult.gender;

				$scope.address1 = result.invocationResult.address1;
				$scope.address2 = result.invocationResult.address2;
				$scope.address3 = result.invocationResult.address3;
				$scope.address4 = result.invocationResult.address4;
				$scope.address5 = result.invocationResult.address5;
				if ($scope.address4 != "" && $scope.address4 != undefined && $scope.address5 != "" && $scope.address5 != undefined) {
					$scope.address4 = result.invocationResult.address4 + ", ";
				}
				$scope.emailAddress = result.invocationResult.emailAddress;

				$scope.mobileNumber1 = result.invocationResult.mobileNumber1;
				$scope.mobileNumber2 = result.invocationResult.mobileNumber2;
				$scope.mobileNumber3 = result.invocationResult.mobileNumber3;
				/*
				$('#mobileNumber1').on('click', function (event) {
					window.location.href = 'tel:' + $scope.mobileNumber1;
				});
				$('#mobileNumber2').on('click', function (event) {
					window.location.href = 'tel:' + $scope.mobileNumber2;
				});
				$('#mobileNumber3').on('click', function (event) {
					window.location.href = 'tel:' + $scope.mobileNumber3;
				});
				*/
			}
			// } else {
			// 	AppsLog.log("No data found. Please try again later!");
			// }
		}

		function getDataClientProfileFailed(result) {
			AppsLog.log("Load Data Failed, Please Check Your Connection");
		}
	})