﻿/**
 * 
 */

angular.module('PruForce.controllers')

.controller("ProposalByClientNumberCtrl", function($scope, $http){
	
	$scope.getDataProposalClientSuccess = getDataProposalClientSuccess;
	$scope.flagShow = false;
	
	$scope.init = function(ProposalByClientNumberData){
		AppsLog.log("masuk init yach "+ProposalByClientNumberData);
		getDataProposalClientSuccess(ProposalByClientNumberData);
	};	
	
	function getDataProposalClientSuccess(result) {
	    if (result.invocationResult.isSuccessful){
			ListClientProposalData = [];
	    	if(result.invocationResult.array != null && result.invocationResult.array.length!=0){
	    		$scope.flagShow = true;
	            for (var i = 0; i < result.invocationResult.array.length; i++){
	            	
		                var dt = {};
		                dt.clientNumber = result.invocationResult.array[i].clientNumber;
		                dt.policyStatus = result.invocationResult.array[i].policyStatus;
		                dt.proposalNumber = result.invocationResult.array[i].proposalNumber;
		                dt.productCode = result.invocationResult.array[i].productCode;
		                dt.PruCodeEnd = (dt.productCode).substring(3,(dt.productCode).size);
		                ListClientProposalData[i] = dt; 
		                
	            }
	            
	    	}
            $scope.ListClientProposalData = ListClientProposalData;
            
	    } else {
            AppsLog.log("No data found. Please try again later!");
        }
    }
 
    function getDataProposalClientFailed(result){
         AppsLog.log("Load Data Failed, Please Check Your Connection");
    }
	    
})