﻿/**
 * 
 */

angular.module('PruForce.controllers')
.controller("ClientDetailsCtrl", function($scope, $rootScope,$ionicLoading, ProfileClientData, ProposalByClientNumberData, PolicyByClientNumberData, LastUpdateClient){
	AnalyticsLog.logPage("prudential.Client.dtl");
	
	$scope.ProfileClientData = ProfileClientData;
	$scope.PolicyByClientNumberData = PolicyByClientNumberData;
	$scope.ProposalByClientNumberData = ProposalByClientNumberData; 
	
	getLastUpdateClientSuccess(LastUpdateClient);
    function getLastUpdateClientSuccess(result)
    {
  	//   if (result.invocationResult.isSuccessful){
  		  var lastUpdateClient = result.invocationResult.latest; 		
  		  var lastUpdate = moment(lastUpdateClient).format('LLLL');
		  $scope.lastUpdateClient = lastUpdate;
  	//   } else if(result.invocationResult.statusCode==500) {
	// 	$ionicLoading.hide();
	// 	AppsLog.log("No data found2. Please try again later!");
  	//   } else {
	//    AppsLog.log("No data found. Please try again later!");
  	//   }
    }
	
	$scope.agentNumber = $rootScope.agent.code;	
})