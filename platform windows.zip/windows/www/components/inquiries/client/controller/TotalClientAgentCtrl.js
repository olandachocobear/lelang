﻿angular.module('PruForce.controllers')
	.controller('TotalClientAgentCtrl', function ($state, $scope, $rootScope, $http, TotalClientAgentService, PDTotalClientAgentService, LastUpdateClientService, $q) {
		$scope.loading = true;
		$scope.loadingSmall = true;
		$scope.successCall = true;
		$scope.successResult = true;

		$scope.TotalClientAgentService = TotalClientAgentService;
		$scope.LastUpdateClientService = LastUpdateClientService;

		$scope.init = function () {
			$scope.loading = true;
			$scope.loadingSmall = true;
			$scope.successCall = true;
			$scope.successResult = true;

			if($rootScope.pd){
				initPD();
			} else {
				initAgency();
			}

			var qLastUpdateClientService = LastUpdateClientService.invoke($rootScope.username, $rootScope.agent.code, true).then(function (res) {
				getMyProposalLastUpdateSuccess(res);
				$scope.loading = false;
			});
		};

		function initAgency(){
			var qTotalClientAgentService = TotalClientAgentService.invoke($rootScope.agent.code, $rootScope.username, true).then(function (res) {
				getTotalClientAgentSuccess(res);
				$scope.loading = false;
			});
		}

		function prepareAgencyData(){
			collection = JsonStoreConfig['findTotalClientByAgentNumber'];
			$scope.$on(collection.JSONSTORE_NAME, function (event, args) {
				$scope.successCall = (args.status == "success") ? true : false;

				var qTotalClientAgentService = TotalClientAgentService.invoke($rootScope.agent.code, $rootScope.username, false).then(function (res) {
					getTotalClientAgentSuccess(res);
				});

				$q.all([qTotalClientAgentService]).then(function () {
					$scope.loadingSmall = false;
					$scope.loading = false;
				});
			});
		}

		function initPD(){
			var qTotalClientAgentService = PDTotalClientAgentService.invoke($rootScope.agent.code, $rootScope.username, true).then(function (res) {
				getTotalClientAgentSuccess(res);
				$scope.loading = false;
			});
		}

		function preparePDData(){
			collection = JsonStoreConfig['findTotalClientByAgentNumberPD'];
			$scope.$on(collection.JSONSTORE_NAME, function (event, args) {
				$scope.successCall = (args.status == "success") ? true : false;

				var qTotalClientAgentService = PDTotalClientAgentService.invoke($rootScope.agent.code, $rootScope.username, false).then(function (res) {
					getTotalClientAgentSuccess(res);
				});

				$q.all([qTotalClientAgentService]).then(function () {
					$scope.loadingSmall = false;
					$scope.loading = false;
				});
			});
		}

		collection = JsonStoreConfig['findLastUpdateClient'];
		$scope.$on(collection.JSONSTORE_NAME, function (event, args) {
			$scope.successCall = (args.status == "success") ? true : false;

			var qLastUpdateClientService = LastUpdateClientService.invoke($rootScope.username, $rootScope.agent.code, false).then(function (res) {
				getMyProposalLastUpdateSuccess(res);
			});

			$q.all([qLastUpdateClientService]).then(function () {
				$scope.loadingSmall = false;
				$scope.loading = false;
			});
		});

		if($rootScope.pd){
			preparePDData();
		} else {
			prepareAgencyData();
		}

		$scope.init();

		function getTotalClientAgentSuccess(result) {
			if (result.invocationResult.statusCode == 200) {
				$scope.totalClient = result.invocationResult.totalclient;
			} else {
				AppsLog.log("No data found. Please try again later!");
				$scope.successResult = false;
			}
		}

		function getMyProposalLastUpdateSuccess(result) {
			if (result.invocationResult.statusCode == 200) {
				var lastUpdateProp = result.invocationResult.latest;
				var lastUpdate = moment(lastUpdateProp).format('LLLL');
				$scope.lastUpdateClient = lastUpdate;
			} else {
				$scope.successResult = false;
			}
		}
  
		$scope.inquiriesMyClient = function(){
			var stateInquiryMyClient = "inquiries_my_client";
			if ($rootScope.pd) {
				stateInquiryMyClient = "pd_inquiries_my_client";
			}
			$state.go(stateInquiryMyClient);
		};
		
		$scope.viewAllIndividuBirthday = function(agentNumber){
			var stateAllBirthday = "customers_birthday";
			if ($rootScope.pd) {
				stateAllBirthday = "pd_customers_birthday";
			}
			$state.go(stateAllBirthday, {'Flag' : '1', 'agentNumber': agentNumber} );
		}
		
	})