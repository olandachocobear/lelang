﻿/**
 * 
 */
angular.module('PruForce.services')
.service('findFollowUpListPolicyService', function(DataFactory, $q){
	function invoke(agentCode,pruforceId,policyNumber,page, size,searchBy,orderBy,statusList,type,agentNumber,pageType){
	    var req = {
	            adapter : "HTTPAdapterInquiry",
	            procedure : "findFollowUpMyPolicy",
	            method: WLResourceRequest.POST,
				parameters : {"params":"['"+agentCode+"','"+pruforceId+"','"+policyNumber+"',"+page+","+size+",'"+searchBy+"','"+orderBy+"',"+statusList+",'"+type+"','"+ agentNumber+"','"+ pageType+"']"}
			};
	    
	    AppsLog.log("1. page " + page);
		AppsLog.log("2. size " + size);
		AppsLog.log("3. salesforceId " + pruforceId);
		AppsLog.log("4. agentNumber " + agentNumber);
		AppsLog.log("5. policyNumber " + policyNumber);
		AppsLog.log("6. searchBy " + searchBy);
		AppsLog.log("7. orderBy " + orderBy);
		AppsLog.log("8. statusList " + statusList);
	    
	    var deferred = $q.defer();
		
		DataFactory.invoke(req,true)
	    .then(function (res) {
        	deferred.resolve(res);
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
	}
	
	return {
		invoke: invoke
	}
});
