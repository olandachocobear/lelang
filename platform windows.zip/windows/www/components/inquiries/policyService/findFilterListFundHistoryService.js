﻿/**
 * 
 */
angular.module('PruForce.services')
.service('findFilterListFundHistoryService', function(DataFactory, $q){
	function invoke(agentNumber,pruforceId,policyNumberFundHistory,searchWordFund){
	    var req = {
	            adapter : "HTTPAdapterInquiry",
	            procedure : "findFilterListFundHistory",
	            method: WLResourceRequest.POST,
				parameters : {"params":"['"+agentNumber+"','"+pruforceId+"','"+policyNumberFundHistory+"','"+searchWordFund+"']"}
			};
		
	    var deferred = $q.defer();
		
	  AppsLog.log("masuk service fund history test "+agentNumber,pruforceId,policyNumberFundHistory);
	    
		DataFactory.invoke(req,true)
	    .then(function (res) {
        	deferred.resolve(res);
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
	}
	
	return {
		invoke: invoke
	}
});

