﻿/**
 * 
 */
angular.module('PruForce.services')
.service('findFilterFollowUpStatusService', function(DataFactory, $q){
	function invoke(agentNumber,pruforceId,policyNumberFollowUp){
	    var req = {
	            adapter : "HTTPAdapterInquiry",
	            procedure : "findFilterFollowUpStatus",
	            method: WLResourceRequest.POST,
				parameters : {"params":"['"+agentNumber+"','"+pruforceId+"','"+policyNumberFollowUp+"']"}
			};
	    
	    var deferred = $q.defer();
		
		DataFactory.invoke(req,true)
	    .then(function (res) {
        	deferred.resolve(res);
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
	}
	
	return {
		invoke: invoke
	}
});