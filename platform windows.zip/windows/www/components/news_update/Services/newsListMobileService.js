﻿/**
 * 
 */
angular.module('PruForce.services')
.service('newsListMobileService', function(DataFactory, $q){
	function invoke(page, size, salesforceId, agentNumber,searchBy,filterBy,orderBy, agentType){
	    var req = {
	            adapter : "HTTPAdapterNewsUpdate",
	            procedure : "newsListMobile",
	            method: WLResourceRequest.POST,
     			parameters : {"params":"["+page+","+size+",'"+salesforceId+"','"+agentNumber+"','"+searchBy+"','"+filterBy+"','"+orderBy+"', '"+agentType+"']"}
	        };
		
	    var deferred = $q.defer();
		
		DataFactory.invoke(req,true)
	    .then(function (res) {
        	deferred.resolve(res);
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
	}
	
	function invokeNewsType(salesforceId, agentNumber, agentType){
	    var req = {
	            adapter : "HTTPAdapterNewsUpdate",
	            procedure : "getNewsType",
	            method: WLResourceRequest.POST,
     			parameters : {"params":"['"+salesforceId+"','"+agentNumber+"','"+agentType+"']"}
	        };
		
	    var deferred = $q.defer();
		
		DataFactory.invoke(req,true)
	    .then(function (res) {
        	deferred.resolve(res);
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
	}
	
	function invokeNewsFileBase64(fileName,module){
	    var req = {
	    		adapter : "HTTPAdapterNewsUpdate",
	            procedure : "getFileBase64",
                    method: WLResourceRequest.POST,
     		    parameters : {"params":"['"+fileName+"','"+module+"']"}
	        };
		
	    var deferred = $q.defer();
		
		DataFactory.invoke(req,true)
	    .then(function (res) {
        	deferred.resolve(res);
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
	}
	
	return {
		invoke: invoke,
		invokeNewsType: invokeNewsType,
		invokeNewsFileBase64: invokeNewsFileBase64
	}
});