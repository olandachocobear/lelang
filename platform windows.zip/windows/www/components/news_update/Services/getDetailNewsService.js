﻿/**
 * 
 */
angular.module('PruForce.services')
.service('getDetailNewsService', function(DataFactory, $q){
	function invoke(id, salesforceId, agentNumber){
	    var req = {
	            adapter : "HTTPAdapterNewsUpdate",
	            procedure : "getDetailNews",
	            method: WLResourceRequest.POST,
     			parameters : {"params":"['"+id+"','"+salesforceId+"','"+agentNumber+"']"}
	        };
		
	    var deferred = $q.defer();
		
		DataFactory.invoke(req,true)
	    .then(function (res) {
        	deferred.resolve(res);
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
	}
	
	return {
		invoke: invoke
	}
});