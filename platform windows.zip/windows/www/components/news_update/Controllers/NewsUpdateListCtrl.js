﻿angular.module('PruForce.controllers')
.controller('NewsUpdateListCtrl', function($scope, $rootScope, $http, $location, $filter, $ionicLoading,NewsUpdateList, NewsUpdateType, newsListMobileService) {
	AppsLog.log("START >> NewsUpdateListCtrl " + new Date());
	AnalyticsLog.logPage("prudential.newsupdate.list");
	
	var sizeIndividu = 30;
	var pageIndividu = 1;
	var searchByIndividu ='';
	var searchValIndividu ='';
	var searchBy2Individu ='';
	var searchVal2Individu ='';
	var orderByIndividu ='';
	var directionIndividu ='';
	$scope.transaction = [];
	var ListNews = [];
	var ListNewsAfterAdd = [];
	var ListBanner = [];
	var contestImageUrl = "http://10.170.49.172/commonUtils/commonFile/getFile?fileName=";
	var contestImageModule = "&module=newsUpdate";
	
	$scope.noMoreItemsAvailable = false;
	$scope.numberOfItemsToDisplay = 30;
	
	$scope.SortType={
			data:[{
				id:0,
				name: $filter('translate')('DEFAULT_SORT')
			},
			{
				id:1,
				name: $filter('translate')('PUBLISH_DATE_ASC')
			},
			{
				id:2,
				 name: $filter('translate')('PUBLISH_DATE_DESC')
			},
			{
				id:3,
				 name: $filter('translate')('SUBJECT_ASC')
			},
			{
				id:4,
				 name: $filter('translate')('SUBJECT_DESC')
			},]
	};
	
	$scope.sortItem = {
			onRequest: $scope.SortType.data[0]
	};
	
	$scope.GoSearching_GoFiltering = function() {
		$ionicLoading.show();
		ListNews = [];
		sizeIndividu = 30;
		pageIndividu = 1;
		searchValIndividu = ($scope.transaction.searchString==undefined)?"":$scope.transaction.searchString.replace(/['|"|\\]/g, "\\$&");
		searchByIndividu = '';
		
		if ($scope.filterItem.onRequest == $filter('translate')('SHOW_ALL')) {
			searchVal2Individu = '';
		} else {
			searchVal2Individu = $scope.filterItem.onRequest.value;
		}
		
		if ($scope.sortItem.onRequest.id === 0) {
			$scope.descSorted = false;
			orderByIndividu = '';
		} else if ($scope.sortItem.onRequest.id === 1) {
			$scope.descSorted = false;
			orderByIndividu = 'publishDateAsc'; 
		} else if ($scope.sortItem.onRequest.id === 2) {
			$scope.descSorted = false;
			orderByIndividu = 'publishDateDesc';
		} else if ($scope.sortItem.onRequest.id === 3) {
			$scope.descSorted = false;
			orderByIndividu = 'subjectAsc';
		} else if ($scope.sortItem.onRequest.id === 4) {
			$scope.descSorted = false;
			orderByIndividu = 'subjectDesc';
		} else {
			$scope.descSorted = false;
			orderByIndividu = '';
		}	
		
		if (searchValIndividu == undefined) {
			searchValIndividu = '';
		}
		
		AppsLog.log("List Request Filtering" + $rootScope.searchBy);
		AppsLog.log("List Request 1 :" + searchByIndividu);
		AppsLog.log("List Request 2 :" + searchValIndividu);
		AppsLog.log("List Request 3 :" + pageIndividu);
		AppsLog.log("List Request 4 :" + sizeIndividu);
		AppsLog.log("List Request 5 :" + orderByIndividu);
		AppsLog.log("List Request 6 :" + directionIndividu);
		AppsLog.log("List Request 7 :" + searchBy2Individu);
		AppsLog.log("List Request 8 :" + searchVal2Individu);
		$scope.noMoreItemsAvailable= false;
		getDataFromService();
	}
		
	$scope.loadMore = function() {
		pageIndividu += 1;
		$scope.showSpinner= true;
		getDataFromService();
		$scope.noMoreItemsAvailable= false;
		$scope.$broadcast('scroll.infiniteScrollComplete');
	};
	
	function getDataFromService() {
		newsListMobileService.invoke(pageIndividu, sizeIndividu, $rootScope.username,$rootScope.agent.code,searchValIndividu,searchVal2Individu,orderByIndividu, $rootScope.agent_agentTypeId)
			.then(function(res) {
				getListMobileSuccess(res);
			});
	}
	
	$scope.init = function(){
		$ionicLoading.show();
		getListMobileSuccess(NewsUpdateList);
		getListMobileType(NewsUpdateType);
	};
	
	$scope.init();
	
	function getListMobileType(result){   
    	if (result.invocationResult.isSuccessful) {
    		if (result.invocationResult.content != null) {
    			
    			$scope.listNewsType = [];
    			$scope.listNewsType.push({"name" : $filter('translate')('SHOW_ALL'), "value":""});
    			for(var i = 0 ; i < result.invocationResult.content.length; i++){
    				$scope.listNewsType.push({name:result.invocationResult.content[i].typeName,value:result.invocationResult.content[i].id.toString()});
    			}
    		}else{
    			$scope.listNewsType = [];
    			$scope.listNewsType.push({"name" : $filter('translate')('SHOW_ALL'), "value":""});
     		}
    		
    		$scope.filterItem = {onRequest: $scope.listNewsType[0]}
    		
    	} else if(result.invocationResult.statusCode==500) {
			$ionicLoading.hide();
			AppsLog.log("No data found2. Please try again later!");
	    }else {
    	   AppsLog.log("No data found. Please try again later!");
        }
    }
	
	
	function getListMobileSuccess(result) {
		AppsLog.log("START >> getListMobileSuccess " + new Date());
		if (result.invocationResult.isSuccessful){
			var momentDate;
			if(result.invocationResult.array != null){
				if (ListNews.length == 0) {
					ListNews = [];
					for (var i = 0; i < result.invocationResult.array.length; i++){
						var dt = {};
						var news_date = new Date(result.invocationResult.array[i].start_publish_date);
						
						dt.news_date = moment(news_date).format('DD MMMM YYYY');
						dt.news_time = moment(news_date).format('hh.mm');
						dt.news_id = result.invocationResult.array[i].id;
						dt.news_title = result.invocationResult.array[i].title;
						dt.news_short_description = result.invocationResult.array[i].description;
						dt.news_type = result.invocationResult.array[i].news_type_id;	
						dt.news_image = result.invocationResult.array[i].image_name;
						dt.news_attachment = result.invocationResult.array[i].file_name;
						dt.news_type_icon = "data:image/png;base64," + result.invocationResult.array[i].newsTypeIcon;
						dt.urutan = i;
						ListNews[i] = dt;
						pageIndividu = 1;
						
					}
				} else
					{
					for (var i = 0; i < result.invocationResult.array.length; i++){
						var dt = {};
						var news_date = new Date(result.invocationResult.array[i].start_publish_date);
						
						dt.news_date = moment(news_date).format('DD MMMM YYYY');
						dt.news_time = moment(news_date).format('hh.mm');
						dt.news_id = result.invocationResult.array[i].id;
						dt.news_title = result.invocationResult.array[i].title;
						dt.news_short_description = result.invocationResult.array[i].description;
						dt.news_type = result.invocationResult.array[i].news_type_id;	
						dt.news_image = result.invocationResult.array[i].image_name;
						dt.news_attachment = result.invocationResult.array[i].file_name;
						dt.news_type_icon = "data:image/png;base64," + result.invocationResult.array[i].newsTypeIcon;
						dt.urutan = i;
						
						ListNewsAfterAdd[i] = dt;
						ListNews.push(ListNewsAfterAdd[i]);
						
						$scope.numberOfItemsToDisplay += ListNewsAfterAdd.length;

					}
					}
			}
			
			
			
			$scope.ListNews = ListNews;
			$rootScope.ListNewsMain = [];
			$rootScope.ListNewsMain = ListNews;
			$ionicLoading.hide();
			$scope.showSpinner = false;
			$scope.noMoreItemsAvailable= false;
			if(result.invocationResult.statusCode==500) {
				$scope.showSpinner = false;
				$ionicLoading.hide();
				$scope.noMoreItemsAvailable= true;
			}
		} else if(result.invocationResult.statusCode==500) {
			$scope.showSpinner = false;
			$ionicLoading.hide();
			$scope.noMoreItemsAvailable= true;
		} else {
			AppsLog.log("No data found. Please try again later!");
 		}
		}
	
	$scope.setFirstNews = function(urutan){
		$rootScope.firstNews = urutan;
	}
	AppsLog.log("END >> NewsUpdateListCtrl " + new Date());
	
});
