﻿angular.module('PruForce.services')

	.service('GetCountRegistrationAAJIService', function (AOBResources, $q, $rootScope) {

		function invoke(agentCode) {

			var req = {
				adapter: "HTTPAdapterAuth",
                procedure: "GetCountAAJIRegistration",
				method: WLResourceRequest.POST,
                parameters: { "params": "['" + agentCode + "']" }
			};

			var deferred = $q.defer();

			AOBResources.invoke(req, false)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invoke: invoke
		}
	});

