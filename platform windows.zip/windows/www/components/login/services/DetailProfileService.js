﻿angular.module('PruForce.services')

	.service('DetailProfileService', function (AOBResources, $q, $rootScope) {

		function invoke(token) {

			var req = {
				adapter: "HTTPAdapterAuth",
				procedure: "getDetailProfile",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + token + "']" }
			};

			var deferred = $q.defer();

			AOBResources.invoke(req, false)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invoke: invoke
		}
	});

