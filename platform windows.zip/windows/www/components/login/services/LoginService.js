﻿angular.module('PruForce.services')

	.service('LoginService', function (AOBResources, $q, sha256, $localStorage) {

		var LoginProvider = function () {

			var deferred = $q.defer();

			function invoke(username, password, channel) {
				var hPassword = sha256.convertToSHA256(username + sha256.convertToSHA256(password));

				var req = {
					adapter: "HTTPAdapterAuth",
					procedure: "getToken",
					method: WLResourceRequest.POST,
					parameters: { "params": "['" + username + "','" + password + "','" + channel + "','" + hPassword + "']" }
				};


				AOBResources.invoke(req, false, false)
					.then(function (res) {
						var networkState = navigator.connection.type;

						if (networkState == Connection.NONE) {
							offlineChecking(username, hPassword, res);
						} else {
							deferred.resolve(res);
						}

					}, function (error) {
						deferred.reject(error);
					});

				return deferred.promise;
			}

			function offlineChecking(username, password, res) {


				var serverErrorResponse = { "statusReason": "Unauthorized", "responseHeaders": { "Keep-Alive": "timeout=5, max=100", "Transfer-Encoding": "chunked", "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Credentials": "true", "WWW-Authenticate": "Bearer", "Connection": "Keep-Alive", "Date": "Wed, 11 Jan 2017 10:06:23 GMT", "Content-Type": "text/plain" }, "isSuccessful": true, "responseTime": 155, "totalTime": 157, "statusCode": 200 }

				var errorResponse = {};
				errorResponse.invocationResult = {};
				errorResponse.invocationResult.isSuccessful = true;
				errorResponse.invocationResult.responseHeaders = serverErrorResponse;
				errorResponse.invocationResult.statusReason = "Unauthorized";
				errorResponse.invocationResult.isLoginExpired = false;

				if (res.invocationResult.username !== undefined) {
					if (res.invocationResult.username === username && res.invocationResult.password === password) {

						var now = moment(new Date()).format("MM/DD/YYYY");
						var today = moment(now, "MM/DD/YYYY");
						var lastOnlineLogin = moment(res.invocationResult.lastOnlineLogin, 'MM/DD/YYYY');
						var diffDays = today.diff(lastOnlineLogin, 'days');

						$localStorage.lastOnlineLogin = res.invocationResult.lastOnlineLogin;

						if (diffDays <= 7) {
							deferred.resolve(res);
						} else {
							errorResponse.invocationResult.isLoginExpired = true;
							delete $localStorage.access_token;
							deferred.resolve(errorResponse);
						}

					} else {

						deferred.resolve(errorResponse);
					}

				} else {
					deferred.resolve(errorResponse);
				}
			}

			return {
				invoke: invoke
			}

		}


		var invoke = function (username, password, channel) {
			var loginProvider = new LoginProvider();
			return loginProvider.invoke(username, password, channel);
		}

		return {
			invoke: invoke
		}
	});

