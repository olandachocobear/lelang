﻿angular.module('PruForce.services')

	.service('GetSosMedService', function (AOBResources, $q, $rootScope) {

		function invoke(npa) {

			var req = {
				adapter: "HTTPAdapterAuth",
                procedure: "getSosMedCan",
				method: WLResourceRequest.POST,
                parameters: { "params": "['" + npa + "']" }
			};

			var deferred = $q.defer();

			AOBResources.invoke(req, false)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invoke: invoke
		}
	});

