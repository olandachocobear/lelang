﻿var pruforce = angular.module('PruForce');

pruforce.controller("SyaratKetentuanCtrl", function ($scope, $filter, $rootScope, $state, SyaratKetentuanService, GetAplicationPackService) {
    $scope.dataCandidateParam = {
        agentId: $rootScope.agent.code,
        npa: $rootScope.candidate.npa
    }
    $scope.data = {};
    $scope.init = function () {
        SyaratKetentuanService.getDataSyaratKetentuan($scope.dataCandidateParam).then(
            function (result) {
                if (result !== 'empty') {
                    $scope.syaratKetentuan = result.json;


                    if ($scope.syaratKetentuan.ketentuanTambahan.haveFamily === undefined) {
                        $scope.syaratKetentuan.ketentuanTambahan.haveFamily = false;
                    } else {
                        if ($scope.syaratKetentuan.ketentuanTambahan.haveFamily === true) {
                            $scope.syaratKetentuan.ketentuanTambahan.dontHaveFamily = false;
                        } else if ($scope.syaratKetentuan.ketentuanTambahan.dontHaveFamily) {
                            $scope.syaratKetentuan.ketentuanTambahan.dontHaveFamily = true;
                        }
                    }
                } else {
                    $scope.syaratKetentuan = {};
                    $scope.syaratKetentuan.ketentuanTambahan = {};
                    $scope.syaratKetentuan.ketentuanTambahan.haveFamily = false;
                    $scope.syaratKetentuan.ketentuanTambahan.formData = {};
                    $scope.syaratKetentuan.perjanjianKeagenan = {};
                    $scope.syaratKetentuan.pernyataanAgen = {};
                }
            },
            function (error) {

            }
        );

        GetAplicationPackService.getDataCandidatePack($scope.dataCandidateParam).then(function (result) {
            try {
                response = result.json;
                $rootScope.calonAgen = response.dataPribadi.name;
                $rootScope.address1 = response.dataPribadi.alamat1;
                $rootScope.address2 = response.dataPribadi.alamat2;
                $rootScope.address3 = response.dataPribadi.alamat3;
                $rootScope.province = response.dataPribadi.province;
                $rootScope.zipcode = response.dataPribadi.zipcode;
                $rootScope.idCardNumber = response.dataPribadi.candidateIdCardNo;
                $rootScope.cellularNo1 = response.dataPribadi.cellPhone.phone1;
            } catch (error) {
            }
        });
    }
    
    $scope.linkNotif = function (notif) {
        if (notif === 'perjanjian') {
            $state.go('perjanjian-keagenan', {}, { reload: true });
        } else if (notif === 'ketentuan') {
            $state.go('syarat-dan-ketentuan-tambahan', {}, { reload: true });
        } else if (notif === 'pernyataan') {
            $state.go('pernyataan-keagenan', {}, { reload: true });
        }
    }
    $scope.init();

    $rootScope.$on('$locationChangeSuccess', function () {
        $scope.init();
    });

    $scope.syaratDanKetentuanChecked1 = { checked: false };
    $scope.syaratDanKetentuanChecked2 = { checked: false };
    $scope.syaratDanKetentuanChecked3 = { checked: false };


    $scope.hideNotif1 = function () {

        if ($rootScope.count1 == undefined) {
            $scope.syaratKetentuan.perjanjianKeagenan.checked = false;
            $state.go('perjanjian-keagenan', {}, { reload: true });
        } else {
            $state.go('perjanjian-keagenan', {}, { reload: true });
            $scope.syaratKetentuan.perjanjianKeagenan.checked = true;
            $scope.syaratKetentuan.agentId = $scope.dataCandidateParam.agentId;
            $scope.syaratKetentuan.npa = $scope.dataCandidateParam.npa;
        }
    }

    $scope.hideNotif2 = function () {
        if ($rootScope.count2 == undefined) {
            $scope.syaratKetentuan.ketentuanTambahan.checked = false;
            $state.go('syarat-dan-ketentuan-tambahan', {}, { reload: true });
        } else {
            $state.go('syarat-dan-ketentuan-tambahan', {}, { reload: true });
            $scope.syaratKetentuan.ketentuanTambahan.checked = true;
            $scope.syaratKetentuan.agentId = $scope.dataCandidateParam.agentId;
            $scope.syaratKetentuan.npa = $scope.dataCandidateParam.npa;
        }
    }

    $scope.hideNotif3 = function () {
        if ($rootScope.count3 == undefined) {
            $scope.syaratKetentuan.pernyataanAgen.checked = false;
            $state.go('pernyataan-keagenan', {}, { reload: true });
        } else {
            $state.go('pernyataan-keagenan', {}, { reload: true });
            $scope.syaratKetentuan.pernyataanAgen.checked = true;
            $scope.syaratKetentuan.agentId = $scope.dataCandidateParam.agentId;
            $scope.syaratKetentuan.npa = $scope.dataCandidateParam.npa;
        }
    }

    $scope.submit = function (param) {
        if (param === 'perjanjianKeagenan') {

            if ($scope.syaratKetentuan.perjanjianKeagenan === undefined) {
                $scope.syaratKetentuan.perjanjianKeagenan = {};
                $scope.syaratKetentuan.perjanjianKeagenan.checked = false;
            } else {
                $scope.syaratKetentuan.perjanjianKeagenan.checked = true;
                $scope.syaratKetentuan.agentId = $scope.dataCandidateParam.agentId;
                $scope.syaratKetentuan.npa = $scope.dataCandidateParam.npa;

                SyaratKetentuanService.saveDataSyaratKetentuan($scope.syaratKetentuan).then(
                    function (result) {
                        $rootScope.count1 = 1;
                        $state.go('syarat-dan-ketentuan-keagenan-checked');
                    },
                    function (error) {

                    }
                );

            }

        }

        if (param === 'ketentuanTambahan') {

            if ($scope.syaratKetentuan.ketentuanTambahan.haveFamily || $scope.syaratKetentuan.ketentuanTambahan.dontHaveFamily) {
                if ($scope.syaratKetentuan.ketentuanTambahan.haveFamily) {
                    if ($scope.syaratKetentuan.ketentuanTambahan.formData.name == undefined || $scope.syaratKetentuan.ketentuanTambahan.formData.name == "" || $scope.syaratKetentuan.ketentuanTambahan.formData.departemen == undefined || $scope.syaratKetentuan.ketentuanTambahan.formData.departemen == "") {
                        $rootScope.AlertDialog($filter('translate')('PRU_95'));
                    } else {
                        saveKetentuanTambahan();
                    }
                } else {
                    $scope.syaratKetentuan.ketentuanTambahan.checked = true;
                    $scope.syaratKetentuan.agentId = $scope.dataCandidateParam.agentId;
                    $scope.syaratKetentuan.npa = $scope.dataCandidateParam.npa;

                    SyaratKetentuanService.saveDataSyaratKetentuan($scope.syaratKetentuan).then(
                        function (result) {
                            $rootScope.count2 = 1;
                            $state.go('syarat-dan-ketentuan-keagenan-checked');
                        },
                        function (error) {
                            AppsLog.log(error);
                        }
                    );
                }
            } else {
                $rootScope.AlertDialog($filter('translate')('PRU_116'));
            }
        }

        if (param === 'pernyataanAgen') {
            if ($scope.syaratKetentuan.pernyataanAgen === undefined) {
                $scope.syaratKetentuan.pernyataanAgen = {};
                $scope.syaratKetentuan.pernyataanAgen.checked = false;
            }

            $scope.syaratKetentuan.pernyataanAgen.checked = true;
            $scope.syaratKetentuan.agentId = $scope.dataCandidateParam.agentId;
            $scope.syaratKetentuan.npa = $scope.dataCandidateParam.npa;


            SyaratKetentuanService.saveDataSyaratKetentuan($scope.syaratKetentuan).then(
                function (result) {
                    $rootScope.count3 = 1;
                    $state.go('syarat-dan-ketentuan-keagenan-checked');
                },
                function (error) {

                }
            );
        }
    }

    function saveKetentuanTambahan() {
        $scope.syaratKetentuan.ketentuanTambahan.checked = true;
        $scope.syaratKetentuan.agentId = $scope.dataCandidateParam.agentId;
        $scope.syaratKetentuan.npa = $scope.dataCandidateParam.npa;

        SyaratKetentuanService.saveDataSyaratKetentuan($scope.syaratKetentuan).then(
            function (result) {
                $state.go('syarat-dan-ketentuan-keagenan-checked');
            },
            function (error) {
                AppsLog.log(error);
            }
        );
    }

    $scope.goToSignature = function () {
        if ($scope.syaratKetentuan.perjanjianKeagenan.checked && $scope.syaratKetentuan.pernyataanAgen.checked && $scope.syaratKetentuan.ketentuanTambahan.checked) {
            $state.go('lembar-persetujuan-tanda-tangan');
        } else {
            $rootScope.AlertDialog($filter('translate')('PRU_75'));
        }
    }

    $scope.dontHaveFamilyClicked = function () {
        if ($scope.syaratKetentuan.ketentuanTambahan.dontHaveFamily === true) {
            $scope.syaratKetentuan.ketentuanTambahan.dontHaveFamily = true;
            $scope.syaratKetentuan.ketentuanTambahan.haveFamily = false;
            $scope.syaratKetentuan.ketentuanTambahan.formData.name = '';
            $scope.syaratKetentuan.ketentuanTambahan.formData.departemen = '';
        } else {
            $scope.syaratKetentuan.ketentuanTambahan.dontHaveFamily = true;
            // $scope.syaratKetentuan.ketentuanTambahan.haveFamily = false;
        }
    }

    $scope.haveFamilyClicked = function () {
        if ($scope.syaratKetentuan.ketentuanTambahan.haveFamily === true) {
            $scope.syaratKetentuan.ketentuanTambahan.dontHaveFamily = false;
            $scope.syaratKetentuan.ketentuanTambahan.haveFamily = true;
        }
        // else {
        //     $scope.syaratKetentuan.ketentuanTambahan.dontHaveFamily = false;
        //     $scope.syaratKetentuan.ketentuanTambahan.haveFamily = true;
        // }
    }

    $scope.backToAplPack = function () {
        $state.go("data-kandidat-pack");
    }
});

