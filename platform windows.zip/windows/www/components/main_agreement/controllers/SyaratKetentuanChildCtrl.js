﻿var pruforce = angular.module('PruForce');

pruforce.controller('SyaratKetentuanChildCtrl', function ($scope, $translate, $filter, $rootScope, $state) {


    $scope.user = {};
    $scope.nextPageKandidate = function (url) {
        $state.go(url);
    };

    $scope.appNext = function (url) {
        $state.go(url);
    };

    $scope.nextToSyaratMain = function (url) {
        if ($scope.user.name == undefined || $scope.user.name == '' || $scope.user.departement == undefined || $scope.user.departement == '') {
            $rootScope.AlertDialog($filter('translate')('PRU_95'));
        } else {
            $state.go(url);
        }
    };

});