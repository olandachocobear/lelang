﻿
angular.module('PruForce.controllers')
    .controller('LembarPersetujuanCtrl', function ($scope, $state, $translate, $filter, $ionicLoading, $ionicHistory, $stateParams, $rootScope, SignatureService, GetAplicationPackService, SpouseAgentService, SubmitDataCandidateService, FormulirPerekrutanService, SupportDocService, CheckAAJIService, CheckFastStartService, RecruitmentResultService, GetCountFastStartService, UploadSignatureService, CheckAAJICountLocalService, SubmitSosMedService, SubmitNotifByUserService, GetCountBPMProccessService, UploadDocumentReadyService, BPMResumeService, UpdateInboxService, InboxService, CancelSupportingDocService) {

        $scope.SignLabelCanvasRecruiter = $filter('translate')('MSG_SIGN_RECRUITER');
        $scope.SignLabelCanvasManager = $filter('translate')('MSG_SIGN_MANAGER');

        $scope.urlManagerSign = "#";
        $scope.urlRecruiterSign = "#";
        $scope.signLeaderClass = "sign-wrap red";
        $scope.signRecruiterClass = "sign-wrap red";
        if ($rootScope.agent.userType != 'candidate') {
            $scope.signRecruiterClass = "sign-wrap";
            $scope.signlabelRecruiter = true;
            $scope.signlabelCandidateOrManajer = false;
            $scope.urlRecruiterSign = "#/tanda-tangan/recruiterleader";
            $scope.SignLabelCanvas = $filter('translate')('SIGN_HERE');
        } else {
            $scope.signlabelRecruiter = false;
            $scope.signlabelCandidateOrManajer = true;
        }

        $scope.signature = SignatureService.signature().getSignatureData();
        $scope.readOnlyButton = false;
        var response;
        var countFastStartRegistration;
        var listDocuments = [];
        var tempListDocuments = [];
        var listPendingDocuments = [];
        var tempListPendingDoc = [];
        var listSosMed = [];
        var listSign = [];
        var signResult;

        $scope.goToSign = function (signParams) {
            if ($rootScope.agent.userType == 'candidate') {
                if (signParams == 'candidate') {
                    $state.go("tanda-tangan", { signParams: signParams });
                }
            } else {
                $state.go("tanda-tangan", { signParams: signParams });
            }
        }

        $scope.SubmitDataCandidate = function () {
            if ($rootScope.agent.userType != 'candidate') {
                if ($scope.signature[0].length == 0 || $scope.signature[1].length == 0) {
                    $rootScope.AlertDialog($filter('translate')('PRU_96'));
                } else {
                    $scope.SendCandidateData();
                }
            } else {
                if ($scope.signature[0].length == 0) {
                    $rootScope.AlertDialog($filter('translate')('PRU_96'));
                } else {
                    $scope.SendCandidateData();
                }
            }
        }

        $scope.SendCandidateData = function () {
            $ionicLoading.show();
            var dataCandidateParam = {
                agentId: $rootScope.agent.code,
                npa: $rootScope.candidate.npa
            }

            FormulirPerekrutanService.getRecExamResult(dataCandidateParam).then(function (res) {
                res.agentCode = $rootScope.agent.recruiteragentcode;
                try {
                    if (res.length != 0) {
                        RecruitmentResultService.invoke(res).then(function (res) {
                            SubmitRecExamSuccess();
                        });
                    } else {
                        SubmitRecExamSuccess();
                    }
                } catch (error) {
                    failedSubmit();
                }
            });


            function SubmitRecExamSuccess() {

                $rootScope.dbImage.transaction(function (tx) {

                    try {
                        tx.executeSql("SELECT * FROM tblImage where agentId = ? and npa = ? GROUP BY type", [dataCandidateParam.agentId, dataCandidateParam.npa], function (tx, result) {
                            for (var i = 0; i < result.rows.length; i++) {
                                if ($rootScope.platform == 'preview') {
                                    // this is for browser
                                    if (result.rows[i].imgBase64 != null && result.rows[i].imgBase64 != undefined && result.rows[i].imgBase64 != '' && result.rows[i].imgBase64 != 'undefined') {
                                        listDocuments.push({ filename: "JPG", filetype: result.rows[i].label, filebasestring: getSubstringImage(result.rows[i].imgBase64), islast: "true" });
                                    }

                                    var docType = parseInt(result.rows[i].type);
                                    if (docType != 11010201 && docType != 30010101 && docType != 13010209 && docType != 11010404 && docType != 30010109 && docType != 30010108 && docType != 30010110 && docType != 16010104 && docType != 16010103) {
                                        tempListDocuments.push(result.rows[i].label);
                                    }
                                } else {
                                    // this is for device
                                    if (result.rows.item(i).imgBase64 != null && result.rows.item(i).imgBase64 != undefined && result.rows.item(i).imgBase64 != '' && result.rows.item(i).imgBase64 != 'undefined') {
                                        listDocuments.push({ filename: "JPG", filetype: result.rows.item(i).label, filebasestring: getSubstringImage(result.rows.item(i).imgBase64), islast: "true" });
                                    }

                                    var docType = parseInt(result.rows.item(i).type);
                                    if (docType != 11010201 && docType != 30010101 && docType != 13010209 && docType != 11010404 && docType != 30010109 && docType != 30010108 && docType != 30010110 && docType != 16010104 && docType != 16010103) {
                                        tempListDocuments.push(result.rows.item(i).label);
                                    }
                                }
                            }
                        }, function (tx, error) {
                            AppsLog.log(error);
                        });

                    } catch (error) {
                        AppsLog.log(error);
                    }
                });

                if ($rootScope.flagPending) {

                    $rootScope.dbImage.transaction(function (tx) {
                        try {
                            tx.executeSql("SELECT * FROM tblPendingDoc where agentId = ? and npa = ?", [dataCandidateParam.agentId, dataCandidateParam.npa], function (tx, result) {
                                for (var i = 0; i < result.rows.length; i++) {
                                    if ($rootScope.platform == 'preview') {
                                        // this is for browser
                                        tempListPendingDoc.push(result.rows[i].docName);
                                    } else {
                                        // this is for device
                                        tempListPendingDoc.push(result.rows.item(i).docName);
                                    }
                                }
                            }, function (tx, error) {
                                AppsLog.log(error);
                            });

                        } catch (error) {
                            AppsLog.log(error);
                        }
                    });
                }



                GetAplicationPackService.getDataCandidatePack(dataCandidateParam).then(function (result) {

                    try {
                        response = result.json;
                        if (response.dataJejaring.facebook != '' && response.dataJejaring.facebook != undefined) {
                            listSosMed.push({ npa: response.npa, sosmedType: 'Facebook', accountname: response.dataJejaring.facebook, description: 'Success add Facebook' });
                        }
                        if (response.dataJejaring.twitter != '' && response.dataJejaring.twitter != undefined) {
                            listSosMed.push({ npa: response.npa, sosmedType: 'Twitter', accountname: response.dataJejaring.twitter, description: 'Success add Twitter' });
                        }
                        if (response.dataJejaring.linkedin != '' && response.dataJejaring.linkedin != undefined) {
                            listSosMed.push({ npa: response.npa, sosmedType: 'LinkedIn', accountname: response.dataJejaring.linkedin, description: 'Success add LinkedIn' });
                        }
                        if (response.dataJejaring.other != '' && response.dataJejaring.other != undefined) {
                            listSosMed.push({ npa: response.npa, sosmedType: 'Other', accountname: response.dataJejaring.other, description: 'Success add Other' });
                        }
                    } catch (error) {
                        AppsLog.log("error sosmed" + error);
                    }

                    if (response.dataKeagenan.spouseAlreadyAgent == 'Y') {
                        CheckSpouseAgent();
                    } else {
                        CheckAAJI();
                    }

                });
            }

            function getSubstringImage(base64Image) {
                var subStringImage;
                subStringImage = base64Image.substring(22, base64Image.length);
                return subStringImage;
            }

            function CheckSpouseAgent() {
                try {

                    var recruitersCode = response.dataKeagenan.recruitersCode;
                    SpouseAgentService.invoke(recruitersCode).then(function (res) {

                        if (res.invocationResult.isSuccessful) {
                            var reportingManagerLeader = res.invocationResult.reportingManagerId;
                            var spouseAgentCode = response.dataKeagenan.spouseAgentCode;
                            SpouseAgentService.invoke(spouseAgentCode).then(function (res) {
                                if (res.invocationResult.isSuccessful) {
                                    if (res.invocationResult.agentId == null || res.invocationResult.agentId == undefined || res.invocationResult.agentId == "") {
                                        $ionicLoading.hide();
                                        $rootScope.AlertDialog($filter('translate')('PRU_99'));
                                    } else {
                                        var reportingManagerSpouseAgent = res.invocationResult.reportingManagerId;
                                        if (reportingManagerLeader != reportingManagerSpouseAgent) {
                                            $ionicLoading.hide();
                                            $rootScope.AlertDialog($filter('translate')('PRU_99'));
                                        } else {
                                            CheckAAJI();
                                        }
                                    }

                                } else {
                                    failedSubmit();
                                }
                            });

                        } else {
                            failedSubmit();
                        }
                    });
                } catch (error) {
                    failedSubmit();

                }

            }
            function CheckAAJI() {
                CheckAAJICountLocalService.invoke(new Date(response.dataUjian.choosedDateDefault)).then(function (res) {
                    var count = res;
                    var date = new Date();
                    var currentHour = date.getHours();
                    var scheduleId = (response.dataUjian.choosedId).toString();
                    if (currentHour >= 11) {
                        if (count >= 6 && count <= 15) {
                            CheckAAJIService.invokeByCandidate(scheduleId).then(function (res) {
                                checkAAJISuccess(res);
                            });
                        } else {
                            $ionicLoading.hide();
                            $rootScope.AlertDialog($filter('translate')('PRU_54'));
                        }

                    } else {
                        if (count >= 5 && count <= 15) {
                            CheckAAJIService.invokeByCandidate(scheduleId).then(function (res) {
                                checkAAJISuccess(res);
                            });
                        } else {
                            $ionicLoading.hide();
                            $rootScope.AlertDialog($filter('translate')('PRU_55'));
                        }
                    }
                });


            }

            function checkAAJISuccess(res) {
                var agentCode = "";
                var aajiexamdate = $filter('date')(new Date(response.dataUjian.choosedDateDefault), 'yyyy-MM-dd');
                var aajischeduleid = (response.dataUjian.choosedId).toString();
                var aajiexamquota = res.invocationResult.aajiexamquota;
                var reserved = res.invocationResult.reserved;
                var isvalidexpireddate = res.invocationResult.isvalidexpireddate;
                var isvalidexamdate = res.invocationResult.isvalidexamdate;

                if (reserved == null) {
                    reserved = 0;
                }
                if (!isvalidexpireddate) {
                    $rootScope.AlertDialog($filter('translate')('PRU_61'));
                } else if (!isvalidexamdate) {
                    $rootScope.AlertDialog($filter('translate')('PRU_58'));
                } else if (reserved >= aajiexamquota) {
                    $rootScope.AlertDialog($filter('translate')('PRU_59'));
                } else {
                    if ($rootScope.flagPending) {
                        CheckAAJIService.changeAAJIRegistration(aajischeduleid, response.npa, agentCode, aajiexamdate).then(function (res) {
                            if (res.invocationResult.respCode == 200) {
                                GetCountFastStartRegistration();
                            } else {
                                failedSubmit();
                            }
                        });
                    } else {
                        SubmitUjianAAJI();
                    }
                }

            }

            function SubmitUjianAAJI() {
                var agentCode = null;
                var aajiexamdate = $filter('date')(new Date(response.dataUjian.choosedDateDefault), 'yyyy-MM-dd');
                var aajischeduleid = (response.dataUjian.choosedId).toString();
                var statusagent = response.dataKeagenan.AgentStatus;
                CheckAAJIService.submitAAJIRegistration(aajischeduleid, response.npa, agentCode, aajiexamdate, statusagent).then(function (res) {
                    if (res.invocationResult.respCode == 200) {
                        GetCountFastStartRegistration();
                    } else {
                        failedSubmit();
                    }
                });

            }

            function GetCountFastStartRegistration() {
                GetCountFastStartService.invoke(response.npa).then(function (res) {
                    var countFastStartRegistration = res.invocationResult.array[0].count;
                    CheckFastStart(countFastStartRegistration);
                });
            }

            function CheckFastStart(countFastStartRegistration) {
                var dataFastStart = {};
                dataFastStart.faststarttype = response.dataFastStart.trainingType == 1 ? "PSA" : "GL";
                if (dataFastStart.faststarttype == 'PSA') {
                    dataFastStart.fstscheduleid = (response.dataFastStart.choosed.faststartscheduleid).toString();
                    dataFastStart.couseCode = response.dataFastStart.choosed.courseCode;
                    dataFastStart.faststartdate = response.dataFastStart.choosed.faststartdate;
                    dataFastStart.agentcode = null;
                    dataFastStart.description = response.dataFastStart.choosed.courseDesc;
                    if (dataFastStart.faststarttype == 'PSA' && countFastStartRegistration != 0) {
                        ChangeFastStartRegistration(dataFastStart);
                    } else if (dataFastStart.faststarttype == 'PSA' && countFastStartRegistration == 0) {
                        SubmitFastStartRegistration(dataFastStart);
                    }
                } else {
                    SubmitDataKandidat();
                }

            }

            function ChangeFastStartRegistration(dataFastStart) {
                CheckFastStartService.invokeUpdate(dataFastStart.fstscheduleid, response.npa, dataFastStart.agentcode, dataFastStart.couseCode, dataFastStart.faststarttype, dataFastStart.faststartdate, dataFastStart.description).then(function (res) {
                    if (res.invocationResult.respCode == 200) {
                        SubmitDataKandidat();
                    } else {
                        failedSubmit();
                    }
                });
            }

            function SubmitFastStartRegistration(dataFastStart) {
                CheckFastStartService.invokeSubmit(dataFastStart.fstscheduleid, response.npa, dataFastStart.agentcode, dataFastStart.couseCode, dataFastStart.faststarttype, dataFastStart.faststartdate, dataFastStart.description).then(function (res) {
                    if (res.invocationResult.respCode == 200) {
                        SubmitDataKandidat();
                    } else {
                        failedSubmit();
                    }
                });
            }


            function SubmitDataKandidat() {
                if ($rootScope.flagPending) {
                    listPendingDocuments = tempListPendingDoc.filter(function (obj) { return tempListDocuments.indexOf(obj) == -1; });
                }

                var date = $filter('date')(new Date(), 'yyyy-MM-dd')
                response.date = date;
                response.signaturecity = "Jakarta";

                if (response.dataPribadi.gender == "M") {
                    response.candidatetitle = "BAPAK";
                } else {
                    response.candidatetitle = "IBU";
                }

                // checking pribadi

                if (response.dataPribadi.cellPhone.phone2 == undefined) {
                    response.dataPribadi.cellPhone.phone2 = '';
                }
                if (response.dataPribadi.cellPhone.phone3 == undefined) {
                    response.dataPribadi.cellPhone.phone3 = '';
                }

                // checking npwp data 
                if (response.dataPajak.npwpStatus != 'no') {
                    response.dataPajak.npwpNumber = (response.dataPajak.npwpNumber).toString();
                    response.dataPajak.zipCode = (response.dataPajak.zipCode).toString();
                } else {
                    response.dataPajak.npwpNumber = '';
                }

                // checking family 
                if (response.dataKeluarga.spouseDateOfBirth != undefined && response.dataKeluarga.spouseDateOfBirth != null && response.dataKeluarga.spouseDateOfBirth != '' && response.dataKeluarga.spouseDateOfBirth != 'undefined') {
                    response.dataKeluarga.spouseDateOfBirth = $filter('date')(new Date(response.dataKeluarga.spouseDateOfBirth), 'yyyy-MM-dd');
                }

                if (response.dataKeluarga.childrens != null && response.dataKeluarga.childrens != '' && response.dataKeluarga.childrens != undefined && response.dataKeluarga.childrens != "undefined") {
                    response.dataKeluarga.childrens = (response.dataKeluarga.childrens).toString();
                }

                if (response.dataKeluarga.childrens == 0 || response.dataKeluarga.childrens == 00) {
                    response.dataKeluarga.childrens = "0";
                }

                if (response.dataKeluarga.childrens == null || response.dataKeluarga.childrens == undefined) {
                    response.dataKeluarga.childrens = '';
                }
                // checking keagenan
                if (response.dataKeagenan.spouseAlreadyAgent == 'Y') {
                    response.dataKeagenan.spouseAgentCode = (response.dataKeagenan.spouseAgentCode).toString();
                } else {
                    response.dataKeagenan.spouseAgentCode = '';
                }
                if (response.dataKeagenan.havePolis == 'Y') {
                    response.dataKeagenan.polisNumber = (response.dataKeagenan.polisNumber).toString();
                } else {
                    response.dataKeagenan.polisNumber = '';
                }

                // convert to format yyyy-MM-dd
                response.dataPribadi.idCardExpDate = $filter('date')(new Date(response.dataPribadi.idCardExpDate), 'yyyy-MM-dd');
                if (response.dataPribadi.isIdCardUnExpired) {
                    response.dataPribadi.idCardExpDate = '2999-12-12';
                }
                response.dataPribadi.candidateDob = $filter('date')(new Date(response.dataPribadi.candidateDobDefault), 'yyyy-MM-dd');
                //convert all number to string
                response.dataPribadi.zipcode = (response.dataPribadi.zipcode).toString();
                response.dataPribadi.graduationYear = (response.dataPribadi.graduationYear).toString();
                response.dataRekening.bankAccountNumber = (response.dataRekening.bankAccountNumber).toString();

                SubmitDataCandidateService.invoke(response).then(function (res) {
                    var doubleSubmitMessage;
                    if ($rootScope.agent.userType != 'candidate') {
                        doubleSubmitMessage = $filter('translate')('PRU_102') + " " + response.dataPribadi.name;
                    } else {
                        if ($rootScope.flagPending) {
                            doubleSubmitMessage = $filter('translate')('PRU_122');
                        } else {
                            doubleSubmitMessage = $filter('translate')('PRU_103') + " " + response.dataKeagenan.recruitersName;
                        }
                    }

                    if (res.invocationResult.respCode == 200) {
                        if (res.invocationResult.respDesc == "00") {
                            UploadImage();
                            getAndUploadSignature();
                            if ($rootScope.flagPending) {
                                removeDocument();
                            }
                        } else if (res.invocationResult.respDesc == "02") {
                            $ionicLoading.hide();
                            $rootScope.AlertDialog(doubleSubmitMessage);
                        } else {
                            failedSubmit();
                        }
                    } else {
                        failedSubmit();
                    }
                });
            }


            function UploadImage() {
                for (var j = 0; j < listDocuments.length; j++) {
                    var islast = "true";
                    SupportDocService.invoke(response.npa, listDocuments[j].filename, listDocuments[j].filetype, listDocuments[j].filebasestring, islast).then(function (res) {
                        if (res.invocationResult.respCode == 200) {
                        } else {
                            failedSubmit();
                        }
                    });
                }
            }

            function getAndUploadSignature() {

                if ($rootScope.agent.userType != 'candidate') {
                    if ($rootScope.agent_isLeader) {
                        var filebasestring = $filter('limitTo')($scope.signature[1], $scope.signature[1].length, 22);
                        listSign.push({ filename: 'JPG', filetype: 'leader', filebasestring: filebasestring, changes: 'false' });
                    } else {
                        var filebasestring = $filter('limitTo')($scope.signature[1], $scope.signature[1].length, 22);
                        listSign.push({ filename: 'JPG', filetype: 'recruiter', filebasestring: filebasestring, changes: 'false' });
                    }
                }

                var filebasestring = $filter('limitTo')($scope.signature[0], $scope.signature[0].length, 22);
                listSign.push({ filename: 'JPG', filetype: 'candidate', filebasestring: filebasestring, changes: 'false' });

                var countUploadSignature = 0;
                for (i = 0; i < listSign.length; i++) {
                    UploadSignatureService.invoke(response.npa, listSign[i].filename, listSign[i].filetype, listSign[i].filebasestring, listSign[i].changes).then(function (res) {
                        if (res.invocationResult.respCode == 200) {
                            countUploadSignature++;
                            if (countUploadSignature == listSign.length) {
                                getCountBPMProccess();
                            }
                        } else {
                            failedSubmit();
                        }
                    });
                }

            }

            function removeDocument() {
                if (listPendingDocuments.length > 0) {
                    for (var i = 0; i < listPendingDocuments.length; i++) {
                        var docId = '';
                        var docName = listPendingDocuments[i];
                        var docType = listPendingDocuments[i];
                        CancelSupportingDocService.invoke(docId, docName, docType, response.npa).then(function (res) {
                            if (res.invocationResult.statusCode == 200) {
                                console.log("succes remove");
                            } else {
                                console.log("error remove");
                            }
                        });
                    }
                }
            }

            function getCountBPMProccess() {
                GetCountBPMProccessService.invoke(response.npa).then(function (res) {
                    if (res.invocationResult.statusCode == 200) {
                        var count_bpmprocess = res.invocationResult.array[0].count;
                        if (count_bpmprocess == 0) {
                            cekIdLogin();
                        } else {
                            SubmitBpmResume();
                        }
                    } else {
                        failedSubmit();
                    }
                });
            }
            function cekIdLogin() {
                if ($rootScope.agent.userType == 'candidate') {
                    submitNotificationToAgent();
                } else {
                    if ($rootScope.agent_isLeader) {
                        submitDocumentReady();
                    } else {
                        submitNotificationToLeader();
                    }
                }
            }
            function submitNotificationToAgent() {

                /*eventId for sign is 99583 (this based on back office) */
                var eventId = 99583;
                var userId = response.dataKeagenan.recruitersCode;
                var payload = {};
                payload.reqId = 'sign';
                payload.npa = response.npa;
                payload.docList = 'From Candidate';
                payload.candidatename = response.dataPribadi.name;

                SubmitNotifByUserService.invoke(userId, eventId, pushNotifToken, payload).then(function (res) {
                    if (res.invocationResult.statusCode == 200) {
                        SubmitSosmed();
                    } else {
                        failedSubmit();
                    }
                });
            }

            function submitDocumentReady() {
                UploadDocumentReadyService.invoke(response.npa).then(function (res) {
                    if (res.invocationResult.respCode == 200) {
                        SubmitSosmed();
                    } else {
                        failedSubmit();
                    }
                });
            }

            function submitNotificationToLeader() {
                /*eventId for sign is 99583 (this based on back office) */
                var eventId = 99583;
                var userId = response.dataKeagenan.managerCode;
                var payload = {};
                payload.reqId = "sign";
                payload.npa = response.npa;
                payload.docList = 'From Recruiter';
                payload.candidatename = response.dataPribadi.name;

                SubmitNotifByUserService.invoke(userId, eventId, pushNotifToken, payload).then(function (res) {
                    if (res.invocationResult.statusCode == 200) {
                        SubmitSosmed();
                    } else {
                        failedSubmit();
                    }
                });
            }

            function SubmitBpmResume() {
                BPMResumeService.invoke(response.npa).then(function (res) {
                    if (res.invocationResult.respCode == 200) {
                        SubmitSosmed();
                    } else {
                        failedSubmit();
                    }
                });
            }

            function SubmitSosmed() {

                try {
                    if (listSosMed.length != 0) {
                        var countSubmitSosMed = 0;

                        for (var i = 0; i < listSosMed.length; i++) {

                            SubmitSosMedService.invoke(listSosMed[i].npa, listSosMed[i].sosmedType, listSosMed[i].accountname, listSosMed[i].description).then(function (res) {

                                if (res.invocationResult.respCode == 200) {
                                    countSubmitSosMed++;
                                    if (countSubmitSosMed == listSosMed.length) {
                                        removeLocalData();
                                        $ionicLoading.hide();
                                        $state.go("aplikasi-berhasil-dikirim");
                                    }
                                } else {
                                    failedSubmit();
                                }
                            });
                        }
                    } else {
                        removeLocalData();
                        $ionicLoading.hide();
                        $state.go("aplikasi-berhasil-dikirim");
                    }

                } catch (error) {
                    failedSubmit();
                }
            }
        }

        function removeLocalData() {

            $ionicHistory.nextViewOptions({
                disableAnimate: true,
                disableBack: true
            });
            $rootScope.dbImage.transaction(function (tx) {
                AppsLog.log('DELETE tblImage: ');
                var query = "DELETE FROM tblImage WHERE agentId = ? and npa = ?";
                var params = [$rootScope.agent.code, response.npa];
                tx.executeSql(query, params, function (tx, res) {
                    AppsLog.log('DELETE success: ');
                }, function (tx, error) {
                    AppsLog.log('DELETE error: ' + error.message);
                });
            });

            if ($rootScope.flagPending) {
                $rootScope.dbImage.transaction(function (tx) {
                    AppsLog.log('DELETE tblPendingDoc: ');
                    var query = "DELETE FROM tblPendingDoc WHERE agentId = ? and npa = ?";
                    var params = [$rootScope.agent.code, response.npa];
                    tx.executeSql(query, params, function (tx, res) {
                        AppsLog.log('success DELETE');
                    }, function (tx, error) {
                        AppsLog.log('DELETE error: ' + error.message);
                    });
                });
            }

            var query = { agentId: $rootScope.agent.code, npa: response.npa };
            var options = {
                exact: true,
            };

            WL.JSONStore.get('CandidatePackData').remove(query, options).then(function (numberOfDocumentsRemoved) {
                console.log('success remove data');
            }).fail(function (errorObject) {
                console.log('failure remove data');
            });
        }

        $scope.goToHome = function () {

            $ionicHistory.nextViewOptions({
                disableAnimate: true,
                disableBack: true
            });

            $ionicLoading.show();

            if ($rootScope.flagPending) {
                UpdateInboxService.invoke($rootScope.inbox.idInbox).then(function (res) {
                    $ionicLoading.hide();
                    if (res.invocationResult.statusCode == 200) {
                        $state.go("home-menu.candidate");
                    } else {
                        $state.go("home-menu.candidate");
                    }
                });
            } else {
                if ($rootScope.agent.userType == 'candidate') {
                    localStorage['CandidateSubmit' + $rootScope.candidate.npa] = true;
                    $state.go("home-menu.candidate");
                } else {
                    $state.go("home-menu.agent");
                }
            }

        }

        function failedSubmit() {
            $ionicLoading.hide();
            $rootScope.AlertDialog($filter('translate')('PRU_44'));
            return false;
        }
    });