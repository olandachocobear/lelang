﻿angular.module('PruForce.services')

	.service('GetAplicationPackService', function ($q, $filter, AOBResources, $rootScope, GetSupportDocService, GetSosMedService, GetFastStartService, GetAAJIService, GetAAJICityService, CandidateFactory, GetAMLScoreService, GetDocByNPAService) {

		var collection = JsonStoreConfig.DataCandidatePack;
		var candidatePack = {};
		var imageCandidatePack = {};
		var imageArray = {};
		var statusImage = '';
		imageArray.listImageCandidate = [];
		candidatePack.dataPribadi = {};
		candidatePack.dataRekening = {};
		candidatePack.dataPajak = {};
		candidatePack.dataKeluarga = {};
		candidatePack.dataKeagenan = {};
		candidatePack.dataJejaring = {};
		candidatePack.dataFastStart = {};
		candidatePack.dataUjian = {};
		imageCandidatePack.dataPribadi = {};
		imageCandidatePack.dataRekening = {};
		imageCandidatePack.dataPajak = {};
		imageCandidatePack.dataDokumen = [];

		function getDataCandidatePack(candidateParam) {
			var deferred = $q.defer();
			$rootScope.candidate.detailwithnpa = candidateParam.npa;
			var networkState = navigator.connection.type;
			var promise;
			if (networkState == Connection.NONE) {
				promise = getDataCandidatePackFromJsonStore(candidateParam);
			} else {
				var childpromise;
				try {
					promise = getDataCandidatePackFromJsonStore(candidateParam).then(
						function (result) {
							if (result === 'empty') {
								childpromise = getDataCandidatePackFromServer(candidateParam).then(
									function (res) {
										return getDataCandidatePackFromJsonStore(candidateParam);
									},
									function (error) {
										return "empty";
									}
								);
							} else {
								if ($rootScope.candidate.statusAgentJourney == 'complete' && $rootScope.agent.userType != 'candidate') {
									childpromise = getDataCandidatePackFromServer(candidateParam).then(
										function (res) {
											return getDataCandidatePackFromJsonStore(candidateParam);
										},
										function (error) {
											return "empty";
										}
									);
								} else {
									childpromise = getDataCandidatePackFromJsonStore(candidateParam);
								}
							}

							return childpromise;
						},
						function (error) {
							deferred.reject(error);
						}
					);
				} catch (error) {
					AppsLog.log("candidate erorrnya :" + error);
				}
			}
			return promise;
		};

		function getImageCandidatePack(candidateParam) {
			var deferred = $q.defer();
			$rootScope.candidate.detailwithnpa = candidateParam.npa;
			var networkState = navigator.connection.type;
			var promise;
			if (networkState == Connection.NONE) {
				promise = getImageCandidatePackFromJsonStore(candidateParam);
			} else {
				var childpromise;
				try {
					promise = getImageCandidatePackFromJsonStore(candidateParam).then(
						function (result) {
							if (result === 'empty') {
								childpromise = getImageCandidatePackFromServer(candidateParam).then(
									function (res) {
										return getImageCandidatePackFromJsonStore(candidateParam);
									},
									function (error) {
										return "empty";
									}
								);
							} else {
								if ($rootScope.candidate.statusAgentJourney == 'complete' && $rootScope.agent.userType != 'candidate') {
									childpromise = getImageCandidatePackFromServer(candidateParam).then(
										function (res) {
											return getImageCandidatePackFromJsonStore(candidateParam);
										},
										function (error) {
											return "empty";
										}
									);
								} else {
									childpromise = result;
								}
							}

							return childpromise;
						},
						function (error) {
							deferred.reject(error);
						}
					);
				} catch (error) {
					AppsLog.log("image candidate erorrnya :" + error);
				}
			}
			return promise;
		};

		function getDataCandidatePackFromJsonStore(candidateParam) {
			var deferred = $q.defer();
			try {
				var query = candidateParam;
				var options = {
					exact: false
				};

				WL.JSONStore.get(collection.JSONSTORE_NAME).find(query, options).then(function (res) {
					try {
						if (res.length > 0) {
							deferred.resolve(res[0]);
						} else {
							deferred.resolve("empty");
						}
					} catch (error) {
						deferred.reject(error);
					}
				}).fail(function (error) {
					deferred.reject(error);
				});
			} catch (error) {
				deferred.reject(error);
			}

			return deferred.promise;
		}

		function getImageCandidatePackFromJsonStore(candidateParam) {
			var deferred = $q.defer();
			imageCandidatePack.dataPribadi = {};
			imageCandidatePack.dataRekening = {};
			imageCandidatePack.dataPajak = {};
			imageCandidatePack.dataDokumen = [];
			$rootScope.dbImage.transaction(function (tx) {
				var query = "SELECT * FROM tblImage where agentId = ? and npa = ? GROUP BY type";
				var params = [candidateParam.agentId, candidateParam.npa];

				tx.executeSql(query, params, function (tx, result) {
					if (result.rows.length <= 0) {
						deferred.resolve("empty");
					} else {
						var imageType;
						var imgBase64;
						var label;
						for (var i = 0; i < result.rows.length; i++) {
							try {
								if ($rootScope.platform == 'preview') {
									imageType = (result.rows[i].type).toString();
									imgBase64 = result.rows[i].imgBase64;
									label = result.rows[i].label;
									statusImage = result.rows[i].statusImage;
								} else {
									imageType = (result.rows.item(i).type).toString();
									imgBase64 = result.rows.item(i).imgBase64;
									label = result.rows.item(i).label;
									statusImage = result.rows.item(i).statusImage;
								}
								var imageTypeParse = parseInt(imageType);
								switch (imageTypeParse) {
									case 11010201:
										imageCandidatePack.dataPribadi.ktpImage = imgBase64;
										break;

									case 30010101:
										imageCandidatePack.dataPribadi.profileImage = imgBase64;
										break;

									case 13010209:
										imageCandidatePack.dataRekening.foto = imgBase64;
										break;

									case 11010404:
										imageCandidatePack.dataPajak.npwpImage = imgBase64;
										break;

									case 11010203:
										imageCandidatePack.dataDokumen.push({ file: imgBase64, type: imageType, label: label });
										break;

									case 30020107:
										imageCandidatePack.dataDokumen.push({ file: imgBase64, type: imageType, label: label });
										break;

									case 30020104:
										imageCandidatePack.dataDokumen.push({ file: imgBase64, type: imageType, label: label });
										break;

									case 11010207:
										imageCandidatePack.dataDokumen.push({ file: imgBase64, type: imageType, label: label });
										break;

									case 11010210:
										imageCandidatePack.dataDokumen.push({ file: imgBase64, type: imageType, label: label });
										break;

									case 30010103:
										imageCandidatePack.dataDokumen.push({ file: imgBase64, type: imageType, label: label });
										break;

									case 30010104:
										imageCandidatePack.dataDokumen.push({ file: imgBase64, type: imageType, label: label });
										break;

									case 30010105:
										imageCandidatePack.dataDokumen.push({ file: imgBase64, type: imageType, label: label });
										break;

									case 30010106:
										imageCandidatePack.dataDokumen.push({ file: imgBase64, type: imageType, label: label });
										break;

									case 30020101:
										imageCandidatePack.dataDokumen.push({ file: imgBase64, type: imageType, label: label });
										break;

									case 30020102:
										imageCandidatePack.dataDokumen.push({ file: imgBase64, type: imageType, label: label });
										break;

									case 30020103:
										imageCandidatePack.dataDokumen.push({ file: imgBase64, type: imageType, label: label });
										break;

									case 30020105:
										imageCandidatePack.dataDokumen.push({ file: imgBase64, type: imageType, label: label });
										break;

									case 30020106:
										imageCandidatePack.dataDokumen.push({ file: imgBase64, type: imageType, label: label });
										break;

									case 30020109:
										imageCandidatePack.dataDokumen.push({ file: imgBase64, type: imageType, label: label });
										break;

									case 30010109:
										imageCandidatePack.dataDokumen.push({ file: imgBase64, type: imageType, label: label });
										break;

									case 30010108:
										imageCandidatePack.dataDokumen.push({ file: imgBase64, type: imageType, label: label });
										break;

									case 80000002:
										imageCandidatePack.dataDokumen.push({ file: imgBase64, type: imageType, label: label });
										break;
								}
							} catch (error) {
								deferred.reject(error);
							}
						}
						deferred.resolve(imageCandidatePack);
					}
				}, function (tx, error) {
					AppsLog.log('SELECT error: ' + error.message);
					deferred.reject(error);
				});
			});
			return deferred.promise;
		}

		function convertToDate(dateStr) {
			try {
				var dateParts = dateStr.match(/(\d+)-(\d+)-(\d+) (\d+):(\d+):(\d+)/);
				var result = new Date(dateParts[1], parseInt(dateParts[2], 10) - 1, dateParts[3], dateParts[4], dateParts[5], dateParts[6]);
				return result;
			} catch (error) {
				AppsLog.log('error get date' + error);
			}

		}

		function getDataCandidatePackFromServer(candidateParam) {
			var deferred = $q.defer();
			var req = {
				adapter: "HTTPAdapterAuth",
				procedure: "getDataApplicationPack",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + candidateParam.npa + "']" }
			};

			CheckingFastStart(candidateParam.npa);
			CheckingAAJI(candidateParam.npa);
			CheckingSosMed(candidateParam.npa);

			CandidateFactory.invoke(req, false)
				.then(function (result) {
					var res = result;

					candidatePack.agentId = candidateParam.agentId;
					candidatePack.npa = candidateParam.npa;

					candidatePack.activeCandidate = res.activeflag;
					candidatePack.rejectStatus = res.reason;
					candidatePack.candidatesignature = res.candidatesignature;

					candidatePack.dataPribadi.name = res.candidateName;
					candidatePack.dataPribadi.candidateDobDefault = res.candidateDobStr;
					candidatePack.dataPribadi.candidateDob = $filter('date')(new Date(res.candidateDobStr), 'dd/MM/yyyy');;
					candidatePack.dataPribadi.candidateIdCardNo = res.candidateIdCardNo;
					candidatePack.dataPribadi.candidateCellularNo1 = res.candidateCellularNo1;
					candidatePack.dataPribadi.candidateEmail = res.candidateEmail;
					$rootScope.candidate.npa = res.npaNumber;
					$rootScope.candidate.name = res.candidateName;
					$rootScope.candidate.candidateDob = res.candidateDobStr;
					$rootScope.candidate.candidateIdCardNo = res.candidateIdCardNo;
					$rootScope.candidate.candidateCellularNo1 = res.candidateCellularNo1;
					$rootScope.candidate.candidateEmail = res.candidateEmail;

					candidatePack.dataPribadi.placeofbirth = res.candidateplaceofbirth;
					candidatePack.dataPribadi.gender = res.candidategender;
					candidatePack.dataPribadi.religion = res.candidatereligion;
					candidatePack.dataPribadi.alamat1 = res.candidateaddress1;
					candidatePack.dataPribadi.alamat2 = res.candidateaddress2;
					candidatePack.dataPribadi.alamat3 = res.candidateaddress3;
					candidatePack.dataPribadi.city = res.candidatecity;
					candidatePack.dataPribadi.province = res.candidateprovice;
					candidatePack.dataPribadi.zipcode = parseInt(res.candidatezipcode);
					if (res.candidatephoneno != null && res.candidatephoneno != '' && res.candidatephoneno != undefined) {
						var homeCodeArea = res.candidatephoneno.substring(3, 5);
						var homeCodeFilter = $filter('filter')($rootScope.codeArea, { id: homeCodeArea });
						if (homeCodeFilter.length > 0) {
							candidatePack.dataPribadi.candidatephonecode = 0 + homeCodeArea;
							candidatePack.dataPribadi.homePhone = res.candidatephoneno.substring(5);
						} else {
							candidatePack.dataPribadi.candidatephonecode = 0 + res.candidatephoneno.substring(3, 6);
							candidatePack.dataPribadi.homePhone = res.candidatephoneno.substring(6);
						}

					} else {
						candidatePack.dataPribadi.candidatephonecode = res.candidatephonecode;
						candidatePack.dataPribadi.homePhone = res.candidatephoneno;
					}

					if (res.candidateofficephoneno != null && res.candidateofficephoneno != '' && res.candidateofficephoneno != undefined) {
						var officeCodeArea = res.candidateofficephoneno.substring(3, 5);
						var officeCodeFilter = $filter('filter')($rootScope.codeArea, { id: homeCodeArea });
						if (officeCodeFilter.length > 0) {
							candidatePack.dataPribadi.candidateofficephonecode = 0 + officeCodeArea;
							candidatePack.dataPribadi.officePhone = res.candidateofficephoneno.substring(5);
						} else {
							candidatePack.dataPribadi.candidateofficephonecode = 0 + res.candidateofficephoneno.substring(3, 6);
							candidatePack.dataPribadi.officePhone = res.candidateofficephoneno.substring(6);
						}

					} else {
						candidatePack.dataPribadi.candidateofficephonecode = res.candidateofficephonecode;
						candidatePack.dataPribadi.officePhone = res.candidateofficephoneno;
					}

					candidatePack.dataPribadi.cellPhone = {};
					try {
						if (res.candidateCellularNo1 != undefined && res.candidateCellularNo1 != "") {
							candidatePack.dataPribadi.cellPhone['phone1'] = 0 + (res.candidateCellularNo1.substring(3, res.candidateCellularNo1.length));
						}

						if (res.candidatecellularno2 != undefined && res.candidatecellularno2 != "") {
							candidatePack.dataPribadi.cellPhone['phone2'] = 0 + (res.candidatecellularno2.substring(3, res.candidatecellularno2.length));
						}

						if (res.candidatecellularno3 != undefined && res.candidatecellularno3 != "") {
							candidatePack.dataPribadi.cellPhone['phone3'] = 0 + (res.candidatecellularno3.substring(3, res.candidatecellularno3.length));
						}

					} catch (error) {
						AppsLog.log(error);
					}

					if (res.candidateidexipred !== "") {
						if (res.candidateidexipred == '2999-12-12' || res.candidateidexipred == '2999-12-12 00:00:00') {
							candidatePack.dataPribadi.isIdCardUnExpired = true;
						} else {
							var expiredDate = convertToDate(res.candidateidexipred);

							if (!angular.isDate(expiredDate)) {
							} else {
								var dbDate = expiredDate;
								var maxDate = new Date('2999-12-12 00:00:00');
								if (dbDate >= maxDate) {
									candidatePack.dataPribadi.isIdCardUnExpired = true;
								} else {
									candidatePack.dataPribadi.idCardExpDate = dbDate;
									candidatePack.dataPribadi.isIdCardUnExpired = false;
								}
							}
						}
					}

					candidatePack.dataPribadi.education = res.candidateeducation;
					candidatePack.dataPribadi.graduationYear = parseInt(res.candidateGraduationYear);
					candidatePack.dataPribadi.schoolName = res.candidateLastSchoolName;
					candidatePack.dataPribadi.maritalStatus = res.candidatemaritalstatus;

					candidatePack.dataRekening.bankAccountNumber = parseInt(res.bankaccount);
					candidatePack.dataRekening.bankName = res.bankname;
					candidatePack.dataRekening.bankBranchOffice = res.bankbranch;
					candidatePack.dataRekening.bankAccountName = res.bankaccountname;

					candidatePack.dataPajak.npwpStatus = res.npwpstatus;
					if (res.npwpno == '' || res.npwpno == undefined) {
						candidatePack.dataPajak.npwpNumber = res.npwpno;
					} else {
						candidatePack.dataPajak.npwpNumber = res.npwpno.replace(/\-/g, "");
					}
					candidatePack.dataPajak.npwpName = res.npwpname;
					candidatePack.dataPajak.address1 = res.npwpaddress1;
					candidatePack.dataPajak.address2 = res.npwpaddress2;
					candidatePack.dataPajak.address3 = res.npwpaddress3;
					candidatePack.dataPajak.city = res.npwpcity;
					candidatePack.dataPajak.province = res.npwpprovince;
					candidatePack.dataPajak.zipCode = res.npwpzipcode;

					candidatePack.dataKeluarga.spouseName = res.spousename;

					var isValidSpouseDate = WL.Client.getEnvironment() === WL.Environment.IPAD || WL.Client.getEnvironment() === WL.Environment.IPHONE ? angular.isDate(res.spousedob) : moment(res.spousedob, "YYYY/MM/DD hh:mm:ss", true).isValid();
					if (res.spousedob !== "") {
						var spouseDob = convertToDate(res.spousedob);
						if (!angular.isDate(spouseDob)) {
							AppsLog.log("not set date");
						} else {
							candidatePack.dataKeluarga.spouseDateOfBirth = spouseDob;
						}
					}

					candidatePack.dataKeluarga.spouseIdCardNumber = res.spouseidcardno;
					candidatePack.dataKeluarga.spouseJobs = res.spousejob;
					candidatePack.dataKeluarga.spouseCompanyName = res.spousecompany;
					candidatePack.dataKeluarga.childrens = res.spousechild;

					candidatePack.dataKeagenan.AgentStatus = res.isreinstate;
					candidatePack.dataKeagenan.candidateOfficeMarketing = res.candidateofficecode;
					candidatePack.dataKeagenan.spouseAlreadyAgent = res.spouseisagent;
					candidatePack.dataKeagenan.spouseAgentCode = res.spouseagentcode;
					candidatePack.dataKeagenan.recruitersName = res.recruitername;
					candidatePack.dataKeagenan.recruitersCode = res.recruiteragentcode;
					candidatePack.dataKeagenan.recruitersOffice = res.recruiterofficecode;
					candidatePack.dataKeagenan.managerName = res.leadername;
					candidatePack.dataKeagenan.managerCode = res.leaderagentcode;
					candidatePack.dataKeagenan.recruitersManagerOffice = res.leaderofficecode;
					candidatePack.dataKeagenan.havePolis = res.isanypolispru;
					candidatePack.dataKeagenan.polisNumber = res.polisnumber;
					candidatePack.dataKeagenan.workInInsuranceCompany = res.workinsurance;
					candidatePack.dataKeagenan.insurancecompany1 = res.insurance1;
					candidatePack.dataKeagenan.insurancecompany2 = res.insurance2;
					candidatePack.dataKeagenan.insurancecompany3 = res.insurance3;
					candidatePack.dataKeagenan.insurancecompany4 = res.insurance4;
					candidatePack.dataKeagenan.recruitVia = res.recruitmethode;
					saveDataCandidate(candidatePack).then(
						function (result) {
							deferred.resolve("done");
						},
						function (error) {
							deferred.reject(error);
						}
					);

				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		function getImageCandidatePackFromServer(candidateParam) {
			if ($rootScope.flagBPMSubmit) {
				var deferred = $q.defer();
				GetSupportDocService.invoke(candidateParam.npa).then(function (res) {
					var res = res.invocationResult;
					if (res.respCode == 200) {
						imageCandidatePack.agentId = candidateParam.agentId;
						imageCandidatePack.npa = candidateParam.npa;
						if (res.result.length != 0) {
							removeImageByNPA(candidateParam);
							imageDataCandidatePack(res);
							imageCandidatePack.listImageCandidate = imageArray.listImageCandidate;
							saveImageCandidate(imageCandidatePack, false).then(
								function (result) {
									deferred.resolve("done");
								},
								function (error) {
									deferred.reject(error);
								}
							);
						} else {
							deferred.resolve("empty");
						}

					} else if (res.respCode == 404) {
						deferred.resolve("empty");
					}
				});
				return deferred.promise;

			} else {
				try {
					var deferred = $q.defer();
					GetDocByNPAService.invoke(candidateParam.npa).then(function (res) {
						var res = res.invocationResult;
						imageCandidatePack.agentId = candidateParam.agentId;
						imageCandidatePack.npa = candidateParam.npa;
						if (res.result.length != 0) {
							removeImageByNPA(candidateParam);
							imageDataCandidatePack(res);
							imageCandidatePack.listImageCandidate = imageArray.listImageCandidate;
							saveImageCandidate(imageCandidatePack, false).then(
								function (result) {
									deferred.resolve("done");
								},
								function (error) {
									deferred.reject(error);
								}
							);
						} else {
							deferred.resolve("empty");
						}
					});
					return deferred.promise;
				} catch (error) {
					AppsLog.log(error);
				}
			}
		}

		function imageDataCandidatePack(res) {
			imageArray.listImageCandidate = [];
			for (var i = 0; i < res.result.length; i++) {
				if (res.result[i].fileBase64 != undefined && res.result[i].fileBase64 != '' && res.result[i].fileBase64 != 'undefined' && res.result[i].fileBase64 != null) {
					var imageBase64 = "data:image/png;base64," + res.result[i].fileBase64;
					var docId = parseInt(res.result[i].docId);
					var label = res.result[i].docName;
					imageArray.listImageCandidate.push({ file: imageBase64, type: docId, label: label });
					if ($rootScope.flagPending) {
						insertPendingDoc(label, docId);
					}
				}
			}
		}

		function insertPendingDoc(docName, docType) {

			// don't insert docType to available documents to delete

			if (docType != 11010201 && docType != 30010101 && docType != 13010209 && docType != 11010404 && docType != 30010109 && docType != 30010108 && docType != 30010110 && docType != 16010104 && docType != 16010103) {
				$rootScope.dbImage.transaction(function (tx) {
					var insertQuery = "INSERT INTO tblPendingDoc (agentId, npa, docName, docType) VALUES " + "('" + $rootScope.agent.code + "','" + $rootScope.candidate.npa + "','" + docName + "', '" + docType + "')";
					tx.executeSql(insertQuery, [], function (tx, res) {
						AppsLog.log(res);
					});
				});
			}

		}

		function CheckingSosMed(npa) {
			GetSosMedService.invoke(npa).then(function (res) {
				candidatePack.dataJejaring.twitter = '';
				candidatePack.dataJejaring.facebook = '';
				candidatePack.dataJejaring.other = '';
				candidatePack.dataJejaring.linkedin = '';

				if (res.invocationResult.array.length != 0) {
					for (var i = 0; i < res.invocationResult.array.length; i++) {
						if (res.invocationResult.array[i].socialnetworktype === "Twitter") {
							candidatePack.dataJejaring.twitter = res.invocationResult.array[i].accountname;
						} else if (res.invocationResult.array[i].socialnetworktype === "Other") {
							candidatePack.dataJejaring.other = res.invocationResult.array[i].accountname;
						} else if (res.invocationResult.array[i].socialnetworktype === "Facebook") {
							candidatePack.dataJejaring.facebook = res.invocationResult.array[i].accountname;
						} else if (res.invocationResult.array[i].socialnetworktype === "LinkedIn") {
							candidatePack.dataJejaring.linkedin = res.invocationResult.array[i].accountname;
						}
					}
				}
			});
		}


		function CheckingFastStart(npa) {
			GetFastStartService.invoke(npa).then(function (res) {
				if (res.invocationResult.array.length != 0) {
					var trainingType = res.invocationResult.array[0].faststarttype == 'PSA' ? 1 : 2;
					candidatePack.dataFastStart.trainingType = trainingType;
					if (trainingType == 1) {
						var startTime = new Date(res.invocationResult.array[0].faststartstarttime);
						var endTime = new Date(res.invocationResult.array[0].faststartendtime);
						var startDate = moment(res.invocationResult.array[0].faststartstartdate);
						var endDate = moment(res.invocationResult.array[0].faststartenddate);

						var icon = (startTime.getHours() >= 6 && startTime.getHours() <= 16) ? "ion-android-sunny" : "ion-ios-moon-outline";
						var part = (startTime.getHours() >= 6 && startTime.getHours() <= 16) ? "Siang" : "Malam";
						candidatePack.dataFastStart.trainingLocation = res.invocationResult.array[0].faststartlocation;
						candidatePack.dataFastStart.faststartlocation = res.invocationResult.array[0].faststartlocation;
						candidatePack.dataFastStart.faststartscheduleid = res.invocationResult.array[0].faststartscheduleid;
						candidatePack.dataFastStart.id = res.invocationResult.array[0].faststartscheduleid;
						candidatePack.dataFastStart.faststartstarttime = res.invocationResult.array[0].faststartstarttime;
						candidatePack.dataFastStart.faststartendtime = res.invocationResult.array[0].faststartendtime;
						candidatePack.dataFastStart.faststartdate = startDate;
						candidatePack.dataFastStart.faststartcourse = res.invocationResult.array[0].faststartcourse;
						candidatePack.dataFastStart.faststartcoursecode = res.invocationResult.array[0].faststartcoursecode;
						candidatePack.dataFastStart.date = startDate.format("DD") + " - " + endDate.format("DD");
						candidatePack.dataFastStart.days = endDate.diff(startDate, "days", true);
						candidatePack.dataFastStart.month = startDate.format("MMMM");
						candidatePack.dataFastStart.icon = icon;
						candidatePack.dataFastStart.part = part;
						candidatePack.dataFastStart.time = startTime.getFormattedTime() + " - " + endTime.getFormattedTime();
					}

				} else {
					candidatePack.dataFastStart.trainingType = undefined;
				}
			});
		}

		function CheckingAAJI(npa) {
			var deferred = $q.defer();
			GetAAJIService.invoke(npa).then(function (res) {
				if (res.invocationResult.array.length != 0) {
					candidatePack.dataUjian.choosedDate = res.invocationResult.array[0].aajiexamdate;
					candidatePack.dataUjian.choosedId = res.invocationResult.array[0].aajiexamscheduleid;
					candidatePack.dataUjian.choosedLocation = res.invocationResult.array[0].aajiexamlocation;
					candidatePack.dataUjian.aajiexamstarttime = res.invocationResult.array[0].aajiexamstarttime;
					candidatePack.dataUjian.aajiexamendtime = res.invocationResult.array[0].aajiexamendtime;
					candidatePack.dataUjian.choosedDateDefault = res.invocationResult.array[0].aajiexamdate;
				}
			});
		}


		function saveDataCandidate(dataParam) {
			var deferred = $q.defer();
			var data = dataParam;
			var dataCandidateParam = {
				agentId: data.agentId,
				npa: data.npa
			}
			getDataCandidatePackFromJsonStore(dataCandidateParam).then(
				function (result) {
					if (result === 'empty') {
						WL.JSONStore.get(collection.JSONSTORE_NAME).add(data).then(function (res) {
							deferred.resolve(result);
						}).fail(function (error) {
							deferred.reject(error);
						});
					} else {
						result.json = data;
						var options = {};
						WL.JSONStore.get(collection.JSONSTORE_NAME).replace(result, options).then(function (numberOfDocsReplaced) {
							deferred.resolve("Success modify " + numberOfDocsReplaced + " documents");
						}).fail(function (error) {
							deferred.reject(error);
						});
					}
				},
				function (error) {
					deferred.reject(error);
				}
			);

			return deferred.promise;
		}

		function saveImageCandidate(imageCandidate, flagImageLocal) {
			var deferred = $q.defer();

			if (flagImageLocal) {
				imageArray.agentId = imageCandidate.agentId;
				imageArray.npa = imageCandidate.npa;

				if (imageCandidate.dataPribadi.ktpImage != '' && imageCandidate.dataPribadi.ktpImage != undefined && imageCandidate.dataPribadi.ktpImage != 'undefined') {
					imageArray.listImageCandidate.push({ file: imageCandidate.dataPribadi.ktpImage, type: 11010201, label: 'KTP' });
				}

				if (imageCandidate.dataPribadi.profileImage != '' && imageCandidate.dataPribadi.profileImage != undefined && imageCandidate.dataPribadi.profileImage != 'undefined') {
					imageArray.listImageCandidate.push({ file: imageCandidate.dataPribadi.profileImage, type: 30010101, label: 'Photo' });
				}

				if (imageCandidate.dataRekening.foto != '' && imageCandidate.dataRekening.foto != undefined && imageCandidate.dataRekening.foto != 'undefined') {
					imageArray.listImageCandidate.push({ file: imageCandidate.dataRekening.foto, type: 13010209, label: 'Buku Rekening' });
				}

				if (imageCandidate.dataPajak.npwpImage != '' && imageCandidate.dataPajak.npwpImage != undefined && imageCandidate.dataPajak.npwpImage != 'undefined') {
					imageArray.listImageCandidate.push({ file: imageCandidate.dataPajak.npwpImage, type: 11010404, label: 'NPWP' });
				}

				if (imageCandidate.dataDokumen.length != 0) {
					for (var i = 0; i < imageCandidate.dataDokumen.length; i++) {
						var type = imageCandidate.dataDokumen[i].type;
						var file = imageCandidate.dataDokumen[i].file;
						var label = imageCandidate.dataDokumen[i].label;
						imageArray.listImageCandidate.push({ file: file, type: type, label: label });
					}
				}

				$rootScope.dbImage.transaction(function (tx) {
					var data = imageArray.listImageCandidate;
					for (var i = 0; i < data.length; i++) {
						var imageType = angular.isNumber(data[i].type) == true ? (data[i].type).toString() : data[i].type;
						var imageFile = data[i].file;
						var imageLabel = data[i].label;
						queryImageData(tx, imageType, imageFile, imageLabel, deferred, imageArray, 'DRAFT');
					}
				});

			} else {
				var data = imageCandidate.listImageCandidate;
				$rootScope.dbImage.transaction(function (tx) {
					for (var i = 0; i < data.length; i++) {
						var imageType = angular.isNumber(data[i].type) == true ? (data[i].type).toString() : data[i].type;
						var imageFile = data[i].file;
						var imageLabel = data[i].label;
						queryImageData(tx, imageType, imageFile, imageLabel, deferred, imageCandidate, 'SERVICE');
					}
				});
			}

			return deferred.promise;
		}

		function removeImageByNPA(candidateParam) {
			$rootScope.dbImage.transaction(function (tx) {
				var query = "DELETE FROM tblImage WHERE agentId = ? and npa = ?";
				var params = [candidateParam.agentId, candidateParam.npa];
				tx.executeSql(query, params, function (tx, res) {
				}, function (tx, error) {
					AppsLog.log('DELETE error: ' + error.message);
				});
			}, function (error) {
				AppsLog.log('transaction error: ' + error.message);
			}, function () {
				AppsLog.log('transaction ok');
			});
		}

		function queryImageData(tx, imageType, imageFile, imageLabel, deferred, dataParam, status) {
			try {
				var query = "SELECT * FROM tblImage where agentId = ? and npa = ? and type = ?";
				var params = [dataParam.agentId, dataParam.npa, imageType];
				tx.executeSql(query, params, function (tx, rs) {
					if (rs.rows.length <= 0) {
						var insertQuery = "INSERT INTO tblImage (agentId, npa, type, label, imgBase64, statusImage) VALUES " + "('" + dataParam.agentId + "','" + dataParam.npa + "','" + imageType + "', '" + imageLabel + "', '" + imageFile + "', '" + status + "')";
						tx.executeSql(insertQuery, [], function (tx, res) {
							deferred.resolve("Success Insert");
						});
					} else {
						var updateQuery = 'UPDATE tblImage SET  agentId = "' + dataParam.agentId + '", npa = "' + dataParam.npa + '", type = "' + imageType + '",label = "' + imageLabel + '", imgBase64 = "' + imageFile + '", statusImage = "' + status + '" WHERE agentId = "' + dataParam.agentId + '" AND npa = "' + dataParam.npa + '" AND type="' + imageType + '" ';
						tx.executeSql(updateQuery, [], function (res) {
							deferred.resolve("Success Update");
						});
					}
				}, function (tx, error) {
					console.log("error" + error);
					deferred.reject(error);
				});

			} catch (error) {
				console.log("error" + error);
				AppsLog.log(error);
				deferred.reject(error);
			}
		}

		var getFastStartType = function () {
			var deferred = $q.defer();
			var fastStartType = [
				{
					value: 1,
					label: "PRUSales academy (PSA)"
				},
				{
					value: 2,
					label: "Guest Lecture"
				}
			]

			deferred.resolve(fastStartType);
			return deferred.promise;
		}

		var getFastStartLocation = function () {
			var deferred = $q.defer()
			var req = {
				adapter: "HTTPAdapterAuth",
				method: WLResourceRequest.GET,
				procedure: "getFastStartCity",
				parameters: []
			};

			var deferred = $q.defer();

			AOBResources.invoke(req, false)
				.then(function (res) {
					var fastStartLocation = [];
					res.invocationResult.array.forEach(function (element) {
						var city = {};
						city.value = element.faststartlocation;
						city.label = element.faststartlocation;

						fastStartLocation.push(city);
					}, this);
					deferred.resolve(fastStartLocation);
				}, function (error) {
					deferred.reject(error);
				});
			return deferred.promise;
		}

		var getfastStartSchedule = function (city) {
			var masterDataFastStartSchedule = [];
			var req = {
				adapter: "HTTPAdapterAuth",
				method: WLResourceRequest.GET,
				procedure: "getDataFaststart",
				parameters: []
			};

			var deferred = $q.defer();
			AOBResources.invoke(req, false)
				.then(function (res) {
					var tempFaststart = $filter('filter')(res.invocationResult, { locationCity: city })[0];
					tempFaststart.scheduleDetail.forEach(function (element) {
						var fastStartSchedule = {};
						var startTime = moment(element.startTime).utc();
						startTime = new Date(startTime.format());
						var endTime = moment(element.endTime).utc();
						endTime = new Date(endTime.format());
						var startDate = moment(element.startDate);
						var endDate = moment(element.endDate);
						var icon = (startTime.getHours() >= 6 && startTime.getHours() <= 16) ? "ion-android-sunny" : "ion-ios-moon-outline";
						var part = (startTime.getHours() >= 6 && startTime.getHours() <= 16) ? "Siang" : "Malam";
						fastStartSchedule.faststartscheduleid = element.fastStartScheduleId;
						fastStartSchedule.courseCode = element.courseCode;
						fastStartSchedule.courseDesc = element.courseDesc;
						fastStartSchedule.faststartdate = element.startDate;
						fastStartSchedule.id = element.fastStartScheduleId;
						fastStartSchedule.part = part;
						fastStartSchedule.icon = icon;
						fastStartSchedule.date = startDate.format("DD") + " - " + endDate.format("DD");
						fastStartSchedule.days = endDate.diff(startDate, "days", true);
						fastStartSchedule.month = startDate.format("MMMM");
						fastStartSchedule.time = startTime.getFormattedTime() + " - " + endTime.getFormattedTime();
						fastStartSchedule.loc = element.locationAddress;
						masterDataFastStartSchedule.push(fastStartSchedule);
					}, this);
					deferred.resolve(masterDataFastStartSchedule);
				}, function (error) {
					deferred.reject(error);
				});
			return deferred.promise;
		}

		var getLocation = function () {
			var deferred = $q.defer();
			var aajiLocation = [];
			GetAAJICityService.invoke().then(function (result) {
				for (var i = 0; i < result.invocationResult.array.length; i++) {
					aajiLocation.push({ value: result.invocationResult.array[i].aajiexamlocation, label: result.invocationResult.array[i].aajiexamlocation });
				};
				deferred.resolve(aajiLocation);
			});
			return deferred.promise;
		}

		var getScheduleAAJI = function (city) {
			var masterDataAAJI = [];
			var req = {
				adapter: "HTTPAdapterAuth",
				procedure: "getAAJIScheduleList",
				method: WLResourceRequest.POST,
				parameters: { "params": "" }
			};

			var deferred = $q.defer();
			AOBResources.invoke(req, false)
				.then(function (res) {
					var tempAAJI = $filter('filter')(res.array.invocationResult, { aajiexamlocation: city });
					var unique = {};
					var distinctDate = [];
					for (var i in tempAAJI) {
						if (typeof (unique[tempAAJI[i].aajiexamdate]) == "undefined") {
							distinctDate.push(tempAAJI[i].aajiexamdate);
						}
						unique[tempAAJI[i].aajiexamdate] = 0;
					}

					distinctDate.forEach(function (trainingDate) {
						var count = 1;
						var training = {};
						training.dateDefault = trainingDate;
						training.date = moment(trainingDate).format("dddd, D MMMM YYYY");
						training.sch = [];
						var tempAAJIChild = $filter('filter')(tempAAJI, { aajiexamdate: trainingDate });
						tempAAJIChild.forEach(function (element) {
							var childAAJI = {};
							var timeStart = new Date(element.aajiexamstarttime);
							var timeEnd = new Date(element.aajiexamendtime);
							childAAJI.id = element.aajiexamscheduleid;
							childAAJI.number = count++;
							childAAJI.time = timeStart.getFormattedTime() + " - " + timeEnd.getFormattedTime();
							childAAJI.loc = element.aajiexamlocation;
							childAAJI.endReg = moment(element.aajiexamexpireddate).format("DD MMMM YYYY");
							training.sch.push(childAAJI);
						}, this);

						masterDataAAJI.push(training);
					}, this);

					deferred.resolve(masterDataAAJI);
				}, function (error) {
					deferred.reject(error);
				});
			return deferred.promise;
		}

		return {
			getDataCandidatePack: getDataCandidatePack,
			getImageCandidatePack: getImageCandidatePack,
			saveDataCandidate: saveDataCandidate,
			saveImageCandidate: saveImageCandidate,
			getfastStartSchedule: getfastStartSchedule,
			getFastStartType: getFastStartType,
			getFastStartLocation: getFastStartLocation,
			getLocation: getLocation,
			getScheduleAAJI: getScheduleAAJI,
		}
	});