﻿var pruforce = angular.module('PruForce');

pruforce.controller('productCtrl', function($q,$scope, $rootScope, $ionicScrollDelegate, /*$element,*/ $ionicPopup, $mdDialog, QuotationStorageService) {
  var quotationId = $rootScope.QuotationId;
  $scope.menuTabs = [
    {name: "Pilih Produk",  url: "components/newSqs/products/product.html"},
    {name: "Manfaat",  url: "components/newSqs/products/manfaat.html"}
  ]

  if ($rootScope.Level == 4) {
    $scope.currentMenuTab = $scope.menuTabs[1];  
  } else {
    $scope.currentMenuTab = $scope.menuTabs[0];
  }


  
  $scope.isActiveTab = function(menuTabUrl){
    return $scope.currentMenuTab.url === menuTabUrl;
  };

  $scope.movingTab = function(e, menuTab){
    $scope.fundCount = 0;
    e.preventDefault();
    QuotationStorageService.getQuotationStorageByKey($q, quotationId).then(function(resQuot){

      QUOTATION_STORAGE = resQuot;
      console.log('isi QUOTATION_STORAGE   ', QUOTATION_STORAGE);
      var flag = false;
      var jenisProd = QUOTATION_STORAGE.Product ? Object.keys(QUOTATION_STORAGE.Product).length > 0 ? QUOTATION_STORAGE.Product.ProductCategory : flag : '';
      var prodCode = QUOTATION_STORAGE.Product ? QUOTATION_STORAGE.Product.ProductCode ? QUOTATION_STORAGE.Product.ProductCode : flag : '';
      var payFreq = QUOTATION_STORAGE.Product ? QUOTATION_STORAGE.Product.PaymentFrequency ? QUOTATION_STORAGE.Product.PaymentFrequency : flag : '';
      var fundObj;
      var itemInputObj;
      var inputValue;
      
      console.log(jenisProd + '---' + payFreq + '---' + prodCode);

      if(jenisProd === false || jenisProd === ''){
          $rootScope.AlertDialog('Mohon Pilih Jenis Produk');
      } else if(prodCode === false){
          $rootScope.AlertDialog('Mohon Pilih Nama Produk');
      } else if(payFreq === false){
          $rootScope.AlertDialog('Mohon Pilih Frekuensi Pembayaran');
      } else {

          console.log('sudah oke ', jenisProd + '---' + payFreq + '---' + prodCode);
          var fundList = QUOTATION_STORAGE.Product.FundList ? QUOTATION_STORAGE.Product.FundList : [];
          console.log('fundList ', fundList);
          if(fundList.length !== 0){

              for(var i = 0; i < fundList.length; i++){
                fundObj = fundList[i];
                itemInputObj = fundObj.itemInput[0];
                inputValue = itemInputObj.inputValue;
                $scope.fundCount += parseFloat(inputValue);
              }

              console.log('Isi dari fund list === ',fundList);
              if(fundList.length > 0){
                  console.log('fundCount ',$scope.fundCount);
                  if($scope.fundCount == 100){
                    $scope.currentMenuTab = menuTab;
                    var self = $(e.toElement);
                    var tabContentTitle = self.attr("href");

                    $(".tab-scrolling").animate({scrollLeft: self.attr("data-position-left")}, 300);
                    self.parent().find("a").removeClass("active");
                    self.addClass("active");
                    $(tabContentTitle).addClass("active");
                    $ionicScrollDelegate.scrollTop();
                  }else{
                    $rootScope.AlertDialog('Persentase Fund Harus 100%');
                  }
              } else {
                  $scope.currentMenuTab = menuTab;
                  var self = $(e.toElement);
                  var tabContentTitle = self.attr("href");

                  $(".tab-scrolling").animate({scrollLeft: self.attr("data-position-left")}, 300);
                  self.parent().find("a").removeClass("active");
                  self.addClass("active");
                  $(tabContentTitle).addClass("active");
                  $ionicScrollDelegate.scrollTop();
              }
          }
      }
      
    });

    

   
  };

  
});
