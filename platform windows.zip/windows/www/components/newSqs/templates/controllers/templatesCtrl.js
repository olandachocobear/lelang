﻿var pruforce = angular.module('PruForce');

pruforce.controller('templatesCtrl', function($scope,  $rootScope, $ionicScrollDelegate, $document, $ionicPopup, $localStorage, $mdDialog) {
  
  $scope.menuTabs = [
    {name: "Pilih Produk",  url: "components/newSqs/templates/pilih-produk.html"},
    {name: "Manfaat",  url: "components/newSqs/templates/template-manfaat.html"}
  ]

  $scope.currentMenuTab = $scope.menuTabs[0];

  $scope.isActiveTab = function(menuTabUrl){
    return $scope.currentMenuTab.url === menuTabUrl;
  };

  $scope.menuDetailTemplate = [
    {name: "Pilih Produk", url: "components/newSqs/templates/template-detail-pilih-produk.html"},
     {name: "Manfaat",  url: "components/newSqs/templates/template-manfaat.html"}
  ]

  $scope.currentMenuDetailTemplate = $scope.menuDetailTemplate[0];

  $scope.isActiveMenuDetailTemplate = function(menuTabUrl){
    return $scope.currentMenuDetailTemplate.url === menuTabUrl;
  };

  $scope.movingTab = function(e, menuTab){
    e.preventDefault();
    $scope.currentMenuTab = menuTab;

    var self = $(e.toElement);
    var tabContentTitle = self.attr("href");

    $(".tab-scrolling").animate({scrollLeft: self.attr("data-position-left")}, 300);
    self.parent().find("a").removeClass("active");
    self.addClass("active");
    $(tabContentTitle).addClass("active");
    $ionicScrollDelegate.scrollTop();
  };

 $scope.jenisProdukList = $rootScope.dataPublishJson.CHANNEL.AG/*[jenisChannelList]*/.PRODUCT_CATEGORY;


 //console.log( $scope.jenisProdukList);
 
 $scope.namaProdukList = [];
  $scope.paymentFreqList = [];
 $scope.namaMataUangList=[];
 $scope.pilihProdukFilled = $scope.dataALokasiDana; 
  $scope.dataALokasiDana = {}
 $scope.tempProdukCurrency = [];
  
 // console.log($scope.dataALokasiDana.jenisProduk);

for (var i=0; i < $scope.jenisProdukList.length; i++) {
    var x = $scope.jenisProdukList[i];
    //console.log(x[1]);
    for (var l=0; l < x.length; l++) {
      var z = x[l].CURRENCY;
    //  console.log(z);
      var tempListProduk = {
        produk : x.longName,
        curr : z.CURRENCY.descriptionEng,
        label : x.longName + ' ' + z.CURRENCY.descriptionEng
      }
     $scope.tempProdukCurrency.push(tempListProduk);
     // console.log($scope.tempProdukCurrency);
    }
  }

 $scope.keyPress = function(value){
    $scope.dataALokasiDana.jenisProduk = value.jenisProduk;
    $scope.namaProdukList = value.jenisProduk.PRODUCT;
    $scope.namaMataUangList = value.produkNama.CURRENCY;
    $scope.paymentFreqList = value.produkNama.PAYMENT_FREQUENCY;
    $scope.fundAlokasi = value.produkMataUang.FUND;
    alokasiDana = [];
  }

// $scope.tempTemplateLocStor = {};
// $scope.keyPress = function(value){
//  $scope.tempTemplateLocStor.jenisProduk = value.jenisProduk;
//   $scope.tempTemplateLocStor.namaProduk = value.namaProduk;
//   localStorage.setItem("templateStorage", JSON.stringify($scope.tempTemplateLocStor));
// }
 //$scope.tempTemplateLocStor.jenisProduk = value.jenisProduk;
 //$scope.tempTemplateLocStor.namaProduk = value.namaProduk;
  //  $scope.totalIncomes = $rootScope.dataPublishJson.INCOME.Individual;
  // $scope.getOccupationData = $rootScope.dataPublishJson.OCCUPATION;
  // $scope.getBusinessData = $rootScope.dataPublishJson.BUSINESS;
  // $scope.getPositionData = $rootScope.dataPublishJson.POSITION;
     

  $scope.templateLists = [
    {id: 1, name: "Cover Crisis 1", status: "Kirim via email", type: "Prulink assurance account", approved: 1, dateCreate:"2016-10-09"},
    {id: 2, name: "Cover Crisis 2", status: "Kirim via email", type: "Prulink assurance account", approved: 1, dateCreate:"2016-10-07"},
    {id: 3, name: "Cover Crisis 3", status: "Kirim via email", type: "Prulink assurance account", approved: 1, dateCreate:"2016-10-04"},
    {id: 4, name: "Cover Crisis 4", status: "Kirim via email", type: "Prulink assurance account", approved: 1, dateCreate:"2016-10-02"},
    {id: 5, name: "Cover Crisis 5", status: "Kirim via email", type: "Prulink assurance account", approved: 1, dateCreate:"2016-10-08"},
    {id: 6, name: "Cover Crisis 6", status: "Kirim via email", type: "Prulink assurance account", approved: 0, dateCreate:"2016-10-10"},
    {id: 7, name: "Cover Crisis 7", status: "Kirim via email", type: "Prulink assurance account", approved: 0, dateCreate:"2016-10-01"},
    {id: 8, name: "Cover Crisis 8", status: "Kirim via email", type: "Prulink assurance account", approved: 0, dateCreate:"2016-10-05"},
    {id: 9, name: "Cover Crisis 9", status: "Kirim via email", type: "Prulink assurance account", approved: 0, dateCreate:"2016-10-03"},
    {id: 10, name: "Cover Crisis 10", status: "Kirim via email", type: "Prulink assurance account", approved: 0, dateCreate:"2016-10-11"},
    {id: 11, name: "Cover Crisis 11", status: "Kirim via email", type: "Prulink assurance account", approved: 0, dateCreate:"2016-10-06"}
  ]

  $scope.tempilTemplateDatas = $scope.templateLists;
  $scope.memberTemplateDatas = loadMemberDatas($scope.tempilTemplateDatas);
  //console.log($scope.memberTemplateDatas);
  $scope.pilihProduk = {
    nospaj: "0A1234567",
    jenisProduk: "PRUlink",
    name :"PRUlink assurance acount (RUP)",
    pilihProduk :"Bulanan",
    pembayaranFrekuensi : "Bulanan"
  }

  $scope.createManfaat = {
    moneyMin : "Rp 0.00",
    moneyMax  : "Rp 0.00",
    premiUnapplied: "Rp 0.00",
    premiTahunan: "Rp 0.00",
    tahunPolisSejak: "0",
    tahunPolisSampai: "0",
    jumlah: "Rp 0.00"
  }

  $scope.premi = {
    besarPremiTahunan : "Rp 100.000.000.00",
    rencanaPembayaran : "10",
    alternatifPembayaran :"99",
    asumsiNilai1 : "45",
    asumsiNilai2 : "55",
    asumsiNilai3 : "65"
  }

  $scope.saveTemplate = function(e) {
    var myPopup = $ionicPopup.show({
      title: "<strong>PRU</strong><em>force</em> SQS",
      template: "<input type='text' class='input-gray' placeholder='Nama Template'/>",
      cssClass: 'pru-alert pru-logo-text button-side-duo',
      scope: $scope,
      buttons: [
      {
        text: 'Batal',
        type: 'button-dark-gray',
        onTap: function(e) {
        }
      },
      {
        text: 'Simpan',
        type: 'button-assertive',
        onTap: function(e) {
          $scope.savedTemplate();
        }
      }
      ]
    });
  };

  $scope.savedTemplate = function() {
    var myPopup = $ionicPopup.show({
      title: "<strong>PRU</strong><em>force</em> SQS",
      template: "<div class='pad-top-30 pad-bot-30'><small>Template <strong>Crisis Cover</strong> berhasil disimpan</small></div>",
      cssClass: 'pru-alert pru-logo-text button-side-duo',
      scope: $scope,
      buttons: [
      {
        text: 'Buat Baru',
        type: 'button-dark-gray',
        onTap: function(e) {
        }
      },
      {
        text: 'Lihat Daftar',
        type: 'button-assertive',
        onTap: function(e) {
          // window.location = window.location.origin + "#/newSqs/homepage/template.html"
          window.location =  window.location.origin +"#/newSqs/homepage/template"
          

        }
      }
      ]
    });
  };

  function loadMemberDatas(array) {
    var datas =  array;
    return datas.map(function (per) {
      per._lowername = per.name.toLowerCase();
      return per;
    });
  }




 $scope.tempilTemplateDatas = $scope.templateLists; 

  $scope.getSearchText = function(text){

var tampunglist=[];
  for(var j =0; j < $scope.templateLists.length; j++){
    if($scope.templateLists[j].name.toLowerCase().indexOf(text.toLowerCase())!==-1||$scope.templateLists[j].type.toLowerCase().indexOf(text.toLowerCase())!==-1){
      tampunglist.push($scope.templateLists[j]);
    }
    else if($scope.templateLists[j].dateCreate.toLowerCase().indexOf(text.toLowerCase())!==-1) {
        tampunglist.push($scope.templateLists[j]);}
    //   else if($scope.findTemplate[j].createdDate.toLowerCase().indexOf(text.toLowerCase())!==-1){
    //     tampunglist.push($scope.findTemplate[j]);
    // }
   
    $scope.tempilTemplateDatas =tampunglist;
  }

}

$scope.statusmanfaat = function () {
    /*$rootScope.AlertDialog("search page");*/
    $state.go("statusmanfaat");
  }

   $scope.popupAlokasiDana =[];

  $scope.addListPopup = function() {
    var labels= $scope.popupAlokasiDana;
    var id = $scope.popupAlokasiDana.length +1;
    var listObj = {id:id, label:$scope.popupAlokasiDana.label, model:"alokasi"+id, checked:true, data:{val1: ""}};
    $scope.popupAlokasiDana.push(listObj);
  }
});
