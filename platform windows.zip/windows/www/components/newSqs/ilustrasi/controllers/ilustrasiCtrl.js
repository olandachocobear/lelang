﻿var pruforce = angular.module('PruForce');

pruforce.controller('ilustrasiCtrl', function(DataFactoryNewSQSOffline, PublishGlobalService, $sce, $ionicHistory, $q, $rootScope, $scope, $ionicPopup, $ionicModal, $ionicLoading, $mdDialog, $state, $rootScope, QuotationStorageService, CustomerStorageService, OutputStorageService, OutputService, $timeout, RateStorageService) {
  var channelCode = $rootScope.agent.channelType;
  var quotationId = $rootScope.QuotationId;
  var QUOTATION_STORAGE = {};
  var CUSTOMER_LIST = [];
  var CUSTOMER = {};
  var CUSTOMER_PEMEGANGPOLIS = {};
  var CUSTOMER_TERTANGGUNGTAMBAHAN1 = {};
  var CUSTOMER_TERTANGGUNGTAMBAHAN2 = {};

  var formatSubStandart = '';

  var blob;
  var startChunk = 0;
  var maxChunk =4;
  var jobState = 0;
  var jsonStoreChunk = [];
  var reader = new FileReader();
  var chunk_blob = [];
  $scope.pdfready = false;
  $scope.progress_msg = "Memproses PDF...";

  var randomString = function(length) {
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
    for(var i = 0; i < length; i++) {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text;
  }

  $scope.progress_time = 50;
  var listen_progress = $scope.$on("pdf_progress", function(event, args){
      //console.log("data ", args.prog.total);
      $scope.progress_time += 1;
      console.log("data ", $scope.progress_time);
      $timeout(function(){
          document.getElementById("progress_bar").style.width = $scope.progress_time + "%";
      },500)
  })

  $scope.$on('$destroy', function() {
      listen_progress();
  })

  var OUTPUT = {};

  $scope.ilustrasi = {};

  var anb;

  var xlistManfaat = [];
  var formatCurr;

  Number.prototype.format = function(n, x) {
    var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\.' : '$') + ')';
    return this.toFixed(Math.max(0, ~~n)).replace(new RegExp(re, 'g'), '$&,');
  };

/*
  function getSaverValue(manfaatList){
      for(){

      }
  }*/


  function generateBarcode(docId, customerDataList, coverageCodeList){
      var tmpBarcode = '';
      var manfaatSelected = QUOTATION_STORAGE.Manfaat.manfaatList;
      var fundSelected = QUOTATION_STORAGE.Product.FundList;
      var payFreqCd = QUOTATION_STORAGE.Product.PaymentFrequency;
      var currencyCd = QUOTATION_STORAGE.Product.ProductCurrency;
      var spajno = QUOTATION_STORAGE.Product.SPAJNo;
      var custMap = QUOTATION_STORAGE.CustomerList;
      var premi = parseFloat(QUOTATION_STORAGE.Manfaat.premi);
      var saver = parseFloat($scope.ilustrasi.saverValue);
      var sumResultPremiSaver = (premi + saver);

      console.log('QUOTATION_STORAGE.QuotationDate --- ' + QUOTATION_STORAGE.QuotationDate);
      console.log('manfaatSelected --- ', manfaatSelected);
      console.log('coverageCodeList --- ', coverageCodeList);
      console.log('Premi : '+ premi);
      console.log('Saver : '+ saver);


      var createdDate = new Date(QUOTATION_STORAGE.QuotationDate);
      //SQS Created Date
      tmpBarcode += getDate(createdDate) + ' ' + createdDate.hhmmss() + ';';
      //Documant Number
      tmpBarcode += docId + ';';


      var tertanggungUtama = getCustomerData(custMap['02'], customerDataList);
      //PEMEGANG POLIS
      var pPolis = getCustomerData(custMap['01'], customerDataList);
      //PAYER
      var payer = getCustomerData(custMap['0' + pPolis.PembayaranPremi], customerDataList);

      var tmpIncomeList = $rootScope.incomeList[pPolis.tipe];

      console.log('income list', tmpIncomeList);

      var covList = [];
      //"PRUlink assurance account"
      var cov1 = 'U1ZR';
      covList.push(cov1);
      //"PRUsaver"
      var cov2 = 'U1CR';
      covList.push(cov2);
      //"PRUcrisis cover 34"
      var cov3 = 'C1KR';
      covList.push(cov3);
      //"PRUcrisis cover benefit plus 61"
      var cov4 = 'C1WR';
      covList.push(cov4);
      //PRUmultiple crisis cover
      var cov5 = 'C1TR';
      covList.push(cov5);

      var cov6;
      var cov7;
      var cov8;
      var cov9;
      var cov10;
      var cov11;
      var cov12;
      var cov13;
      var cov14;
      var cov15;
      var cov16;
      var cov17;
      var cov18;
      var cov19;
      var cov20;
      var cov21;

      var anak = tertanggungUtama.anb <= 15 ? true : false;
      if(anak){
          //PRUearly Stage Crisis cover plus
          var cov6 = 'C106';
          //PRUjuvenile crisis cover"
          var cov7 = 'C103';
          //PRUpersonal accident death"
          var cov8 = 'P1CR';
          //PRUpersonal accident death plus"
          var cov9 = 'P1QR';
          //"PRUpersonal accident death & disablement"
          var cov10 = 'P1DR';
          //"PRUpersonal accident death & disablement Plus"
          var cov11 = 'P1RR';
          //"PRUmed"
          var cov12 = 'H1VR';
          //"PRUhospital & surgical cover plus""
          var cov13 = 'H1TR';
          //"PRUparent payor 33 Tertanggung 1
          var cov14 = 'W1XR';
          //PRUHospital & Surgical as Charge
          var cov15 = 'H1X1'; //As Charge
          //"PRUparent payor 33 Tertanggung 2
          var cov16 = 'W1XR';
          //"PRUearly stage parent payor ; Parent 1"
          var cov17 = 'W3AR';
          //"PRUearly stage parent payor ; Parent 2"
          var cov18 = 'W3AR';
          var cov19 = '';
          var cov20 = '';
          var cov21 = '';
      }else{
          //PRUcrisis Income
          var cov6 = 'I1DR';
          //PRUearly Stage Crisis cover plus
          var cov7 = 'C106';
          //"PRUlink term
          var cov8 = 'T1JR';
          //PRUpersonal accident death"
          var cov9 = 'P1CR';
          //PRUpersonal accident death plus"
          var cov10 = 'P1QR';
          //PRUpersonal accident death & disablement
          var cov11 = 'P1DR';
          //"PRUpersonal accident death & disablement Plus 
          var cov12 = 'P1RR';
          //PRUmed 
          var cov13 = 'H1VR';
          //"PRUhospital & surgical cover plus"
          var cov14 = 'H1TR';
          //PRUHospital & Surgical as Charge
          var cov15 = 'H1X1'; //As Charge
          //PRUpayor 33 
          var cov16 = 'W1QR';
          //"PRUwaiver 33 
          var cov17 = 'W1MR';
          //""PRUspouse payor 33"
          var cov18 = 'S1KR';
          //"PRUspouse waiver 33"
          var cov19 = 'S1FR';
          //"PRUearly stage payor"
          var cov20 = 'W3BR';
          //"PRUearly stage spouse payor"
          var cov21 = 'S1YR';
      }
      covList.push(cov6);
      covList.push(cov7);
      covList.push(cov8);
      covList.push(cov9);
      covList.push(cov10);
      covList.push(cov11);
      covList.push(cov12);
      covList.push(cov13);
      covList.push(cov14);
      covList.push(cov15);
      covList.push(cov16);
      covList.push(cov17);
      covList.push(cov18);
      covList.push(cov19);
      covList.push(cov20);
      covList.push(cov21);

      var fundListHardCode = ['PRMF','PRFF','PREF','PRCF','PRMP','PRGC','PREP','PRIE','PRAE','PVDE'];      

      /*for(var x = 0; x < covList.length; x++){
          var cov = covList[x];

          //Life Assure
          var lifeAssureCd = ';';

          //Coverage Name
          var coverageName = cov + ';';

          //Premium
          var premium = ';';
          //Sum Assured
          var sumAssured = ';';
          //Term
          var term = ';';          

          for(var g = 0 ; g < coverageCodeList.length; g++){
              if(cov == coverageCodeList[g].coverageCd){
                  lifeAssureCd =  coverageCodeList[g].lifeAssureCd + ';';                
              }
          }
          
          tmpBarcode +=  lifeAssureCd;
          tmpBarcode +=  coverageName;

          var flag = true;
          for(var j = 0; j < manfaatSelected.length; j++){
              var  manfaat = manfaatSelected[j];

              if(cov == manfaat.code){
                  flag = false;
                 
                  for(var k = 0; k < manfaat.custList.length; k++){
                      var cust = manfaat.custList[k];
                      for(var l = 0; l < cust.itemInput.length; l++){
                          var itemInput = cust.itemInput[l];
                          //Premium
                          premium = cust.annualPremi + ';';

                          if(itemInput.key == 'PDSA'){
                            //Sum Assured
                            sumAssured = itemInput.inputValue + ';';
                          }else if(itemInput.key == 'PDTERM'){
                            //Term
                            term = itemInput.inputValue + ';';
                          }else{
                            sumAssured = itemInput.inputValue + ';';
                          }
                      }
                      if(manfaat.coverageType == 'topup'){
                          //Premium
                          premium = parseFloat($scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala)) <= 0 ? ';' : $scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala) + ';';
                          //term
                          term = '99' + ';';
                      }else if(manfaat.coverageType == 'main'){
                          //Premium
                          premium = $scope.replaceMoneyFormat($scope.ilustrasi.premi) + ';';
                          //term
                          term = '99' + ';';
                      }
                      tmpBarcode +=  premium;
                      tmpBarcode +=  sumAssured;
                      tmpBarcode +=  term;  
                  }
                  break;
              }
          }
          if(flag){
              tmpBarcode +=  ';';
              tmpBarcode +=  ';';
              tmpBarcode +=  ';';
          }                   
      }*/

      
      //"PRUlink assurance account"    
      //Life Number 1
      tmpBarcode +=  '01' + ';';
      //Product Code / Rider Code
      tmpBarcode +=  covList[0] + ';';
      //Premium
      var premium = ';';
      //Sum Assured
      var sumAssured = ';';
      //Term
      var term = ';';
      for(var j = 0; j < manfaatSelected.length; j++){
          var  manfaat = manfaatSelected[j];
          if(covList[0] == manfaat.code){
              for(var k = 0; k < manfaat.custList.length; k++){
                  var cust = manfaat.custList[k];
                  //TERM
                  term = '99' + ';';
                  //Premium
                  premium = $scope.replaceMoneyFormat($scope.ilustrasi.premi) + ';';

                  for(var l = 0; l < cust.itemInput.length; l++){
                      var itemInput = cust.itemInput[l];
                      if(itemInput.key == 'PDTERM'){
                        //Term
                        term = itemInput.inputValue + ';';
                      }else{
                        //Sum Assured
                        sumAssured = itemInput.inputValue + ';';
                      }
                  }                  
              }
              break;
          }
      }
      tmpBarcode +=  premium;
      tmpBarcode +=  sumAssured;
      tmpBarcode +=  term;            
      

      //"PRUsaver"
      //Life Number 1
      tmpBarcode +=  '01' + ';';
      //Product Code / Rider Code
      tmpBarcode +=  covList[1] + ';';
      //Premium
      var premium = ';';
      //Sum Assured
      var sumAssured = ';';
      //Term
      var term = ';';
      for(var j = 0; j < manfaatSelected.length; j++){
          var  manfaat = manfaatSelected[j];
          if(covList[1] == manfaat.code){
              for(var k = 0; k < manfaat.custList.length; k++){
                  var cust = manfaat.custList[k];
                  //TERM
                  term = '99' + ';';

                  //Premium
                  premium = parseFloat($scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala)) <= 0 ? ';' : $scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala) + ';';                  
              }
              break;
          }
      }
      tmpBarcode +=  premium;
      tmpBarcode +=  sumAssured;
      tmpBarcode +=  term;            



      //"PRUcrisis cover 34"
      //Life Number 1
      tmpBarcode +=  '01' + ';';
      //Product Code / Rider Code
      tmpBarcode +=  covList[2] + ';';
      //Premium
      var premium = ';';
      //Sum Assured
      var sumAssured = ';';
      //Term
      var term = ';';
      for(var j = 0; j < manfaatSelected.length; j++){
          var  manfaat = manfaatSelected[j];
          if(covList[2] == manfaat.code){
              for(var k = 0; k < manfaat.custList.length; k++){
                  var cust = manfaat.custList[k];
                  for(var l = 0; l < cust.itemInput.length; l++){
                      var itemInput = cust.itemInput[l];
                      if(itemInput.key == 'PDTERM'){
                        //Term
                        term = itemInput.inputValue + ';';
                      }else{
                        //Sum Assured
                        sumAssured = itemInput.inputValue + ';';
                      }
                  }
                  /*if(manfaat.coverageType == 'topup'){
                      //Premium
                      premium = parseFloat($scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala)) <= 0 ? ';' : $scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala) + ';';
                      //term
                      term = '99' + ';';
                  }else if(manfaat.coverageType == 'main'){
                      //Premium
                      premium = $scope.replaceMoneyFormat($scope.ilustrasi.premi) + ';';
                      //term
                      term = '99' + ';';
                  }else{
                      //Premium
                      premium = cust.annualPremi + ';';
                  }*/
              }
              break;
          }
      }
      tmpBarcode +=  premium;
      tmpBarcode +=  sumAssured;
      tmpBarcode +=  term;            



      //"PRUcrisis cover benefit plus 61"
      //Life Number 1
      tmpBarcode +=  '01' + ';';
      //Product Code / Rider Code
      tmpBarcode +=  covList[3] + ';';
      //Premium
      var premium = ';';
      //Sum Assured
      var sumAssured = ';';
      //Term
      var term = ';';
      for(var j = 0; j < manfaatSelected.length; j++){
          var  manfaat = manfaatSelected[j];
          if(covList[3] == manfaat.code){
              for(var k = 0; k < manfaat.custList.length; k++){
                  var cust = manfaat.custList[k];
                  for(var l = 0; l < cust.itemInput.length; l++){
                      var itemInput = cust.itemInput[l];
                      if(itemInput.key == 'PDTERM'){
                        //Term
                        term = itemInput.inputValue + ';';
                      }else{
                        //Sum Assured
                        sumAssured = itemInput.inputValue + ';';
                      }
                  }
                  /*if(manfaat.coverageType == 'topup'){
                      //Premium
                      premium = parseFloat($scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala)) <= 0 ? ';' : $scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala) + ';';
                      //term
                      term = '99' + ';';
                  }else if(manfaat.coverageType == 'main'){
                      //Premium
                      premium = $scope.replaceMoneyFormat($scope.ilustrasi.premi) + ';';
                      //term
                      term = '99' + ';';
                  }else{
                      //Premium
                      premium = cust.annualPremi + ';';
                  }*/
              }
              break;
          }
      }
      tmpBarcode +=  premium;
      tmpBarcode +=  sumAssured;
      tmpBarcode +=  term;            



      //PRUmultiple crisis cover
      //Life Number 1
      tmpBarcode +=  '01' + ';';
      //Product Code / Rider Code
      tmpBarcode +=  covList[4] + ';';
      //Premium
      var premium = ';';
      //Sum Assured
      var sumAssured = ';';
      //Term
      var term = ';';
      for(var j = 0; j < manfaatSelected.length; j++){
          var  manfaat = manfaatSelected[j];
          if(covList[4] == manfaat.code){
              for(var k = 0; k < manfaat.custList.length; k++){
                  var cust = manfaat.custList[k];
                  for(var l = 0; l < cust.itemInput.length; l++){
                      var itemInput = cust.itemInput[l];
                      if(itemInput.key == 'PDTERM'){
                        //Term
                        term = itemInput.inputValue + ';';
                      }else{
                        //Sum Assured
                        sumAssured = itemInput.inputValue + ';';
                      }
                  }
                  /*if(manfaat.coverageType == 'topup'){
                      //Premium
                      premium = parseFloat($scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala)) <= 0 ? ';' : $scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala) + ';';
                      //term
                      term = '99' + ';';
                  }else if(manfaat.coverageType == 'main'){
                      //Premium
                      premium = $scope.replaceMoneyFormat($scope.ilustrasi.premi) + ';';
                      //term
                      term = '99' + ';';
                  }else{
                      //Premium
                      premium = cust.annualPremi + ';';
                  }*/
              }
              break;
          }
      }
      tmpBarcode +=  premium;
      tmpBarcode +=  sumAssured;
      tmpBarcode +=  term;            




      //PRUcrisis Income || PRUearly Stage Crisis cover plus
      //Life Number 1
      tmpBarcode +=  '01' + ';';
      //Product Code / Rider Code
      tmpBarcode +=  covList[5] + ';';
      //Premium
      var premium = ';';
      //Sum Assured
      var sumAssured = ';';
      //Term
      var term = ';';
      for(var j = 0; j < manfaatSelected.length; j++){
          var  manfaat = manfaatSelected[j];
          if(covList[5] == manfaat.code){
              for(var k = 0; k < manfaat.custList.length; k++){
                  var cust = manfaat.custList[k];
                  for(var l = 0; l < cust.itemInput.length; l++){
                      var itemInput = cust.itemInput[l];
                      if(itemInput.key == 'PDTERM'){
                        //Term
                        term = itemInput.inputValue + ';';
                      }else{
                        //Sum Assured
                        sumAssured = itemInput.inputValue + ';';
                      }
                  }
                  /*if(manfaat.coverageType == 'topup'){
                      //Premium
                      premium = parseFloat($scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala)) <= 0 ? ';' : $scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala) + ';';
                      //term
                      term = '99' + ';';
                  }else if(manfaat.coverageType == 'main'){
                      //Premium
                      premium = $scope.replaceMoneyFormat($scope.ilustrasi.premi) + ';';
                      //term
                      term = '99' + ';';
                  }else{
                      //Premium
                      premium = cust.annualPremi + ';';
                  }*/
              }
              break;
          }
      }
      tmpBarcode +=  premium;
      tmpBarcode +=  sumAssured;
      tmpBarcode +=  term;            




      //PRUearly Stage Crisis cover plus || "PRUjuvenile crisis cover"
      //Life Number 1
      tmpBarcode +=  '01' + ';';
      //Product Code / Rider Code
      tmpBarcode +=  covList[6] + ';';
      //Premium
      var premium = ';';
      //Sum Assured
      var sumAssured = ';';
      //Term
      var term = ';';
      for(var j = 0; j < manfaatSelected.length; j++){
          var  manfaat = manfaatSelected[j];
          if(covList[6] == manfaat.code){
              for(var k = 0; k < manfaat.custList.length; k++){
                  var cust = manfaat.custList[k];
                  for(var l = 0; l < cust.itemInput.length; l++){
                      var itemInput = cust.itemInput[l];
                      if(itemInput.key == 'PDTERM'){
                        //Term
                        term = itemInput.inputValue + ';';
                      }else{
                        //Sum Assured
                        sumAssured = itemInput.inputValue + ';';
                      }
                  }
                  /*if(manfaat.coverageType == 'topup'){
                      //Premium
                      premium = parseFloat($scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala)) <= 0 ? ';' : $scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala) + ';';
                      //term
                      term = '99' + ';';
                  }else if(manfaat.coverageType == 'main'){
                      //Premium
                      premium = $scope.replaceMoneyFormat($scope.ilustrasi.premi) + ';';
                      //term
                      term = '99' + ';';
                  }else{
                      //Premium
                      premium = cust.annualPremi + ';';
                  }*/
              }
              break;
          }
      }
      tmpBarcode +=  premium;
      tmpBarcode +=  sumAssured;
      tmpBarcode +=  term;            




      //"PRUlink term" || PRUpersonal accident death"
      //Life Number 1
      tmpBarcode +=  '01' + ';';
      //Product Code / Rider Code
      tmpBarcode +=  covList[7] + ';';
      //Premium
      var premium = ';';
      //Sum Assured
      var sumAssured = ';';
      //Term
      var term = ';';
      for(var j = 0; j < manfaatSelected.length; j++){
          var  manfaat = manfaatSelected[j];
          if(covList[7] == manfaat.code){
              for(var k = 0; k < manfaat.custList.length; k++){
                  var cust = manfaat.custList[k];
                  for(var l = 0; l < cust.itemInput.length; l++){
                      var itemInput = cust.itemInput[l];
                      if(itemInput.key == 'PDTERM'){
                        //Term
                        term = itemInput.inputValue + ';';
                      }else{
                        //Sum Assured
                        sumAssured = itemInput.inputValue + ';';
                      }
                  }
                  /*if(manfaat.coverageType == 'topup'){
                      //Premium
                      premium = parseFloat($scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala)) <= 0 ? ';' : $scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala) + ';';
                      //term
                      term = '99' + ';';
                  }else if(manfaat.coverageType == 'main'){
                      //Premium
                      premium = $scope.replaceMoneyFormat($scope.ilustrasi.premi) + ';';
                      //term
                      term = '99' + ';';
                  }else{
                      //Premium
                      premium = cust.annualPremi + ';';
                  }*/
              }
              break;
          }
      }
      tmpBarcode +=  premium;
      tmpBarcode +=  sumAssured;
      tmpBarcode +=  term;            



      //PRUpersonal accident death" || "PRUpersonal accident death plus"
      //Life Number 1
      tmpBarcode +=  '01' + ';';
      //Product Code / Rider Code
      tmpBarcode +=  covList[8] + ';';
      //Premium
      var premium = ';';
      //Sum Assured
      var sumAssured = ';';
      //Term
      var term = ';';
      for(var j = 0; j < manfaatSelected.length; j++){
          var  manfaat = manfaatSelected[j];
          if(covList[8] == manfaat.code){
              for(var k = 0; k < manfaat.custList.length; k++){
                  var cust = manfaat.custList[k];
                  for(var l = 0; l < cust.itemInput.length; l++){
                      var itemInput = cust.itemInput[l];
                      if(itemInput.key == 'PDTERM'){
                        //Term
                        term = itemInput.inputValue + ';';
                      }else{
                        //Sum Assured
                        sumAssured = itemInput.inputValue + ';';
                      }
                  }
                  /*if(manfaat.coverageType == 'topup'){
                      //Premium
                      premium = parseFloat($scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala)) <= 0 ? ';' : $scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala) + ';';
                      //term
                      term = '99' + ';';
                  }else if(manfaat.coverageType == 'main'){
                      //Premium
                      premium = $scope.replaceMoneyFormat($scope.ilustrasi.premi) + ';';
                      //term
                      term = '99' + ';';
                  }else{
                      //Premium
                      premium = cust.annualPremi + ';';
                  }*/
              }
              break;
          }
      }
      tmpBarcode +=  premium;
      tmpBarcode +=  sumAssured;
      tmpBarcode +=  term;            




      //PRUpersonal accident death plus" || "PRUpersonal accident death & disablement"
      //Life Number 1
      tmpBarcode +=  '01' + ';';
      //Product Code / Rider Code
      tmpBarcode +=  covList[9] + ';';
      //Premium
      var premium = ';';
      //Sum Assured
      var sumAssured = ';';
      //Term
      var term = ';';
      for(var j = 0; j < manfaatSelected.length; j++){
          var  manfaat = manfaatSelected[j];
          if(covList[9] == manfaat.code){
              for(var k = 0; k < manfaat.custList.length; k++){
                  var cust = manfaat.custList[k];
                  for(var l = 0; l < cust.itemInput.length; l++){
                      var itemInput = cust.itemInput[l];
                      if(itemInput.key == 'PDTERM'){
                        //Term
                        term = itemInput.inputValue + ';';
                      }else{
                        //Sum Assured
                        sumAssured = itemInput.inputValue + ';';
                      }
                  }
                  /*if(manfaat.coverageType == 'topup'){
                      //Premium
                      premium = parseFloat($scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala)) <= 0 ? ';' : $scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala) + ';';
                      //term
                      term = '99' + ';';
                  }else if(manfaat.coverageType == 'main'){
                      //Premium
                      premium = $scope.replaceMoneyFormat($scope.ilustrasi.premi) + ';';
                      //term
                      term = '99' + ';';
                  }else{
                      //Premium
                      premium = cust.annualPremi + ';';
                  }*/
              }
              break;
          }
      }
      tmpBarcode +=  premium;
      tmpBarcode +=  sumAssured;
      tmpBarcode +=  term;            




      //PRUpersonal accident death & disablement || "PRUpersonal accident death & disablement Plus"
      //Life Number 1
      tmpBarcode +=  '01' + ';';
      //Product Code / Rider Code
      tmpBarcode +=  covList[10] + ';';
      //Premium
      var premium = ';';
      //Sum Assured
      var sumAssured = ';';
      //Term
      var term = ';';
      for(var j = 0; j < manfaatSelected.length; j++){
          var  manfaat = manfaatSelected[j];
          if(covList[10] == manfaat.code){
              for(var k = 0; k < manfaat.custList.length; k++){
                  var cust = manfaat.custList[k];
                  for(var l = 0; l < cust.itemInput.length; l++){
                      var itemInput = cust.itemInput[l];
                      if(itemInput.key == 'PDTERM'){
                        //Term
                        term = itemInput.inputValue + ';';
                      }else{
                        //Sum Assured
                        sumAssured = itemInput.inputValue + ';';
                      }
                  }
                 /* if(manfaat.coverageType == 'topup'){
                      //Premium
                      premium = parseFloat($scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala)) <= 0 ? ';' : $scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala) + ';';
                      //term
                      term = '99' + ';';
                  }else if(manfaat.coverageType == 'main'){
                      //Premium
                      premium = $scope.replaceMoneyFormat($scope.ilustrasi.premi) + ';';
                      //term
                      term = '99' + ';';
                  }else{
                      //Premium
                      premium = cust.annualPremi + ';';
                  }*/
              }
              break;
          }
      }
      tmpBarcode +=  premium;
      tmpBarcode +=  sumAssured;
      tmpBarcode +=  term;            




      //"PRUpersonal accident death & disablement Plus || PRUmed"
      //Life Number 1
      tmpBarcode +=  '01' + ';';
      //Product Code / Rider Code
      tmpBarcode +=  covList[11] + ';';
      //Premium
      var premium = ';';
      //Sum Assured
      var sumAssured = ';';
      //Term
      var term = ';';
      for(var j = 0; j < manfaatSelected.length; j++){
          var  manfaat = manfaatSelected[j];
          if(covList[11] == manfaat.code){
              for(var k = 0; k < manfaat.custList.length; k++){
                  var cust = manfaat.custList[k];
                  for(var l = 0; l < cust.itemInput.length; l++){
                      var itemInput = cust.itemInput[l];
                      if(itemInput.key == 'PDTERM'){
                        //Term
                        term = itemInput.inputValue + ';';
                      }else{
                        //Sum Assured
                        sumAssured = itemInput.inputValue + ';';

                        //IF PRUMed
                        if(covList[11] == 'H1VR'){
                          //PREMIUM
                          premium = itemInput.inputValue + ';';                          
                        }
                      }
                  }
                  /*if(manfaat.coverageType == 'topup'){
                      //Premium
                      premium = parseFloat($scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala)) <= 0 ? ';' : $scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala) + ';';
                      //term
                      term = '99' + ';';
                  }else if(manfaat.coverageType == 'main'){
                      //Premium
                      premium = $scope.replaceMoneyFormat($scope.ilustrasi.premi) + ';';
                      //term
                      term = '99' + ';';
                  }else{
                      //Premium
                      premium = cust.annualPremi + ';';
                  }*/
              }
              break;
          }
      }
      tmpBarcode +=  premium;
      tmpBarcode +=  sumAssured;
      tmpBarcode +=  term;            




      //PRUmed || "PRUhospital & surgical cover plus""
      //Life Number 1
      tmpBarcode +=  '01' + ';';
      //Product Code / Rider Code
      tmpBarcode +=  covList[12] + ';';
      //Premium
      var premium = ';';
      //Sum Assured
      var sumAssured = ';';
      //Term
      var term = ';';
      for(var j = 0; j < manfaatSelected.length; j++){
          var  manfaat = manfaatSelected[j];
          if(covList[12] == manfaat.code){
              for(var k = 0; k < manfaat.custList.length; k++){
                  var cust = manfaat.custList[k];
                  for(var l = 0; l < cust.itemInput.length; l++){
                      var itemInput = cust.itemInput[l];
                      if(itemInput.key == 'PDTERM'){
                        //Term
                        term = itemInput.inputValue + ';';
                      }else{
                        //Sum Assured
                        sumAssured = itemInput.inputValue + ';';

                        //PREMIUM
                        premium = itemInput.inputValue + ';';                        
                      }
                  }
                  /*if(manfaat.coverageType == 'topup'){
                      //Premium
                      premium = parseFloat($scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala)) <= 0 ? ';' : $scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala) + ';';
                      //term
                      term = '99' + ';';
                  }else if(manfaat.coverageType == 'main'){
                      //Premium
                      premium = $scope.replaceMoneyFormat($scope.ilustrasi.premi) + ';';
                      //term
                      term = '99' + ';';
                  }else{
                      //Premium
                      premium = cust.annualPremi + ';';
                  }*/
              }
              break;
          }
      }
      tmpBarcode +=  premium;
      tmpBarcode +=  sumAssured;
      tmpBarcode +=  term;            



      
      //"PRUhospital & surgical cover plus" || "PRUparent payor 33 Tertanggung 1
      //Life Number 1
      tmpBarcode +=  anak ? '02' + ';' : '01' + ';';
      //Product Code / Rider Code
      tmpBarcode +=  covList[13] + ';';
      //Premium
      var premium = ';';
      //Sum Assured
      var sumAssured = ';';
      //Term
      var term = ';';
      for(var j = 0; j < manfaatSelected.length; j++){
          var  manfaat = manfaatSelected[j];
          if(covList[13] == manfaat.code){
              for(var k = 0; k < manfaat.custList.length; k++){
                if(k == 0){
                  var cust = manfaat.custList[k];
                  for(var l = 0; l < cust.itemInput.length; l++){
                      var itemInput = cust.itemInput[l];
                      if(itemInput.key == 'PDTERM'){
                        //Term
                        term = itemInput.inputValue + ';';
                      }else{
                        if(anak){
                            //Sum Assured
                            sumAssured = sumResultPremiSaver + ';';
                        }else{
                            //PREMIUM
                            premium = itemInput.inputValue + ';';
                            //Sum Assured
                            sumAssured = itemInput.inputValue + ';';
                        }
                       
                      }
                  }
                  /*if(manfaat.coverageType == 'topup'){
                      //Premium
                      premium = parseFloat($scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala)) <= 0 ? ';' : $scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala) + ';';
                      //term
                      term = '99' + ';';
                  }else if(manfaat.coverageType == 'main'){
                      //Premium
                      premium = $scope.replaceMoneyFormat($scope.ilustrasi.premi) + ';';
                      //term
                      term = '99' + ';';
                  }else{
                      //Premium
                      premium = cust.annualPremi + ';';

                  }*/
                }
              }
              break;
          }
      }
      tmpBarcode +=  premium;
      tmpBarcode +=  sumAssured;
      tmpBarcode +=  term;            



      //PRUHospital & Surgical as Charge
      //Life Number 1
      tmpBarcode +=  '01' + ';';
      //Product Code / Rider Code
      tmpBarcode +=  covList[14] + ';';
      //Premium
      var premium = ';';
      //Sum Assured
      var sumAssured = ';';
      //Term
      var term = ';';
      for(var j = 0; j < manfaatSelected.length; j++){
          var  manfaat = manfaatSelected[j];
          if(covList[14] == manfaat.code){
              for(var k = 0; k < manfaat.custList.length; k++){
                  var cust = manfaat.custList[k];
                  for(var l = 0; l < cust.itemInput.length; l++){
                      var itemInput = cust.itemInput[l];
                      if(itemInput.key == 'PDTERM'){
                        //Term
                        term = itemInput.inputValue + ';';
                      }else{
                        //Sum Assured
                        sumAssured = itemInput.inputValue + ';';
                      }
                  }
                  if(manfaat.coverageType == 'topup'){
                      //Premium
                      premium = parseFloat($scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala)) <= 0 ? ';' : $scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala) + ';';
                      //term
                      term = '99' + ';';
                  }else if(manfaat.coverageType == 'main'){
                      //Premium
                      premium = $scope.replaceMoneyFormat($scope.ilustrasi.premi) + ';';
                      //term
                      term = '99' + ';';
                  }else{
                      //Premium
                      premium = cust.annualPremi + ';';
                  }
              }
              break;
          }
      }
      tmpBarcode +=  premium;
      tmpBarcode +=  sumAssured;
      tmpBarcode +=  term;            




      //PRUpayor 33  || "PRUparent payor 33 Tertanggung 2
      //Life Number 1
      tmpBarcode +=  anak ? '03' + ';' : '01' + ';';
      //Product Code / Rider Code
      tmpBarcode +=  covList[15] + ';';
      //Premium
      var premium = ';';
      //Sum Assured
      var sumAssured = ';';
      //Term
      var term = ';';

      for(var j = 0; j < manfaatSelected.length; j++){
          var  manfaat = manfaatSelected[j];
          if(covList[15] == manfaat.code){
              for(var k = 0; k < manfaat.custList.length; k++){
                var exec = true;
                if(anak == true && k != 1){
                    exec = false;
                }
                if(exec){
                  var cust = manfaat.custList[k];
                  for(var l = 0; l < cust.itemInput.length; l++){
                      var itemInput = cust.itemInput[l];
                      if(itemInput.key == 'PDTERM'){
                        //Term
                        term = itemInput.inputValue + ';';
                      }else{
                        //Sum Assured
                        sumAssured = sumResultPremiSaver + ';';
                      }
                  }
                  /*if(manfaat.coverageType == 'topup'){
                      //Premium
                      premium = parseFloat($scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala)) <= 0 ? ';' : $scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala) + ';';
                      //term
                      term = '99' + ';';
                  }else if(manfaat.coverageType == 'main'){
                      //Premium
                      premium = $scope.replaceMoneyFormat($scope.ilustrasi.premi) + ';';
                      //term
                      term = '99' + ';';
                  }else{
                      //Premium
                      premium = cust.annualPremi + ';';

                  }                 */ 
                }
              }
              break;
          }
      }
      tmpBarcode +=  premium;
      tmpBarcode +=  sumAssured;
      tmpBarcode +=  term;                       





      //"PRUwaiver 33 ||  "PRUearly stage parent payor ; Parent 1"
      //Life Number 1
      tmpBarcode +=  anak ? '02' + ';' : '01' + ';';
      //Product Code / Rider Code
      tmpBarcode +=  covList[16] + ';';
      //Premium
      var premium = ';';
      //Sum Assured
      var sumAssured = ';';
      //Term
      var term = ';';
      for(var j = 0; j < manfaatSelected.length; j++){
          var  manfaat = manfaatSelected[j];
          if(covList[16] == manfaat.code){
              for(var k = 0; k < manfaat.custList.length; k++){
                if(k == 0){
                  var cust = manfaat.custList[k];
                  for(var l = 0; l < cust.itemInput.length; l++){
                      var itemInput = cust.itemInput[l];
                      if(itemInput.key == 'PDTERM'){
                        //Term
                        term = itemInput.inputValue + ';';
                      }else{
                        //Sum Assured
                        if(anak){
                            sumAssured = sumResultPremiSaver + ';';                          
                        }else{
                            sumAssured = premi + ';';                          
                        }
                      }
                  }
                  /*if(manfaat.coverageType == 'topup'){
                      //Premium
                      premium = parseFloat($scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala)) <= 0 ? ';' : $scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala) + ';';
                      //term
                      term = '99' + ';';
                  }else if(manfaat.coverageType == 'main'){
                      //Premium
                      premium = $scope.replaceMoneyFormat($scope.ilustrasi.premi) + ';';
                      //term
                      term = '99' + ';';
                  }else{
                      //Premium
                      premium = cust.annualPremi + ';';

                  }*/
                }
              }
              break;
          }
      }
      tmpBarcode +=  premium;
      tmpBarcode +=  sumAssured;
      tmpBarcode +=  term;            




      //""PRUspouse payor 33" ||  "PRUearly stage parent payor ; Parent 2"
      //Life Number 1
      tmpBarcode +=  anak ? '03' + ';' : '02' + ';';
      //Product Code / Rider Code
      tmpBarcode +=  covList[17] + ';';
      //Premium
      var premium = ';';
      //Sum Assured
      var sumAssured = ';';
      //Term
      var term = ';';

      for(var j = 0; j < manfaatSelected.length; j++){
          var  manfaat = manfaatSelected[j];
          if(covList[17] == manfaat.code){
              for(var k = 0; k < manfaat.custList.length; k++){
                var exec = true;
                if(anak == true && k != 1){
                    exec = false;
                }
                if(exec){
                  var cust = manfaat.custList[k];
                  for(var l = 0; l < cust.itemInput.length; l++){
                      var itemInput = cust.itemInput[l];
                      if(itemInput.key == 'PDTERM'){
                        //Term
                        term = itemInput.inputValue + ';';
                      }else{
                        //Sum Assured
                        sumAssured = sumResultPremiSaver + ';';
                      }
                  }
                 /* if(manfaat.coverageType == 'topup'){
                      //Premium
                      premium = parseFloat($scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala)) <= 0 ? ';' : $scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala) + ';';
                      //term
                      term = '99' + ';';
                  }else if(manfaat.coverageType == 'main'){
                      //Premium
                      premium = $scope.replaceMoneyFormat($scope.ilustrasi.premi) + ';';
                      //term
                      term = '99' + ';';
                  }else{
                      //Premium
                      premium = cust.annualPremi + ';';

                  }*/                  
                }
              }
              break;
          }
      }
      tmpBarcode +=  premium;
      tmpBarcode +=  sumAssured;
      tmpBarcode +=  term;    




      //"PRUspouse waiver 33"
      //Life Number 1
      tmpBarcode +=  anak ? ';' : '02' + ';';
      //Product Code / Rider Code
      tmpBarcode +=  covList[18] + ';';
      //Premium
      var premium = ';';
      //Sum Assured
      var sumAssured = ';';
      //Term
      var term = ';';
      for(var j = 0; j < manfaatSelected.length; j++){
          var  manfaat = manfaatSelected[j];
          if(covList[18] == manfaat.code){
              for(var k = 0; k < manfaat.custList.length; k++){
                  var cust = manfaat.custList[k];
                  for(var l = 0; l < cust.itemInput.length; l++){
                      var itemInput = cust.itemInput[l];
                      if(itemInput.key == 'PDTERM'){
                        //Term
                        term = itemInput.inputValue + ';';
                      }else{
                        //Sum Assured
                        sumAssured = premi + ';';
                      }
                  }
                  /*if(manfaat.coverageType == 'topup'){
                      //Premium
                      premium = parseFloat($scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala)) <= 0 ? ';' : $scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala) + ';';
                      //term
                      term = '99' + ';';
                  }else if(manfaat.coverageType == 'main'){
                      //Premium
                      premium = $scope.replaceMoneyFormat($scope.ilustrasi.premi) + ';';
                      //term
                      term = '99' + ';';
                  }else{
                      //Premium
                      premium = cust.annualPremi + ';';
                  }*/
              }
              break;
          }
      }
      tmpBarcode +=  premium;
      tmpBarcode +=  sumAssured;
      tmpBarcode +=  term;            





      //"PRUearly stage payor"
      //Life Number 1
      tmpBarcode +=  anak ? ';' : '01' + ';';
      //Product Code / Rider Code
      tmpBarcode +=  covList[19] + ';';
      //Premium
      var premium = ';';
      //Sum Assured
      var sumAssured = ';';
      //Term
      var term = ';';
      for(var j = 0; j < manfaatSelected.length; j++){
          var  manfaat = manfaatSelected[j];
          if(covList[19] == manfaat.code){
              for(var k = 0; k < manfaat.custList.length; k++){
                  var cust = manfaat.custList[k];
                  for(var l = 0; l < cust.itemInput.length; l++){
                      var itemInput = cust.itemInput[l];
                      if(itemInput.key == 'PDTERM'){
                        //Term
                        term = itemInput.inputValue + ';';
                      }
                  }
                  //Sum Assured
                  sumAssured = sumResultPremiSaver + ';';
                  /*if(manfaat.coverageType == 'topup'){
                      //Premium
                      premium = parseFloat($scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala)) <= 0 ? ';' : $scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala) + ';';
                      //term
                      term = '99' + ';';
                  }else if(manfaat.coverageType == 'main'){
                      //Premium
                      premium = $scope.replaceMoneyFormat($scope.ilustrasi.premi) + ';';
                      //term
                      term = '99' + ';';
                  }else{
                      //Premium
                      premium = cust.annualPremi + ';';
                  }*/
              }
              break;
          }
      }
      tmpBarcode +=  premium;
      tmpBarcode +=  sumAssured;
      tmpBarcode +=  term;            






      //"PRUearly stage spouse payor"
      //Life Number 1
      tmpBarcode +=  anak ? ';' : '02' + ';';
      //Product Code / Rider Code
      tmpBarcode +=  covList[20] + ';';
      //Premium
      var premium = ';';
      //Sum Assured
      var sumAssured = ';';
      //Term
      var term = ';';
      for(var j = 0; j < manfaatSelected.length; j++){
          var  manfaat = manfaatSelected[j];
          if(covList[20] == manfaat.code){
              for(var k = 0; k < manfaat.custList.length; k++){
                  var cust = manfaat.custList[k];
                  for(var l = 0; l < cust.itemInput.length; l++){
                      var itemInput = cust.itemInput[l];
                      if(itemInput.key == 'PDTERM'){
                        //Term
                        term = itemInput.inputValue + ';';
                      }
                  }
                  //Sum Assured
                  sumAssured = sumResultPremiSaver + ';';
                  /*if(manfaat.coverageType == 'topup'){
                      //Premium
                      premium = parseFloat($scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala)) <= 0 ? ';' : $scope.replaceMoneyFormat($scope.ilustrasi.topupBerkala) + ';';
                      //term
                      term = '99' + ';';
                  }else if(manfaat.coverageType == 'main'){
                      //Premium
                      premium = $scope.replaceMoneyFormat($scope.ilustrasi.premi) + ';';
                      //term
                      term = '99' + ';';
                  }else{
                      //Premium
                      premium = cust.annualPremi + ';';
                  }*/
              }
              break;
          }
      }
      tmpBarcode +=  premium;
      tmpBarcode +=  sumAssured;
      tmpBarcode +=  term;            




      var incomeList = [';',';',';',';',';'];
      var jobList = [];
      for(var j = 0; j <= 4; j++){
          var job = {
                business : ';',
                department : ';',
                position : ';'
          }
          jobList.push(job);
      }

      var backDate = ';';

      for(var j = 2; j <= 6; j++){
          
              if(custMap['0' + j]){
                  var customer = getCustomerData(custMap['0' + j], customerDataList);
                  
                  for(var t = 0; t < tmpIncomeList.length; t++){
                      if(tmpIncomeList[t].code == customer.Income ){
                        incomeList[j-2] = tmpIncomeList[t].value + ';';
                        break;
                      }
                  }

                  //DOB
                  tmpBarcode +=  customer.name + ';';
                  //DOB
                  tmpBarcode +=  new Date(customer.Dob).yyyymmdd() + ';';

                  if(j == 2){
                    //Insurable Interest
                    tmpBarcode +=  '' + ';';                    
                  }

                  //Occupation Code
                  tmpBarcode +=  customer.Occupation.code + ';';
                  //Occupation Class
                  tmpBarcode +=  customer.Occupation.clazz + ';';

                  var jk = customer.jenisKelaminPerokok.split('|');
                  //Gender
                  tmpBarcode +=  jk[0] + ';';
                  //Smoking status
                  tmpBarcode +=  jk[1] + ';';


                  jobList[j-2].business = customer.Business + ';';
                  jobList[j-2].department = customer.Department + ';';
                  jobList[j-2].position = customer.Position + ';';


                  if(customer.tanggalBerlakuSurut && j == 2){
                      backDate = new Date(customer.tanggalBerlakuSurut).yyyymmdd() + ';';
                  }
              }else{
                  //DOB 1
                  tmpBarcode +=  ';';
                  //Insurable Interest
                  tmpBarcode +=  ';';
                  //Occupation Code
                  tmpBarcode +=  ';';
                  //Occupation Class
                  tmpBarcode +=  ';';
                  //Gender
                  tmpBarcode +=  ';';
                  //Smoking status
                  tmpBarcode +=  ';';
              }          
          
      }


      //BACKDATE
      tmpBarcode +=  backDate;




      //FUND
      for(var x = 0; x < fundListHardCode.length; x++){
          var fundCode = fundListHardCode[x];
          //Investment Type
          tmpBarcode +=  fundCode + ';';

          //Allocation Percentage
          var persentage = ';';
          /*for(var i = 0; i < fundList.length; i++){
              var fund = fundList[i];*/
             
              for(var j = 0; j < fundSelected.length; j++){
                  var  investasi = fundSelected[j];
                  if(fundCode == investasi.code){
                      // if(fund.code == investasi.code){
                          for(var l = 0; l < investasi.itemInput.length; l++){
                              var itemInput = investasi.itemInput[l];
                              var nol = '';
                              var lengthInputValue = (itemInput.inputValue).toString().length;
                              if(lengthInputValue > 0){
                                for(var e = 0; e < (3 - lengthInputValue); e++){
                                    nol += '0';
                                }
                              }
                              persentage = nol + itemInput.inputValue + ';';
                          }
                      // }
                  }
              }
          //}
          tmpBarcode +=  persentage;
      }

      //BILLING FREQUENCY
      tmpBarcode +=  payFreqCd + ';';

      //AGENT_NUMBER
      tmpBarcode +=  $rootScope.agent.code + ';';

      //CURRENCY
      tmpBarcode +=  currencyCd + ';';

      //SPAJ NUMBER
      tmpBarcode +=  spajno ? spajno + ';' : ';';


      //NAME
      tmpBarcode +=  pPolis.name + ';';      
      //OCCUPATION CODE
      tmpBarcode +=  pPolis.Occupation.code + ';';    

      
      //NAME
      tmpBarcode +=  payer.name + ';';      
      //OCCUPATION CODE
      tmpBarcode +=  payer.Occupation.code + ';';     

      //RISK PROFILE SUITABLE
      tmpBarcode +=  'Y' + ';';

      //INCOME
      //PAYER INCOME
      var payerIncome = ';'
      for(var t = 0; t < tmpIncomeList.length; t++){
          if(tmpIncomeList[t].code == payer.Income ){
            var nolIncome = '';
            var lengthIncome = tmpIncomeList[t].value.length;
            if(lengthIncome > 1){
              for(var f = 0; f < (11 - lengthIncome); f++){
                  nolIncome += '0';
              }            
            }
            payerIncome =  nolIncome + tmpIncomeList[t].value + ';';
            break;
          }
      }      
      tmpBarcode += payerIncome;
      for(var i = 0; i < incomeList.length; i++){
          var nolIncome1 = '';
          var lengthIncome = (incomeList[i].length)-1;
          if(lengthIncome > 1){
            for(var g = 0; g < (11 - lengthIncome); g++){
                nolIncome1 += '0';
            }            
          }
          tmpBarcode +=  nolIncome1 + incomeList[i];
      }

      //POLIS BUSINESS
      tmpBarcode +=  pPolis.Business + ';';
      //POLIS DEPARTMENT
      tmpBarcode +=  pPolis.Department + ';';
      //POLIS POSITION
      tmpBarcode +=  pPolis.Position + ';';


      //PAYER BUSINESS
      tmpBarcode +=  payer.Business + ';';
      //PAYER DEPARTMENT
      tmpBarcode +=  payer.Department + ';';
      //PAYER POSITION
      tmpBarcode +=  payer.Position + ';';

      for(var i = 0; i < jobList.length; i++){
          tmpBarcode += jobList[i].business;
          tmpBarcode += jobList[i].department;
          tmpBarcode += jobList[i].position;
      }

      //VERIVICATION CODE
      tmpBarcode += $scope.ilustrasi.uniqueCode;


      console.log(tmpBarcode);
      return tmpBarcode;
  }

  function getCustomerData(custId, customerDataList){
      for(var j = 0; j < customerDataList.length; j++){
          if(custId == customerDataList[j].customerId){
              return customerDataList[j];
          }
      }
  }

  function getCoverageFromStorage(coverageList){
      var allCoverage = [];
      for(var i = 0; i < coverageList.length; i++){
          var coverage = $rootScope.COVERAGE[coverageList[i].coverageCd];
          allCoverage.push(coverage);          
      }
      return allCoverage;
  }
  function getFundFromStorage(fundList){
      var allFund = [];
      for(var i = 0; i < fundList.length; i++){
          var fund = $rootScope.FUND[fundList[i]];
          allFund.push(fund);          
      }
      return allFund;
  }

  Date.prototype.hhmmss = function() {
      var hh = this.getHours(); // getMonth() is zero-based
      var mm = this.getMinutes();
      var ss = this.getSeconds();

      return [
                (hh>9 ? '' : '0') + hh,
                (mm>9 ? '' : '0') + mm,
                (ss>9 ? '' : '0') + ss

             ].join(':');
  }; 

  Date.prototype.yyyymmdd = function() {
      var mm = this.getMonth() + 1; // getMonth() is zero-based
      var dd = this.getDate();

      return [this.getFullYear(),
              (mm>9 ? '' : '0') + mm,
              (dd>9 ? '' : '0') + dd             
             ].join('');
  };
  
  QuotationStorageService.getQuotationStorageByKey($q, quotationId).then(function(resQuot){
      QUOTATION_STORAGE = resQuot;

      $rootScope.Level = 5;
      if(QUOTATION_STORAGE.Level < 5){
          QUOTATION_STORAGE.Level = 5;

          if(QUOTATION_STORAGE.QuotationDate == undefined){
              QUOTATION_STORAGE.QuotationDate = new Date();
          }
          QuotationStorageService.addQuotationStorage($q, quotationId, QUOTATION_STORAGE);
      }

      var prodCatCd = QUOTATION_STORAGE.Product.ProductCategory;
      var prodCd = QUOTATION_STORAGE.Product.ProductCode;
      var currCd = QUOTATION_STORAGE.Product.ProductCurrency;
      var fundList = QUOTATION_STORAGE.Product.FundList;
      var fundListFormat = QUOTATION_STORAGE.Product.FundList; //unused code
      $scope.ilustrasi.fundListOutput = fundList;
      $scope.danaInvestasiList = getDanaInvestasi(fundList);
      formatCurr = currCd == 'USD' ? 2 : 0;
      $scope.ilustrasi.prodCatCd = prodCatCd;
      $scope.ilustrasi.prodCd = prodCd;

      var product = getProduct(channelCode, prodCatCd, prodCd);
      $scope.ilustrasi.productName = product.shortName;
      var tmpCoverageList = getCoverageList(product, currCd);
      var tmpFundList = getFundList(product, currCd);

      
      var freqCd = QUOTATION_STORAGE.Product.PaymentFrequency;
      $scope.ilustrasi.frequency = $rootScope.PAYMENT_FREQUENSI[freqCd];
      $scope.ilustrasi.currency = currCd;

      $scope.ilustrasi.premi = $scope.getNewPremi(freqCd, QUOTATION_STORAGE.Manfaat.premi);
      $scope.ilustrasi.topupBerkala = 0 ;
      $scope.ilustrasi.totalPremi = $scope.getNewPremi(freqCd, QUOTATION_STORAGE.Manfaat.totalPremi);
      $scope.ilustrasi.totalPremiThn = QUOTATION_STORAGE.Manfaat.totalPremi;
      $scope.ilustrasi.strTotalPremiThn = parseFloat(QUOTATION_STORAGE.Manfaat.totalPremi).format(formatCurr);
      $scope.ilustrasi.alternatifRencanaPembayaran = QUOTATION_STORAGE.Manfaat.alternatifRencanaPembayaran;

      var rencanaPembayaran = QUOTATION_STORAGE.Manfaat.rencanaPembayaran;
      
      var spajNo = QUOTATION_STORAGE.Product.SPAJNo;

      if(spajNo == undefined){
          $scope.ilustrasi.SPAJNo = '';  
      }else{
          $scope.ilustrasi.SPAJNo = spajNo;
      }
      
      function sortingRiderTopupMain(tempManfaatList){
        console.log('sorting rider == ',tempManfaatList);
        var manfaatList = [];
        for(var i = 0; i < tempManfaatList.length; i++){
          var tmpManfaat = tempManfaatList[i];
          for(var j = 0; j < tmpManfaat.custList.length; j++){
            var tmpCustList = tmpManfaat.custList[j];
            var isInsert = false;
            var manfaat = {};

            manfaat.code = tmpManfaat.code;
            manfaat.name = tmpManfaat.name;
            manfaat.disabled = tmpManfaat.disabled;
            manfaat.coverageType = tmpManfaat.coverageType;
            manfaat.type = tmpManfaat.type;
            manfaat.lifeAssureCd = tmpManfaat.lifeAssureCd;


            manfaat.tertanggungName = tmpCustList.name;
            manfaat.tertanggungAge = tmpCustList.anb;
            manfaat.tertanggungKey = tmpCustList.key;
            manfaat.tertanggungCustomerId = tmpCustList.customerId;
            manfaat.biayaBulanan = tmpCustList.biayaBulanan;
            manfaat.annualPremi = tmpCustList.annualPremi;
            manfaat.itemInput = tmpCustList.itemInput;

            for(var k = 0; k < tmpCustList.itemInput.length; k++){
              if((tmpCustList.itemInput[k].key=='PDPLAN' && tmpCustList.itemInput[k].inputValue == '') || (tmpCustList.itemInput[k].key=='PDPLAN' && tmpCustList.itemInput[k].inputValue == 'N')){
                  isInsert = false;
                  break;
              }else if(tmpCustList.itemInput[k].key=='PDTERM' && tmpCustList.itemInput[k].inputValue == ''){
                  isInsert = false;
                  break;
              }else if(tmpCustList.itemInput[k].key=='PDUNIT' && tmpCustList.itemInput[k].inputValue == ''){
                  isInsert = false;
                  break;
              }else{
                  isInsert = true;
              }    
            }

            console.log('ifInsert == ',tmpManfaat.code + ' - '+isInsert);

            if(isInsert){
              manfaatList.push(manfaat);  
            }
            
          }         
        }
        return manfaatList;
      }

      
      console.log(QUOTATION_STORAGE.Manfaat.manfaatList);
      $scope.ilustrasi.manfaatList = sortingRiderTopupMain(QUOTATION_STORAGE.Manfaat.manfaatList);
      console.log($scope.ilustrasi.manfaatList);

      var premi = parseFloat(QUOTATION_STORAGE.Manfaat.premi);
      var saver = parseFloat($scope.ilustrasi.saverValue);

      console.log(premi + '- '+ $scope.ilustrasi.totalPremiThn);

      $scope.ilustrasi.manfaatListFormat = manfaatListToFormatCurrency($scope.ilustrasi.manfaatList, premi, $scope.ilustrasi.totalPremiThn, $scope.ilustrasi.frequency);
      console.log($scope.ilustrasi.manfaatListFormat);

      var uangPertanggungan;
      for(var x = 0; x < $scope.ilustrasi.manfaatList.length; x++){
          var coverageType = $scope.ilustrasi.manfaatList[x].coverageType;
          if(coverageType == 'main'){
            uangPertanggungan = $scope.ilustrasi.manfaatList[x].itemInput[0].inputValue;
          }
      }

      $scope.ilustrasi.uangPertanggungan = uangPertanggungan;
      

      //***************** Topup & Penarikan ***********************//
      var manfaatTopup = QUOTATION_STORAGE.Manfaat.manfaatTopup;
      
      var totalPenarikan = 0;

      var dataFund = [];

      for(var fundcnt = 0; fundcnt < fundList.length; fundcnt++){
        var fundObject = fundList[fundcnt];
        dataFund.push(fundObject.code+'|'+fundObject.itemInput[0].inputValue);        
      }

      var dataTopUp = [];
      var totalTopup = 0;
      if(manfaatTopup != undefined){
        
        for(var cnt = 0; cnt < manfaatTopup.length; cnt++){
            var topupData = manfaatTopup[cnt];

            for(var i = parseInt(topupData.yearStart); i <= parseInt(topupData.yearEnd); i++){
                totalTopup = totalTopup + parseFloat(topupData.amount);

            }
            

            for(var year = parseInt(topupData.yearStart); year <= parseInt(topupData.yearEnd); year++){
              dataTopUp.push(year.toString()+'|'+topupData.amount);
            }
        } 
      }

      $scope.ilustrasi.totalTopup = totalTopup;


      var manfaatPenarikan = QUOTATION_STORAGE.Manfaat.manfaatPenarikan;
      var dataPenarikan = [];

      if(manfaatPenarikan != undefined){
          for(var cnt2 = 0; cnt2 < manfaatPenarikan.length; cnt2++){
            var penarikanData = manfaatPenarikan[cnt2];
            totalPenarikan = totalPenarikan + parseFloat(penarikanData.amount);

            for(var year = parseInt(penarikanData.yearStart); year <= parseInt(penarikanData.yearEnd); year++){
              dataPenarikan.push(year.toString()+'|'+penarikanData.amount);
            }

        }
      }

      
      $scope.ilustrasi.totalPenarikan = totalPenarikan;
      $scope.ilustrasi.dataFund = dataFund;
      $scope.ilustrasi.dataTopUp = dataTopUp;
      $scope.ilustrasi.dataPenarikan = dataPenarikan;

      //***************** Topup & Penarikan ***********************//

      var pruHSFlag;
      var pruCCB61Flag;
      var pruMedCoverFlag;
      var isPickSpouseFlag = false;
      var isPickParentFlag = false;
      for(var i = 0; i < $scope.ilustrasi.manfaatList.length; i++){
          var productCode = $scope.ilustrasi.manfaatList[i].code;
          var productName = $scope.ilustrasi.manfaatList[i].name;
          if(productCode == 'H1TR'){
              pruHSFlag = true;
          }else if(productCode == 'C1WR' ||productCode == 'C1WD'){
              pruCCB61Flag = true;
          }else if(productCode == 'H1VR'){
              pruMedCoverFlag = true;
          }

          if(productName.toLowerCase().indexOf('spouse') > -1){
              isPickSpouseFlag = true;
          }

          if(productCode == 'W3AR' ||productCode == 'W1XR'){
              isPickParentFlag = true;
          } 

      }
      
          
      $scope.ilustrasi.pruHSFlag = pruHSFlag;
      $scope.ilustrasi.pruCCB61Flag = pruCCB61Flag;
      $scope.ilustrasi.pruMedCoverFlag = pruMedCoverFlag;
      $scope.ilustrasi.isPickSpouseFlag = isPickSpouseFlag;
      $scope.ilustrasi.isPickParentFlag = isPickParentFlag;

      if(pruMedCoverFlag){
          $scope.ilustrasi.pruMedLabel = '#';
          $scope.ilustrasi.pruMedLabelDesc = 'Keterangan lengkap lihat tabel Tindakan Bedah di dalam Polis';        
      }else{
          $scope.ilustrasi.pruMedLabel = ' ';
          $scope.ilustrasi.pruMedLabelDesc = ' ';
      }

      var agentId = $rootScope.agent.code;
      var agentName = $rootScope.userLoginName;
      var agentOffice = $rootScope.agent.agentOfficeCode;

      if(agentId != undefined){
          $scope.ilustrasi.agentId = agentId;
      }else{
          $scope.ilustrasi.agentId = '';
      }

      if(agentName != undefined){
          $scope.ilustrasi.agentName = agentName;
      }else{
          $scope.ilustrasi.agentName = '';
      }

      if(agentOffice != undefined){
          $scope.ilustrasi.agentOffice = agentOffice;
      }else{
          $scope.ilustrasi.agentOffice = '';
      }

      $scope.ilustrasi.today = today();

      $scope.ilustrasi.versi = 'New SQS v.1.0';

      if(QUOTATION_STORAGE.QuotationDate != undefined){
          $scope.ilustrasi.QuotationDate = getDate(QUOTATION_STORAGE.QuotationDate.toString());  
      }else{
          $scope.ilustrasi.QuotationDate = $scope.ilustrasi.today;
      }


      $scope.ilustrasi.formatDate = getMonthName['1'];



      //GET ALL CUSTOMER LIST 
      CustomerStorageService.getCustomerStorageByCustMap($q, QUOTATION_STORAGE.CustomerList).then(function(resCust){
          CUSTOMER_LIST = resCust;
          var benefitList = getCoverageFromStorage(tmpCoverageList);
          var investasiList = getFundFromStorage(tmpFundList);
          var docId = $scope.ilustrasi.docIdStandard;
          var barcode = generateBarcode(docId, CUSTOMER_LIST, tmpCoverageList);
          $scope.ilustrasi.barcode = barcode;
      })


      var custId = QUOTATION_STORAGE.CustomerList['02'];
      CustomerStorageService.getCustomerStorageByKey($q, custId).then(function(resCust){
        CUSTOMER = resCust;
        console.log('isi dari data tertanggung utama ',resCust)
        console.log(CUSTOMER);

        $scope.ilustrasi.tertanggungName = CUSTOMER.name;
        $scope.ilustrasi.age = CUSTOMER.anb + ' tahun';
        
        var dateDOB = new Date(CUSTOMER.Dob);

        var dd = dateDOB.getDate().toString().length==1?'0'+dateDOB.getDate().toString():dateDOB.getDate().toString();
        var mm = (dateDOB.getMonth()+1).toString().length==1?'0'+(dateDOB.getMonth()+1).toString():(dateDOB.getMonth()+1).toString();
        var yyyy = dateDOB.getFullYear().toString();
        
        console.log(dateDOB.getDate().toString().length);
        console.log(dd + ' - ' + mm + ' - '+yyyy);

        $scope.ilustrasi.anb = CUSTOMER.anb + ' ('+CUSTOMER.Dob+')';
        $scope.ilustrasi.ageonly = CUSTOMER.anb;
        anb = CUSTOMER.anb + ' ('+CUSTOMER.Dob+')';
        var datetime = CUSTOMER.Dob.split('-');
        $scope.ilustrasi.dob = getFormatDate(dd, mm, yyyy);

        $scope.ilustrasi.gender = CUSTOMER.jenisKelaminPerokok ? getGender(CUSTOMER.jenisKelaminPerokok) : 'kosong';
        $scope.ilustrasi.kodepekerjaan = CUSTOMER.Occupation.code;
        $scope.ilustrasi.pekerjaan = CUSTOMER.Occupation.nameInd;
        $scope.ilustrasi.deskripsiPekerjaan = CUSTOMER.Occupation.descriptionInd;
        $scope.ilustrasi.kelasPekerjaan = CUSTOMER.Occupation.clazz;
        $scope.ilustrasi.departement = CUSTOMER.Department;

        if(CUSTOMER.subStandard == undefined){
          CUSTOMER.subStandard = false;
        }

        $scope.ilustrasi.substandardFlag = CUSTOMER.subStandard;
        $scope.ilustrasi.backDatedFlag = CUSTOMER.berlakuSurut;


        //ditarik kebawah, untuk dapetin age, by Aulia
        
      if(rencanaPembayaran == undefined || rencanaPembayaran == 0 ){
          $scope.ilustrasi.rencanaPembayaran = 99 - CUSTOMER.anb;  
      }else{
          $scope.ilustrasi.rencanaPembayaran = rencanaPembayaran;
      }

      
      if(isNaN($scope.ilustrasi.totalPremiThn)){
          $scope.ilustrasi.totalPremiAll = parseFloat($scope.ilustrasi.totalPremiThn.replace(/,/g , "")) *$scope.ilustrasi.rencanaPembayaran;
      }else{
          $scope.ilustrasi.totalPremiAll = $scope.ilustrasi.totalPremiThn*$scope.ilustrasi.rencanaPembayaran;
      }
      
        
        //-------- ian pj ---------
        var subValList = []; 
        // ----- Parsing Array ke String ------
        var nilai = '';
        //var pengecualian = '';
        $scope.ilustrasi.substandardValue = formatSubStandart;
        if(CUSTOMER.loadList != undefined || CUSTOMER.loadList != null){
          formatSubStandart = getSubStandart(CUSTOMER);
          if(CUSTOMER.Pengecualian != undefined || CUSTOMER.Pengecualian != null){
            $scope.ilustrasi.Pengecualian = CUSTOMER.Pengecualian==undefined?' ':CUSTOMER.Pengecualian;
            console.log('isi data dari $scope.ilustrasi = ',$scope.ilustrasi);
          }
          console.log('isi data formatSubStandart = ',formatSubStandart);
          $scope.ilustrasi.substandardValue = formatSubStandart.substring(0, formatSubStandart.length-1);
        }

        console.log('data customer tertanggung utama = ',CUSTOMER);
        
        
        for(var buss=0; buss< $rootScope.businessList.length; buss++){
            if ($rootScope.businessList[buss].code == CUSTOMER.Business) {
                $scope.ilustrasi.bidUsaha = $rootScope.businessList[buss].descriptionInd;
                $scope.ilustrasi.kodebidUsaha = $rootScope.businessList[buss].code;                   
            }
        }
        for(var jab=0; jab< $rootScope.positionList.length; jab++){
            if ($rootScope.positionList[jab].code == CUSTOMER.Position) {
              $scope.ilustrasi.jabatanPangkat = $rootScope.positionList[jab].descriptionInd;
              $scope.ilustrasi.kodejabatanPangkat = $rootScope.positionList[jab].code; 
            }
        }
        for(var incm in $rootScope.incomeList){
          if(incm == 'Individual'){
            for(var x=0; x<$rootScope.incomeList[incm].length; x++){
                if ($rootScope.incomeList[incm][x].code == CUSTOMER.Income) {
                  $scope.ilustrasi.nilaiIncome = $rootScope.incomeList[incm][x].code  +' '+$rootScope.incomeList[incm][x].individualInd
                }
            }
          }
          if(incm == 'Corporate'){
            for(var x=0; x<$rootScope.incomeList[incm].length; x++){
                if ($rootScope.incomeList[incm][x].code == CUSTOMER.Income) {
                  $scope.ilustrasi.nilaiIncome = $rootScope.incomeList[incm][x].code  +' '+$rootScope.incomeList[incm][x].corporateInd
                }
            }
          }
        }

        var rateCd = 'RTMAXSA';
        var ageLife1 = CUSTOMER.anb;
        var gender = CUSTOMER.jenisKelaminPerokok.split("|")[0];
        var smokerStatus = CUSTOMER.jenisKelaminPerokok.split("|")[1];
        var clazz = ' ';
        var term = ' ';
        var plan = ' ';
        console.log(rateCd +' - '+ageLife1+ ' - '+gender+ ' - '+smokerStatus);
        RateStorageService.getRate($q, rateCd, ageLife1, gender, smokerStatus, clazz, term, plan).then(function(rate){
          console.log('isi dari rate RTMAXSA == ',rate);

          //           if(res.rows.length > 0){
          //     for(var i =0 ; i < res.rows.length; i++)
          //     {
          //       if(res.rows.item(i).pdfdata != "data:")
          //       {
          //         chunk_blob.push(b64toBlob(res.rows.item(i).pdfdata.replace("data:;base64,",'')));
          //       }
          //     }
          //     var b2 = new Blob(chunk_blob,{type: 'application/pdf'});
          //     $scope.pdfUrl = URL.createObjectURL(b2);
          //     init2().then(function(){
          //           $scope.modal.show();
          //       });
          // }
          console.log('rate.rows.length == ',rate.rows.length);
          if(rate.rows.length > 0){
              $scope.ilustrasi.rtMaxSAValue = rate.rows.item(0).value;  
          }else{
              console.log('rtMaxSAValue undefined xxx');
              $scope.ilustrasi.rtMaxSAValue = 1;
          }
          
          console.log('RT Max SA Value == ', $scope.ilustrasi.rtMaxSAValue);

          var docIdStandard = '';
          var docIdRingkasan = '';
          var docIdSubstandar = '';
          var docIdBackdated = '17060306';
          var docIdDropHS = '14570901';

          if(prodCd == 'U1Z' && $scope.ilustrasi.currency == 'IDR'){
              // PAA Revamp Rupiah
              docIdStandard = '17030970';
              docIdSubstandar = '17030973';
              docIdRingkasan = '17060307';
          }else if(prodCd == 'U1Z' && $scope.ilustrasi.currency == 'USD'){
              // PAA Revamp USD
              docIdStandard = '17030971';
              docIdSubstandar = '17030974';
          }

          if($scope.ilustrasi.substandardValue != ""){
              console.log('ada subStandard');
              $scope.ilustrasi.docIdStandard = docIdSubstandar;  
          }else{
              console.log('tidak ada subStandard');
              $scope.ilustrasi.docIdStandard = docIdStandard;  
          }
          
          $scope.ilustrasi.docIdRingkasan = docIdRingkasan;
          // $scope.ilustrasi.docIdStandard = docIdStandard;
          // $scope.ilustrasi.docIdSubstandar = docIdSubstandar;
          $scope.ilustrasi.docIdBackdated = docIdBackdated;
          $scope.ilustrasi.docIdDropHS = docIdDropHS;

          PublishGlobalService.getpdf($q, $rootScope.QuotationId).then(function(res){
              if(res.rows.length > 0){
                  $scope.progress_msg = "Selesai!";
                  $scope.pdfready = true;
                }else{
                    console.log('$scope.ilustrasi ketika proses pdf .... ',$scope.ilustrasi);
                    OutputService.createPdf($scope.ilustrasi).then(function (pdf) {
                      blob = new Blob([pdf], { type: 'application/pdf' });
                      endChunk = blob.size/4;
                      $scope.doStorePdf();
                      //$scope.pdfUrl = URL.createObjectURL(blob);
                      // console.log("link pdf"+$scope.pdfUrl);            
                      // Display the modal view
                      // $scope.modal.show();
                      end = new Date();
                      end = end.getHours() + ":" + end.getMinutes() + ":" + end.getSeconds();
                      // init2().then(function(){
                      //   $scope.modal.show();
                      // })
                  });
                }
            });
          })
    });

            //----- jika Pemegang Polis
      custIdPemegangPolis = QUOTATION_STORAGE.CustomerList['01'];
      CustomerStorageService.getCustomerStorageByKey($q, custIdPemegangPolis).then(function(resCust){
      CUSTOMER_PEMEGANGPOLIS = resCust;

        $scope.ilustrasi.pemegangPolis = CUSTOMER_PEMEGANGPOLIS.name;
        // $scope.ilustrasi.nomorSPAJ = validProdNoSpaj;
        $scope.ilustrasi.kodepekerjaanPemegangPolis = CUSTOMER_PEMEGANGPOLIS.Occupation.code;
        $scope.ilustrasi.pekerjaanPemegangPolis = CUSTOMER_PEMEGANGPOLIS.Occupation.nameInd;
        $scope.ilustrasi.instansiDepartement = CUSTOMER_PEMEGANGPOLIS.Department;
        //------- FOR BIDANG USAHA PEMEGANG POLIS
        for(var i=0; i< $rootScope.businessList.length; i++){
            if ($rootScope.businessList[i].code == CUSTOMER_PEMEGANGPOLIS.Business) {
              $scope.ilustrasi.bidangUsaha = $rootScope.businessList[i].descriptionInd                   
            }
        }
      
        //------- FOR JABATAN PEMEGANG POLIS
        for(var y=0; y< $rootScope.positionList.length; y++){
            if ($rootScope.positionList[y].code == CUSTOMER_PEMEGANGPOLIS.Position) {
              $scope.ilustrasi.jabatanPemegangPolis = $rootScope.positionList[y].descriptionInd;
              $scope.ilustrasi.kodejabatanPemegangPolis = $rootScope.positionList[y].code; 
            }
        }

        var totalIncome = $rootScope.incomeList;
        for(var im in totalIncome){
          if(im == 'Individual'){
            for(var m=0; m<totalIncome[im].length; m++){
                if (totalIncome[im][m].code == CUSTOMER_PEMEGANGPOLIS.Income) {
                  $scope.ilustrasi.nilaiIncome = totalIncome[im][m].code  +' '+totalIncome[im][m].individualInd
                }
            }
            }
          }
      });


      $scope.ilustrasi.fundList = [];
      $scope.ilustrasi.fundListFormat = [];
      var outputId = QUOTATION_STORAGE.OutputId;
      OutputStorageService.getOutputStorageByKey($q, outputId).then(function(resOut){
        OUTPUT = resOut;
        console.log('OUTPUT == ',OUTPUT);
        $scope.ilustrasi.output = OUTPUT;
        $scope.ilustrasi.fundList = generateAsumtionCashValue(QUOTATION_STORAGE.Manfaat, OUTPUT.output['FUNDBENEFIT']);
        console.log('Angen $scope.ilustrasi.fundList == ',$scope.ilustrasi.fundList);
        $scope.ilustrasi.fundListFormat = generateAsumtionsFormatNumber(QUOTATION_STORAGE.Manfaat, OUTPUT.output['FUNDBENEFIT']);

        var warningRule = [];
        if(OUTPUT.mapRule != undefined && OUTPUT.mapRule.length > 0){
          for(var i = 0; i < OUTPUT.mapRule.length; i++){
              var rule = OUTPUT.mapRule[i];
              console.log('rule === ',rule);
              if(rule.type.toUpperCase() == 'WARNING'){
                  warningRule.push(rule.errorMsg);
              }

          }

          console.log('warning Rule == ',warningRule);

          if(warningRule.length > 0){
            $scope.ilustrasi.warningRule = warningRule;
          }
        }

                
        // $scope.ilustrasi.fundListAlt = generateAsumtionCashValue(QUOTATION_STORAGE.Manfaat, OUTPUT.output['FUNDBENEFIT']);
        // $scope.ilustrasi.deathBenefitList = generateAsumtionCashValue(QUOTATION_STORAGE.Manfaat, OUTPUT.output['DEATHBENEFIT']);
        // $scope.ilustrasi.deathBenefitListAlt = generateAsumtionCashValue(QUOTATION_STORAGE.Manfaat, OUTPUT.output['DEATHBENEFIT']);    

        // added by Efrat -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        getJenisMedical(prodCatCd, prodCd, currCd, anb);
        

      });

      var custIdTT1 = QUOTATION_STORAGE.CustomerList['03'];
      if(custIdTT1 != null || custIdTT1 != undefined){
        CustomerStorageService.getCustomerStorageByKey($q, custIdTT1).then(function(resCust){
        CUSTOMER_TERTANGGUNGTAMBAHAN1 = resCust;
        console.log('isi dari data tertanggung tambahan 1 ',resCust);

        if(CUSTOMER_TERTANGGUNGTAMBAHAN1.loadList != undefined){
          formatSubStandart = formatSubStandart.substring(0, formatSubStandart.length-1);
          formatSubStandart = ' '+formatSubStandart+'/';
          formatSubStandart = formatSubStandart+getSubStandart(CUSTOMER_TERTANGGUNGTAMBAHAN1);
          $scope.ilustrasi.substandardValue = ' '+formatSubStandart.substring(0, formatSubStandart.length-1);
        }


        if(CUSTOMER_TERTANGGUNGTAMBAHAN1 && $scope.ilustrasi.isPickParentFlag){
              console.log('Ada tertanggung tambahan 1');
              $scope.ilustrasi.tertanggungtambahan1flag = true;
              $scope.ilustrasi.tertanggungNameTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.name;


              $scope.ilustrasi.ageTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.anb + ' tahun';
              
              var dateDOB = new Date(CUSTOMER_TERTANGGUNGTAMBAHAN1.Dob);

              var dd = dateDOB.getDate().toString().length==1?'0'+dateDOB.getDate().toString():dateDOB.getDate().toString();
              var mm = (dateDOB.getMonth()+1).toString().length==1?'0'+(dateDOB.getMonth()+1).toString():(dateDOB.getMonth()+1).toString();
              var yyyy = dateDOB.getFullYear().toString();
              
              console.log(dateDOB.getDate().toString().length);
              console.log(dd + ' - ' + mm + ' - '+yyyy);

              $scope.ilustrasi.anbTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.anb + ' ('+CUSTOMER_TERTANGGUNGTAMBAHAN1.Dob+')';
              $scope.ilustrasi.ageonlyTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.anb;
              anb = CUSTOMER_TERTANGGUNGTAMBAHAN1.anb + ' ('+CUSTOMER_TERTANGGUNGTAMBAHAN1.Dob+')';
              var datetime = CUSTOMER_TERTANGGUNGTAMBAHAN1.Dob.split('-');
              $scope.ilustrasi.dobTT1 = getFormatDate(dd, mm, yyyy);

              $scope.ilustrasi.genderTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.jenisKelaminPerokok ? getGender(CUSTOMER_TERTANGGUNGTAMBAHAN1.jenisKelaminPerokok) : 'kosong';
              $scope.ilustrasi.kodepekerjaanTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.Occupation.code;
              $scope.ilustrasi.pekerjaanTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.Occupation.nameInd;
              $scope.ilustrasi.deskripsiPekerjaanTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.Occupation.descriptionInd;
              $scope.ilustrasi.kelasPekerjaanTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.Occupation.clazz;
              $scope.ilustrasi.departementTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.Department;

              for(var i=0; i< $rootScope.businessList.length; i++){
                  if ($rootScope.businessList[i].code == CUSTOMER_TERTANGGUNGTAMBAHAN1.Business) {
                    $scope.ilustrasi.bidangUsahaTT1 = $rootScope.businessList[i].descriptionInd                   
                  }
              }

              
            
              //------- FOR JABATAN PEMEGANG POLIS
              for(var y=0; y< $rootScope.positionList.length; y++){
                  if ($rootScope.positionList[y].code == CUSTOMER_TERTANGGUNGTAMBAHAN1.Position) {
                    $scope.ilustrasi.jabatanPemegangPolisTT1 = $rootScope.positionList[y].descriptionInd;
                    $scope.ilustrasi.kodejabatanPemegangPolisTT1 = $rootScope.positionList[y].code; 
                  }
              }

              var totalIncome = $rootScope.incomeList;
              for(var im in totalIncome){
                if(im == 'Individual'){
                  for(var m=0; m<totalIncome[im].length; m++){
                      if (totalIncome[im][m].code == CUSTOMER_TERTANGGUNGTAMBAHAN1.Income) {
                        $scope.ilustrasi.nilaiIncomeTT1 = totalIncome[im][m].code  +' '+totalIncome[im][m].individualInd
                      }
                  }
                }
              }

              $scope.ilustrasi.labelTT1 = 'Orang Tua';
              $scope.ilustrasi.totPenghasilan = 'Total Penghasilan Rutin Orangtua 1 per Bulan**';                  

              $scope.ilustrasi.labelAnb1 = 'Usia tahun Berikutnya ';
              $scope.ilustrasi.lbPekerjaan = 'Pekerjaan **';
              $scope.ilustrasi.lbInstansiDepartement = 'Instansi/Departemen';
              $scope.ilustrasi.lbBidangUsaha = 'Bidang Usaha ';
              $scope.ilustrasi.lbJabatan = 'Jabatan/Pangkat/Golongan';
                        
        }else if(CUSTOMER_TERTANGGUNGTAMBAHAN1 && $scope.ilustrasi.isPickSpouseFlag){
            console.log('Ada tertanggung tambahan 1');
              $scope.ilustrasi.tertanggungtambahan1flag = true;
              $scope.ilustrasi.tertanggungNameTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.name;


              $scope.ilustrasi.ageTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.anb + ' tahun';
              
              var dateDOB = new Date(CUSTOMER_TERTANGGUNGTAMBAHAN1.Dob);

              var dd = dateDOB.getDate().toString().length==1?'0'+dateDOB.getDate().toString():dateDOB.getDate().toString();
              var mm = (dateDOB.getMonth()+1).toString().length==1?'0'+(dateDOB.getMonth()+1).toString():(dateDOB.getMonth()+1).toString();
              var yyyy = dateDOB.getFullYear().toString();
              
              console.log(dateDOB.getDate().toString().length);
              console.log(dd + ' - ' + mm + ' - '+yyyy);

              $scope.ilustrasi.anbTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.anb + ' ('+CUSTOMER_TERTANGGUNGTAMBAHAN1.Dob+')';
              $scope.ilustrasi.ageonlyTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.anb;
              anb = CUSTOMER_TERTANGGUNGTAMBAHAN1.anb + ' ('+CUSTOMER_TERTANGGUNGTAMBAHAN1.Dob+')';
              var datetime = CUSTOMER_TERTANGGUNGTAMBAHAN1.Dob.split('-');
              $scope.ilustrasi.dobTT1 = getFormatDate(dd, mm, yyyy);

              $scope.ilustrasi.genderTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.jenisKelaminPerokok ? getGender(CUSTOMER_TERTANGGUNGTAMBAHAN1.jenisKelaminPerokok) : 'kosong';
              $scope.ilustrasi.kodepekerjaanTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.Occupation.code;
              $scope.ilustrasi.pekerjaanTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.Occupation.nameInd;
              $scope.ilustrasi.deskripsiPekerjaanTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.Occupation.descriptionInd;
              $scope.ilustrasi.kelasPekerjaanTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.Occupation.clazz;
              $scope.ilustrasi.departementTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.Department;

              for(var i=0; i< $rootScope.businessList.length; i++){
                  if ($rootScope.businessList[i].code == CUSTOMER_TERTANGGUNGTAMBAHAN1.Business) {
                    $scope.ilustrasi.bidangUsahaTT1 = $rootScope.businessList[i].descriptionInd                   
                  }
              }

              if(CUSTOMER_TERTANGGUNGTAMBAHAN1.loadList != undefined){
                formatSubStandart = formatSubStandart.substring(0, formatSubStandart.length-1);
                formatSubStandart = formatSubStandart+'/';
                formatSubStandart = formatSubStandart+getSubStandart(CUSTOMER_TERTANGGUNGTAMBAHAN1);
                $scope.ilustrasi.substandardValue = formatSubStandart.substring(0, formatSubStandart.length-1);
              }
            
              //------- FOR JABATAN PEMEGANG POLIS
              for(var y=0; y< $rootScope.positionList.length; y++){
                  if ($rootScope.positionList[y].code == CUSTOMER_TERTANGGUNGTAMBAHAN1.Position) {
                    $scope.ilustrasi.jabatanPemegangPolisTT1 = $rootScope.positionList[y].descriptionInd;
                    $scope.ilustrasi.kodejabatanPemegangPolisTT1 = $rootScope.positionList[y].code; 
                  }
              }

              var totalIncome = $rootScope.incomeList;
              for(var im in totalIncome){
                if(im == 'Individual'){
                  for(var m=0; m<totalIncome[im].length; m++){
                      if (totalIncome[im][m].code == CUSTOMER_TERTANGGUNGTAMBAHAN1.Income) {
                        $scope.ilustrasi.nilaiIncomeTT1 = totalIncome[im][m].code  +' '+totalIncome[im][m].individualInd
                      }
                  }
                }
              }


              $scope.ilustrasi.labelTT1 = 'Suami/Istri';
              $scope.ilustrasi.totPenghasilan = 'Total Penghasilan Rutin Suami/Istri 1 per Bulan**';    
              

              $scope.ilustrasi.labelAnb1 = 'Usia tahun Berikutnya ';
              $scope.ilustrasi.lbPekerjaan = 'Pekerjaan **';
              $scope.ilustrasi.lbInstansiDepartement = 'Instansi/Departemen';
              $scope.ilustrasi.lbBidangUsaha = 'Bidang Usaha ';
              $scope.ilustrasi.lbJabatan = 'Jabatan/Pangkat/Golongan';
        }else{
            $scope.ilustrasi.tertanggungNameTT1 = '';
            $scope.ilustrasi.ageTT1 = '';
            $scope.ilustrasi.anbTT1 = '';
            $scope.ilustrasi.ageonlyTT1 = '';
            $scope.ilustrasi.dobTT1 = '';
            $scope.ilustrasi.genderTT1 = '';
            $scope.ilustrasi.genderTT1 = '';
            $scope.ilustrasi.kodepekerjaanTT1 = '';
            $scope.ilustrasi.pekerjaanTT1 = '';
            $scope.ilustrasi.deskripsiPekerjaanTT1 = '';
            $scope.ilustrasi.kelasPekerjaanTT1 = '';
            $scope.ilustrasi.departementTT1 = '';
            $scope.ilustrasi.bidangUsahaTT1 = '';
            $scope.ilustrasi.jabatanPemegangPolisTT1 = '';
            $scope.ilustrasi.kodejabatanPemegangPolisTT1 = '';
            $scope.ilustrasi.nilaiIncomeTT1 = '';

            $scope.ilustrasi.labelTT1 = '';
            $scope.ilustrasi.labelAnb1 = '';
            $scope.ilustrasi.lbInstansiDepartement = '';
            $scope.ilustrasi.bidangUsaha = '';
            $scope.ilustrasi.jabatan = '';
            $scope.ilustrasi.totPenghasilan = '';
        }

        /*
        if(CUSTOMER_TERTANGGUNGTAMBAHAN1 && $scope.ilustrasi.isPickSpouseFlag){
              console.log('Ada tertanggung tambahan 1');
              $scope.ilustrasi.tertanggungtambahan1flag = true;
              $scope.ilustrasi.tertanggungNameTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.name;


              $scope.ilustrasi.ageTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.anb + ' tahun';
              
              var dateDOB = new Date(CUSTOMER_TERTANGGUNGTAMBAHAN1.Dob);

              var dd = dateDOB.getDate().toString().length==1?'0'+dateDOB.getDate().toString():dateDOB.getDate().toString();
              var mm = (dateDOB.getMonth()+1).toString().length==1?'0'+(dateDOB.getMonth()+1).toString():(dateDOB.getMonth()+1).toString();
              var yyyy = dateDOB.getFullYear().toString();
              
              console.log(dateDOB.getDate().toString().length);
              console.log(dd + ' - ' + mm + ' - '+yyyy);

              $scope.ilustrasi.anbTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.anb + ' ('+CUSTOMER_TERTANGGUNGTAMBAHAN1.Dob+')';
              $scope.ilustrasi.ageonlyTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.anb;
              anb = CUSTOMER_TERTANGGUNGTAMBAHAN1.anb + ' ('+CUSTOMER_TERTANGGUNGTAMBAHAN1.Dob+')';
              var datetime = CUSTOMER_TERTANGGUNGTAMBAHAN1.Dob.split('-');
              $scope.ilustrasi.dobTT1 = getFormatDate(dd, mm, yyyy);

              $scope.ilustrasi.genderTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.jenisKelaminPerokok ? getGender(CUSTOMER_TERTANGGUNGTAMBAHAN1.jenisKelaminPerokok) : 'kosong';
              $scope.ilustrasi.kodepekerjaanTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.Occupation.code;
              $scope.ilustrasi.pekerjaanTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.Occupation.nameInd;
              $scope.ilustrasi.deskripsiPekerjaanTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.Occupation.descriptionInd;
              $scope.ilustrasi.kelasPekerjaanTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.Occupation.clazz;
              $scope.ilustrasi.departementTT1 = CUSTOMER_TERTANGGUNGTAMBAHAN1.Department;

              for(var i=0; i< $rootScope.businessList.length; i++){
                  if ($rootScope.businessList[i].code == CUSTOMER_TERTANGGUNGTAMBAHAN1.Business) {
                    $scope.ilustrasi.bidangUsahaTT1 = $rootScope.businessList[i].descriptionInd                   
                  }
              }

              if(CUSTOMER_TERTANGGUNGTAMBAHAN1.loadList != undefined){
                formatSubStandart = formatSubStandart.substring(0, formatSubStandart.length-1);
                formatSubStandart = formatSubStandart+'/';
                formatSubStandart = formatSubStandart+getSubStandart(CUSTOMER_TERTANGGUNGTAMBAHAN1);
                $scope.ilustrasi.substandardValue = formatSubStandart.substring(0, formatSubStandart.length-1);
              }
            
              //------- FOR JABATAN PEMEGANG POLIS
              for(var y=0; y< $rootScope.positionList.length; y++){
                  if ($rootScope.positionList[y].code == CUSTOMER_TERTANGGUNGTAMBAHAN1.Position) {
                    $scope.ilustrasi.jabatanPemegangPolisTT1 = $rootScope.positionList[y].descriptionInd;
                    $scope.ilustrasi.kodejabatanPemegangPolisTT1 = $rootScope.positionList[y].code; 
                  }
              }

              var totalIncome = $rootScope.incomeList;
              for(var im in totalIncome){
                if(im == 'Individual'){
                  for(var m=0; m<totalIncome[im].length; m++){
                      if (totalIncome[im][m].code == CUSTOMER_TERTANGGUNGTAMBAHAN1.Income) {
                        $scope.ilustrasi.nilaiIncomeTT1 = totalIncome[im][m].code  +' '+totalIncome[im][m].individualInd
                      }
                  }
                }
              }


              $scope.ilustrasi.labelTT1 = 'Suami/Istri';
              $scope.ilustrasi.totPenghasilan = 'Total Penghasilan Rutin Suami/Istri 1 per Bulan**';    
              

              $scope.ilustrasi.labelAnb1 = 'Usia tahun Berikutnya ';
              $scope.ilustrasi.lbPekerjaan = 'Pekerjaan **';
              $scope.ilustrasi.lbInstansiDepartement = 'Instansi/Departemen';
              $scope.ilustrasi.lbBidangUsaha = 'Bidang Usaha ';
              $scope.ilustrasi.lbJabatan = 'Jabatan/Pangkat/Golongan';
                        
        }else{
            $scope.ilustrasi.tertanggungNameTT1 = '';
            $scope.ilustrasi.ageTT1 = '';
            $scope.ilustrasi.anbTT1 = '';
            $scope.ilustrasi.ageonlyTT1 = '';
            $scope.ilustrasi.dobTT1 = '';
            $scope.ilustrasi.genderTT1 = '';
            $scope.ilustrasi.genderTT1 = '';
            $scope.ilustrasi.kodepekerjaanTT1 = '';
            $scope.ilustrasi.pekerjaanTT1 = '';
            $scope.ilustrasi.deskripsiPekerjaanTT1 = '';
            $scope.ilustrasi.kelasPekerjaanTT1 = '';
            $scope.ilustrasi.departementTT1 = '';
            $scope.ilustrasi.bidangUsahaTT1 = '';
            $scope.ilustrasi.jabatanPemegangPolisTT1 = '';
            $scope.ilustrasi.kodejabatanPemegangPolisTT1 = '';
            $scope.ilustrasi.nilaiIncomeTT1 = '';

            $scope.ilustrasi.labelTT1 = '';
            $scope.ilustrasi.labelAnb1 = '';
            $scope.ilustrasi.lbInstansiDepartement = '';
            $scope.ilustrasi.bidangUsaha = '';
            $scope.ilustrasi.jabatan = '';
            $scope.ilustrasi.totPenghasilan = '';
        }
        */

        });
      }
      

      var custIdTT2 = QUOTATION_STORAGE.CustomerList['04'];
      if(custIdTT2 != null || custIdTT2 != undefined){
        CustomerStorageService.getCustomerStorageByKey($q, custIdTT2).then(function(resCust){
        CUSTOMER_TERTANGGUNGTAMBAHAN2 = resCust;
        console.log('isi dari data tertanggung tambahan 2 ',resCust)

        if(CUSTOMER_TERTANGGUNGTAMBAHAN2.loadList != undefined){
          formatSubStandart = formatSubStandart.substring(0, formatSubStandart.length-1);
          formatSubStandart = ' '+formatSubStandart+'/';
          formatSubStandart = formatSubStandart+getSubStandart(CUSTOMER_TERTANGGUNGTAMBAHAN2);
          $scope.ilustrasi.substandardValue = formatSubStandart.substring(0, formatSubStandart.length-1);
        }

        if(CUSTOMER_TERTANGGUNGTAMBAHAN2 && $scope.ilustrasi.isPickParentFlag){
              console.log('Ada tertanggung tambahan 2');
              $scope.ilustrasi.tertanggungtambahan2flag = true;
              $scope.ilustrasi.tertanggungNameTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.name;

              $scope.ilustrasi.ageTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.anb + ' tahun';
              
              var dateDOB = new Date(CUSTOMER_TERTANGGUNGTAMBAHAN2.Dob);

              var dd = dateDOB.getDate().toString().length==1?'0'+dateDOB.getDate().toString():dateDOB.getDate().toString();
              var mm = (dateDOB.getMonth()+1).toString().length==1?'0'+(dateDOB.getMonth()+1).toString():(dateDOB.getMonth()+1).toString();
              var yyyy = dateDOB.getFullYear().toString();
              
              console.log(dateDOB.getDate().toString().length);
              console.log(dd + ' - ' + mm + ' - '+yyyy);

              $scope.ilustrasi.anbTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.anb + ' ('+CUSTOMER_TERTANGGUNGTAMBAHAN2.Dob+')';
              $scope.ilustrasi.ageonlyTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.anb;
              anb = CUSTOMER_TERTANGGUNGTAMBAHAN2.anb + ' ('+CUSTOMER_TERTANGGUNGTAMBAHAN2.Dob+')';
              var datetime = CUSTOMER_TERTANGGUNGTAMBAHAN2.Dob.split('-');
              $scope.ilustrasi.dobTT2 = getFormatDate(dd, mm, yyyy);

              $scope.ilustrasi.genderTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.jenisKelaminPerokok ? getGender(CUSTOMER_TERTANGGUNGTAMBAHAN2.jenisKelaminPerokok) : 'kosong';
              $scope.ilustrasi.kodepekerjaanTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.Occupation.code;
              $scope.ilustrasi.pekerjaanTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.Occupation.nameInd;
              $scope.ilustrasi.deskripsiPekerjaanTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.Occupation.descriptionInd;
              $scope.ilustrasi.kelasPekerjaanTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.Occupation.clazz;
              $scope.ilustrasi.departementTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.Department;

              

              for(var i=0; i< $rootScope.businessList.length; i++){
                  if ($rootScope.businessList[i].code == CUSTOMER_TERTANGGUNGTAMBAHAN2.Business) {
                    $scope.ilustrasi.bidangUsahaTT2 = $rootScope.businessList[i].descriptionInd                   
                  }
              }
            
              //------- FOR JABATAN PEMEGANG POLIS
              for(var y=0; y< $rootScope.positionList.length; y++){
                  if ($rootScope.positionList[y].code == CUSTOMER_TERTANGGUNGTAMBAHAN2.Position) {
                    $scope.ilustrasi.jabatanPemegangPolisTT2 = $rootScope.positionList[y].descriptionInd;
                    $scope.ilustrasi.kodejabatanPemegangPolisTT2 = $rootScope.positionList[y].code; 
                  }
              }

              var totalIncome = $rootScope.incomeList;
              for(var im in totalIncome){
                if(im == 'Individual'){
                  for(var m=0; m<totalIncome[im].length; m++){
                      if (totalIncome[im][m].code == CUSTOMER_TERTANGGUNGTAMBAHAN2.Income) {
                        $scope.ilustrasi.nilaiIncomeTT2 = totalIncome[im][m].code  +' '+totalIncome[im][m].individualInd
                      }
                  }
                }
              }

              $scope.ilustrasi.labelTT2 = 'Orang Tua';
              $scope.ilustrasi.totPenghasilan2 = 'Total Penghasilan Rutin Orangtua 2 per Bulan ** ';    

              
              
              $scope.ilustrasi.labelAnb2 = 'Usia Tahun Berikutnya ';
              $scope.ilustrasi.pekerjaan2 = 'Pekerjaan **';
              $scope.ilustrasi.instansiDepartement2 = 'Instansi/Departemen ';
              $scope.ilustrasi.bidangUsaha2 = 'Bidang Usaha ';
              $scope.ilustrasi.jabatan2 = 'Jabatan/Pangkat/Golongan ';
        }else if(CUSTOMER_TERTANGGUNGTAMBAHAN2 && $scope.ilustrasi.isPickSpouseFlag && CUSTOMER_TERTANGGUNGTAMBAHAN2.Occupation.nameInd.toLowerCase().indexOf('pelajar') < 0){      
              console.log('Ada tertanggung tambahan 2');
              $scope.ilustrasi.tertanggungtambahan2flag = true;
              $scope.ilustrasi.tertanggungNameTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.name;

              $scope.ilustrasi.ageTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.anb + ' tahun';
              
              var dateDOB = new Date(CUSTOMER_TERTANGGUNGTAMBAHAN2.Dob);

              var dd = dateDOB.getDate().toString().length==1?'0'+dateDOB.getDate().toString():dateDOB.getDate().toString();
              var mm = (dateDOB.getMonth()+1).toString().length==1?'0'+(dateDOB.getMonth()+1).toString():(dateDOB.getMonth()+1).toString();
              var yyyy = dateDOB.getFullYear().toString();
              
              console.log(dateDOB.getDate().toString().length);
              console.log(dd + ' - ' + mm + ' - '+yyyy);

              $scope.ilustrasi.anbTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.anb + ' ('+CUSTOMER_TERTANGGUNGTAMBAHAN2.Dob+')';
              $scope.ilustrasi.ageonlyTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.anb;
              anb = CUSTOMER_TERTANGGUNGTAMBAHAN2.anb + ' ('+CUSTOMER_TERTANGGUNGTAMBAHAN2.Dob+')';
              var datetime = CUSTOMER_TERTANGGUNGTAMBAHAN2.Dob.split('-');
              $scope.ilustrasi.dobTT2 = getFormatDate(dd, mm, yyyy);

              $scope.ilustrasi.genderTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.jenisKelaminPerokok ? getGender(CUSTOMER_TERTANGGUNGTAMBAHAN2.jenisKelaminPerokok) : 'kosong';
              $scope.ilustrasi.kodepekerjaanTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.Occupation.code;
              $scope.ilustrasi.pekerjaanTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.Occupation.nameInd;
              $scope.ilustrasi.deskripsiPekerjaanTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.Occupation.descriptionInd;
              $scope.ilustrasi.kelasPekerjaanTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.Occupation.clazz;
              $scope.ilustrasi.departementTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.Department;

              if(CUSTOMER_TERTANGGUNGTAMBAHAN2.loadList != undefined){
                formatSubStandart = formatSubStandart.substring(0, formatSubStandart.length-1);
                formatSubStandart = formatSubStandart+'/';
                formatSubStandart = formatSubStandart+getSubStandart(CUSTOMER_TERTANGGUNGTAMBAHAN2);
                $scope.ilustrasi.substandardValue = formatSubStandart.substring(0, formatSubStandart.length-1);
              }

              for(var i=0; i< $rootScope.businessList.length; i++){
                  if ($rootScope.businessList[i].code == CUSTOMER_TERTANGGUNGTAMBAHAN2.Business) {
                    $scope.ilustrasi.bidangUsahaTT2 = $rootScope.businessList[i].descriptionInd                   
                  }
              }
            
              //------- FOR JABATAN PEMEGANG POLIS
              for(var y=0; y< $rootScope.positionList.length; y++){
                  if ($rootScope.positionList[y].code == CUSTOMER_TERTANGGUNGTAMBAHAN2.Position) {
                    $scope.ilustrasi.jabatanPemegangPolisTT2 = $rootScope.positionList[y].descriptionInd;
                    $scope.ilustrasi.kodejabatanPemegangPolisTT2 = $rootScope.positionList[y].code; 
                  }
              }

              var totalIncome = $rootScope.incomeList;
              for(var im in totalIncome){
                if(im == 'Individual'){
                  for(var m=0; m<totalIncome[im].length; m++){
                      if (totalIncome[im][m].code == CUSTOMER_TERTANGGUNGTAMBAHAN2.Income) {
                        $scope.ilustrasi.nilaiIncomeTT2 = totalIncome[im][m].code  +' '+totalIncome[im][m].individualInd
                      }
                  }
                }
              }


              $scope.ilustrasi.labelTT2 = 'Suami/Istri';
              $scope.ilustrasi.totPenghasilan2 = 'Total Penghasilan Rutin Suami/Istri per Bulan ** ';    
              
              $scope.ilustrasi.labelAnb2 = 'Usia Tahun Berikutnya ';
              $scope.ilustrasi.pekerjaan2 = 'Pekerjaan **';
              $scope.ilustrasi.instansiDepartement2 = 'Instansi/Departemen ';
              $scope.ilustrasi.bidangUsaha2 = 'Bidang Usaha ';
              $scope.ilustrasi.jabatan2 = 'Jabatan/Pangkat/Golongan ';
        }else{
            $scope.ilustrasi.tertanggungNameTT2 = '';
            $scope.ilustrasi.ageTT2 = '';
            $scope.ilustrasi.anbTT2 = '';
            $scope.ilustrasi.ageonlyTT2 = '';
            $scope.ilustrasi.dobTT2 = '';
            $scope.ilustrasi.genderTT2 = '';
            $scope.ilustrasi.genderTT2 = '';
            $scope.ilustrasi.kodepekerjaanTT2 = '';
            $scope.ilustrasi.pekerjaanTT2 = '';
            $scope.ilustrasi.deskripsiPekerjaanTT2 = '';
            $scope.ilustrasi.kelasPekerjaanTT2 = '';
            $scope.ilustrasi.departementTT2 = '';
            $scope.ilustrasi.bidangUsahaTT2 = '';
            $scope.ilustrasi.jabatanPemegangPolisTT2 = '';
            $scope.ilustrasi.kodejabatanPemegangPolisTT2 = '';
            $scope.ilustrasi.nilaiIncomeTT2 = '';

            

            $scope.ilustrasi.labelAnb2 = '';
            $scope.ilustrasi.pekerjaan2 = '';
            $scope.ilustrasi.instansiDepartement2 = '';
            $scope.ilustrasi.bidangUsaha2 = '';
            $scope.ilustrasi.jabatan2 = '';
            $scope.ilustrasi.totPenghasilan2 = '';
        }

        console.log($scope.ilustrasi.pekerjaanTT2.toLowerCase().indexOf('pelajar'));
        /*
        if(CUSTOMER_TERTANGGUNGTAMBAHAN2 && $scope.ilustrasi.isPickSpouseFlag && CUSTOMER_TERTANGGUNGTAMBAHAN2.Occupation.nameInd.toLowerCase().indexOf('pelajar') < 0){
              console.log('Ada tertanggung tambahan 2');
              $scope.ilustrasi.tertanggungtambahan2flag = true;
              $scope.ilustrasi.tertanggungNameTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.name;

              $scope.ilustrasi.ageTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.anb + ' tahun';
              
              var dateDOB = new Date(CUSTOMER_TERTANGGUNGTAMBAHAN2.Dob);

              var dd = dateDOB.getDate().toString().length==1?'0'+dateDOB.getDate().toString():dateDOB.getDate().toString();
              var mm = (dateDOB.getMonth()+1).toString().length==1?'0'+(dateDOB.getMonth()+1).toString():(dateDOB.getMonth()+1).toString();
              var yyyy = dateDOB.getFullYear().toString();
              
              console.log(dateDOB.getDate().toString().length);
              console.log(dd + ' - ' + mm + ' - '+yyyy);

              $scope.ilustrasi.anbTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.anb + ' ('+CUSTOMER_TERTANGGUNGTAMBAHAN2.Dob+')';
              $scope.ilustrasi.ageonlyTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.anb;
              anb = CUSTOMER_TERTANGGUNGTAMBAHAN2.anb + ' ('+CUSTOMER_TERTANGGUNGTAMBAHAN2.Dob+')';
              var datetime = CUSTOMER_TERTANGGUNGTAMBAHAN2.Dob.split('-');
              $scope.ilustrasi.dobTT2 = getFormatDate(dd, mm, yyyy);

              $scope.ilustrasi.genderTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.jenisKelaminPerokok ? getGender(CUSTOMER_TERTANGGUNGTAMBAHAN2.jenisKelaminPerokok) : 'kosong';
              $scope.ilustrasi.kodepekerjaanTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.Occupation.code;
              $scope.ilustrasi.pekerjaanTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.Occupation.nameInd;
              $scope.ilustrasi.deskripsiPekerjaanTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.Occupation.descriptionInd;
              $scope.ilustrasi.kelasPekerjaanTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.Occupation.clazz;
              $scope.ilustrasi.departementTT2 = CUSTOMER_TERTANGGUNGTAMBAHAN2.Department;

              if(CUSTOMER_TERTANGGUNGTAMBAHAN2.loadList != undefined){
                formatSubStandart = formatSubStandart.substring(0, formatSubStandart.length-1);
                formatSubStandart = formatSubStandart+'/';
                formatSubStandart = formatSubStandart+getSubStandart(CUSTOMER_TERTANGGUNGTAMBAHAN2);
                $scope.ilustrasi.substandardValue = formatSubStandart.substring(0, formatSubStandart.length-1);
              }

              for(var i=0; i< $rootScope.businessList.length; i++){
                  if ($rootScope.businessList[i].code == CUSTOMER_TERTANGGUNGTAMBAHAN2.Business) {
                    $scope.ilustrasi.bidangUsahaTT2 = $rootScope.businessList[i].descriptionInd                   
                  }
              }
            
              //------- FOR JABATAN PEMEGANG POLIS
              for(var y=0; y< $rootScope.positionList.length; y++){
                  if ($rootScope.positionList[y].code == CUSTOMER_TERTANGGUNGTAMBAHAN2.Position) {
                    $scope.ilustrasi.jabatanPemegangPolisTT2 = $rootScope.positionList[y].descriptionInd;
                    $scope.ilustrasi.kodejabatanPemegangPolisTT2 = $rootScope.positionList[y].code; 
                  }
              }

              var totalIncome = $rootScope.incomeList;
              for(var im in totalIncome){
                if(im == 'Individual'){
                  for(var m=0; m<totalIncome[im].length; m++){
                      if (totalIncome[im][m].code == CUSTOMER_TERTANGGUNGTAMBAHAN2.Income) {
                        $scope.ilustrasi.nilaiIncomeTT2 = totalIncome[im][m].code  +' '+totalIncome[im][m].individualInd
                      }
                  }
                }
              }


              $scope.ilustrasi.labelTT2 = 'Suami/Istri';
              $scope.ilustrasi.totPenghasilan2 = 'Total Penghasilan Rutin Suami/Istri per Bulan ** ';    
              
              $scope.ilustrasi.labelAnb2 = 'Usia Tahun Berikutnya ';
              $scope.ilustrasi.pekerjaan2 = 'Pekerjaan **';
              $scope.ilustrasi.instansiDepartement2 = 'Instansi/Departemen ';
              $scope.ilustrasi.bidangUsaha2 = 'Bidang Usaha ';
              $scope.ilustrasi.jabatan2 = 'Jabatan/Pangkat/Golongan ';

        }else{
            $scope.ilustrasi.tertanggungNameTT2 = '';
            $scope.ilustrasi.ageTT2 = '';
            $scope.ilustrasi.anbTT2 = '';
            $scope.ilustrasi.ageonlyTT2 = '';
            $scope.ilustrasi.dobTT2 = '';
            $scope.ilustrasi.genderTT2 = '';
            $scope.ilustrasi.genderTT2 = '';
            $scope.ilustrasi.kodepekerjaanTT2 = '';
            $scope.ilustrasi.pekerjaanTT2 = '';
            $scope.ilustrasi.deskripsiPekerjaanTT2 = '';
            $scope.ilustrasi.kelasPekerjaanTT2 = '';
            $scope.ilustrasi.departementTT2 = '';
            $scope.ilustrasi.bidangUsahaTT2 = '';
            $scope.ilustrasi.jabatanPemegangPolisTT2 = '';
            $scope.ilustrasi.kodejabatanPemegangPolisTT2 = '';
            $scope.ilustrasi.nilaiIncomeTT2 = '';

            

            $scope.ilustrasi.labelAnb2 = '';
            $scope.ilustrasi.pekerjaan2 = '';
            $scope.ilustrasi.instansiDepartement2 = '';
            $scope.ilustrasi.bidangUsaha2 = '';
            $scope.ilustrasi.jabatan2 = '';
            $scope.ilustrasi.totPenghasilan2 = '';
        }
        */
      });
      }
      

      $scope.ilustrasi.uniqueCode = randomString(8);

      QUOTATION_STORAGE.dataEmail = $scope.ilustrasi;
      QuotationStorageService.addQuotationStorage($q, quotationId, QUOTATION_STORAGE);


      $scope.previous = function(){
          // QUOTATION_STORAGE.Level = 4;
          // QuotationStorageService.addQuotationStorage($q, quotationId, QUOTATION_STORAGE).then(function(){
              // $rootScope.Level = 4;
              // $scope.historyview = $ionicHistory.backView();
              // if($scope.historyview.stateName == "daftar-newsqs"){
              //     $ionicHistory.goBack();
              // }else{
                  window.location = "#/produk-manfaat";
              // }     
          // })
      }

      $scope.back = function(){
        $rootScope.QuotationId = undefined;
        $rootScope.Level = undefined;
        $state.go("daftar-newsqs");
        
      }

      console.log($scope.ilustrasi);

      $ionicLoading.hide();
  });

  function manfaatListToFormatCurrency(listManfaat, premi, totalPremiThn, frequencyParam){
    var manfaatObj;

    var frequency;
    if(frequencyParam.descriptionInd.toLowerCase() == 'bulanan'){
        frequency = 12;
    }else if(frequencyParam.descriptionInd.toLowerCase() == 'tiga bulanan'){
        frequency = 4;
    }else if(frequencyParam.descriptionInd.toLowerCase() == 'setengah tahunan'){
        frequency = 2;
    }else{
        frequency = 1;
    }
    
    var tmpManfaatList = listManfaat;
    var listResult = [];
    var biayaBulanan = '';
    var inputValue = '';
    var coverageType = '';
    var term = 0;
    var name = '';
    var saNpremi;
    var uangPertanggungan = 0;
    console.log('List Manfaat di halaman ilustrasi isi nya ', listManfaat);

    for(var i = 0; i < tmpManfaatList.length; i++){
        var itemInput = [];
        for (var j = 0; j < tmpManfaatList[i].itemInput.length; j++){

          if(tmpManfaatList[i].itemInput[j].key == 'PDSA' || 'PDPREMI') {
            saNpremi = parseFloat(tmpManfaatList[i].itemInput[j].inputValue.toString()).format(formatCurr);
          }

          if(tmpManfaatList[i].itemInput[j].key == 'PDPLAN') {
            if(tmpManfaatList[i].code == 'W1MR' || tmpManfaatList[i].code == 'W1MD'){
                //PRUwaiver 33
                // uangPertanggungan = parseFloat($scope.replaceMoneyFormat(premi))*frequency;
                saNpremi = parseFloat(premi).format(formatCurr);
            }else if(tmpManfaatList[i].code == 'W1QR' || tmpManfaatList[i].code == 'W1QD' || tmpManfaatList[i].code == 'W3BR' || tmpManfaatList[i].code == 'W3BD' || tmpManfaatList[i].code == 'W1XR' || tmpManfaatList[i].code == 'W1XD' || tmpManfaatList[i].code == 'S1KR' || tmpManfaatList[i].code == 'S1KD' || tmpManfaatList[i].code == 'S1FR' || tmpManfaatList[i].code == 'S1FD' || tmpManfaatList[i].code == 'S1YR' || tmpManfaatList[i].code == 'S1YD' || tmpManfaatList[i].code == 'W3AR' || tmpManfaatList[i].code == 'W3AD'){
                //PRUpayor 33
                // uangPertanggungan = parseFloat($scope.replaceMoneyFormat(totalPremi))*frequency;
                //var totalPremi = parseFloat(premi)+parseFloat(saver);
                saNpremi = parseFloat(totalPremiThn).format(formatCurr);
            }else{
                saNpremi = parseFloat(tmpManfaatList[i].itemInput[j].hsplan.toString()).format(formatCurr);  
            }                
            console.log('value dari saNpremi adalah ==== ',saNpremi);
          }

           var itemValue = {
              inputValue : saNpremi =! '' || null ? saNpremi : '',
              term : tmpManfaatList[i].itemInput[j].key == 'PDTERM' ? tmpManfaatList[i].itemInput[j].inputValue : '99'
            };
          
          itemInput.push(itemValue);

          saNpremi = '';

        }

        if(tmpManfaatList[i].coverageType == 'main'){
            var itemValue = {
              inputValue : saNpremi =! '' || null ? saNpremi : '',
              term : '99'
            };
          
            itemInput.push(itemValue);
        }
        
        coverageType = tmpManfaatList[i].coverageType;

        var manfaat = {
            code : tmpManfaatList[i].code,
            biayaBulanan : parseFloat(tmpManfaatList[i].biayaBulanan.toString()).format(formatCurr),
            itemInput : itemInput,
            coverageType : coverageType,
            name : tmpManfaatList[i].name
        };
        
        listResult.push(manfaat);
    }

    return listResult;

  }
  
  var arrayAnBAge = [];
  var upCollection = [];
  var upCollection2 = [];
  var UPFinish; 

  function getJenisMedical(prodCatCd, prodCd, currCd, anb){
    
    var productList = $rootScope.CHANNEL[channelCode].PRODUCT_CATEGORY[0].PRODUCT;
    var productCurrencyList;
    var medicalList;
    var UPList;
    var UPList2;
    var maxUp;
    var up = $scope.ilustrasi.output.up;

    console.log('$scope.ilustrasi.output.up Isi nya adalah ====== ',$scope.ilustrasi.output);
    
    var maxAge ;
    for(var i = 0; i < productList.length; i++){
      if(productList[i].code == prodCd){
          productCurrencyList = productList[i].CURRENCY;

          for(var x = 0; x < productCurrencyList.length ;x++){
              if(productCurrencyList[x].code == currCd){
                medicalList = productCurrencyList[x].MEDICAL;

                for(var z = 0; z < medicalList.length; z++){
                    maxAge = medicalList[z].maxAge;

                  //cek maxAge > ANB
                  if(parseInt(maxAge) >= parseInt(anb)){
                      arrayAnBAge.push(medicalList[z]);                        
                  }
                }  
                 
                break;
                
              }                  
          }

          break;
      }
    }

    for(var j = 0; j < arrayAnBAge.length; j++){
        UPList = arrayAnBAge[j];

        maxUp = UPList.maxRisk;

        //cek maxUP > UP
        if(parseFloat(maxUp) >= parseFloat(up)){
              upCollection.push(UPList);                        
        }
    }

    for(var k = 0; k < upCollection.length; k++){
        UPList2 = upCollection[k];

        if(parseInt(UPList2.minAge) <= parseInt(anb)){
            upCollection2.push(UPList2);
        }
    }

    console.log('Medical upCollection2 ==== ',upCollection2);
    for(var l = 0; l < upCollection2.length; l++){
        UPFinish = upCollection2[l];
        if(parseFloat(UPFinish.minRisk) <= parseFloat(up)){
          console.log('Medical Code == ',UPFinish.medicalCd, 'up nya adalah ==== ', parseFloat(up));
            $scope.ilustrasi.medicalCode = UPFinish.medicalCd;
        }
    }
    
     //console.log('Medical List == ',medicalList);
  }

  

  // PRINT PREVIEW
  
  // Initialize the modal view. 
  /*$ionicModal.fromTemplateUrl('pdf-viewer.html', {
      scope: $scope,
      animation: 'slide-in-up',
      windowClass: 'fullmodal'
  }).then(function (modal) {
      $scope.modal = modal;
  });*/

  var init2 = function(){
    if($scope.modal){
      return $q.when();
    }
    else{
      return $ionicModal.fromTemplateUrl('pdf-viewer.html', {
              scope: $scope,
              animation: 'slide-in-up',
              windowClass: 'fullmodal'
              }).then(function (modal) {
                  $scope.modal = modal;
              });
    }
  }

  init2().then(function(){
  })

  $scope.closePopup = function(){
    $scope.modal.remove().then(function()
    {
      $scope.modal = null;
    })
  }

  $scope.showLoadingOverlay = function (){
    $ionicLoading.show({
      template: "Loading..."
    });
  };

  $scope.hideLoadingOverlay = function (){
      $ionicLoading.hide();
  };


  var blob;
  var startChunk = 0;
  var maxChunk =4;
  var jobState = 0;
  var jsonStoreChunk = [];
  var reader = new FileReader();
  var chunk_blob = [];

  function b64toBlob(b64Data, contentType, sliceSize){
    contentType = contentType || '';
    sliceSize = sliceSize || 512;

    var byteCharacters = atob(b64Data);
    var byteArrays = [];

    for(var offset = 0; offset < byteCharacters.length; offset += sliceSize ){
      var slice = byteCharacters.slice(offset,offset + sliceSize);

      var byteNumbers = new Array(slice.length);
      for(var i = 0; i < slice.length; i++){
        byteNumbers[i]= slice.charCodeAt(i);
      }

      var byteArray = new Uint8Array(byteNumbers);

      byteArrays.push(byteArray);
    }

    var blob = new Blob(byteArrays, {type: contentType});
    return blob;
  }
  $scope.previewOutput = function () {
    
    $ionicLoading.show();
           
    $timeout(function(){
      

       var mapOutput = $scope.ilustrasi;
       var rate = $rootScope.RATE; 
       console.log('mapOutput isi : ',mapOutput);
       console.log('isi rate : ',rate);
       PublishGlobalService.getpdf($q, $rootScope.QuotationId).then(function(res){
          if(res.rows.length > 0){
              for(var i =0 ; i < res.rows.length; i++)
              {
                if(res.rows.item(i).pdfdata != "data:")
                {
                  chunk_blob.push(b64toBlob(res.rows.item(i).pdfdata.replace("data:;base64,",'')));
                }
              }
              var b2 = new Blob(chunk_blob,{type: 'application/pdf'});
              $scope.pdfUrl = URL.createObjectURL(b2);
              $ionicLoading.hide();
              
              init2().then(function(){
                    $scope.modal.show();
                });
          }
          else
          { var start = new Date();
              start = start.getHours() + ":" + start.getMinutes() + ":" + start.getSeconds();
              OutputService.createPdf(mapOutput).then(function (pdf) {
                  blob = new Blob([pdf], { type: 'application/pdf' });
                  endChunk = blob.size/4;
                  $scope.doStorePdf();
                  $scope.pdfUrl = URL.createObjectURL(blob);
                  // console.log("link pdf"+$scope.pdfUrl);            
                  // Display the modal view
                  // $scope.modal.show();
                  end = new Date();
                  end = end.getHours() + ":" + end.getMinutes() + ":" + end.getSeconds();
                  console.log("Elapsed : " + start + " - " + end);
                  $ionicLoading.hide();
                  init2().then(function(){
                    $scope.modal.show();
                  })
              });
          }
       })    
    },500);
  };


  $scope.doStorePdf = function(){
    if(jobState > maxChunk){
      $timeout(function(){
          DataFactoryNewSQSOffline.savepdf(jsonStoreChunk).then(function(res){
            document.getElementById("progress_bar").style.width = "100%";
            $scope.progress_msg = "Selesai!";
            $timeout(function(){
                $scope.pdfready = true;
            },500)
            console.log("sukses");
          });
      },500)
    }
    else
    {
      var tmp_file = {};
      tmp_file.sqsid = $rootScope.QuotationId;
      tmp_file.seq = jobState;
      reader.readAsDataURL(blob.slice(startChunk,endChunk * (jobState+1)));
      reader.onloadend = function(){
        tmp_file.pdfdata = reader.result;
        jsonStoreChunk.push(tmp_file);
        startChunk = endChunk * (jobState+1);
        jobState++;
        $scope.doStorePdf();
      }
    }

  }

  $scope.downldPdf = function () {
    var mapOutput = $scope.ilustrasi;
    console.log('mapOutput == ',mapOutput);

    OutputService.outputPdf(mapOutput)
        .then(function (pdf) {
            var blob = new Blob([pdf], { type: 'application/pdf' });
            $scope.pdfUrl = URL.createObjectURL(blob);
        });
  };

            
  
  function setDefaultsForPdfViewer() {
      $scope.scroll = 0;
      $scope.loading = 'loading';

      $scope.getNavStyle = function(scroll) {
          if(scroll > 100) return 'pdf-controls fixed';
          else return 'pdf-controls';
      }

      $scope.onError = function (error) {
          console.error(error);
      };

      $scope.onLoad = function () {
          $scope.loading = '';
      };

      $scope.onProgress = function (progress) {
          console.log(progress);
      };
  }


  function generateAsumtionCashValue(param, benefitList){
      var resultList = [];
      for(var i = 0; i < benefitList.length; i++){
          if(benefitList[i].customerAge == param.halamanRingkasanTahun1 || benefitList[i].customerAge == param.halamanRingkasanTahun2 || benefitList[i].customerAge == param.halamanRingkasanTahun3){
              resultList.push(benefitList[i]);
          }

      }


      return resultList;
  }

  function generateAsumtionsFormatNumber(param, benefitList){
      var resultList = [];
      for(var i = 0; i < benefitList.length; i++){
          if(benefitList[i].customerAge == param.halamanRingkasanTahun1 || benefitList[i].customerAge == param.halamanRingkasanTahun2 || benefitList[i].customerAge == param.halamanRingkasanTahun3){
              var fundObj = {};
              fundObj.year = benefitList[i].year;
              fundObj.customerAge = benefitList[i].customerAge;
              fundObj.lowClient = (parseFloat(benefitList[i].lowClient) <= 0) ? '***' : parseFloat(benefitList[i].lowClient).format(formatCurr);
              fundObj.medClient = (parseFloat(benefitList[i].medClient) <= 0) ? '***' : parseFloat(benefitList[i].medClient).format(formatCurr);
              fundObj.highClient = (parseFloat(benefitList[i].highClient) <= 0) ? '***' : parseFloat(benefitList[i].highClient).format(formatCurr);
              resultList.push(fundObj);
          }

      }
      return resultList;
  }


  function getDanaInvestasi(fundList){
    var tmpDanaInvestasiList = [
      {code : 'PRMF', flag : false, title : 'PRUlink Rupiah Managed Fund', since : '12.52', thn2011: '10,70', thn2012 : '8,82', thn2013 : '-8,22', thn2014 : '14.51', thn2015 : '-4.37', thn2016 : '9.39'},
      {code : 'PREF', flag : false, title : 'PRUlink Rupiah Equity Fund', since : '17.00', thn2011: '1,14', thn2012 : '10,39', thn2013 : '-2,54', thn2014 : '26.97', thn2015 : '-19.4', thn2016 : '8.10'},
      {code : 'PRFF', flag : false, title : 'PRUlink Rupiah Fixed Income Fund', since : '10.02', thn2011: '17,71', thn2012 : '10,25', thn2013 : '-13,51', thn2014 : '10.43', thn2015 : '0.98', thn2016 : '11.11'},
      {code : 'PRCF', flag : false, title : 'PRUlink Rupiah Cash Fund', since : '7.73', thn2011: '5,16', thn2012 : '4,43', thn2013 : '5,09', thn2014 : '7.36', thn2015 : '6.82', thn2016 : '6.12'},
      {code : 'PRMP', flag : false, title : 'PRUlink Rupiah Managed Fund Plus', since : '12.18', thn2011: '6,33', thn2012 : '9,26', thn2013 : '-4,28', thn2014 : '19.42', thn2015 : '-10.05', thn2016 : '8.79'},
      {code : 'PDFF', flag : false, title : 'PRUlink US Dollar Fixed Income Fund', since : '6.46', thn2011: '6,61', thn2012 : '12,00', thn2013 : '-10,74', thn2014 : '12.74', thn2015 : '-2.07', thn2016 : '10.15'},
      {code : 'PRGC', flag : false, title : 'PRUlink Rupiah Indonesia Greater China Equity Fund', since : '4.35', thn2011: '-', thn2012 : '-', thn2013 : '-', thn2014 : '24.81', thn2015 : '-12.05', thn2016 : '6.70'},
      {code : 'PDGC', flag : false, title : 'PRUlink US Dollar Indonesia Greater China Equity Fund', since : '-4.20', thn2011: '-', thn2012 : '-', thn2013 : '-', thn2014 : '22.29', thn2015 : '-20.69', thn2016 : '9.56'},
      {code : 'PREP', flag : false, title : 'PRUlink Rupiah Equity Fund Plus', since : '3.36', thn2011: '-', thn2012 : '-', thn2013 : '-', thn2014 : '-', thn2015 : '-13.3', thn2016 : '8.66'},
      {code : 'PRIE', flag : false, title : 'PRUlink Rupiah Infrastructure & Consumer Equity Fund', since : '2.59', thn2011: '-', thn2012 : '-', thn2013 : '-', thn2014 : '-', thn2015 : '-', thn2016 : '10.52'},
      {code : 'PRVE', flag : false, title : 'PRUlink Rupiah Value Discovery Equity Fund', since : '-', thn2011: '-', thn2012 : '-', thn2013 : '-', thn2014 : '-', thn2015 : '-', thn2016 : '-'},
      {code : 'PRAE', flag : false, title : 'PRUlink Rupiah Asia Pacific Equity Fund', since : '-', thn2011: '-', thn2012 : '-', thn2013 : '-', thn2014 : '-', thn2015 : '-', thn2016 : '-'},
      {code : 'PDAE', flag : false, title : 'PRUlink US Dollar Asia Pacific Equity Fund', since : '-', thn2011: '-', thn2012 : '-', thn2013 : '-', thn2014 : '-', thn2015 : '-', thn2016 : '-'}
    ];

    for(var i = 0; i < fundList.length; i++){
        for(var j = 0; j < tmpDanaInvestasiList.length; j++){

            if(fundList[i].itemInput[0].inputValue != '0' || fundList[i].itemInput[0].inputValue != 0){
                if(fundList[i].code == tmpDanaInvestasiList[j].code){
                    tmpDanaInvestasiList[j].flag = true;
                }  
            }
            
        }  
    }
    return tmpDanaInvestasiList;
  }

  $scope.getNewPremi = function(type, value){
      var result = value;
      if(type == '03'){
        result = parseInt(value)/4;
      }else if(type == '02'){
        result = parseInt(value)/2;
      }else if(type == '12'){
        result = parseInt(value)/12;
      }

      return parseFloat(result.toString()).format(formatCurr);
  }

  function getGender(keyword){
    var keywordList = keyword.split("|");
    var stringKeyword = "";
    for(var i = 0; i < keywordList.length; i++){
      if(i == 0){
        if(keywordList[i] == "M"){
          stringKeyword += "Pria";
        }else{
          stringKeyword += "Wanita";
        }
      }else if(i == 1){
        if(keywordList[i] == "S"){
          stringKeyword += "/Perokok";
        }else{
          stringKeyword += "/Bukan Perokok";
        }
      }
    }
    return stringKeyword;
  }

  function getProduct(channelId, productCatCd, productCd){
    var channel = $rootScope.CHANNEL[channelId];
    for(var i = 0; i < channel.PRODUCT_CATEGORY.length; i++){
      var prodCat = channel.PRODUCT_CATEGORY[i];
      if(prodCat.code === productCatCd){
        for(var j = 0; j < prodCat.PRODUCT.length; j++){
          var prod = prodCat.PRODUCT[j];
          if(prod.code === productCd){
            return prod;
            break;
          }
        }
      }
    }
  }

  var getMonthName={
    '01':'January|Jan',
    '02':'February|Feb',
    '03':'March|Mar',
    '04':'April|Apr',
    '05':'May|May',
    '06':'June|Jun',
    '07':'July|Jul',
    '08':'August|Aug',
    '09':'September|Sep',
    '10':'October|Oct',
    '11':'November|Nov',
    '12':'December|Dec',
  };

  function getFormatDate(dd, mm, yyyy){
      var monthName = getMonthName[mm].split('|');
      var retValue = dd + '-'+monthName[1] + '-'+ yyyy;
      return retValue;
  }

  function getSubStandart(CUSTOMER){
    var nilai = '';
    for(var cl = 0; cl<CUSTOMER.loadList.length; cl++){
      var valCode = CUSTOMER.loadList[cl];
      nilai = nilai+valCode.selectedCode+',';
    }
    return nilai;
  }

  function today(){
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth()+1; //January is 0!
    

    var yyyy = today.getFullYear();
    if(dd<10){
        dd='0'+dd;
    } 
    if(mm<10){
        mm='0'+mm;
    }

    var monthName = getMonthName[mm].split('|'); 
    var today = dd+'-'+monthName[1]+'-'+yyyy;

    return today;
    //document.getElementById("DATE").value = today;
  }

  function getDate(param){
    var day = new Date(param);
    var dd = day.getDate();
    var mm = day.getMonth()+1; //January is 0!
    console.log('mm == ',mm);

    var yyyy = day.getFullYear();
    if(dd<10){
        dd='0'+dd;
    } 
    if(mm<10){
        mm='0'+mm;
    }

    var monthName = getMonthName[mm].split('|'); 
    var today = dd+'-'+monthName[1]+'-'+yyyy;

    return today;
    //document.getElementById("DATE").value = today;
  }


  $scope.replaceMoneyFormat = function(value){
    var result = '';
    if(isNaN(value) && value.indexOf(',') > -1){
       value = value.replace(/,/g , "");
    }
    result = value;
    return !isNaN(result) ? result : '0';
  }

  function getCoverageList(product, currCd){
    for(var i=0; i < product.CURRENCY.length; i++){
      var currency = product.CURRENCY[i];
      if(currency.code === currCd){
        return currency.COVERAGE;
      }
    }
  }
  function getFundList(product, currCd){
    for(var i=0; i < product.CURRENCY.length; i++){
      var currency = product.CURRENCY[i];
      if(currency.code === currCd){
        return currency.FUND;
      }
    }
  }
/*

  $scope.illustrationProgress = [
    {id:1,name: "Pemegang Polis" },
    {id:2,name: "Profile Tertanggung" },
    {id:3,name: "Pilih Produk" },
    {id:4,name: "Manfaat" },
    {id:5,name: "Ilustrasi" }
  ];

  $scope.illustrationDatas = [
    {id: 1, name: "Spongebob Square Pants 1", status: "Disetujui dan disingkronkan", quotationNumber:"0A1234567", type: "Prulink assurance account", approved: 1, dateCreate:"2016-10-09", amount: 120000000},
    {id: 2, name: "Spongebob Square Pants 2", status: "Disetujui dan disingkronkan", quotationNumber:"0A2234567", type: "Prulink assurance account", approved: 1, dateCreate:"2016-10-07", amount: 220000000},
    {id: 3, name: "Spongebob Square Pants 3", status: "Disetujui dan disingkronkan", quotationNumber:"0A3234567", type: "Prulink assurance account", approved: 1, dateCreate:"2016-10-04", amount: 320000000},
    {id: 4, name: "Spongebob Square Pants 4", status: "Disetujui dan disingkronkan", quotationNumber:"0A4234567", type: "Prulink assurance account", approved: 1, dateCreate:"2016-10-02", amount: 420000000},
    {id: 5, name: "Spongebob Square Pants 5", status: "Disetujui dan disingkronkan", quotationNumber:"0A5234567", type: "Prulink assurance account", approved: 1, dateCreate:"2016-10-08", amount: 520000000},
    {id: 6, name: "Spongebob Square Pants 6", status: "Disetujui dan disingkronkan", quotationNumber:"0A6234567", type: "Prulink assurance account", approved: 0, dateCreate:"2016-10-10", amount: 620000000},
    {id: 7, name: "Spongebob Square Pants 7", status: "Disetujui dan disingkronkan", quotationNumber:"0A7234567", type: "Prulink assurance account", approved: 0, dateCreate:"2016-10-01", amount: 720000000},
    {id: 8, name: "Spongebob Square Pants 8", status: "Disetujui dan disingkronkan", quotationNumber:"0A8234567", type: "Prulink assurance account", approved: 0, dateCreate:"2016-10-05", amount: 1020000000},
    {id: 9, name: "Spongebob Square Pants 9", status: "Disetujui dan disingkronkan", quotationNumber:"0A9234567", type: "Prulink assurance account", approved: 0, dateCreate:"2016-10-03", amount: 920000000},
    {id: 10, name: "Spongebob Square Pants 10", status: "Disetujui dan disingkronkan", quotationNumber:"0A1034567", type: "Prulink assurance account", approved: 0, dateCreate:"2016-10-11", amount: 820000000},
    {id: 11, name: "Spongebob Square Pants 11", status: "Disetujui dan disingkronkan", quotationNumber:"0A1134567", type: "Prulink assurance account", approved: 0, dateCreate:"2016-10-06", amount: 1120000000}
  ]

  $scope.illustrationOnHoldDatas = [
    {id: 1, name: "Spongebob Square Pants 1", status: "Disetujui dan disingkronkan", quotationNumber:"0A1234567", type: "Prulink assurance account", approved: 1, dateCreate:"2016-10-09", amount: 120000000, progress:3},
    {id: 2, name: "Spongebob Square Pants 2", status: "Disetujui dan disingkronkan", quotationNumber:"0A2234567", type: "Prulink assurance account", approved: 1, dateCreate:"2016-10-07", amount: 220000000, progress:4},
    {id: 3, name: "Spongebob Square Pants 3", status: "Disetujui dan disingkronkan", quotationNumber:"0A3234567", type: "Prulink assurance account", approved: 1, dateCreate:"2016-10-04", amount: 320000000, progress:1},
    {id: 4, name: "Spongebob Square Pants 4", status: "Disetujui dan disingkronkan", quotationNumber:"0A4234567", type: "Prulink assurance account", approved: 1, dateCreate:"2016-10-02", amount: 420000000, progress:2},
    {id: 5, name: "Spongebob Square Pants 5", status: "Disetujui dan disingkronkan", quotationNumber:"0A5234567", type: "Prulink assurance account", approved: 1, dateCreate:"2016-10-08", amount: 520000000, progress:3},
    {id: 6, name: "Spongebob Square Pants 6", status: "Disetujui dan disingkronkan", quotationNumber:"0A6234567", type: "Prulink assurance account", approved: 0, dateCreate:"2016-10-10", amount: 620000000, progress:4},
    {id: 7, name: "Spongebob Square Pants 7", status: "Disetujui dan disingkronkan", quotationNumber:"0A7234567", type: "Prulink assurance account", approved: 0, dateCreate:"2016-10-01", amount: 720000000, progress:5},
    {id: 8, name: "Spongebob Square Pants 8", status: "Disetujui dan disingkronkan", quotationNumber:"0A8234567", type: "Prulink assurance account", approved: 0, dateCreate:"2016-10-05", amount: 1020000000, progress:1},
    {id: 9, name: "Spongebob Square Pants 9", status: "Disetujui dan disingkronkan", quotationNumber:"0A9234567", type: "Prulink assurance account", approved: 0, dateCreate:"2016-10-03", amount: 920000000, progress:3},
    {id: 10, name: "Spongebob Square Pants 10", status: "Disetujui dan disingkronkan", quotationNumber:"0A1034567", type: "Prulink assurance account", approved: 0, dateCreate:"2016-10-11", amount: 820000000, progress:2},
    {id: 11, name: "Spongebob Square Pants 11", status: "Disetujui dan disingkronkan", quotationNumber:"0A1134567", type: "Prulink assurance account", approved: 0, dateCreate:"2016-10-06", amount: 1120000000, progress:4}
  ]

  $scope.tempillustrationDatas = $scope.illustrationDatas;
  $scope.memberIllustrationDatas = loadMemberDatas($scope.tempillustrationDatas);
  $scope.tempillustrationOnHoldDatas = $scope.illustrationOnHoldDatas;
  $scope.memberIllustrationOnHoldDatas = loadMemberDatas($scope.tempillustrationOnHoldDatas);
  $scope.readonly = false;
  $scope.querySearch = querySearch;
  $scope.selectedCode = [];
  $scope.numberChips = [];
  $scope.numberChips2 = [];
  $scope.numberBuffer = '';
  $scope.chipSearch = chipSearch;

  
  $scope.removeChips = function (arrayName){
    if ($scope.selectedCode.length > 1){
      $scope[arrayName] = $scope.selectedCode;
    }else{
      $scope[arrayName] = $scope['temp'+arrayName];
    }
  } 
  */
  /**
   * Search for memberDatas.
   */
  // function querySearch (query, array) {
  //   var results = query ? array.filter(createFilterFor(query)) : [];
  //   return results;
  // }
  
  // function chipSearch(item, arrayName) {
  //   if ($scope.selectedCode.length>0){
  //     $scope[arrayName] = $scope.selectedCode;
  //   }
  // }
  /**
   * Create filter function for a query string
   */
 /* function createFilterFor(query) {
    var lowercaseQuery = angular.lowercase(query);
    return function filterFn(member) {
      return (member._lowername.indexOf(lowercaseQuery) === 0) || (member._lowertype.indexOf(lowercaseQuery) === 0); 
    };
  }

  function loadMemberDatas(array) {
    var datas =  array;
    return datas.map(function (per) {
      per._lowername = per.name.toLowerCase();
      per._lowertype = per.quotationNumber.toLowerCase();
      return per;
    });
  }

  $scope.filterIlustrasiList = function(individuStatus, arrayName){
    if(individuStatus == 1){
      $scope[arrayName] = $scope[arrayName].filter(function(a){return a.approved == 1});
    }else{
      if($scope.selectedCode.length>0){
        $scope[arrayName] = $scope.selectedCode;
      }else{
        $scope[arrayName] = $scope['temp'+arrayName];
      }
    }
  }

  $scope.sortingIlustrasiList = function (orderBy, arrayName){
    if (orderBy == 1){
      $scope[arrayName] = $scope[arrayName].sort(function(a, b) {
         return new Date(a.dateCreate).getTime() - new Date(b.dateCreate).getTime() 
      });
    }else{
      $scope[arrayName] = $scope['temp'+arrayName].sort(function(a, b) {
        return a.id - b.id;
      });
    }
  }

  var canvasAgen = document.getElementById('signatureCanvasAgen');
  if (canvasAgen){
    var signaturePadAgen = new SignaturePad(canvasAgen);
    function resizeCanvas() {
        var ratio =  Math.max(window.devicePixelRatio || 1, 1);
        canvasAgen.width = canvasAgen.offsetWidth * ratio;
        canvasAgen.height = canvasAgen.offsetHeight * ratio;
        canvasAgen.getContext("2d").scale(ratio, ratio);
        signaturePadAgen.clear(); // otherwise isEmpty() might return incorrect value
    }
    window.addEventListener("resize", resizeCanvas);
    resizeCanvas();
  }

  $scope.clearCanvasAgen = function() {
    signaturePadAgen.clear();
  }

  $scope.saveCanvasAgen = function() {
    if (signaturePadAgen.isEmpty()){
        signaturePadAgen.clear();
    }else{
      var sigImg = signaturePadAgen.toDataURL();
    }    
  }

  var canvasKlien = document.getElementById('signatureCanvasKlien');
  if (canvasKlien){
    var signaturePadKlien = new SignaturePad(canvasKlien);
    function resizeCanvas() {
        var ratio =  Math.max(window.devicePixelRatio || 1, 1);
        canvasKlien.width = canvasKlien.offsetWidth * ratio;
        canvasKlien.height = canvasKlien.offsetHeight * ratio;
        canvasKlien.getContext("2d").scale(ratio, ratio);
        signaturePadKlien.clear(); // otherwise isEmpty() might return incorrect value
    }
    window.addEventListener("resize", resizeCanvas);
    resizeCanvas();
  }

  $scope.clearCanvasKlien = function() {
    signaturePadKlien.clear();
  }

  $scope.saveCanvasKlien = function() {
    if (signaturePadKlien.isEmpty()){
        signaturePadKlien.clear();
    }else{
      var sigImg = signaturePadAgen.toDataURL();
    }    
  }

  $scope.btnDownload = function(e) { 
    var myPopup = $ionicPopup.show({ 
      title: "", 
      template: `<h5 class="font-dark text-capitalize">Ilustrasi berhasil terdownload</h5>`, 
      cssClass: 'pru-alert white-header font-dark button-side-duo', 
      scope: $scope, 
      buttons: [
      {
        text: 'lihat ilustrasi',
        type: 'button-dark-gray',
        onTap: function(e) {
        }
      },
      {
        text: 'kirim email',
        type: 'button-assertive',
        onTap: function(e) {
          $scope.addListPopup();
        }
      }
      ]
    }); 
  };

  JsBarcode("#code39", "Hello", {format: "code39"});

  /*$scope.chart = {
      labels : ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
      datasets : [
          {
              fillColor : "rgba(151,187,205,0)",
              strokeColor : "#e67e22",
              pointColor : "rgba(151,187,205,0)",
              pointStrokeColor : "#e67e22",
              data : [4, 3, 5, 4, 6]
          },
          {
              fillColor : "rgba(151,187,205,0)",
              strokeColor : "#f1c40f",
              pointColor : "rgba(151,187,205,0)",
              pointStrokeColor : "#f1c40f",
              data : [8, 3, 2, 5, 4]
          }
      ], 
  };*/

  $scope.salinIlustrasi = function() {
    $state.go("salin-ilustrasi");
  }

  $scope.output = function() {
    $state.go("output");
  }

  $scope.sendEmail = function() {
    $state.go("send-email-ilustrasi");
  }

  $scope.statusIlustrasi = function() {
    $rootScope.AlertDialog("search page");
    $state.go("status-ilustrasi");
  }
  
  $scope.ilustrasiTertunda = function () {
    /*$rootScope.AlertDialog("search page");*/
    $state.go("daftar-ilustrasi-tertunda");
  }



  $scope.kirimIlustrasi = function(){
    $rootScope.QuotationId = quotationId;
    
    $scope.closePopup();
    $state.go('send-email-ilustrasi');
  };

});