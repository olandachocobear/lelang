﻿angular.module('PruForce.controllers')

  .controller('newSqsCtrl', function ($q, $scope, $ionicScrollDelegate, $state, $rootScope, $localStorage, Publish,  $ionicPopup,$ionicLoading, $timeout, QuotationStorageService, CustomerStorageService,RateStorageService, PublishGlobalService, OutputStorageService) {
    var channelType = $rootScope.agent.channelType;
    $scope.quotStorage = [];
    $scope.cList = [];
    var QuotationId;
    var CustomerList;
    var Level;
    $scope.illustrationOnHoldDatas = [];
    var tmpIllustrationOnHoldDatas = [];   
    

    $scope.filterList = [{code : '0', label : 'Semua'}];  
    $scope.filterSelected = '0';

    $scope.sortList = [
      {code : 'asc', label : 'Paling Lama'},
      {code : 'desc', label : 'Paling Baru'}
    ];
    $scope.sortSelected = 'desc';

    /*$scope.$on("$ionicView.beforeEnter", function(){
        $timeout(function(){
          //getPublishGlobaService(Publish);
          if($rootScope.CHANNEL && Object.size($rootScope.CHANNEL) > 0 && !$rootScope.version_changed){
              console.log("Channel exist on rootscope");
              callQuotStorage();
          }else{
              PublishGlobalService.getChannel($q).then(function(fs){
                  //console.log("CHN : ", fs);
                  $rootScope.CHANNEL = fs[0].json.invocationResult;
                  callQuotStorage();
              })
          }
          //callQuotStorage();
        },500)
        
    })

    $scope.$on("$ionicView.afterEnter", function(){
        
    })*/


    callQuotStorage();

    function callQuotStorage(){
      QuotationStorageService.getQuotationStorage($q).then(function(result){
          $scope.quotStorage = result;
          CustomerStorageService.getCustomerStorage($q).then(function(res){
            //console.log('$scope.quotStorage == ',$scope.quotStorage);
            for (var i=0; i < $scope.quotStorage.length; i++) {
              var QUOTATION = $scope.quotStorage[i].json.invocationResult;
              QuotationId = QUOTATION.QuotationId;
              CustomerList = QUOTATION.CustomerList['01'];
              Level = QUOTATION.Level;
              var Product = QUOTATION.Product;
              
              $scope.cList = res;
              for (var j=0; j < $scope.cList.length; j++) {
                var y = $scope.cList[j].json.invocationResult;
                var date = new Date(QUOTATION.QuotationDate);
              
                if (y.customerId === CustomerList) {
                  var tempCustList = {
                    id : i+1,
                    dateCreate : date.ddmmyyyy() + ' ' + date.hhmmss(),
                    newCreatedDate : date.getTime(),
                    quotationNumber : QuotationId,
                    name : y.name,
                    // status : 'Disetujui dan disingkronkan',
                    type : Product ? Product.ProductCategory ? Product.ProductCode ? getProduct(channelType, Product.ProductCategory, Product.ProductCode).longName + ' (' + Product.ProductCurrency + ')' : '' : '' : '',
                    progress : Level,
                    approved : 0
                  }
                  $scope.illustrationOnHoldDatas.push(tempCustList);
                }
              }
            }
            tmpIllustrationOnHoldDatas = $scope.illustrationOnHoldDatas;
            $scope.filterList = genFilterList();
        });
      });
    }
    function getProduct(channelId, productCatCd, productCd){
      var channel = $rootScope.CHANNEL[channelId];
      for(var i = 0; i < channel.PRODUCT_CATEGORY.length; i++){
        var prodCat = channel.PRODUCT_CATEGORY[i];
        if(prodCat.code === productCatCd){
          for(var j = 0; j < prodCat.PRODUCT.length; j++){
            var prod = prodCat.PRODUCT[j];
            if(prod.code === productCd){
              return prod;
              break;
            }
          }
        }
      }
  }

  Date.prototype.ddmmyyyy = function() {
      var mm = this.getMonth() + 1; // getMonth() is zero-based
      var dd = this.getDate();

      return [(dd>9 ? '' : '0') + dd,
              getBulan(mm),
              this.getFullYear()
              
             ].join(' ');
  };

  Date.prototype.hhmmss = function() {
      var hh = this.getHours(); // getMonth() is zero-based
      var mm = this.getMinutes();
      var ss = this.getSeconds();

      return [
                (hh>9 ? '' : '0') + hh,
                (mm>9 ? '' : '0') + mm,
                (ss>9 ? '' : '0') + ss

             ].join(':');
  };  

  function getBulan(mm){
    var bulan;
    switch (mm) {
      case 1:
          bulan = "Januari";
          break;
      case 2:
          bulan = "Februari";
          break;
      case 3:
          bulan = "Maret";
          break;
      case 4:
          bulan = "April";
          break;
      case 5:
          bulan = "Mei";
          break;
      case 6:
          bulan = "Juni";
          break;
      case 7:
          bulan = "Juli";
          break;
      case 8:
          bulan = "Agustus";
          break;
      case 9:
          bulan = "September";
          break;
      case 10:
          bulan = "Oktober";
          break;
      case 11:
          bulan = "November";
          break;
      case 12:
          bulan = "Desember";
          break;
    }

    return bulan;
  }

    function genFilterList(){
        var tmpFilterMap = {};
        tmpFilterMap['0'] = 'Semua';
        console.log('console length : ' + $scope.illustrationOnHoldDatas.length);
        for(var i = 0; i < $scope.illustrationOnHoldDatas.length; i++){
            var tmpilust = $scope.illustrationOnHoldDatas[i];

            if(tmpilust.progress == 5){
               tmpFilterMap['1'] = 'Belum Terkirim';
            }else if(tmpilust.progress == 6){
                tmpFilterMap['2'] = 'Terkirim';
            }else{
                tmpFilterMap['3'] = 'Belum Selesai';
            }         
        }
        var tmpList = [];
        for(var map in tmpFilterMap){
            tmpList.push({code : map, label : tmpFilterMap[map]});          
        }
        return tmpList;
    }

    $scope.getDataQuotation = function(searchIlustrasi, filterSelected, sortSelected){
        var tempList = filterData(filterSelected);

        if(searchIlustrasi){
          var lengthSearchIlustrasi = searchIlustrasi.trim().length;
          var resSearchList = [];
          for(var j =0; j < tempList.length; j++){     
              var tmp = tempList[j];
              if((tmp.quotationNumber).substring(0, lengthSearchIlustrasi).trim().toLowerCase() == searchIlustrasi.trim().toLowerCase() || (tmp.name).substring(0, lengthSearchIlustrasi).trim().toLowerCase() == searchIlustrasi.trim().toLowerCase()){
                  resSearchList.push(tmp);
              }
          }
          tempList = resSearchList;
        }

        return sorting(sortSelected, tempList);  
    }


    function filterData(level){
        var tmpList = [];
        if(level == 0){
            tmpList = tmpIllustrationOnHoldDatas;
        }else{
            for(var i = 0; i < tmpIllustrationOnHoldDatas.length; i++){
                if(level == 1 && tmpIllustrationOnHoldDatas[i].progress == 5){
                    tmpList.push(tmpIllustrationOnHoldDatas[i]);                       
                }else if(level == 2 && tmpIllustrationOnHoldDatas[i].progress == 6){
                    tmpList.push(tmpIllustrationOnHoldDatas[i]);                       
                }else if(level == 3 && (tmpIllustrationOnHoldDatas[i].progress == 1 || tmpIllustrationOnHoldDatas[i].progress == 2 || tmpIllustrationOnHoldDatas[i].progress == 3 || tmpIllustrationOnHoldDatas[i].progress == 4)){
                    tmpList.push(tmpIllustrationOnHoldDatas[i]);                       
                }
            }          
        }

        return tmpList;
    }

    function sorting(sort, items){       
        var length = items.length;
        for (var i = 0; i < length; i++) {
        //Number of passes
            for (var j = 0; j < length; j++) {
                //Compare the adjacent positions
                if(sort == 'desc'){
                    if (items[i].newCreatedDate > items[j].newCreatedDate) {
                        //Swap the numbers
                        var tmp = items[i];
                        items[i] = items[j];
                        items[j] = tmp;
                    }                  
                } else if(sort == 'asc'){
                    if (items[i].newCreatedDate < items[j].newCreatedDate) {
                        //Swap the numbers
                        var tmp = items[i];
                        items[i] = items[j];
                        items[j] = tmp;
                    }                  
                }
            }
        }

        return items;
    }

    $rootScope.registerPolicyHolders = [
      {key: 1, value: "Tidak Sebagai Tertanggung"},
      {key: 2, value: "Tertanggung Utama"},
      {key: 3, value: "Tertanggung Kedua"},
      {key: 4, value: "Tertanggung Ketiga"},
      {key: 5, value: "Tertanggung Keempat"},
      {key: 6, value: "Tertanggung Kelima"}
    ]

     $rootScope.registerPolicyHolders2 = [
      {key: 1, value: "Pemegang Polis"},
      {key: 2, value: "Tertanggung Utama"},
      {key: 3, value: "Tertanggung Kedua"},
      {key: 4, value: "Tertanggung Ketiga"},
      {key: 5, value: "Tertanggung Keempat"},
      {key: 6, value: "Tertanggung Kelima"},
      {key: 7, value: "lainnya"}
    ]
    
    $rootScope.typeList = [
      {nameInd: "Individu", nameEng:"Individual", value: "Individual"},
      {nameInd: "Korporat", nameEng:"Corporate", value: "Corporate"}
    ]

    $rootScope.maritalStatusList = [
      {nameInd: "Belum Menikah", nameEng:"Single", value: "single"},
      {nameInd: "Menikah", nameEng:"married", value: "married"},
      {nameInd: "Janda/Duda", nameEng:"Widow/Widower", value: "widower"}
    ]

    $scope.menuTabs = [
      {name: "Ilustrasi",  url: "components/newSqs/home/ilustrasi.html"},
      {name: "Template",  url: "components/newSqs/home/template.html"}
    ]

    $scope.currentMenuTab = $scope.menuTabs[0];
    /*$scope.calcHide = false;*/

    $scope.statusilustrasi = function(){
      console.log('aaaaaaaaaaaa');
    }

    $scope.isActiveTab = function(menuTabUrl){
      return $scope.currentMenuTab.url === menuTabUrl;
    };

    $scope.movingTab = function(e, menuTab){
      e.preventDefault();
      $scope.currentMenuTab = menuTab;

      var self = $(e.toElement);
      var tabContentTitle = self.attr("href");

      $(".tab-scrolling").animate({scrollLeft: self.attr("data-position-left")}, 300);
      self.parent().find("a").removeClass("active");
      self.addClass("active");
      $(tabContentTitle).addClass("active");
      $ionicScrollDelegate.scrollTop();
    };

    $scope.illustrationProgress = [
      {id:1,name: "Pemegang Polis" },
      {id:2,name: "Profil Tertanggung" },
      {id:3,name: "Pilih Produk" },
      {id:4,name: "Manfaat" },
      {id:5,name: "Ilustrasi" }
    ];


    $scope.templateDatas = [
      {id:1, name:"Cover Accident", dateCreate:"2016-10-07", type: "Prulink assurance account"},
      {id:2, name:"Cover Sick", dateCreate:"2016-10-08", type: "Prulink assurance account"},
      {id:3, name:"Cover Crisis", dateCreate:"2016-10-09", type: "Prulink assurance account"},
      {id:4, name:"Cover Crisis", dateCreate:"2016-10-10", type: "Prulink assurance account"},
      {id:5, name:"Cover Crisis", dateCreate:"2016-10-11", type: "Prulink assurance account"},
      {id:6, name:"Cover Tertanggung", dateCreate:"2016-10-09", type: "Prulink assurance account"}
    ] 

    $scope.tempillustrationOnHoldDatas = $scope.illustrationOnHoldDatas;
    $scope.memberIllustrationOnHoldDatas = loadMemberDatas($scope.tempillustrationOnHoldDatas);
    $scope.temptemplateDatas = $scope.templateDatas;
    $scope.memberTemplateDatas = loadMemberDatas($scope.temptemplateDatas);
    $scope.readonly = false;
    $scope.querySearch = querySearch;
    $scope.selectedCode = [];
    $scope.numberChips = [];
    $scope.numberChips2 = [];
    $scope.numberBuffer = '';
    $scope.chipSearch = chipSearch;


    
    /**
     * Search for memberDatas.
     */
    function querySearch (query) {
      console.log(query);
      var results = query ? filterxxx(query) : $scope.illustrationOnHoldDatas;
      return results;
    }

    function filterxxx(query){
      var temp = [];    
      console.log('list nya ', $scope.illustrationOnHoldDatas);
      for(var j =0; j < $scope.illustrationOnHoldDatas.length; j++){     
        if($scope.illustrationOnHoldDatas[j].name.toLowerCase().indexOf(query.toLowerCase()) !== -1){
          temp.push($scope.illustrationOnHoldDatas[j]);
        }
      }
      return temp;
    }
    /**
     * Remove chips function.
     */
    $scope.removeChips = function (arrayName){
      if ($scope.selectedCode.length > 1){
        $scope[arrayName] = $scope.selectedCode;
      }else{
        $scope[arrayName] = $scope['temp'+arrayName];
      }
    } 
    
    function chipSearch(item, arrayName) {
      if ($scope.selectedCode.length>0){
        $scope[arrayName] = $scope.selectedCode;
      }
    }
    /**
     * Create filter function for a query string
     */
    function createFilterFor(query) {
      var lowercaseQuery = angular.lowercase(query);
      return function filterFn(member) {
        return (member._lowername.indexOf(lowercaseQuery) === 0) || (member._lowertype.indexOf(lowercaseQuery) === 0); 
      };
    }

    function loadMemberDatas(array) {
      var datas =  array;
      return datas.map(function (per) {
        per._lowername = per.name.toLowerCase();
        if(per.quotationNumber){
          per._lowertype = per.quotationNumber.toLowerCase();
        }
        return per;
      });
    }

    

    function getCustListbyMap(quotationStorage) {
      var custStorage = {};
      console.log(quotationStorage);
      CustomerStorageService.getCustomerStorageByCustMap($q, quotationStorage).then(function(res){
          var custStorage = res;
          console.log(custStorage);
          
      });
      return custStorage;
    }


    $scope.confirmRemovePopup = function(idx, model, quotsID){
      var msgPopup = null;
      if(model == "ilustrasi"){
        msgPopup = "Apakah anda ingin menghapus ilustrasi <br> " + quotsID + " ?"
      }else if(model == "topup"){
        msgPopup = "Apakah anda ingin menghapus <br> TOP UP 1?"
      }else if(model == "penarikan"){
        msgPopup = "Apakah anda ingin menghapus <br> penarikan 1?"
      }else if(model == "template"){
        msgPopup = "Apakah anda ingin menghapus <br> template 1?"
      }

      var confirmPopup = $ionicPopup.confirm({
        title: "",
        template: msgPopup,
        cssClass: 'pru-white-alert without-header popup-large pru-logo-text button-side-duo',
        scope: $scope,
        buttons: [
        {
          text: 'TIDAK',
          type: 'button-dark-gray',
          onTap: function(e) {
          }
        },
        {
          text: 'YA',
          type: 'button-assertive',
          onTap: function(e, qID) {           
            QuotationStorageService.getQuotationStorageByKey($q, quotsID).then(function(resQuot){
                if(resQuot){
                    console.log('deleting... ', resQuot);
                    QuotationStorageService.deleteQuotationStorageByKey($q, quotsID);

                    if(resQuot.CustomerList){
                        var promList = [];
                        for(var objCust in resQuot.CustomerList){
                            function deleteCustomer(){
                              var defDell = $q.defer();
                              var cust = resQuot.CustomerList[objCust];
                              CustomerStorageService.deleteCustomerStorageByKey($q, cust).then(function(c){
                                  defDell.resolve(c)
                              })
                            }
                            promList.push(deleteCustomer());
                        }
                        $q.all(promList).then(function(resCust){
                            console.log('Berhasil hapus : ', resCust);
                        })
                    }

                    
                    if(resQuot.OutputId){
                        OutputStorageService.deleteOutputStorageByKey($q, resQuot.OutputId).then(function(resOut){
                            console.log('Berhasil hapus : ', resOut);
                        })
                    }
                    
                    $scope.removedPopup(model, idx);
                }
            })
          }
        }
        ]
      });      
    }


    $scope.confirmSalinIlustrasi = function(idx, model, quotsID){
      var msgPopup = null;
      console.log('indexnya ', idx);
      var quotsIDVar = quotsID;
      if(model == "ilustrasi"){
        msgPopup = "Apakah anda ingin salin ilustrasi <br> " + quotsID + " ?"
      }else if(model == "topup"){
        msgPopup = "Apakah anda ingin salin <br> TOP UP 1?"
      }else if(model == "penarikan"){
        msgPopup = "Apakah anda ingin salin <br> penarikan 1?"
      }else if(model == "template"){
        msgPopup = "Apakah anda ingin salin <br> template 1?"
      }

      var confirmPopup = $ionicPopup.confirm({
        title: "",
        template: msgPopup,
        cssClass: 'pru-white-alert without-header popup-large pru-logo-text button-side-duo',
        scope: $scope,
        buttons: [
        {
          text: 'TIDAK',
          type: 'button-dark-gray',
          onTap: function(e) {
          }
        },
        {
          text: 'YA',
          type: 'button-assertive',
          onTap: function(e, qID) {
            
            
            var QuotationStorage = {};
            QuotationStorageService.getQuotationStorageByKey($q, quotsIDVar).then(function(result){
                QuotationStorage = result;
                var oldQuotationId = QuotationStorage.QuotationId;

                var reDate = moment(new Date()).format('YYYYMMDDHHMMSS');
                QuotationStorage.QuotationId = $rootScope.agent.code + reDate;
                QuotationStorage.QuotationDate = new Date();
                QuotationStorageService.addQuotationStorage($q, QuotationStorage.QuotationId, QuotationStorage).then(function(){

                    if(QuotationStorage.OutputId){

                        var OutputStorage = {};
                        OutputStorageService.getOutputStorageByKey($q, QuotationStorage.OutputId).then(function(res){
                            OutputStorage = res;

                            OutputStorage.OutputId = 'OUT' + (new Date().getTime());   
                            OutputStorageService.addOutputStorage($q, OutputStorage.OutputId, OutputStorage).then(function(){                                
                                $scope.closePopupSalinIlustrasi(oldQuotationId, QuotationStorage.QuotationId);
                            });
                        });
                    }


                });
            });

            
          }
        }
        ]
      });
      
    }

    var confirmPopup;
    $scope.morePopup = function(idx, model, lvl, qID){
      var listInPopup = null;
      console.log(qID);
      if(model == "ilustrasi"){

        if (lvl==1 || lvl==2 || lvl==3 || lvl==4 ) {
            listInPopup = "<div class='font-red pad-bot-20 b-border-gray' ng-click='lanjutkanIlustrasi("+"\""+lvl+"\""+", "+"\""+qID+"\""+")'>Lanjutkan Ilustrasi</div>" +
                          "<div class='font-gray marg-top-20' ng-click='confirmRemovePopup("+"\""+idx+"\""+",\"ilustrasi\","+"\""+qID+"\""+")'>Hapus Ilustrasi</div>"
        } else if(lvl==5){
            listInPopup = "<div class='font-gray marg-top-20 b-border-gray pad-bot-20' ng-click='lihatRincianIlustrasi("+"\""+lvl+"\""+", "+"\""+qID+"\""+")'>Lihat Rincian Ilustrasi</div>" +
                          "<div class='font-gray marg-top-20 b-border-gray pad-bot-20' ng-click='editRincianIlustrasi("+"\""+5+"\""+", "+"\""+qID+"\""+")'>Edit Rincian Ilustrasi</div>" +
                          "<div class='font-gray marg-top-20 b-border-gray pad-bot-20' ng-click='kirimIlustrasi("+"\""+qID+"\""+")'>Kirim Ilustrasi</div>" +
                          "<div class='font-gray marg-top-20 b-border-gray pad-bot-20' ng-click='confirmSalinIlustrasi("+"\""+idx+"\""+", \"ilustrasi\","+"\""+qID+"\""+")'>Salin Ilustrasi</div>" +
                          "<div class='font-gray marg-top-20' ng-click='confirmRemovePopup("+"\""+idx+"\""+", \"ilustrasi\","+"\""+qID+"\""+")'>Hapus Ilustrasi</div>"
        }else if(lvl==6){
            listInPopup = "<div class='font-gray marg-top-20 b-border-gray pad-bot-20' ng-click='lihatRincianIlustrasi("+"\""+lvl+"\""+", "+"\""+qID+"\""+")'>Lihat Rincian Ilustrasi</div>" +
                          "<div class='font-gray marg-top-20 b-border-gray pad-bot-20' ng-click='editRincianIlustrasi("+"\""+1+"\""+", "+"\""+qID+"\""+")'>Edit Rincian Ilustrasi</div>" +
                          "<div class='font-gray marg-top-20 b-border-gray pad-bot-20' ng-click='kirimIlustrasi("+"\""+qID+"\""+")'>Kirim Ilustrasi</div>" +
                          "<div class='font-gray marg-top-20 b-border-gray pad-bot-20' ng-click='confirmSalinIlustrasi("+"\""+idx+"\""+", \"ilustrasi\","+"\""+qID+"\""+")'>Salin Ilustrasi</div>" +
                          "<div class='font-gray marg-top-20' ng-click='confirmRemovePopup("+"\""+idx+"\""+", \"ilustrasi\","+"\""+qID+"\""+")'>Hapus Ilustrasi</div>"
        }
        //---------- source ori before validate ----------
        // listInPopup = "<div class='font-red pad-bot-20 b-border-gray' ng-click='lanjutkanIlustrasi("+"\""+lvl+"\""+", "+"\""+qID+"\""+")'>Lanjutkan Ilustrasi</div>" +
        //   "<div class='font-gray marg-top-20 b-border-gray pad-bot-20' ng-click='lihatRincianIlustrasi()'>Lihat Rincian Ilustrasi</div>" +
        //   "<div class='font-gray marg-top-20 b-border-gray pad-bot-20' ng-click='kirimIlustrasi("+"\""+qID+"\""+")'>Kirim Ilustrasi</div>" +
        //   "<div class='font-gray marg-top-20' ng-click='confirmRemovePopup(\"ilustrasi\")'>Hapus Ilustrasi</div>"
        //   console.log(listInPopup);
        // listInPopup = "<div class='font-red pad-bot-20 b-border-gray' ng-click='lanjutkanIlustrasi("+"\""+lvl+"\""+", "+"\""+qID+"\""+")'>Lanjutkan Ilustrasi</div>" +
        //   "<div class='font-gray marg-top-20 b-border-gray pad-bot-20' ng-click='lihatRincianIlustrasi()'>Lihat Rincian Ilustrasi</div>" +
        //   "<div class='font-gray marg-top-20 b-border-gray pad-bot-20' ng-click='kirimIlustrasi("+"\""+qID+"\""+")'>Kirim Ilustrasi</div>" +
        //   "<div class='font-gray marg-top-20' ng-click='confirmRemovePopup(\"ilustrasi\","+"\""+qID+"\""+")'>Hapus Ilustrasi</div>"
        //   console.log(listInPopup);
      }else if(model == "template"){
        listInPopup = "<div class='font-red pad-bot-20 b-border-gray' ng-click='lihatRincianTemplate()'>Lihat Rincian Template</div>" +
          "<div class='font-gray marg-top-20 pad-bot-20 b-border-gray' ng-click='lihatRincianTemplate()'>Edit Template</div>" +
          "<div class='font-gray marg-top-20' ng-click='confirmRemovePopup(\"template\")'>Hapus Template</div>"
      }
      confirmPopup = $ionicPopup.confirm({
        title: "",
        template: listInPopup,
        cssClass: 'pru-white-alert without-header popup-large pru-logo-text button-side-duo',
        scope: $scope,
        buttons: [{
          text: 'Batal',
          type: 'font-gray bg-white pad-bot-0 t-border-gray',
          onTap: function(e) {
          }
        }]
      });
      $scope.lanjutkanIlustrasi = function(lvl, quotsID){

      $ionicLoading.show();

      $rootScope.QuotationId = quotsID;
      $rootScope.Level = parseInt(lvl);
      // window.location = "#/pemegangpolis";

      if ($rootScope.Level <= 2) {
        window.location = "#/pemegangpolis";
      } else if ($rootScope.Level <= 4){
        window.location = "#/produk-manfaat";
      } else {
        window.location = "#/salin-ilustrasi";
      }

      console.log('Quotation ID :' + $rootScope.QuotationId);
      console.log('Level        :' + $rootScope.Level);
      console.log('=======================================================');
      confirmPopup.close();
      };  

      $scope.editRincianIlustrasi = function(lvl, quotsID){

        $ionicLoading.show();

        $rootScope.QuotationId = quotsID;
        $rootScope.Level = parseInt(lvl);
        // window.location = "#/pemegangpolis";

        if ($rootScope.Level <= 2) {
          window.location = "#/pemegangpolis";
        } else if ($rootScope.Level <= 4){
          window.location = "#/produk-manfaat";
        } else {
          window.location = "#/salin-ilustrasi";
        }

        console.log('Quotation ID :' + $rootScope.QuotationId);
        console.log('Level        :' + $rootScope.Level);
        console.log('=======================================================');
        confirmPopup.close();
      };  
      $scope.lihatRincianIlustrasi = function(lvl, quotsID){
        $rootScope.QuotationId = quotsID;
        $rootScope.Level = parseInt(lvl);
        window.location = "#/salin-ilustrasi";
        confirmPopup.close();
      };
      $scope.kirimIlustrasi = function(quotsID){
        $rootScope.QuotationId = quotsID;
        $state.go('send-email-ilustrasi');          
        confirmPopup.close();
      };
      $scope.lihatRincianTemplate= function(){
        window.location = "#/templates/detail-pilih-produk";
        confirmPopup.close();
      };
    }

    $scope.removedPopup = function(model, idx){
      $timeout(function(){
        var alertPopup = $ionicPopup.alert({
          title: "Ilustrasi telah terhapus",
          template: model + " telah terhapus",
          cssClass: 'pru-white-alert without-header popup-large pru-logo-text button-side-duo',
          scope: $scope,
          buttons: [
          {
            text: 'SELESAI',
            type: 'button-assertive',
            onTap: function(e) {
              alertPopup.close();
              confirmPopup.close();
              $scope.illustrationOnHoldDatas.splice(idx, 1);              
            }
          }
          ]
        }, 5);
      })
    }

    $scope.closePopupSalinIlustrasi = function(quotId, newQuotId){
      $timeout(function(){
        var alertPopup = $ionicPopup.alert({
          title: "Ilustrasi " + quotId + " telah disalin menjadi " + newQuotId,
          template: quotId + " telah tersalin",
          cssClass: 'pru-white-alert without-header popup-large pru-logo-text button-side-duo',
          scope: $scope,
          buttons: [
          {
            text: 'SELESAI',
            type: 'button-assertive',
            onTap: function(e) {
              alertPopup.close();
              confirmPopup.close();
              $scope.illustrationOnHoldDatas = [];
              callQuotStorage();
            }
          }
          ]
        }, 5);
      })
      // $scope.removeIlustrasi.close();
    }

  $scope.pemegangpolis = function () {
    $rootScope.QuotationId = undefined;
    $rootScope.Level = undefined;
    $rootScope.check = false;
    $rootScope.flagOpenTertanggung = false;
    console.log('---------- masuk function pempol');
    // $rootScope.dataset = [];
    // $rootScope.datasetTertanggung = [];
    // $rootScope.datasetMandatory = [];
    $state.go("pemegangpolis");
  }
  
  $scope.buattemplate = function () {
    $state.go("buat-template");
  }
  

  $scope.previous = function(){
    $state.go("home-menu.agent");
  }
});