﻿angular.module('PruForce.services')

	.service('newSqsService', function (DataFactoryNewSQSOffline, DataFactoryNewSQS, $q, $rootScope,$ionicLoading) {

		function invoke(channelId) {
			
			var req = {
				adapter: "HTTPAdapterNewSQS",
                procedure: "findPublish",
				method: WLResourceRequest.POST,
                parameters: { "params": "['" + channelId + "']" }
			};

			var deferred = $q.defer();

			DataFactoryNewSQSOffline.invoke(req)
				.then(function (res) {
					deferred.resolve(res);
					$ionicLoading.hide();
				}, function (error) {
					deferred.reject(error);
					$ionicLoading.hide();
				});

			return deferred.promise;
		}

		/*
		function send(to, cc, bcc, subject, transactionId, transactionTime, signatureString, channelId, processCode, pwdUser, pwdOwner, base64att, fileName, mimeType, name, nomorIlustrasi, Dob, gender, tertanggungUtama) {
            
             var req = {
				adapter: "HTTPAdapterNewSQS",
                procedure: "newSqsEmail",
				method: WLResourceRequest.POST,
                parameters: { "params": "['" + to + "','" + cc + "','" + bcc + "','" + subject + "','" + transactionId + "','" + transactionTime + "','" + signatureString + "','" + channelId + "','" + processCode + "','" + pwdUser + "','" + pwdOwner + "','" + base64att + "','" + fileName + "','" + mimeType + "','" + name + "','" + nomorIlustrasi + "','" + Dob + "','" + gender + "','" + tertanggungUtama + "']" }
            };
				
			var deferred = $q.defer();

			DataFactoryNewSQS.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}
		*/

		function send(param) {
            
             console.log('param == ', param); 	
             var req = {
				adapter: "HTTPAdapterNewSQS",
                procedure: "newSqsEmail",
				method: WLResourceRequest.POST,
                parameters: { "params": "['" + param.to + "','" + param.cc + "','" + param.bcc + "','" + param.subject + "','" + param.transactionId + "','" + param.transactionTime + "','" + param.signatureString + "','" + param.channelId + "','" + param.processCode + "','" + param.pwdUser + "','" + param.pwdOwner + "','" + param.base64att + "','" + param.fileName + "','" + param.mimeType + "','" + param.name + "','" + param.nomorIlustrasi + "','" + param.DobPP + "','" + param.gender + "','" + param.tertanggungUtama + "','" + param.DobTertanggung + "','" + param.uangPertanggungan + "','" + param.productName + "','" + param.tertanggungTambahan1 + "','" + param.tertanggungTambahan2 + "','" + param.agentId + "','" + param.agentName + "','" + param.agentOffice + "']" }
            };
				
			var deferred = $q.defer();

			DataFactoryNewSQSOffline.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invoke: invoke,
			send: send
		}




	});

