﻿angular.module('PruForce.services').factory('OutputService', function($q, $rootScope){
    
    //console.log($rootScope);
    var formatCurr;
    var docId;
    var arrayAnBAge = [];
    var upCollection = [];
    var upCollection2 = [];
    var UPFinish; 
    function createPdf(mapOutput) {
        formatCurr = mapOutput.currency == 'USD' ? 2 : 0;
        docId = mapOutput.docIdStandard;
        return $q(function (resolve, reject) {
            var dd = createDocumentDefinition(mapOutput);
            var pdf = pdfMake.createPdf(dd);

            pdf.getBase64(function (output) {
                $rootScope.base64Att = output;
                // //console.log('base64Att == ', output.subtring(1,300));
                resolve(base64ToUint8Array(output));
            });
        });
    }

    function outputPdf(mapOutput) {
        formatCurr = mapOutput.currency == 'USD' ? 2 : 0;
        docId = mapOutput.docIdStandard;
        return $q(function (resolve, reject) {
            var dd = createDocumentDefinition(mapOutput);
            var pdf = pdfMake.createPdf(dd);
            pdf.download('ilustrasi.pdf');
            /*var data64 = pdf.download('sample.pdf');
            data64.getBase64(function (output) {
                $rootScope.base64Att = output;
                // //console.log('base64Att == ', output.subtring(1,300));
                resolve(base64ToUint8Array(output));
            });*/
        });
    }

        
    

    var whiteWitSpace = function () {
        return {
            
            hLineWidth: function(i, node) {
                    return (i === 0 || i === node.table.body.length) ? 1 : 0;
            },
            vLineWidth: function(i, node) {
                    return (i === 0 || i === node.table.widths.length) ? 1 : 0;
            },
            hLineColor: function(i, node) {
                    return (i === 0 || i === node.table.body.length) ? 'black' : 'white';
            },
            vLineColor: function(i, node) {
                    return (i === 0 || i === node.table.widths.length) ? 'black' : 'white';
            },
                            
        };
    }

    var whiteNoSpace = function () {
        return {
            
            hLineWidth: function(i, node) {
                    return (i === 0 || i === node.table.body.length) ? 0 : 0;
            },
            vLineWidth: function(i, node) {
                    return (i === 0 || i === node.table.widths.length) ? 0: 0;
            },
            hLineColor: function(i, node) {
                    return (i === 0 || i === node.table.body.length) ? 'black' : 'white';
            },
            vLineColor: function(i, node) {
                    return (i === 0 || i === node.table.widths.length) ? 'black' : 'white';
            },
            paddingLeft: function(i, node) { return 1; },
            paddingRight: function(i, node) { return 1; },
            paddingTop: function(i, node) { return 1; },
            paddingBottom: function(i, node) { return 1 },
                            
        };
    }


    var whiteNoSpacePadBot = function () {
        return {
            hLineWidth: function(i, node) {
                    return (i === 0 || i === node.table.body.length) ? 0 : 0;
            },
            vLineWidth: function(i, node) {
                    return (i === 0 || i === node.table.widths.length) ? 0: 0;
            },
            hLineColor: function(i, node) {
                    return (i === 0 || i === node.table.body.length) ? 'black' : 'white';
            },
            vLineColor: function(i, node) {
                    return (i === 0 || i === node.table.widths.length) ? 'black' : 'white';
            },
            paddingLeft: function(i, node) { return 1; },
            paddingRight: function(i, node) { return 1; },
            paddingTop: function(i, node) { return 1; },
            paddingBottom: function(i, node) { return 5 },
                            
        };
    }

    var lineFullWidth = function () {
        return {
            hLineWidth: function(i, node) {
                return (i === 0 || i === node.table.body.length) ? 0 : 1;
            },
            vLineWidth: function(i, node) {
                return 0;
            },
        };
    }

    function sortingRiderTopupMain(tempManfaatList){
        var manfaatList = [];
        for(var i = 0; i < tempManfaatList.length; i++){
          var tmpManfaat = tempManfaatList[i];
          for(var j = 0; j < tmpManfaat.custList.length; j++){
            var tmpCustList = tmpManfaat.custList[j];

            var manfaat = {};

            manfaat.code = tmpManfaat.code;
            manfaat.name = tmpManfaat.name;
            manfaat.disabled = tmpManfaat.disabled;
            manfaat.coverageType = tmpManfaat.coverageType;
            manfaat.type = tmpManfaat.type;
            manfaat.lifeAssureCd = tmpManfaat.lifeAssureCd;


            manfaat.tertanggungName = tmpCustList.name;
            manfaat.tertanggungAge = tmpCustList.anb;
            manfaat.tertanggungKey = tmpCustList.key;
            manfaat.tertanggungCustomerId = tmpCustList.customerId;
            manfaat.biayaBulanan = tmpCustList.biayaBulanan;
            manfaat.annualPremi = tmpCustList.annualPremi;
            manfaat.itemInput = tmpCustList.itemInput;

            manfaatList.push(manfaat);
          }         
        }
        return manfaatList;
    }

    function getJenisMedical(prodCatCd, prodCd, currCd, anb, up, mapOutput){
        //console.log('up == ',up);
        var channelCode = $rootScope.agent.channelType;
        var productList = $rootScope.CHANNEL[channelCode].PRODUCT_CATEGORY[0].PRODUCT;
        var productCurrencyList;
        var medicalList;
        var UPList;
        var UPList2;
        var maxUp;
        // var up = $scope.ilustrasi.output.up;
        
        var maxAge ;
        for(var i = 0; i < productList.length; i++){
          if(productList[i].code == prodCd){
              productCurrencyList = productList[i].CURRENCY;

              for(var x = 0; x < productCurrencyList.length ;x++){
                  if(productCurrencyList[x].code == currCd){
                    medicalList = productCurrencyList[x].MEDICAL;

                    for(var z = 0; z < medicalList.length; z++){
                        maxAge = medicalList[z].maxAge;

                      //cek maxAge > ANB
                      if(parseInt(maxAge) >= parseInt(anb)){
                          arrayAnBAge.push(medicalList[z]);                        
                      }
                    }  
                     
                    break;
                    
                  }                  
              }

              break;
          }
        }

        for(var j = 0; j < arrayAnBAge.length; j++){
            UPList = arrayAnBAge[j];

            maxUp = UPList.maxRisk;

            //cek maxUP > UP
            if(parseFloat(maxUp) >= parseFloat(up)){
                  upCollection.push(UPList);                        
            }
        }

        for(var k = 0; k < upCollection.length; k++){
            UPList2 = upCollection[k];

            if(parseInt(UPList2.minAge) <= parseInt(anb)){
                upCollection2.push(UPList2);
            }
        }

        for(var l = 0; l < upCollection2.length; l++){
            UPFinish = upCollection2[l];
            if(parseFloat(UPFinish.minRisk) <= parseFloat(up)){
                mapOutput.medicalCode = UPFinish.medicalCd;
            }
        }

        //console.log('mapOutput.medicalCode == ',mapOutput.medicalCode);
        
        // //console.log('Medical List == ',medicalList);
      }

    function ringkasanNilaiTunaiHeader(mapOutput){
        // //console.log("====================== Ringkasan Nilai Tunai Header (START) =====================");
        var body = [];
        body.push([ emptycol, emptycol]);
        for(var i = 0; i < mapOutput.fundList.length; i++){
            // var year = mapOutput.fundList[i].year;
            var customerAge = mapOutput.fundList[i].customerAge;
            body.push(['Usia ke- '+customerAge,mapOutput.currency]);
        }
        // //console.log(body);
        // //console.log('body after transpose', body.transpose());
        // //console.log("====================== Ringkasan Nilai Tunai Header (FINISH) =====================");
        return body.transpose();
    }

    function deskripsiPekerjaan(mapOutput){
        var body = [];

        var usiaTU = mapOutput.ageonly;
        var usiaTT1 = mapOutput.ageonlyTT1;
        var usiaTT2 = mapOutput.ageonlyTT2;
        var jkTU = mapOutput.gender.split("/")[0];
        var jkTT1 = mapOutput.genderTT1 != undefined?mapOutput.genderTT1.split("/")[0]:undefined;
        var jkTT2 = mapOutput.genderTT2 != undefined?mapOutput.genderTT2.split("/")[0]:undefined;
        var pekerjaan = mapOutput.pekerjaan;
        var pekerjaanTT1 = mapOutput.pekerjaanTT1;
        var pekerjaanTT2 = mapOutput.pekerjaanTT2;

        var deskripsiPekerjaan = mapOutput.deskripsiPekerjaan;
        var deskripsiPekerjaanTT1 = mapOutput.deskripsiPekerjaanTT1;
        var deskripsiPekerjaanTT2 = mapOutput.deskripsiPekerjaanTT2;

        var isPickSpouseFlag = mapOutput.isPickSpouseFlag;

        var isDewasaTU = false;
        var isDewasaTT1 = false;
        var isDewasaTT2 = false;


        if(parseInt(usiaTU) >= 21){
            isDewasaTU = true;
        }else if(jkTU.toLowerCase() == 'wanita' && parseInt(usiaTU) >= 19){
            isDewasaTU = true;
        }else{
            isDewasaTU = false;
        }

        if(parseInt(usiaTT1) >= 21){
            isDewasaTT1 = true;
        }else if(jkTU.toLowerCase() == 'wanita' && parseInt(usiaTT1) >= 19){
            isDewasaTT1 = true;
        }else{
            isDewasaTT1 = false;
        }

        if(parseInt(usiaTT2) >= 21){
            isDewasaTT2 = true;
        }else if(jkTU.toLowerCase() == 'wanita' && parseInt(usiaTT2) >= 19){
            isDewasaTT2 = true;
        }else{
            isDewasaTT2 = false;
        }        

        //console.log('Usia TU = ', usiaTU);
        //console.log('Usia TT1 = ', usiaTT1);
        //console.log('Usia TT2 = ', usiaTT2);
        //console.log('jkTU = ', jkTU);
        //console.log('jkTT1 = ', jkTT1);
        //console.log('jkTT2 = ', jkTT2);
        //console.log('pekerjaan = ', pekerjaan);
        //console.log('pekerjaanTT1 = ', pekerjaanTT1);
        //console.log('pekerjaanTT2 = ', pekerjaanTT2);
        //console.log('deskripsiPekerjaan = ', deskripsiPekerjaan);
        //console.log('deskripsiPekerjaanTT1 = ', deskripsiPekerjaanTT1);
        //console.log('deskripsiPekerjaanTT2 = ', deskripsiPekerjaanTT2);
        //console.log('isDewasaTU = ', isDewasaTU);
        //console.log('isDewasaTT1 = ', isDewasaTT1);
        //console.log('isDewasaTT2 = ', isDewasaTT2);
        //console.log('isPickSpouseFlag = ',isPickSpouseFlag);

        /*
        if(usiaTT1 == undefined || usiaTT2 == undefined){
            //console.log('hanya TU');
            body.push([pekerjaan, deskripsiPekerjaan]);            
        }else if(isDewasaTU && isDewasaTT1 && isPickSpouseFlag){            
            //console.log('TU dan TT1 dewasa, ngambil spouse');
            body.push([pekerjaan, deskripsiPekerjaan]);
            body.push([pekerjaanTT1, deskripsiPekerjaanTT1]);
        }else if(!isDewasaTU && isDewasaTT1 && isDewasaTT2){
            //console.log('TU anak-anak, TT1 & TT2 dewasa');
            body.push([pekerjaan, deskripsiPekerjaan]);
            body.push([pekerjaanTT1, deskripsiPekerjaanTT1]);
            body.push([pekerjaanTT2, deskripsiPekerjaanTT2]);
        }else if(isDewasaTU && isDewasaTT1 && !isPickSpouseFlag){
            //console.log('TU dan TT1 dewasa, tidak ngambil spouse');
            body.push([pekerjaan, deskripsiPekerjaan]);
        }
        */

        

        var pekerjaanArr = [];

        if(pekerjaan != undefined){
            pekerjaanArr.push(pekerjaan+'|'+deskripsiPekerjaan);            
        }

        if(pekerjaanTT1 != undefined){
            pekerjaanArr.push(pekerjaanTT1+'|'+deskripsiPekerjaanTT1);            
        }

        if(pekerjaanTT2 != undefined){
            pekerjaanArr.push(pekerjaanTT2+'|'+deskripsiPekerjaanTT2);            
        }    

        //console.log('pekerjaanArr == ',pekerjaanArr);

        pekerjaanArr = pekerjaanArr.filter( function( item, index, inputArray ) {
           return inputArray.indexOf(item) == index;
        });

        //console.log('pekerjaanArr after remove duplicate == ',pekerjaanArr);


        for(var i = 0; i < pekerjaanArr.length; i++){
            var objek = pekerjaanArr[i].split("|");
            body.push([objek[0], objek[1]]);
        }

        // if(pekerjaan != undefined && pekerjaanTT1 == undefined && pekerjaanTT2 == undefined){
        //     body.push([pekerjaan, deskripsiPekerjaan]);
        // }

        // if(pekerjaan != undefined && pekerjaanTT1 != undefined && pekerjaan != pekerjaanTT1){
        //     body.push([pekerjaan, deskripsiPekerjaan]);
        //     body.push([pekerjaanTT1, deskripsiPekerjaanTT1]);
        // }else{
        //     body.push([pekerjaan, deskripsiPekerjaan]);
        // }

        // if(pekerjaan != undefined && pekerjaanTT1 != undefined && pekerjaanTT2 != undefined){

        // }     

        
        return body;
    }

    function informasiTambahan(mapOutput){
        var body = [];
        //console.log(mapOutput.warningRule);

        if(mapOutput.warningRule != undefined){
            body.push([{text: 'INFORMASI TAMBAHAN', fontSize:10, bold: true},]);

            for(var i = 0; i < mapOutput.warningRule.length; i++){
                body.push([mapOutput.warningRule[i]]);
            }
            //body.push(['Informasi Tambahan :']);    
        }else{
            body.push([' ']);
        }

        
        return body;
    } 

    function ringkasanNilaiTunaiContent(mapOutput){
        // //console.log("====================== Ringkasan Nilai Tunai Content (START) =====================");
        var body = [];
        var isNegatifValue = false;
        body.push([ {text:'Rendah (000)', alignment:'center'}, {text:'Sedang (000)', alignment:'center'}, {text:'Tinggi (000)', alignment:'center'}]);
        for(var i = 0; i < mapOutput.fundListFormat.length; i++){

            var lowCv = mapOutput.fundListFormat[i].lowClient;
            var medCv = mapOutput.fundListFormat[i].medClient;
            var highCv = mapOutput.fundListFormat[i].highClient;
            body.push([lowCv, medCv, highCv]);

            if(lowCv.indexOf('*') > -1 || medCv.indexOf('*') > -1 || highCv.indexOf('*') > -1){
                isNegatifValue = true;
            }
        }

        if(isNegatifValue){
            mapOutput.valueNilaiTunaiLabel = '***';
            mapOutput.valueNilaiTunaiLabelDesc = {text: ['Menunjukkan bahwa Nilai Tunai pada tahun tersebut tidak mencukupi untuk membayar Biaya Asuransi dan Biaya Administrasi, dan oleh karena itu Polis menjadi batal (lapse). Supaya Manfaat Polis dapat terus berlanjut, maka Anda dapat melakukan pembayaran Premi ',{text:'Top-up', font: 'garamount' },' Tunggal.']};
        }else{
            mapOutput.valueNilaiTunaiLabel = ' ';
            mapOutput.valueNilaiTunaiLabelDesc = ' ';
        }
        
        return body.transpose();
    }

    function fakultatifValue(mapOutput, deathBenefitValue, totalCCValue, addValue){
        var result = '';
        var tidakBekerjaIDR = parseFloat(2000000000);
        var tidakBekerjaUSD = parseFloat(250000*8000);
        var bekerjaIDR = parseFloat(10000000000);
        var bekerjaUSD = parseFloat(1250000*8000);

        
        var tidakBekerja = ['STDN', 'NSTN', 'HSWF', 'UNEM'];
        if(tidakBekerja.indexOf(mapOutput.kodepekerjaan) > -1 && mapOutput.currency == 'IDR'){
            //console.log('Tidak Bekerja IDR');
            if(parseFloat(deathBenefitValue) > tidakBekerjaIDR || parseFloat(totalCCValue) > tidakBekerjaIDR || parseFloat(addValue) > tidakBekerjaIDR){
                result = 'Fakultatif';
            }else{
                result = 'Tidak Fakultatif';
            }
        }else if(tidakBekerja.indexOf(mapOutput.kodepekerjaan) > -1 && mapOutput.currency == 'USD'){
            //console.log('Tidak Bekerja USD');
            if(parseFloat(deathBenefitValue) > tidakBekerjaUSD || parseFloat(totalCCValue) > tidakBekerjaUSD || parseFloat(addValue) > tidakBekerjaUSD){
                result = 'Fakultatif';
            }else{
                result = 'Tidak Fakultatif';
            }
        }else if(!tidakBekerja.indexOf(mapOutput.kodepekerjaan) > -1 && mapOutput.currency == 'IDR'){
            //console.log('Bekerja IDR');
            if(parseFloat(deathBenefitValue) > bekerjaIDR || parseFloat(totalCCValue) > bekerjaIDR || parseFloat(addValue) > bekerjaIDR){
                result = 'Fakultatif';
            }else{
                result = 'Tidak Fakultatif';
            }
        }else{
            //console.log('Bekerja USD');
            if(parseFloat(deathBenefitValue) > bekerjaUSD || parseFloat(totalCCValue) > bekerjaUSD || parseFloat(addValue) > bekerjaUSD){
                result = 'Fakultatif';
            }else{
                result = 'Tidak Fakultatif';
            }
        }
        

        
        

        //console.log('result == ',result);
        return result;
    }

//------- ian coding disini
    function fundAllocationPage7(mapOutput){

        var body = [];
        var pekerjaan = '';
        var compare = '';
        var valueJCC = 0;
        var valueCI = 0;
        var valueESCC = 0;
        var valueMCC = 0;
        var valueCC = 0;
        var valueCCB = 0;
        var valuePAD = 0;
        var valuePADPlus = 0;
        var valuePADD = 0;
        var valuePADDPlus = 0;
        var additionalCCMedical = 0;
        var additionalCCFacultatif = 0;
        var ACC_CC = 0;
        var totalCC = 0;
        var totalADD = 0;
        var showAdditionalLifeFlag = false;
        var annuityList = $rootScope.COVERAGE['I1DR'];
        var termCI = 0;
        var annuityFactor = 0;
        var annuityFactorValue = 0;
        pekerjaan = mapOutput.kelasPekerjaan.toUpperCase().trim();
        //console.log(pekerjaan);


        for(var x = 0; x < mapOutput.manfaatList.length; x++){
            //console.log(mapOutput.manfaatList[x]);
            var productName = mapOutput.manfaatList[x].name;
            var productCode = mapOutput.manfaatList[x].code;
            var coverageType = mapOutput.manfaatList[x].coverageType;

            var itemInput = mapOutput.manfaatList[x].itemInput;

            if(productCode == 'W1QR' || productCode == 'W1MR' || productCode == 'S1KR' || productCode == 'S1FR' || productCode == 'W3BR' || productCode == 'S1YR' || productCode == 'W1XR' || productCode == 'W3AR'){
                showAdditionalLifeFlag = true;                
            }

            // if(productCode == 'I1DR'){
            //     annuityFactorValue = annuityList.ANNUITY[annuityFactor.toString()].factor;
            // }
            
            for(var y = 0; y < itemInput.length; y++){
                if(itemInput[y].key == 'PDSA' && productCode == 'I1DR'){
                    valueCI = parseFloat(itemInput[y].inputValue)/12;
                }else if(itemInput[y].key == 'PDSA' && productCode == 'C103'){  
                    valueJCC = parseFloat(itemInput[y].inputValue);
                }else if(itemInput[y].key == 'PDSA' && productCode == 'C104'){
                    valueJCC = parseFloat(itemInput[y].inputValue)*8000;    
                }else if(itemInput[y].key == 'PDSA' && productCode == 'C106'){
                    valueESCC = parseFloat(itemInput[y].inputValue);
                }else if(itemInput[y].key == 'PDSA' && productCode == 'C107'){
                    valueESCC = parseFloat(itemInput[y].inputValue)*8000;
                }else if(itemInput[y].key == 'PDSA' && productCode == 'C1TR'){
                    valueMCC = parseFloat(itemInput[y].inputValue)*1.6;
                }else if(itemInput[y].key == 'PDSA' && productCode == 'C1TD'){
                    valueMCC = parseFloat(itemInput[y].inputValue)*1.6*8000;
                }else if(itemInput[y].key == 'PDSA' && productCode == 'C1KR'){
                    valueCC =  parseFloat(itemInput[y].inputValue);
                }else if(itemInput[y].key == 'PDSA' && productCode == 'C1KD'){
                    valueCC =  parseFloat(itemInput[y].inputValue)*8000;
                }else if(itemInput[y].key == 'PDSA' && productCode == 'C1WR'){
                    valueCCB =  parseFloat(itemInput[y].inputValue);
                }else if(itemInput[y].key == 'PDSA' && productCode == 'C1WD'){
                    valueCCB =  parseFloat(itemInput[y].inputValue)*8000;
                }else if(itemInput[y].key == 'PDSA' && productCode == 'P1CR'){
                    valuePAD =  parseFloat(itemInput[y].inputValue);
                }else if(itemInput[y].key == 'PDSA' && productCode == 'P1CD'){
                    valuePAD =  parseFloat(itemInput[y].inputValue)*8000;
                }else if(itemInput[y].key == 'PDSA' && productCode == 'P1QR'){
                    valuePADPlus =  parseFloat(itemInput[y].inputValue);
                }else if(itemInput[y].key == 'PDSA' && productCode == 'P1QD'){
                    valuePADPlus =  parseFloat(itemInput[y].inputValue)*8000;
                }else if(itemInput[y].key == 'PDSA' && productCode == 'P1DR'){
                    valuePADD =  parseFloat(itemInput[y].inputValue);
                }else if(itemInput[y].key == 'PDSA' && productCode == 'P1DD'){
                    valuePADD =  parseFloat(itemInput[y].inputValue)*8000;
                }else if(itemInput[y].key == 'PDSA' && productCode == 'P1RR'){
                    valuePADDPlus =  parseFloat(itemInput[y].inputValue);
                }else if(itemInput[y].key == 'PDSA' && productCode == 'P1RD'){
                    valuePADDPlus =  parseFloat(itemInput[y].inputValue)*8000;
                }else if(itemInput[y].key == 'PDTERM' && productCode == 'I1DR'){
                    termCI = parseFloat(itemInput[y].inputValue);
                }
                
            }
        }

        
        annuityFactor = (termCI-parseFloat(mapOutput.ageonly))*12;

        //console.log('termCI == ',termCI);
        //console.log('usia == ',mapOutput.ageonly);
        //console.log('annuityFactor == ',annuityFactor);
        //console.log('annuityList ==',annuityList);

        //console.log('anuity 10 tahun ', annuityList.ANNUITY['10'].factor);

        if(annuityFactor > 0){
            annuityFactorValue = annuityList.ANNUITY[annuityFactor.toString()].factor;    
        }
        


        var valueCIAfter = annuityFactorValue*valueCI;

        //console.log('valueCI == ',valueCI);
        //console.log('annuityFactorValue == ',annuityFactorValue);
        //console.log('valueCIAfter  == ',valueCIAfter);
        //console.log('valueJCC == ',valueJCC);
        //console.log('valueESCC == ',valueESCC);
        //console.log('valueMCC == ',valueMCC);    
        //console.log('valueCC == ',valueCC);
        //console.log('valueCCB == ',valueCCB);
        //console.log('valuePAD == ',valuePAD);
        //console.log('valuePADPlus == ',valuePADPlus);
        //console.log('valuePADD == ',valuePADD);
        //console.log('valuePADDPlus == ',valuePADDPlus);


        additionalCCMedical = valueJCC+valueCIAfter+valueESCC+valueMCC;
        additionalCCFacultatif = valueCIAfter+valueMCC;
        ACC_CC = valueCC+valueCCB;
        totalCC = ACC_CC+additionalCCFacultatif;
        totalADD = valuePAD+valuePADPlus+valuePADD+valuePADDPlus;        

        //console.log('additionalCCMedical == ',additionalCCMedical);
        //console.log('additionalCCFacultatif == ',additionalCCFacultatif);
        //console.log('ACC_CC == ',ACC_CC);
        //console.log('totalCC == ',totalCC);
        //console.log('totalADD == ',totalADD);

        if(mapOutput.currency == 'IDR' && additionalCCMedical >= parseFloat(mapOutput.output.totalDeathBenefit)){
            getJenisMedical(mapOutput.prodCatCd, mapOutput.prodCd, 'IDR', mapOutput.ageonly, additionalCCMedical, mapOutput);    
        }else if(mapOutput.currency == 'IDR' && parseFloat(mapOutput.output.totalDeathBenefit) >=additionalCCMedical){
            getJenisMedical(mapOutput.prodCatCd, mapOutput.prodCd, 'IDR', mapOutput.ageonly, parseFloat(mapOutput.output.totalDeathBenefit), mapOutput);
        }else if(mapOutput.currency == 'USD' && additionalCCMedical >= (parseFloat(mapOutput.output.totalDeathBenefit)*8000)){
            getJenisMedical(mapOutput.prodCatCd, mapOutput.prodCd, 'IDR', mapOutput.ageonly, additionalCCMedical, mapOutput);
        }else{
            getJenisMedical(mapOutput.prodCatCd, mapOutput.prodCd, 'IDR', mapOutput.ageonly, (parseFloat(mapOutput.output.totalDeathBenefit)*8000), mapOutput);
        }

        body.push(['Nama Calon Pemegang Polis', mapOutput.pemegangPolis]);
        body.push(['(sesuai Kartu ID)', ' ']);
        body.push(['Pekerjaan**',mapOutput.kodepekerjaanPemegangPolis+' '+mapOutput.pekerjaanPemegangPolis]);

        body.push(['Instansi/Departemen',mapOutput.instansiDepartement]);

        body.push(['Bidang Usaha',mapOutput.kodebidUsaha+' '+mapOutput.bidangUsaha]);

        body.push(['Jabatan/Pangkat/Golongan',mapOutput.kodejabatanPemegangPolis+' '+mapOutput.jabatanPemegangPolis]);

        body.push(['Nama Calon Pembayar Premi',mapOutput.pemegangPolis]);

        body.push(['(sesuai Kartu ID)','']);

        body.push(['Pekerjaan**',mapOutput.kodepekerjaanPemegangPolis+' '+mapOutput.pekerjaanPemegangPolis]);

        body.push(['Instansi/Departemen',mapOutput.instansiDepartement]);

        body.push(['Bidang Usaha',mapOutput.kodebidUsaha+' '+mapOutput.bidangUsaha]);

        body.push(['Jabatan/Pangkat/Golongan',mapOutput.kodejabatanPemegangPolis+' '+mapOutput.jabatanPemegangPolis]);
        body.push(['Total Penghasilan Rutin Calon Pembayar Premi per Bulan **',mapOutput.nilaiIncome]);
        
        body.push(['Nama  Calon Tertanggung Utama',mapOutput.tertanggungName+' (sesuai kartu ID)']);
        body.push(['(sesuai Kartu ID/Akta lahir)',' ']);

        body.push(['Usia Tahun Berikutnya',mapOutput.ageonly+' ('+mapOutput.dob+')']);

        body.push(['Jenis Kelamin',mapOutput.gender]);


        body.push(['Pekerjaan**',mapOutput.kodepekerjaan+' '+mapOutput.pekerjaan]);

        body.push(['Kelas Pekerjaan**',mapOutput.kelasPekerjaan]);

        body.push(['Bidang Usaha',mapOutput.kodebidUsaha+' '+mapOutput.bidUsaha]);
        body.push(['Jabatan/Pangkat/Golongan',mapOutput.kodejabatanPangkat+' '+mapOutput.jabatanPangkat]);
        body.push(['Total Penghasilan Rutin Calon Tertanggung Utama per Bulan **',mapOutput.nilaiIncome]);
        body.push([{colSpan:2, text: 'ALOKASI DANA INVESTASI'},'']);

        for(var x = 0; x < mapOutput.fundListOutput.length; x++){
            var fundCode = mapOutput.fundListOutput[x].code;
            var allocationPercentage = mapOutput.fundListOutput[x].itemInput[0].inputValue;
            var fundName = mapOutput.fundListOutput[x].name;

            if(allocationPercentage != '0' || allocationPercentage != 0){
                body.push([fundCode+' '+allocationPercentage+'% dari'+fundName,'']);    
            }
            
        }

        if(mapOutput.tertanggungtambahan1flag == true && mapOutput.tertanggungtambahan2flag == true && showAdditionalLifeFlag == true){
            body.push([{colSpan:2, text: 'Total Manfaat untuk menentukan jenis medikal :                                          Life 1 (Rp)                            Life 2 (Rp)                          Life 3 (Rp)'}]);
            // //console.log('total death benefit dari map output adalah : ', mapOutput.output.totalDeathBenefit);
            if(mapOutput.currency == 'IDR'){
                body.push(['Meninggal           ', ''+parseFloat(mapOutput.output.totalDeathBenefit).format(formatCurr)+'                      '+parseFloat('0').format(formatCurr)+'                      '+parseFloat('0').format(formatCurr)+'']);    
            }else{
                body.push(['Meninggal           ', ''+(parseFloat(mapOutput.output.totalDeathBenefit)*8000).format(formatCurr)+'                      '+parseFloat('0').format(formatCurr)+'                      '+parseFloat('0').format(formatCurr)+'']);    
            }
            
            // body.push(['Additional CC                           ', ''+parseFloat(mapOutput.output.medicalU1ZR).format(formatCurr)+'']);
            body.push(['Additional CC                           ', ''+additionalCCMedical.format(formatCurr)+'                                           '+parseFloat('0').format(formatCurr)+'                                           '+parseFloat('0').format(formatCurr)+'']);

            if(parseFloat(mapOutput.output.totalDeathBenefit) <= additionalCCMedical){
                body.push(['Besarnya UP                             ', ''+additionalCCMedical.format(formatCurr)+'                                '+parseFloat('0').format(formatCurr)+'                                '+parseFloat('0').format(formatCurr)+'']);
            }else{
                body.push(['Besarnya UP                             ', ''+parseFloat(mapOutput.output.totalDeathBenefit).format(formatCurr)+'                  '+parseFloat('0').format(formatCurr)+'                  '+parseFloat('0').format(formatCurr)+'']);
            }

            body.push(['Jenis Pemeriksaan yang dibutuhkan           ', mapOutput.medicalCode]);
            body.push([{colSpan:2, text: 'Total Manfaat untuk menentukan Fakultatif atau tidak : '},'']);
            if(mapOutput.currency == 'IDR'){
                body.push(['Meninggal                               ', ''+parseFloat(mapOutput.output.totalDeathBenefit).format(formatCurr)+'                    '+parseFloat('0').format(formatCurr)+'                    '+parseFloat('0').format(formatCurr)+'']);
            }else{
                body.push(['Meninggal                               ', ''+(parseFloat(mapOutput.output.totalDeathBenefit)*8000).format(formatCurr)+'                    '+parseFloat('0').format(formatCurr)+'                    '+parseFloat('0').format(formatCurr)+'']);
            }    
            
            // body.push(['Additional CC                           ', ''+parseFloat(mapOutput.output.facultativeU1ZR).format(formatCurr)+'']);
            body.push(['Additional CC                           ', ''+additionalCCFacultatif.format(formatCurr)+'                                     '+parseFloat('0').format(formatCurr)+'                                     '+parseFloat('0').format(formatCurr)+'']);
            // body.push(['Crisis Income                           ', ''+parseFloat(mapOutput.output.crisisIncome).format(formatCurr)+'']);
            body.push(['Crisis Income                           ', ''+valueCIAfter.format(formatCurr)+'                                           '+parseFloat('0').format(formatCurr)+'                                           '+parseFloat('0').format(formatCurr)+'']);
            // body.push(['ACC-CC                                  ', ''+parseFloat(mapOutput.output.totAccU1ZR).format(formatCurr)+'']);
            body.push(['ACC-CC                                  ', ''+ACC_CC.format(formatCurr)+'                                         '+parseFloat('0').format(formatCurr)+'                                         '+parseFloat('0').format(formatCurr)+'']);
            // body.push(['Total CC                                ', ''+parseFloat(mapOutput.output.detFaculU1ZR).format(formatCurr)+'']);
            body.push(['Total CC                                ', ''+totalCC.format(formatCurr)+'                                         '+parseFloat('0').format(formatCurr)+'                                         '+parseFloat('0').format(formatCurr)+'']);
            if(mapOutput.currency == 'IDR'){
                if(parseFloat(mapOutput.uangPertanggungan) > parseFloat(2000000000)){
                    body.push(['TPD                                     ', ''+parseFloat(2000000000).format(formatCurr)+'                  '+parseFloat('0').format(formatCurr)+'                  '+parseFloat('0').format(formatCurr)+'']);    
                }else{
                    body.push(['TPD                                     ', ''+parseFloat(mapOutput.uangPertanggungan).format(formatCurr)+'                  '+parseFloat('0').format(formatCurr)+'                  '+parseFloat('0').format(formatCurr)+'']);    
                }
                
            }else{
                if((parseFloat(mapOutput.uangPertanggungan) * 8000) > parseFloat(2000000000)){
                    body.push(['TPD                                     ', ''+parseFloat(2000000000).format(formatCurr)+'                  '+parseFloat('0').format(formatCurr)+'                  '+parseFloat('0').format(formatCurr)+'']);    
                }else{
                    body.push(['TPD                                     ', ''+(parseFloat(mapOutput.uangPertanggungan)*8000).format(formatCurr)+'                  '+parseFloat('0').format(formatCurr)+'                  '+parseFloat('0').format(formatCurr)+'']);    
                }    
                
            }
            
            // body.push(['ADD/AD                                  ', ''+parseFloat(mapOutput.output.sa_basic).format(formatCurr)+'']);
            body.push(['ADD/AD                                  ', ''+totalADD.format(formatCurr)+'                                         '+parseFloat('0').format(formatCurr)+'                                         '+parseFloat('0').format(formatCurr)+'']);

            if(pekerjaan === 'Pengangguran atau Tidak Bekerja'.toUpperCase() || pekerjaan === 'Pelajar atau Mahasiswa'.toUpperCase() || pekerjaan === 'Bukan Pelajar atau Mahasiswa'.toUpperCase() || pekerjaan === 'Ibu Rumah Tangga'.toUpperCase()){
                if(parseFloat(mapOutput.output.totalDeathBenefit) >= parseFloat(mapOutput.output.detFaculU1ZR)){
                    compare = mapOutput.output.totalDeathBenefit;
                    if(parseFloat(compare) >= parseFloat(mapOutput.output.sa_basic)){
                       if(parseFloat(compare) >= 2000000000.0){
                            body.push(['Fakultatif untuk manfaat*               ', 'Fakultatif'+'                     Tidak Fakultatif'+'                     Tidak Fakultatif']);
                       }else{
                            body.push(['Fakultatif untuk manfaat*               ', 'Tidak Fakultatif'+'                     Tidak Fakultatif'+'                     Tidak Fakultatif']);
                       }
                    }else{
                        if(parseFloat(mapOutput.output.sa_basic) >= 2000000000.0){
                            body.push(['Fakultatif untuk manfaat*               ', 'Fakultatif'+'                     Tidak Fakultatif'+'                     Tidak Fakultatif']);
                        }else{
                            body.push(['Fakultatif untuk manfaat*               ', 'Tidak Fakultatif'+'                     Tidak Fakultatif'+'                     Tidak Fakultatif']);
                        }
                    }
                }else{
                    compare = mapOutput.output.totAccU1ZR;
                    if(parseFloat(compare) >= parseFloat(mapOutput.output.sa_basic)){
                       if(parseFloat(compare) >= 2000000000.00){
                            body.push(['Fakultatif untuk manfaat*               ', 'Fakultatif'+'                     Tidak Fakultatif'+'                     Tidak Fakultatif']);
                       }else{
                            body.push(['Fakultatif untuk manfaat*               ', 'Tidak Fakultatif'+'                     Tidak Fakultatif'+'                     Tidak Fakultatif']);
                       }
                    }else{
                        if(parseFloat(mapOutput.output.sa_basic) >= 2000000000.0){
                            body.push(['Fakultatif untuk manfaat*               ', 'Fakultatif'+'                     Tidak Fakultatif'+'                     Tidak Fakultatif']);
                        }else{
                            body.push(['Fakultatif untuk manfaat*               ', 'Tidak Fakultatif'+'                     Tidak Fakultatif'+'                     Tidak Fakultatif']);
                        }
                    }
                }
            }else{
                if(parseFloat(mapOutput.output.totalDeathBenefit) >= parseFloat(mapOutput.output.detFaculU1ZR)){
                    compare = mapOutput.output.totalDeathBenefit;
                    if(parseFloat(compare) >= parseFloat(mapOutput.output.sa_basic)){
                       if(parseFloat(compare) >= 10000000000.0){
                            body.push(['Fakultatif untuk manfaat*               ', 'Fakultatif'+'                     Tidak Fakultatif'+'                     Tidak Fakultatif']);
                       }else{
                            body.push(['Fakultatif untuk manfaat*               ', 'Tidak Fakultatif'+'                     Tidak Fakultatif'+'                     Tidak Fakultatif']);
                       }
                    }else{
                        if(parseFloat(mapOutput.output.sa_basic) >= 10000000000.0){
                            body.push(['Fakultatif untuk manfaat*               ', 'Fakultatif'+'                     Tidak Fakultatif'+'                     Tidak Fakultatif']);
                        }else{
                            body.push(['Fakultatif untuk manfaat*               ', 'Tidak Fakultatif'+'                     Tidak Fakultatif'+'                     Tidak Fakultatif']);
                        }
                    }
                }else{
                    compare = mapOutput.output.totAccU1ZR;
                    if(parseFloat(compare) >= parseFloat(mapOutput.output.sa_basic)){
                       if(parseFloat(compare) >= 10000000000.0){
                            body.push(['Fakultatif untuk manfaat*               ', 'Fakultatif'+'                     Tidak Fakultatif'+'                     Tidak Fakultatif']);
                       }else{
                            body.push(['Fakultatif untuk manfaat*               ', 'Tidak Fakultatif'+'                     Tidak Fakultatif'+'                     Tidak Fakultatif']);
                       }
                    }else{
                        if(parseFloat(mapOutput.output.sa_basic) >= 10000000000.0){
                            body.push(['Fakultatif untuk manfaat*               ', 'Fakultatif'+'                     Tidak Fakultatif'+'                     Tidak Fakultatif']);
                        }else{
                            body.push(['Fakultatif untuk manfaat*               ', 'Tidak Fakultatif'+'                     Tidak Fakultatif'+'                     Tidak Fakultatif']);
                        }
                    }
                }
            }
        }else if(mapOutput.tertanggungtambahan1flag == true && showAdditionalLifeFlag == true){
                    body.push([{colSpan:2, text: 'Total Manfaat untuk menentukan jenis medikal :                                          Life 1 (Rp)                            Life 2 (Rp)       '}]);
            // //console.log('total death benefit dari map output adalah : ', mapOutput.output.totalDeathBenefit);
            if(mapOutput.currency == 'IDR'){
                body.push(['Meninggal           ', ''+parseFloat(mapOutput.output.totalDeathBenefit).format(formatCurr)+'                      '+parseFloat('0').format(formatCurr)+'']);
            }else{
                body.push(['Meninggal           ', ''+(parseFloat(mapOutput.output.totalDeathBenefit)*8000).format(formatCurr)+'                      '+parseFloat('0').format(formatCurr)+'']);
            }    
            
            // body.push(['Additional CC                           ', ''+parseFloat(mapOutput.output.medicalU1ZR).format(formatCurr)+'']);
            body.push(['Additional CC                           ', ''+additionalCCMedical.format(formatCurr)+'                                           '+parseFloat('0').format(formatCurr)+'']);

            if(parseFloat(mapOutput.output.totalDeathBenefit) <= additionalCCMedical){
                body.push(['Besarnya UP                             ', ''+additionalCCMedical.format(formatCurr)+'                                '+parseFloat('0').format(formatCurr)+'']);
            }else{
                body.push(['Besarnya UP                             ', ''+parseFloat(mapOutput.output.totalDeathBenefit).format(formatCurr)+'                  '+parseFloat('0').format(formatCurr)+'']);
            }

            body.push(['Jenis Pemeriksaan yang dibutuhkan           ', mapOutput.medicalCode]);
            body.push([{colSpan:2, text: 'Total Manfaat untuk menentukan Fakultatif atau tidak : '},'']);
            body.push(['Meninggal                               ', ''+parseFloat(mapOutput.output.totalDeathBenefit).format(formatCurr)+'                    '+parseFloat('0').format(formatCurr)+'']);
            // body.push(['Additional CC                           ', ''+parseFloat(mapOutput.output.facultativeU1ZR).format(formatCurr)+'']);
            body.push(['Additional CC                           ', ''+additionalCCFacultatif.format(formatCurr)+'                                     '+parseFloat('0').format(formatCurr)+'']);
            // body.push(['Crisis Income                           ', ''+parseFloat(mapOutput.output.crisisIncome).format(formatCurr)+'']);
            body.push(['Crisis Income                           ', ''+valueCIAfter.format(formatCurr)+'                                           '+parseFloat('0').format(formatCurr)+'']);
            // body.push(['ACC-CC                                  ', ''+parseFloat(mapOutput.output.totAccU1ZR).format(formatCurr)+'']);
            body.push(['ACC-CC                                  ', ''+ACC_CC.format(formatCurr)+'                                         '+parseFloat('0').format(formatCurr)+'']);
            // body.push(['Total CC                                ', ''+parseFloat(mapOutput.output.detFaculU1ZR).format(formatCurr)+'']);
            body.push(['Total CC                                ', ''+totalCC.format(formatCurr)+'                                         '+parseFloat('0').format(formatCurr)+'']);
            if(mapOutput.currency == 'IDR'){
                if(parseFloat(mapOutput.uangPertanggungan) > parseFloat(2000000000)){
                    body.push(['TPD                                     ', ''+parseFloat(2000000000).format(formatCurr)+'                  '+parseFloat('0').format(formatCurr)+'                  '+parseFloat('0').format(formatCurr)+'']);    
                }else{
                    body.push(['TPD                                     ', ''+parseFloat(mapOutput.uangPertanggungan).format(formatCurr)+'                  '+parseFloat('0').format(formatCurr)+'                  '+parseFloat('0').format(formatCurr)+'']);    
                }
                
            }else{
                if((parseFloat(mapOutput.uangPertanggungan) * 8000) > parseFloat(2000000000)){
                    body.push(['TPD                                     ', ''+parseFloat(2000000000).format(formatCurr)+'                  '+parseFloat('0').format(formatCurr)+'                  '+parseFloat('0').format(formatCurr)+'']);    
                }else{
                    body.push(['TPD                                     ', ''+(parseFloat(mapOutput.uangPertanggungan)*8000).format(formatCurr)+'                  '+parseFloat('0').format(formatCurr)+'                  '+parseFloat('0').format(formatCurr)+'']);    
                }    
                
            }
            
            // body.push(['ADD/AD                                  ', ''+parseFloat(mapOutput.output.sa_basic).format(formatCurr)+'']);
            body.push(['ADD/AD                                  ', ''+totalADD.format(formatCurr)+'                                         '+parseFloat('0').format(formatCurr)+'']);

            if(pekerjaan === 'Pengangguran atau Tidak Bekerja'.toUpperCase() || pekerjaan === 'Pelajar atau Mahasiswa'.toUpperCase() || pekerjaan === 'Bukan Pelajar atau Mahasiswa'.toUpperCase() || pekerjaan === 'Ibu Rumah Tangga'.toUpperCase()){
                if(parseFloat(mapOutput.output.totalDeathBenefit) >= parseFloat(mapOutput.output.detFaculU1ZR)){
                    compare = mapOutput.output.totalDeathBenefit;
                    if(parseFloat(compare) >= parseFloat(mapOutput.output.sa_basic)){
                       if(parseFloat(compare) >= 2000000000.0){
                            body.push(['Fakultatif untuk manfaat*               ', 'Fakultatif'+'                     Tidak Fakultatif']);
                       }else{
                            body.push(['Fakultatif untuk manfaat*               ', 'Tidak Fakultatif'+'                     Tidak Fakultatif']);
                       }
                    }else{
                        if(parseFloat(mapOutput.output.sa_basic) >= 2000000000.0){
                            body.push(['Fakultatif untuk manfaat*               ', 'Fakultatif'+'                     Tidak Fakultatif']);
                        }else{
                            body.push(['Fakultatif untuk manfaat*               ', 'Tidak Fakultatif'+'                     Tidak Fakultatif']);
                        }
                    }
                }else{
                    compare = mapOutput.output.totAccU1ZR;
                    if(parseFloat(compare) >= parseFloat(mapOutput.output.sa_basic)){
                       if(parseFloat(compare) >= 2000000000.00){
                            body.push(['Fakultatif untuk manfaat*               ', 'Fakultatif'+'                     Tidak Fakultatif']);
                       }else{
                            body.push(['Fakultatif untuk manfaat*               ', 'Tidak Fakultatif'+'                     Tidak Fakultatif']);
                       }
                    }else{
                        if(parseFloat(mapOutput.output.sa_basic) >= 2000000000.0){
                            body.push(['Fakultatif untuk manfaat*               ', 'Fakultatif'+'                     Tidak Fakultatif']);
                        }else{
                            body.push(['Fakultatif untuk manfaat*               ', 'Tidak Fakultatif'+'                     Tidak Fakultatif']);
                        }
                    }
                }
            }else{
                if(parseFloat(mapOutput.output.totalDeathBenefit) >= parseFloat(mapOutput.output.detFaculU1ZR)){
                    compare = mapOutput.output.totalDeathBenefit;
                    if(parseFloat(compare) >= parseFloat(mapOutput.output.sa_basic)){
                       if(parseFloat(compare) >= 10000000000.0){
                            body.push(['Fakultatif untuk manfaat*               ', 'Fakultatif'+'                     Tidak Fakultatif']);
                       }else{
                            body.push(['Fakultatif untuk manfaat*               ', 'Tidak Fakultatif'+'                     Tidak Fakultatif']);
                       }
                    }else{
                        if(parseFloat(mapOutput.output.sa_basic) >= 10000000000.0){
                            body.push(['Fakultatif untuk manfaat*               ', 'Fakultatif'+'                     Tidak Fakultatif']);
                        }else{
                            body.push(['Fakultatif untuk manfaat*               ', 'Tidak Fakultatif'+'                     Tidak Fakultatif']);
                        }
                    }
                }else{
                    compare = mapOutput.output.totAccU1ZR;
                    if(parseFloat(compare) >= parseFloat(mapOutput.output.sa_basic)){
                       if(parseFloat(compare) >= 10000000000.0){
                            body.push(['Fakultatif untuk manfaat*               ', 'Fakultatif'+'                     Tidak Fakultatif']);
                       }else{
                            body.push(['Fakultatif untuk manfaat*               ', 'Tidak Fakultatif'+'                     Tidak Fakultatif']);
                       }
                    }else{
                        if(parseFloat(mapOutput.output.sa_basic) >= 10000000000.0){
                            body.push(['Fakultatif untuk manfaat*               ', 'Fakultatif'+'                     Tidak Fakultatif']);
                        }else{
                            body.push(['Fakultatif untuk manfaat*               ', 'Tidak Fakultatif'+'                     Tidak Fakultatif']);
                        }
                    }
                }
            }
    
        }else{

            body.push(['Total Manfaat untuk menentukan jenis medikal :', 'Life 1 (Rp)']);
            // //console.log('total death benefit dari map output adalah : ', mapOutput.output.totalDeathBenefit);
            if(mapOutput.currency == 'IDR'){
                body.push(['Meninggal           ', ''+parseFloat(mapOutput.output.totalDeathBenefit).format(formatCurr)+'']);
            }else{
                body.push(['Meninggal           ', ''+(parseFloat(mapOutput.output.totalDeathBenefit)*8000).format(formatCurr)+'']);
            }    
            
            // body.push(['Additional CC                           ', ''+parseFloat(mapOutput.output.medicalU1ZR).format(formatCurr)+'']);
            body.push(['Additional CC                           ', ''+additionalCCMedical.format(formatCurr)+'']);

            if(mapOutput.currency == 'IDR' && parseFloat(mapOutput.output.totalDeathBenefit) <= additionalCCMedical){
                body.push(['Besarnya UP                             ', ''+additionalCCMedical.format(formatCurr)+'']);
            }else if(mapOutput.currency == 'USD' && (parseFloat(mapOutput.output.totalDeathBenefit)*8000) <= additionalCCMedical){
                body.push(['Besarnya UP                             ', ''+additionalCCMedical.format(formatCurr)+'']); 
            }else{
                if(mapOutput.currency == 'IDR'){
                    body.push(['Besarnya UP                             ', ''+parseFloat(mapOutput.output.totalDeathBenefit).format(formatCurr)+'']);
                }else{
                    body.push(['Besarnya UP                             ', ''+(parseFloat(mapOutput.output.totalDeathBenefit)*8000).format(formatCurr)+'']);    
                }    
                
            }

            body.push(['Jenis Pemeriksaan yang dibutuhkan           ', mapOutput.medicalCode]);
            body.push([{colSpan:2, text: 'Total Manfaat untuk menentukan Fakultatif atau tidak : '},'']);
            if(mapOutput.currency == 'IDR'){
                body.push(['Meninggal                               ', ''+parseFloat(mapOutput.output.totalDeathBenefit).format(formatCurr)+'']);    
            }else{
                body.push(['Meninggal                               ', ''+(parseFloat(mapOutput.output.totalDeathBenefit)*8000).format(formatCurr)+'']);    
            }    
            
            // body.push(['Additional CC                           ', ''+parseFloat(mapOutput.output.facultativeU1ZR).format(formatCurr)+'']);
            body.push(['Additional CC                           ', ''+additionalCCFacultatif.format(formatCurr)+'']);
            // body.push(['Crisis Income                           ', ''+parseFloat(mapOutput.output.crisisIncome).format(formatCurr)+'']);
            body.push(['Crisis Income                           ', ''+valueCIAfter.format(formatCurr)+'']);
            // body.push(['ACC-CC                                  ', ''+parseFloat(mapOutput.output.totAccU1ZR).format(formatCurr)+'']);
            body.push(['ACC-CC                                  ', ''+ACC_CC.format(formatCurr)+'']);
            // body.push(['Total CC                                ', ''+parseFloat(mapOutput.output.detFaculU1ZR).format(formatCurr)+'']);
            body.push(['Total CC                                ', ''+totalCC.format(formatCurr)+'']);

            if(mapOutput.currency == 'IDR'){
                if(parseFloat(mapOutput.uangPertanggungan) > parseFloat(2000000000)){
                    body.push(['TPD                                     ', ''+parseFloat(2000000000).format(formatCurr)+'']);
                }else{
                    body.push(['TPD                                     ', ''+parseFloat(mapOutput.uangPertanggungan).format(formatCurr)+'']);    
                }                    
            }else{
                if((parseFloat(mapOutput.uangPertanggungan) * 8000) > parseFloat(2000000000)){
                    body.push(['TPD                                     ', ''+parseFloat(2000000000).format(formatCurr)+'']);
                }else{
                    body.push(['TPD                                     ', ''+(parseFloat(mapOutput.uangPertanggungan)*8000).format(formatCurr)+'']);    
                }    
                
            }    
            
            // body.push(['ADD/AD                                  ', ''+parseFloat(mapOutput.output.sa_basic).format(formatCurr)+'']);
            body.push(['ADD/AD                                  ', ''+totalADD.format(formatCurr)+'']);

            if(mapOutput.currency == 'IDR'){
                body.push(['Fakultatif untuk manfaat*               ', ''+fakultatifValue(mapOutput, parseFloat(mapOutput.output.totalDeathBenefit), totalCC, totalADD)+'']);
            }else{
                body.push(['Fakultatif untuk manfaat*               ', ''+fakultatifValue(mapOutput, parseFloat(mapOutput.output.totalDeathBenefit)*8000, totalCC, totalADD)+'']);
                
            }
            
            /*
            if(pekerjaan === 'Pengangguran atau Tidak Bekerja'.toUpperCase() || pekerjaan === 'Pelajar atau Mahasiswa'.toUpperCase() || pekerjaan === 'Bukan Pelajar atau Mahasiswa'.toUpperCase() || pekerjaan === 'Ibu Rumah Tangga'.toUpperCase()){
                if(parseFloat(mapOutput.output.totalDeathBenefit) >= parseFloat(mapOutput.output.detFaculU1ZR)){
                    compare = mapOutput.output.totalDeathBenefit;
                    if(parseFloat(compare) >= parseFloat(mapOutput.output.sa_basic)){
                       if(parseFloat(compare) >= 2000000000.0){
                            body.push(['Fakultatif untuk manfaat*               ', 'Fakultatif']);
                       }else{
                            body.push(['Fakultatif untuk manfaat*               ', 'Non Fakultatif']);
                       }
                    }else{
                        if(parseFloat(mapOutput.output.sa_basic) >= 2000000000.0){
                            body.push(['Fakultatif untuk manfaat*               ', 'Fakultatif']);
                        }else{
                            body.push(['Fakultatif untuk manfaat*               ', 'Non Fakultatif']);
                        }
                    }
                }else{
                    compare = mapOutput.output.totAccU1ZR;
                    if(parseFloat(compare) >= parseFloat(mapOutput.output.sa_basic)){
                       if(parseFloat(compare) >= 2000000000.00){
                            body.push(['Fakultatif untuk manfaat*               ', 'Fakultatif']);
                       }else{
                            body.push(['Fakultatif untuk manfaat*               ', 'Non Fakultatif']);
                       }
                    }else{
                        if(parseFloat(mapOutput.output.sa_basic) >= 2000000000.0){
                            body.push(['Fakultatif untuk manfaat*               ', 'Fakultatif']);
                        }else{
                            body.push(['Fakultatif untuk manfaat*               ', 'Non Fakultatif']);
                        }
                    }
                }
            }else{
                if(parseFloat(mapOutput.output.totalDeathBenefit) >= parseFloat(mapOutput.output.detFaculU1ZR)){
                    compare = mapOutput.output.totalDeathBenefit;
                    if(parseFloat(compare) >= parseFloat(mapOutput.output.sa_basic)){
                       if(parseFloat(compare) >= 10000000000.0){
                            body.push(['Fakultatif untuk manfaat*               ', 'Fakultatif']);
                       }else{
                            body.push(['Fakultatif untuk manfaat*               ', 'Non Fakultatif']);
                       }
                    }else{
                        if(parseFloat(mapOutput.output.sa_basic) >= 10000000000.0){
                            body.push(['Fakultatif untuk manfaat*               ', 'Fakultatif']);
                        }else{
                            body.push(['Fakultatif untuk manfaat*               ', 'Non Fakultatif']);
                        }
                    }
                }else{
                    compare = mapOutput.output.totAccU1ZR;
                    if(parseFloat(compare) >= parseFloat(mapOutput.output.sa_basic)){
                       if(parseFloat(compare) >= 10000000000.0){
                            body.push(['Fakultatif untuk manfaat*               ', 'Fakultatif']);
                       }else{
                            body.push(['Fakultatif untuk manfaat*               ', 'Non Fakultatif']);
                       }
                    }else{
                        if(parseFloat(mapOutput.output.sa_basic) >= 10000000000.0){
                            body.push(['Fakultatif untuk manfaat*               ', 'Fakultatif']);
                        }else{
                            body.push(['Fakultatif untuk manfaat*               ', 'Non Fakultatif']);
                        }
                    }
                }
            }
            */
        }

        

        return body;

    }

    function fundAllocationPage7Section2(mapOutput){
        var body = [];
        var tertanggungNameTT1 = (mapOutput.tertanggungNameTT1 != undefined)?mapOutput.tertanggungNameTT1:' ';
        var labelTT1 = (mapOutput.labelTT1 != undefined) ? mapOutput.labelTT1 : ' ';

        body.push([labelTT1, tertanggungNameTT1]);

        var ageonlyTT1 = (mapOutput.ageonlyTT1 != undefined)?mapOutput.ageonlyTT1:' ';
        var dobTT1 = (mapOutput.dobTT1 != undefined && mapOutput.dobTT1 != "")?'('+mapOutput.dobTT1+')': ' ';
        var labelAnb1 = (mapOutput.labelAnb1 != undefined) ? mapOutput.labelAnb1 : ' ';
        body.push([labelAnb1, ageonlyTT1+dobTT1]);

        var lebelPekerjaan = (mapOutput.lbPekerjaan != undefined)?mapOutput.lbPekerjaan:' ';
        var kodePek = (mapOutput.kodepekerjaanTT1 != undefined)?mapOutput.kodepekerjaanTT1:' ';
        var pekerjaanT1 = (mapOutput.pekerjaanTT1 != undefined)?mapOutput.pekerjaanTT1:' ';
        body.push([lebelPekerjaan, kodePek+' '+pekerjaanT1]);

        var lbInstansiDepartement = (mapOutput.lbInstansiDepartement != undefined)?mapOutput.lbInstansiDepartement:' ';
        var departementTT1 = (mapOutput.departementTT1 != undefined)?mapOutput.departementTT1:' ';
        body.push([lbInstansiDepartement, departementTT1]);

        var lbBidangUsaha = (mapOutput.lbBidangUsaha != undefined) ? mapOutput.lbBidangUsaha:' ';
        var bidangUsahaTT1 = (mapOutput.bidangUsahaTT1 != undefined) ? mapOutput.bidangUsahaTT1:' ';
        body.push([lbBidangUsaha, bidangUsahaTT1]);

        var lbJabatan = (mapOutput.lbJabatan != undefined)?mapOutput.lbJabatan:' ';
        var kdJab = (mapOutput.kodejabatanPemegangPolisTT1 != undefined)?mapOutput.kodejabatanPemegangPolisTT1:' ';
        var jabTT1 = (mapOutput.jabatanPemegangPolisTT1 != undefined)?mapOutput.jabatanPemegangPolisTT1:' ';
        body.push([lbJabatan, kdJab+' '+jabTT1]);

        var totPenghasilan = (mapOutput.totPenghasilan != undefined)?mapOutput.totPenghasilan:' ';
        var nilaiIncomeTT1 = (mapOutput.nilaiIncomeTT1 != undefined)?mapOutput.nilaiIncomeTT1:' ';
        body.push([totPenghasilan, nilaiIncomeTT1]);

        var labelTT2 = (mapOutput.labelTT2 != undefined)?mapOutput.labelTT2:' ';
        var tertanggungNameTT2 = (mapOutput.tertanggungNameTT2 != undefined)?mapOutput.tertanggungNameTT2:' ';
        body.push([labelTT2, tertanggungNameTT2]);

        var labelAnb2 = (mapOutput.labelAnb2 != undefined)?mapOutput.labelAnb2:' ';
        var ageonlyTT2 = (mapOutput.ageonlyTT2 != undefined)?mapOutput.ageonlyTT2:' ';
        var dobTT2 = (mapOutput.dobTT2 != undefined && mapOutput.dobTT2 != "")?' ('+mapOutput.dobTT2+')':' ';
        body.push([labelAnb2, ageonlyTT2+dobTT2]);

        var lbPekerjaan2 = (mapOutput.pekerjaan2 != undefined)?mapOutput.pekerjaan2:' ';
        var kodepekerjaanTT2 = (mapOutput.kodepekerjaanTT2 != undefined)?mapOutput.kodepekerjaanTT2:' ';
        var pekerjaanTT2 = (mapOutput.pekerjaanTT2 != undefined)?mapOutput.pekerjaanTT2:' ';
        body.push([lbPekerjaan2, kodepekerjaanTT2+' '+pekerjaanTT2]);

        var lbInstansiDepartement2 = (mapOutput.instansiDepartement2 != undefined)?mapOutput.instansiDepartement2:' ';
        var departementTT2 = (mapOutput.departementTT2 != undefined)?mapOutput.departementTT2:' ';
        body.push([lbInstansiDepartement2, departementTT2]);

        var lblkodepekerjaan = mapOutput.kodepekerjaan != undefined ? mapOutput.kodepekerjaan : '';
        var lblpekerjaan = mapOutput.bidangUsaha2 != undefined ? mapOutput.bidangUsaha2 : '';
        var lblbidangusahatt2 = mapOutput.bidangUsahaTT2 != undefined ? mapOutput.bidangUsahaTT2 : '';
        body.push([lblpekerjaan, lblbidangusahatt2]);

        var lbJabatan2 = (mapOutput.jabatan2 != undefined)?mapOutput.jabatan2:' ';
        var kodejabatanPemegangPolisTT2 = (mapOutput.kodejabatanPemegangPolisTT2 != undefined)?mapOutput.kodejabatanPemegangPolisTT2:' ';
        var jabatanPemegangPolisTT2 = (mapOutput.jabatanPemegangPolisTT2 != undefined)?mapOutput.jabatanPemegangPolisTT2:' ';
        body.push([lbJabatan2, kodejabatanPemegangPolisTT2+' '+jabatanPemegangPolisTT2]);

        var lbTotPenghasilan2 = (mapOutput.totPenghasilan2 != undefined)?mapOutput.totPenghasilan2:' ';
        var nilaiIncomeTT2 = (mapOutput.nilaiIncomeTT2 != undefined)?mapOutput.nilaiIncomeTT2:' ';
        body.push([lbTotPenghasilan2, nilaiIncomeTT2]);


        return body;

    }    

    function fundAllocationPage7Section3(mapOutput){
        var body = [];
        body.push(['Fakultatif', 'Life1', 'Life2', 'Life3']);

        return body;        
    }    

    var emptyspace = [" "," "," "," "," "];
    var emptycol = emptyspace.join(''); //string of 5 spaces
    
    function fundAllocationPage2(mapOutput){
        //console.log('mapOutput.totalPremiThn == ',mapOutput.totalPremiThn);
        var chargePeriod = 100-parseInt(mapOutput.age);

        var body = [];
        body.push(['Nama Tertanggung Utama (sesuai Kartu ID)',mapOutput.tertanggungName, '', 'Jenis Kelamin',mapOutput.gender, 'ALOKASI DANA INVESTASI']);

        for(var x = 0; x < mapOutput.fundListOutput.length; x++){
            var fundName1 = mapOutput.fundListOutput[x].name.substring(0,3);
            var fundName2 = mapOutput.fundListOutput[x].name.substring(3,7);
            var fundName3 = mapOutput.fundListOutput[x].name.substring(7);
            var allocationPercentage = mapOutput.fundListOutput[x].itemInput[0].inputValue;
            // //console.log('fundListOutput === ',fundName + ' - '+allocationPercentage);

            if(mapOutput.fundListOutput.length == 1){
                if( x == 0){
                    body.push(['Usia Tahun Berikutnya (tanggal lahir)',mapOutput.age+'('+mapOutput.dob+')', emptycol,'Kelas Pekerjaan',mapOutput.kelasPekerjaan, {text:[''+allocationPercentage+'% dari ', { text:fundName1, font: 'frutiger' },{text:fundName2, font: 'garamount'},fundName3]}]);
                    body.push([
                                    'Pekerjaan',
                                    mapOutput.pekerjaan, 
                                    emptycol,emptycol,emptycol,
                                    emptycol
                                ]);

                    if(mapOutput.pekerjaan.toLowerCase().indexOf('pelajar') > -1 && mapOutput.isPickParentFlag){

                            if(mapOutput.tertanggungNameTT1 != undefined && mapOutput.tertanggungNameTT1 != '' ){
                                    body.push([
                                        'Nama Orangtua 1 (sesuai Kartu ID)',
                                        mapOutput.tertanggungNameTT1, 
                                        'Usia Orangtua 1',mapOutput.ageonlyTT1+'('+mapOutput.dobTT1+')',emptycol,
                                        emptycol
                                    ]);    
                            }

                            if(mapOutput.tertanggungNameTT2 != undefined && mapOutput.tertanggungNameTT2 != '' ){
                                    body.push([
                                        'Nama Orangtua 2 (sesuai Kartu ID)',
                                        mapOutput.tertanggungNameTT2, 
                                        'Usia Orangtua 2',mapOutput.ageonlyTT2+'('+mapOutput.dobTT2+')',emptycol,
                                        emptycol
                                    ]);    
                            }                                
                    }

                    if(mapOutput.isPickSpouseFlag){
                            if(mapOutput.tertanggungNameTT1 != undefined && mapOutput.tertanggungNameTT1 != '' ){
                                    body.push([
                                        'Nama Suami/Istri',
                                        mapOutput.tertanggungNameTT1, 
                                        'Usia Suami/Istri',mapOutput.ageonlyTT1+'('+mapOutput.dobTT1+')',emptycol,
                                        emptycol
                                    ]);    
                            }                        
                    }
                }
            }else{
                if(x == 0){
                    body.push(['Usia Tahun Berikutnya (tanggal lahir)',mapOutput.age+'('+mapOutput.dob+')', emptycol,'Kelas Pekerjaan',mapOutput.kelasPekerjaan, {text:[''+allocationPercentage+'% dari ', { text:fundName1, font: 'frutiger' },{text:fundName2, font: 'garamount'},fundName3]}]);
                }else if(x == 1){
                    if(allocationPercentage != '0' || allocationPercentage != 0){
                        body.push([
                                    'Pekerjaan',
                                    mapOutput.pekerjaan, 
                                    emptycol,emptycol,emptycol,
                                    {text:[''+allocationPercentage+'% dari ', { text:fundName1, font: 'frutiger' },{text:fundName2, font: 'garamount'},fundName3]}
                                ]);

                        if(mapOutput.pekerjaan.toLowerCase().indexOf('pelajar') > -1 && mapOutput.isPickParentFlag){

                            if(mapOutput.tertanggungNameTT1 != undefined && mapOutput.tertanggungNameTT1 != '' ){
                                    body.push([
                                        'Nama Orangtua 1 (sesuai Kartu ID)',
                                        mapOutput.tertanggungNameTT1, 
                                        'Usia Orangtua 1',mapOutput.ageonlyTT1+'('+mapOutput.dobTT1+')',emptycol,
                                        emptycol
                                    ]);    
                            }

                            if(mapOutput.tertanggungNameTT2 != undefined && mapOutput.tertanggungNameTT2 != '' ){
                                    body.push([
                                        'Nama Orangtua 2 (sesuai Kartu ID)',
                                        mapOutput.tertanggungNameTT2, 
                                        'Usia Orangtua 2',mapOutput.ageonlyTT2+'('+mapOutput.dobTT2+')',emptycol,
                                        emptycol
                                    ]);    
                            }                              
                        }

                        if(mapOutput.isPickSpouseFlag){
                            if(mapOutput.tertanggungNameTT1 != undefined && mapOutput.tertanggungNameTT1 != '' ){
                                    body.push([
                                        'Nama Suami/Istri',
                                        mapOutput.tertanggungNameTT1, 
                                        'Usia Suami/Istri',mapOutput.ageonlyTT1+'('+mapOutput.dobTT1+')',emptycol,
                                        emptycol
                                    ]);    
                            }                        
                        }              
                    }else{
                        body.push([
                                    'Pekerjaan',
                                    mapOutput.pekerjaan, 
                                    emptycol,emptycol,emptycol,
                                    ''
                                ]);
                    }    
                    
                }else{
                    if(allocationPercentage != '0' || allocationPercentage != 0){
                        body.push([
                                    emptycol,
                                    emptycol, 
                                    emptycol,emptycol,emptycol,
                                    {text:[''+allocationPercentage+'% dari ', { text:fundName1, font: 'frutiger' },{text:fundName2, font: 'garamount'},fundName3]}
                                ]);    
                    }
                    
                }
            }
        }
        
        return body.transpose();

    }

    function ringkasanManfaat1(mapOutput){
        // //console.log("====================== Ringkasan Manfaat (START) =====================");
        var body = [];

        var frequency;
        if(mapOutput.frequency.descriptionInd.toLowerCase() == 'bulanan'){
            frequency = 12;
        }else if(mapOutput.frequency.descriptionInd.toLowerCase() == 'tiga bulanan'){
            frequency = 4;
        }else if(mapOutput.frequency.descriptionInd.toLowerCase() == 'setengah tahunan'){
            frequency = 2;
        }else{
            frequency = 1;
        }

         var planMapping={
            'A':250000,
            'B':425000,
            'C':600000,
            'D':900000,
            'E':1200000,
            'F':1800000,
            'G':2350000,
            'H':3000000,
            '0':0,
          };

        for(var x = 0; x < mapOutput.manfaatList.length; x++){
            //console.log(mapOutput.manfaatList[x]);
            var productName = mapOutput.manfaatList[x].name;
            var productCode = mapOutput.manfaatList[x].code;
            var coverageType = mapOutput.manfaatList[x].coverageType;
            // var value = parseFloat(mapOutput.manfaatList[x].itemInput[0].inputValue);
            // var term;
            // if(mapOutput.manfaatList[x].itemInput[1] != undefined){
            //     term = mapOutput.manfaatList[x].itemInput[1].inputValue;
            //     //console.log('term halaman 2 == ', term);
            // }else{
            //     term = ' ';
            // }

            var itemInput = mapOutput.manfaatList[x].itemInput;
            var value = 0;
            var term = 99;
            var plan = '';
            var unit = 0;
            for(var y = 0; y < itemInput.length; y++){
                if(itemInput[y].key == 'PDSA'){
                    value = parseFloat(itemInput[y].inputValue);
                }else if(itemInput[y].key == 'PDTERM'){
                    term = itemInput[y].inputValue;
                }else if(itemInput[y].key == 'PDPLAN'){
                    plan = itemInput[y].inputValue;
                }else if(itemInput[y].key == 'PDUNIT'){
                    unit = parseInt(itemInput[y].inputValue);
                }
            }

            //console.log(productCode+' - '+ value + ' - '+term + ' - '+plan);
            //console.log(planMapping[plan]);


            var saverValue = 0;
            var totalValue = 0;

            // //console.log(productCode + ' - ' +productName + ' - '+coverageType + ' - '+value +' - '+term );

            if(productCode == 'U1ZR' || productCode == 'U1ZD'){

                var percentage20;
                var percentage80

                if(mapOutput.currency == 'IDR'){
                    if(value > 2000000000){
                        percentage20 = 0.2 * 2000000000; 
                        percentage80 = 0.8 * 2000000000;
                    }else{
                        percentage20 = 0.2 * value;
                        percentage80 = 0.8 * value;    
                    }    
                }else{
                    //currency == USD
                    if(value > 250000){
                        percentage20 = 0.2 * 250000; 
                        percentage80 = 0.8 * 250000;
                    }else{
                        percentage20 = 0.2 * value;
                        percentage80 = 0.8 * value;    
                    }
                }
                
                
                body.push([{margin:[0,0,0,5],columns: [
                            {width:10, text:'-'},
                            {width:'*', text: [ {text:'PRU', font:'frutiger'}, {text:'link assurance account', font: 'garamount' }, ': Apabila Tertanggung Utama meninggal dunia atau Cacat Total & Tetap selama masa Asuransi, akan diberikan Manfaat Asuransi dan Nilai Tunai (lihat Bagian B), apabila ada(Apabila Tertanggung Utama masih hidup sampai berakhirnya masa asuransi, Penanggung akan membayarkan Nilai Tunai,apabila ada) ']},
                            {width:30, alignment:'center', text:mapOutput.currency},
                            {width:80, alignment:'right', text:''+value.format(formatCurr)+''},
                           ]},
                ]);

                body.push([{
                    margin:[0,0,0,5],columns: [
                        {width:10, text:'-', alignment: 'center'},
                        {
                            table: {
                                widths: [ 120, '*'],
                                body: [
                                    [
                                        {rowSpan: 2, text:['Cacat Total & Tetap (Total & Permanent Disability ', {text:'PRU', font:'frutiger'}, {text:'link assurance account', font: 'garamount' }, '(PAA)']}, 
                                        {columns: [
                                                {width:'*', text:'Pembayaran Pertama, sebesar: 20% dari Uang Pertanggungan, (poin di atas), sebesar:'},
                                                {width:30, alignment:'center', text:mapOutput.currency},
                                                {width:75, alignment:'right', text:''+percentage20.format(formatCurr)+''},
                                            ]
                                        }
                                        
                                    ],
                                    ['', 
                                        {columns:[
                                                {text:'Pembayaran Kedua (satu tahun sesudah Pembayaran Pertama), sebesar: 80% dari Uang Pertanggungan (poin di atas), sebesar:'},
                                                {width:30, alignment:'center', text:mapOutput.currency},
                                                {width:75, alignment:'right', text:''+percentage80.format(formatCurr)+''},
                                            ]
                                        }
                                    ],
                                ]
                            }
                        }
                    ]
                },]);    
            }else if(productCode == 'U1CR' || productCode == 'U1CD'){
                saverValue = value;
            }else if(productCode == 'T1JR' || productCode == 'T1JD'){
                body.push([{margin:[0,0,0,5],columns: [
                            {width:10, text:'-'},
                            {width:'*', text: [ {text:'PRU', font:'frutiger'}, {text:'link term', font: 'garamount' },' Apabila Tertanggung Utama meninggal dunia sampai dengan Tertanggung Utama berusia '+''+term+''+' tahun, diberikan  tambahan Uang Pertanggungan ', {text:'PRU', font:'frutiger'}, {text:'link term', font: 'garamount' },' sebesar:']},
                            {width:30, alignment:'center', text:mapOutput.currency},
                            {width:80, alignment:'right', text:''+value.format(formatCurr)+''},]}]);   
            }else if(productCode == 'C1KR' || productCode == 'C1KD'){
                body.push([{margin:[0,0,0,5],columns: [
                            {width:10, text:'-'},
                            {width:'*', text: [ {text:'PRU', font:'frutiger'}, {text:'crisis cover 34', font: 'garamount' }, ': Apabila Tertanggung Utama memenuhi kriteria salah satu dari 34 Kondisi Kritis sampai dengan Tertanggung Utama berusia '+''+term+''+' tahun, diberikan Uang Pertanggungan ', {text:'PRU', font:'frutiger'}, {text:'crisis cover 34', font: 'garamount' },' (yang akan mengurangi UP PAA),']},
                            {width:30, alignment:'center', text:mapOutput.currency},
                            {width:80, alignment:'right', text:''+value.format(formatCurr)+''},]}]);
            }else if(productCode == 'C1WR' ||productCode == 'C1WD'){
                body.push([{margin:[0,0,0,5],columns: [
                            {width:10, text:'-'},
                            {width:'*', text: [ {text:'PRU', font:'frutiger'}, {text:'crisis cover benefit plus 61', font: 'garamount' },': Apabila Tertanggung Utama memenuhi kriteria salah satu dari 61 Kondisi Kritis atau meninggal dunia sampai dengan Tertanggung Utama berusia '+''+term+''+' tahun, diberikan tambahan Uang Pertanggungan ',{text:'PRU', font:'frutiger'}, {text:'crisis cover benefit plus 61', font: 'garamount' }, ' (yang tidak akan mengurangi UP PAA), sebesar:']},
                            {width:30, alignment:'center', text:mapOutput.currency},
                            {width:80, alignment:'right', text:''+value.format(formatCurr)+''},]}]);
            }else if(productCode == 'C1TR' || productCode == 'C1TD'){
                body.push([{margin:[0,0,0,5],columns: [
                            {width:10, text:'-'},
                            {width:'*', text: [ {text:'PRU', font:'frutiger'}, {text:'multiple crisis cover', font: 'garamount' },': Apabila Tertanggung Utama memenuhi kriteria salah satu dari 34 Kondisi Kritis sampai dengan Tertanggung Utama berusia '+''+term+''+' tahun sebanyak maksimum 3 Kondisi Kritis dalam kelompok yang berbeda, diberikan Uang Pertanggungan ',{text:'PRU', font:'frutiger'}, {text:'multiple crisis cover', font: 'garamount' }, ' (yang tidak akan mengurangi UP PAA), sebesar:']},
                            {width:30, alignment:'center', text:mapOutput.currency},
                            {width:80, alignment:'right', text:''+value.format(formatCurr)+''},]}]);
            }else if(productCode == 'I1DR'){
                body.push([{margin:[0,0,0,5],columns: [
                            {width:10, text:'-'},
                            {width:'*', text: [ {text:'PRU', font:'frutiger'}, {text:'crisis income', font: 'garamount' },': Apabila Tertanggung Utama memenuhi kriteria salah satu dari 33 Kondisi Kritis sampai dengan Tertanggung Utama berusia '+''+term+''+' tahun,  diberikan pembayaran manfaat pendapatan s.d. usia '+''+term+''+' tahun, sebesar:']},
                            {width:30, alignment:'center', text:mapOutput.currency},
                            {width:80, alignment:'right', text:''+value.format(formatCurr)+''},]}]);
            }else if(productCode == 'P1CR' || productCode == 'P1CD'){
                body.push([{margin:[0,0,0,5],columns: [
                            {width:10, text:'-'},
                            {width:'*', text: [ {text:'PRU', font:'frutiger'}, {text:'personal accident death', font: 'garamount' },': Apabila Tertanggung Utama meninggal dunia karena kecelakaan sampai dengan Tertanggung Utama berusia '+''+term+''+' tahun, diberikan tambahan Uang Pertanggungan sebesar:']},
                            {width:30, alignment:'center', text:mapOutput.currency},
                            {width:80, alignment:'right', text:''+value.format(formatCurr)+''},]}]);
            }else if(productCode == 'P1DR' || productCode == 'P1DD'){
                body.push([{margin:[0,0,0,5],columns: [
                            {width:10, text:'-'},
                            {width:'*', text: [ {text:'PRU', font:'frutiger'}, {text:'personal accident death &  disablement', font: 'garamount' },': Apabila Tertanggung Utama meninggal dunia atau Cacat tetap karena kecelakaan sampai dengan Tertanggung Utama berusia '+''+term+''+' tahun, diberikan tambahan Uang Pertanggungan sebesar:']},
                            {width:30, alignment:'center', text:mapOutput.currency},
                            {width:80, alignment:'right', text:''+value.format(formatCurr)+''},]}]);
            }else if(productCode == 'H1TR'){
                body.push([{columns: [
                            {width:10, text:'-'},
                            {width:'*', text: [ {text:'PRU', font:'frutiger'}, {text:'hospital & surgical cover plus', font: 'garamount' },' (maksimum s.d. usia '+''+term+''+' tahun), ']},
                            {width:30, alignment:'center', text:plan},
                            {width:80, alignment:'right', text: emptycol},]},
                            {margin:[0,0,0,5],columns: [
                            {width:10, text:emptycol},
                            {width:'*', text: 'Batas maksimum rawat inap per hari, sebesar:'},
                            {width:30, alignment:'center', text:mapOutput.currency},
                            {width:80, alignment:'right', text:''+planMapping[plan].format(formatCurr)+''},]}
                        ]);
            }else if(productCode == 'P1QR' || productCode == 'P1QD'){
                body.push([{margin:[0,0,0,5],columns: [
                            {width:10, text:'-'},
                            {width:'*', text: [ {text:'PRU', font:'frutiger'}, {text:'personal accident death plus', font: 'garamount' },': Apabila Tertanggung Utama meninggal dunia atau mengalami patah tulang atau luka bakar atau menjalani rawat jalan darurat karena kecelakaan pada saat usia Tertanggung Utama tidak melebihi '+''+term+''+' tahun, diberikan Uang Pertanggungan ',{text:'PRU', font:'frutiger'}, {text:'personal accident death plus', font: 'garamount' }, ', maksimum sebesar:']},
                            {width:30, alignment:'center', text:mapOutput.currency},
                            {width:80, alignment:'right', text:''+value.format(formatCurr)+''},]}]);
            }else if(productCode == 'P1RR' || productCode == 'P1RD'){
                body.push([{margin:[0,0,0,5],columns: [
                            {width:10, text:'-'},
                            {width:'*', text: [ {text:'PRU', font:'frutiger'}, {text:'personal accident death & disablement plus', font: 'garamount' },': Apabila Tertanggung Utama meninggal dunia atau mengalami cacat tetap atau patah tulang atau luka bakar atau menjalani rawat jalan darurat karena kecelakaan pada saat usia Tertanggung Utama tidak melebihi '+''+term+''+' tahun, diberikan Uang Pertanggungan ',{text:'PRU', font:'frutiger'}, {text:'personal accident death & disablement plus', font: 'garamount' }, ' maksimum sebesar:']},
                            {width:30, alignment:'center', text:mapOutput.currency},
                            {width:80, alignment:'right', text:''+value.format(formatCurr)+''},]}]);
            }else if(productCode == 'H1VR'){
                body.push([{
                    margin:[0,0,0,5],columns: [
                        {width:10, text:'-', alignment: 'center'},
                        {
                            table: {
                                widths: ['*', 30, 77],
                                body: [
                                    [{text: [ {text:'PRU', font:'frutiger'}, {text:'med cover', font: 'garamount' },' (maksimum s.d. usia '+''+term+''+' tahun)']}, '', ''],
                                    [
                                        {text:'a.  Rawat Inap Rumah Sakit per Hari, sebesar:'}, 
                                        {alignment:'center', text:mapOutput.currency},
                                        {alignment:'right', text:''+(unit*40000).format(formatCurr)+''},
                                    ],
                                    [
                                        {text:'b.  Unit Perawatan Intensif (ICU) per Hari, sebesar: '}, 
                                        {alignment:'center', text:mapOutput.currency},
                                        {alignment:'right', text:''+(unit*80000).format(formatCurr)+''},
                                    ],
                                    [
                                        {text:'c.  Pembedahan #'}, '', ''
                                    ],
                                    [
                                        {text:'Tipe 4 (Complex)', margin: [30,0,0,0]}, 
                                        {alignment:'center', text:mapOutput.currency},
                                        {alignment:'right', text:''+(unit*400000).format(formatCurr)+''},
                                    ],
                                    [
                                        {text:'Tipe 3 (Major)', margin: [30,0,0,0]}, 
                                        {alignment:'center', text:mapOutput.currency},
                                        {alignment:'right', text:''+(unit*300000).format(formatCurr)+''},
                                    ],
                                    [
                                        {text:'Tipe 2 (Intermediate)', margin: [30,0,0,0]}, 
                                        {alignment:'center', text:mapOutput.currency},
                                        {alignment:'right', text:''+(unit*200000).format(formatCurr)+''},
                                    ],
                                    [
                                        {text:'Tipe 1 (Minor)', margin: [30,0,0,0]}, 
                                        {alignment:'center', text:mapOutput.currency},
                                        {alignment:'right', text:''+(unit*100000).format(formatCurr)+''},
                                    ],
                                ]
                            },layout: whiteNoSpace()
                        }
                    ]
                },]);  
            }/*else if(productCode == 'H1VR'){
                body.push([{width:'*', text: 'PRUmed cover (maksimum s.d. usia '+''+term+''+' tahun)'}]);
                body.push([{
                                ol:[
                                    {text:'Rawat Inap Rumah Sakit per Hari, sebesar:                         '+mapOutput.currency+'    '+(unit*40000)},
                                    {text:'Unit Perawatan Intensif (ICU) per Hari, sebesar:                 '+mapOutput.currency+'    '+(unit*80000)},
                                    {
                                        stack: [
                                            'Pembedahan #',
                                            {
                                                ul: [
                                                    'Tipe 4 (Complex)                                                                   '+mapOutput.currency+'    '+(unit*400000),
                                                    'Tipe 3 (Major)                                                                         '+mapOutput.currency+'    '+(unit*300000),
                                                    'Tipe 2 (Intermediate)                                                             '+mapOutput.currency+'    '+(unit*200000),
                                                    'Tipe 1 (Minor)                                                                         ' +mapOutput.currency+'    '+(unit*100000),
                                                ]
                                            }
                                        ]
                                    }
                                ],
                            },
                            {width:30, alignment:'center', text:mapOutput.currency},
                            {width:80, alignment:'right', text:''},]);  
                
            }*/else if(productCode == 'W1MR' ||productCode == 'W1MD'){
                value = parseFloat(mapOutput.premi.replace(/,/g , ""))*frequency;
                body.push([{margin:[0,0,0,5],columns: [
                            {width:10, text:'-'},
                            {width:'*', text: [ {text:'PRU', font:'frutiger'}, {text:'waiver 33', font: 'garamount' },' s.d. usia Tertanggung Utama 55/65/70/75/80/85 tahun \nApabila Tertanggung Utama memenuhi kriteria salah satu dari 33 Kondisi Kritis (setelah ',{text:'PRU', font:'frutiger'}, {text:'waiver 33', font: 'garamount' },' berlangsung 90 hari atau lebih), sebelum Tertanggung Utama berusia '+''+term+''+' tahun, Penanggung membayarkan Premi Berkala s.d. usia '+''+term+''+' tahun, sebesar:']},
                            {width:30, alignment:'center', text:'Premium'},
                            {width:80, alignment:'right', text:''+value.format(formatCurr)+''},]}]);
            }else if(productCode == 'W1QR' ||productCode == 'W1QD'){
                value = parseFloat(mapOutput.totalPremi.replace(/,/g , ""))*frequency;
                body.push([{margin:[0,0,0,5],columns: [
                            {width:10, text:'-'},
                            {width:'*', text: [ {text:'PRU', font:'frutiger'}, {text:'payor 33', font: 'garamount' },' s.d. usia Tertanggung Utama 55/65/70/75/80/85 tahun \nApabila Tertanggung Utama memenuhi kriteria salah satu dari 33 Kondisi Kritis (setelah ',{text:'PRU', font:'frutiger'}, {text:'payor 33', font: 'garamount' },' berlangsung 90 hari atau lebih), sampai dengan Tertanggung Utama berusia '+''+term+''+' tahun, Penanggung membayarkan Premi Berkala dan Premi ',{text:'PRU', font:'frutiger'}, {text:'saver', font: 'garamount' },' s.d. usia '+''+term+''+' tahun, sebesar:']},
                            {width:30, alignment:'center', text:mapOutput.currency},
                            {width:80, alignment:'right', text:''+mapOutput.totalPremiThn.format(formatCurr)+''},]}]);
            }else if(productCode == 'S1KR' ||productCode == 'S1KD'){
                value = parseFloat(mapOutput.premi.replace(/,/g , ""))*frequency;
                body.push([{margin:[0,0,0,5],columns: [
                            {width:10, text:'-'},
                            {width:'*', text: [ {text:'PRU', font:'frutiger'}, {text:'spouse payor 33', font: 'garamount' },' s.d. usia Tertanggung Utama 55/65/70/75/80/85 tahun \nApabila Suami/Istri Tertanggung Utama memenuhi kriteria salah satu dari 33 Kondisi Kritis (setelah ',{text:'PRU', font:'frutiger'}, {text:'spouse payor 33', font: 'garamount' },' berlangsung 90 hari atau lebih)/Cacat Total & Tetap sebelum usia Suami/Istri dari Tertanggung Utama 70 tahun/meninggal dunia, sampai dengan Tertanggung Utama berusia '+''+term+''+' tahun, Penanggung membayarkan Premi Berkala & Premi ',{text:'Top-up', font: 'garamount' },' Berkala (',{text:'PRU', font:'frutiger'}, {text:'saver', font: 'garamount' },') s.d. usia Tertanggung Utama '+''+term+''+' tahun, sebesar:']},
                            {width:30, alignment:'center', text:mapOutput.currency},
                            {width:80, alignment:'right', text:''+mapOutput.totalPremiThn.format(formatCurr)+''},]}]);
            }else if(productCode == 'C106' ||productCode == 'C107'){
                body.push([{margin:[0,0,0,5],columns: [
                            {width:10, text:'-'},
                            {width:'*', text: [ {text:'PRU', font:'frutiger'}, {text:'early stage crisis cover plus', font: 'garamount' },': Apabila Tertanggung Utama memenuhi kriteria salah satu dari Kondisi Kritis untuk setiap jenis stadium dan kriteria Kondisi Kritis pada manfaat tambahan, sampai dengan Tertanggung Utama berusia '+''+term+''+' tahun, diberikan manfaat pertanggungan ',{text:'PRU', font:'frutiger'}, {text:'early stage crisis cover plus', font: 'garamount' },' (yang tidak akan mengurangi UP PAA) sebesar:']},
                            {width:30, alignment:'center', text:mapOutput.currency},
                            {width:80, alignment:'right', text:''+value.format(formatCurr)+''},]}]);
            }else if(productCode == 'S1FR' ||productCode == 'S1FD'){
                value = parseFloat(mapOutput.premi.replace(/,/g , ""))*frequency;
                body.push([{margin:[0,0,0,5],columns: [
                            {width:10, text:'-'},
                            {width:'*', text: [ {text:'PRU', font:'frutiger'}, {text:'spouse waiver 33', font: 'garamount' },' s.d. usia Tertanggung Utama 55/65/70/75/80/85 tahun \nApabila Suami/Istri Tertanggung Utama memenuhi kriteria salah satu dari 33 Kondisi Kritis (setelah ',{text:'PRU', font:'frutiger'}, {text:'spouse waiver 33', font: 'garamount' },' berlangsung 90 hari atau lebih)/Cacat Total & Tetap sebelum usia Suami/Istri dari Tertanggung Utama 70 tahun/meninggal dunia, sebelum Tertanggung Utama berusia '+''+term+''+' tahun, Penanggung membayarkan Premi Berkala s.d. usia Tertanggung Utama '+''+term+''+' tahun, sebesar:']},
                            {width:30, alignment:'center', text:mapOutput.currency},
                            {width:80, alignment:'right', text:''+value.format(formatCurr)+''},]}]);
            }else if(productCode == 'W1XR' ||productCode == 'W1XD'){
                totalValue = value + saverValue;
                body.push([{margin:[0,0,0,5],columns: [
                            {width:10, text:'-'},
                            {width:'*', text: [ {text:'PRU', font:'frutiger'}, {text:'parent payor 33', font: 'garamount' },' s.d. usia Tertanggung Utama '+''+term+''+' tahun \nApabila Ayah dan/atau Ibu Tertanggung Utama memenuhi kriteria salah satu dari 33 Kondisi Kritis (setelah ',{text:'PRU', font:'frutiger'}, {text:'parent payor 33', font: 'garamount' },' berlangsung 90 hari atau lebih)/Cacat Total & Tetap sebelum usia Ayah dan/atau Ibu dari Tertanggung Utama 70 tahun/meninggal dunia, Penanggung membayarkan Premi Berkala dan Premi ',{text:'Top-up', font: 'garamount' },' Berkala (',{text:'PRU', font:'frutiger'}, {text:'saver', font: 'garamount' },') s.d. Tertanggung Utama berusia <Up to term> tahun (sesuai dengan manfaat yang dipilih), sebesar:']},
                            {width:30, alignment:'center', text:mapOutput.currency},
                            {width:80, alignment:'right', text:''+mapOutput.totalPremiThn.format(formatCurr)+''},]}]);
            }else if(productCode == 'C103' ||productCode == 'C104'){
                body.push([{margin:[0,0,0,5],columns: [
                            {width:10, text:'-'},
                            {width:'*', text: [ {text:'PRU', font:'frutiger'}, {text:'juvenile crisis cover', font: 'garamount' },': Apabila Tertanggung Utama memenuhi kriteria salah satu dari 32 Kondisi Kritis sampai dengan Tertanggung berusia 18 tahun, diberikan tambahan Uang Pertanggungan (yang tidak akan mengurangi UP PAA), sebesar:']},
                            {width:30, alignment:'center', text:mapOutput.currency},
                            {width:80, alignment:'right', text:''+value.format(formatCurr)+''},]}]);
            }else if(productCode == 'W3BR' ||productCode == 'W3BD'){
                value = parseFloat(mapOutput.totalPremi.replace(/,/g , ""))*frequency;
                body.push([{margin:[0,0,0,5],columns: [
                            {width:10, text:'-'},
                            {width:'*', text: [ {text:'PRU', font:'frutiger'}, {text:'early stage payor', font: 'garamount' },' s.d. usia Tertanggung Utama 55/60/65/70/75/80/85 tahun \nApabila Tertanggung Utama memenuhi kriteria salah satu dari Kondisi Kritis baik stadium awal (38 jenis kondisi), stadium menengah (26 jenis kondisi) ataupun stadium akhir (48 jenis kondisi), setelah ',{text:'PRU', font:'frutiger'}, {text:'early stage payor', font: 'garamount' },' berlaku selama 90 hari atau lebih, Penanggung akan membayarkan Premi Berkala & Premi ',{text:'Top-up', font: 'garamount' },' Berkala (',{text:'PRU', font:'frutiger'}, {text:'saver', font: 'garamount' },') jika ada selama periode tertentu maksimal s.d usia Tertanggung Utama '+''+term+''+' tahun.']},
                            {width:30, alignment:'center', text:mapOutput.currency},
                            {width:80, alignment:'right', text:''+mapOutput.totalPremiThn.format(formatCurr)+''},]}]);
            }else if(productCode == 'S1YR' ||productCode == 'S1YD'){
                value = parseFloat(mapOutput.totalPremi.replace(/,/g , ""))*frequency;
                body.push([{margin:[0,0,0,5],columns: [
                            {width:10, text:'-'},
                            {width:'*', text: [ {text:'PRU', font:'frutiger'}, {text:'early stage spouse payor', font: 'garamount' },' s.d. usia Tertanggung Utama 55/60/65/70/75/80/85 tahun \nApabila Suami/Istri dari Tertanggung Utama memenuhi kriteria salah satu dari Kondisi Kritis baik stadium awal (38 jenis kondisi), stadium menengah (26 jenis kondisi) ataupun stadium akhir (48 jenis kondisi) setelah ',{text:'PRU', font:'frutiger'}, {text:'early stage spouse payor', font: 'garamount' },' berlaku selama 90 hari atau lebih)/Cacat Total dan Tetap sebelum usia Suami/Istri dari Tertanggung Utama 70 tahun/meninggal dunia, Penanggung akan membayarkan Premi Berkala & Premi ',{text:'Top-up', font: 'garamount' },' Berkala (',{text:'PRU', font:'frutiger'}, {text:'saver', font: 'garamount' },') jika ada selama periode tertentu maksimal s.d usia Tertanggung Utama '+''+term+''+' tahun.']},
                            {width:30, alignment:'center', text:mapOutput.currency},
                            {width:80, alignment:'right', text:''+mapOutput.totalPremiThn.format(formatCurr)+''},]}]);
            }else if(productCode == 'W3AR' ||productCode == 'W3AD'){
                totalValue = value + saverValue;
                body.push([{margin:[0,0,0,5],columns: [
                            {width:10, text:'-'},
                            {width:'*', text: [ {text:'PRU', font:'frutiger'}, {text:'early stage parent payor', font: 'garamount' },' s.d. usia Tertanggung Utama 18/25 tahun: \nApabila Ayah dan/atau Ibu dari Tertanggung Utama memenuhi kriteria salah satu dari Kondisi Kritis baik stadium awal (38 jenis kondisi), stadium menengah (26 jenis kondisi) ataupun stadium akhir (48 jenis kondisi) setelah ',{text:'PRU', font:'frutiger'}, {text:'early stage parent payor', font: 'garamount' },' berlaku selama 90 hari atau lebih/Cacat Total dan Tetap sebelum usia Ayah dan/atau Ibu dari Tertanggung Utama 70 tahun/meninggal dunia, Penanggung akan membayarkan sebesar Premi Berkala & Premi ',{text:'Top-up', font: 'garamount' },' Berkala (',{text:'PRU', font:'frutiger'}, {text:'saver', font: 'garamount' },') selama periode tertentu maksimal s.d. usia Tertanggung Utama '+''+term+''+' tahun']},
                            {width:30, alignment:'center', text:mapOutput.currency},
                            {width:80, alignment:'right', text:''+mapOutput.totalPremiThn.format(formatCurr)+''},]}]);
            }else if(productCode == 'C1WR' ||productCode == 'C1WD'){
                body.push([{margin:[0,0,0,5],columns: [
                            {width:10, text:'-'},
                            {width:'*', text: [ {text:'PRU', font:'frutiger'}, {text:'crisis cover benefit plus 61', font: 'garamount' },': Apabila Tertanggung Utama memenuhi kriteria salah satu dari 61 Kondisi Kritis atau meninggal dunia\nsampai dengan Tertanggung Utama berusia '+''+term+''+' tahun, diberikan tambahan Uang Pertanggungan ',{text:'PRU', font:'frutiger'}, {text:'crisis cover benefit plus 61', font: 'garamount' },' (yang tidak akan mengurangi UP PAA), sebesar:']},
                            {width:30, alignment:'center', text:mapOutput.currency},
                            {width:80, alignment:'right', text:''+value.format(formatCurr)+''},]}]);
            }
            
        }


        // //console.log(body);
        // //console.log("====================== Ringkasan Manfaat (END) =====================");
        return body;
    }    

    
    function ringkasanManfaatMeninggal(mapOutput){
        // //console.log("====================== Ringkasan Manfaat Meninggal (START) =====================");
        var ccbSA = 0;
        var pruLinkTermSA = 0;
        var padSA = 0;
        var padPlusSA = 0;
        var paddSA = 0;
        var paddPlusSA = 0;
        var paaSA = 0;
        var prulinkTermSA = 0;
        
        var currency = mapOutput.currency;

        //Term
        var pruLinkTerm = 0;
        var ccbTerm = 0;
        var paaTerm = 99;
        var prulinkTerm = 0;
        var padTerm = 0;
        var padPlusTerm = 0;
        var paddTerm = 0;
        var paddPlusTerm = 0;
        
        //SA
        var totalSA = 0;
        var totalSA2 = 0;
        var totalSA3 = 0;
        var totalSA4 = 0;
        var totalSA5 = 0;
        var totalSA6 = 0;
        var totalSA7 = 0;
        var totalSA8 = 0;
        var totalSA9 = 0;
        var totalSA10 = 0;
        var totalSA11 = 0;
        var totalSA12 = 0;
        var totalSA13 = 0;
        var totalSA14 = 0;
        var totalSA15 = 0;
        var totalSA16 = 0;
        var totalSA17 = 0;
        var totalSA18 = 0;

        var body = [];
        var totalRider = 0;

        //console.log('data manfaat == ',mapOutput.manfaatList);
        for(var x = 0; x < mapOutput.manfaatList.length; x++){
            var productName = mapOutput.manfaatList[x].name;
            var productCode = mapOutput.manfaatList[x].code;
            var coverageType = mapOutput.manfaatList[x].coverageType;

            var itemInput = mapOutput.manfaatList[x].itemInput;
            var value;
            var term;
            for(var z = 0; z < itemInput.length; z++){
                if(itemInput[z].key == 'PDSA'){
                    value = itemInput[z].inputValue;
                }else if(itemInput[z].key == 'PDTERM'){
                    term = itemInput[z].inputValue;
                }
            }

            // var value = mapOutput.manfaatList[x].itemInput[0].inputValue;
            // var term = mapOutput.manfaatList[x].term;

            // //console.log(productCode + ' - ' +productName + ' - '+coverageType + ' - '+value +' - '+term );

            if(coverageType == 'main'){
                paaSA = parseFloat(value);
                // totalSA = totalSA + paaSA;
            }else if(coverageType == 'rider'){

                totalRider = totalRider+1;

                if(productCode == 'C1WR' ||productCode == 'C1WD'){
                    //CCB
                    ccbTerm = term;
                    ccbSA = parseFloat(value);
                }else if(productCode == 'T1JR' || productCode == 'T1JD'){
                    //PRUlink Term
                    prulinkTerm = term;
                    prulinkTermSA = parseFloat(value);
                    
                }else if(productCode == 'C1WR' ||productCode == 'C1WD'){
                    //PRUcrisis cover benefit plus 61
                    ccbTerm = term;
                    ccbSA = parseFloat(value);
                }else if(productCode == 'P1CR' || productCode == 'P1CD'){
                    //PRUpersonal accident death
                    padTerm = term;
                    padSA = parseFloat(value);
                }else if(productCode == 'P1QR' || productCode == 'P1QD'){
                    //PRUpersonal accident death plus
                    padPlusTerm = term;
                    padPlusSA = parseFloat(value);
                }else if(productCode == 'P1DR' || productCode == 'P1DD'){
                    //PRUpersonal accident death &  disablement
                    paddTerm = term;
                    paddSA = parseFloat(value);
                }else if(productCode == 'P1RR' || productCode == 'P1RD'){
                    //PRUpersonal accident death & disablement plus
                    paddPlusTerm = term;
                    paddPlusSA = parseFloat(value);
                }
            }    
        }

        totalSA2 = paaSA + ccbSA;
        totalSA3 = paaSA + prulinkTermSA;
        totalSA4 = paaSA + prulinkTermSA + ccbSA;
        totalSA5 = paaSA + padSA + padPlusSA + paddSA + paddPlusSA;
        totalSA6 = paaSA + ccbSA + padSA + padPlusSA + paddSA + paddPlusSA;
        totalSA7 = paaSA + prulinkTermSA + padSA + padPlusSA + paddSA + paddPlusSA;
        totalSA8 = paaSA + ccbSA + prulinkTermSA + padSA + paddSA + padPlusSA + paddPlusSA;
        totalSA9 = paaSA + ccbSA + prulinkTermSA;

        // //console.log('paaSA = ',paaSA.format(formatCurr));
        // //console.log('totalSA2 = ',totalSA2);
        // //console.log('totalSA3 = ',totalSA3);
        // //console.log('totalSA4 = ',totalSA4);
        // //console.log('totalSA5 = ',totalSA5);
        // //console.log('totalSA6 = ',totalSA6);
        // //console.log('totalSA7 = ',totalSA7);
        // //console.log('totalSA8 = ',totalSA8);
        //console.log('ccbTerm == ',ccbTerm);
        //console.log('paaTerm == ',paaTerm);
        //console.log('prulinkTerm == ',prulinkTerm);
        //console.log('padTerm == ',padTerm);
        //console.log('padPlusTerm == ',padPlusTerm);                
        //console.log('paddTerm == ',paddTerm);
        //console.log('padPlusTerm == ',padPlusTerm);

        var padMaxTerm = Math.max(padTerm, padPlusTerm, paddTerm, padPlusTerm);
        //console.log('padMaxTerm == ',padMaxTerm);
        
        if(totalRider == 0){
            //1
            body.push([ {margin: [0,0,0,4], columns:[
                {text:'Jika Tertanggung Utama meninggal sebelum berusia 99, Manfaat yang diterima adalah sejumlah:', width:200}, 
                {text:mapOutput.currency, width: 60, alignment:'center'}, 
                {text:''+paaSA.format(formatCurr)+'', alignment:'right', width:'*'} 
            ]} ]);
        }else{
            //console.log('rider ada == ',totalRider);
            if(ccbTerm != 0 && prulinkTerm == 0 && padTerm == 0 && padPlusTerm == 0 && paddTerm == 0 && paddPlusTerm == 0 && (ccbTerm < paaTerm)){
                //2
                //console.log('masuk logic 2');
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal sebelum berusia '+ccbTerm+', Manfaat yang diterima adalah sejumlah:', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA2.format(formatCurr)+'', alignment:'right', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal setelah melampaui usia '+ ccbTerm+', dan sebelum berusia 99, Manfaat yang diterima adalah sejumlah:', width:200},
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                     {text:''+paaSA.format(formatCurr)+'', width:'*'}
                ]} ]);
            }else if(prulinkTerm != 0 && ccbTerm == 0 && padTerm == 0 && padPlusTerm == 0 && paddTerm == 0 && paddPlusTerm == 0  && (prulinkTerm < paaTerm)){
                //3
                //console.log('masuk logic 3');
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal sebelum berusia '+prulinkTerm+', Manfaat yang diterima adalah sejumlah:', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA3.format(formatCurr)+'', alignment:'right', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal setelah melampaui usia '+prulinkTerm+', dan sebelum berusia 99, Manfaat yang diterima adalah sejumlah:', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+paaSA.format(formatCurr)+'', alignment:'right', width:'*'}
                ]} ]);
            }else if(ccbTerm != 0 && prulinkTerm != 0 && padTerm == 0 && padPlusTerm == 0 && paddTerm == 0 && paddPlusTerm == 0 && (ccbTerm == prulinkTerm) && (ccbTerm < paaTerm)){
                //4
                //console.log('masuk logic 4');
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal sebelum berusia '+prulinkTerm+', Manfaat yang diterima adalah sejumlah:', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA4.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text: 'Jika Tertanggung Utama meninggal setelah melampaui usia '+prulinkTerm+', dan sebelum berusia 99, Manfaat yang diterima adalah sejumlah:', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+paaSA.format(formatCurr)+'', width:'*'}
                ]} ]);
            }else if(ccbTerm != 0 && prulinkTerm != 0 && padTerm == 0 && padPlusTerm == 0 && paddTerm == 0 && paddPlusTerm == 0 && (ccbTerm < prulinkTerm < paaTerm)){
                //5
                //console.log('masuk logic 5');
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal sebelum berusia '+ccbTerm+', Manfaat yang diterima adalah sejumlah:', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA4.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal setelah melampaui usia '+ccbTerm+', dan sebelum berusia '+prulinkTerm+', Manfaat yang diterima adalah sejumlah:', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA3.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal setelah melampaui usia '+prulinkTerm+', dan sebelum berusia 99, Manfaat yang diterima adalah sejumlah:', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+paaSA.format(formatCurr)+'', width:'*'}
                ]} ]);
            }else if(ccbTerm != 0 && prulinkTerm != 0 && padTerm == 0 && padPlusTerm == 0 && paddTerm == 0 && paddPlusTerm == 0 && (prulinkTerm < ccbTerm < paaTerm)){
                //6
                //console.log('masuk logic 6');
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal sebelum berusia '+prulinkTerm+', Manfaat yang diterima adalah sejumlah:', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA4.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal setelah melampaui usia '+prulinkTerm+', dan sebelum berusia '+ccbTerm+', Manfaat yang diterima adalah sejumlah:', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA2.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal setelah melampaui usia '+ccbTerm+', dan sebelum berusia 99, Manfaat yang diterima adalah sejumlah:', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+paaSA.format(formatCurr)+'', width:'*'}
                ]} ]);
            }else if((padTerm != 0 && ccbTerm == 0 && prulinkTerm == 0 && padTerm < paaTerm) || (padPlusTerm != 0 && ccbTerm == 0 && prulinkTerm == 0 && padPlusTerm < paaTerm) || (paddTerm != 0 && ccbTerm == 0 && prulinkTerm == 0 && paddTerm < paaTerm) || (paddPlusTerm != 0 && ccbTerm == 0 && prulinkTerm == 0 && paddPlusTerm < paaTerm)){
                //7
                //console.log('masuk logic 7');
                //body.push([ 'Jika Tertanggung Utama meninggal karena kecelakaan sebelum berusia PAD, PADplus, PADD, PADDplus_term, Manfaat yang diterima adalah sejumlah:', mapOutput.currency, ''+totalSA5.format(formatCurr)+'']);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal karena kecelakaan sebelum berusia '+padMaxTerm+', Manfaat yang diterima adalah sejumlah:', width: 200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA5.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal sebelum berusia 99, Manfaat yang diterima adalah sejumlah:', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+paaSA.format(formatCurr)+'', width:'*'}
                ]} ]);
            }else if((ccbTerm != 0 && padTerm != 0 && prulinkTerm == 0 &&  ccbTerm < padTerm && padTerm < paaTerm) || (ccbTerm != 0 && padPlusTerm != 0 && prulinkTerm == 0 &&  ccbTerm < padPlusTerm && padPlusTerm < paaTerm) || (ccbTerm != 0 && paddTerm != 0 && prulinkTerm == 0 && ccbTerm < paddTerm && paddTerm < paaTerm) || (ccbTerm != 0 && paddPlusTerm != 0 && prulinkTerm == 0 &&  ccbTerm < paddPlusTerm && paddPlusTerm < paaTerm) ){
                //8
                //console.log('masuk logic 8');
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal sebelum berusia '+ccbTerm+', Manfaat yang diterima adalah sejumlah:', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA2.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal karena kecelakaan sebelum berusia '+ccbTerm+', Manfaat yang diterima adalah sejumlah:', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA6.format(formatCurr)+'', width:'*'}
                ]} ]);
                //body.push([ 'Jika Tertanggung Utama meninggal karena kecelakaan setelah melampaui usia '+ccbTerm+', dan sebelum berusia PAD, PADplus, PADD, PADDplus_term, Manfaat yang diterima adalah sejumlah:', mapOutput.currency, ''+totalSA5.format(formatCurr)+'']);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal karena kecelakaan setelah melampaui usia '+ccbTerm+', dan sebelum berusia '+padMaxTerm+', Manfaat yang diterima adalah sejumlah:', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text: ''+totalSA5.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal setelah melampaui usia '+ccbTerm+', dan sebelum berusia 99, Manfaat yang diterima adalah sejumlah:', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+paaSA.format(formatCurr)+'', width:'*'}
                ]} ]);
            }else if((ccbTerm != 0 && padTerm != 0 && prulinkTerm == 0 && padTerm < ccbTerm && ccbTerm < paaTerm) || (ccbTerm != 0 && padPlusTerm != 0 && prulinkTerm == 0 && padPlusTerm < ccbTerm && ccbTerm < paaTerm) || (ccbTerm != 0 && paddTerm != 0 && prulinkTerm == 0 && paddTerm < ccbTerm && ccbTerm < paaTerm) || (ccbTerm != 0 && paddPlusTerm != 0 && prulinkTerm == 0 && paddPlusTerm < ccbTerm && ccbTerm < paaTerm) ){
                //9
                //console.log('masuk logic 9');
                //body.push([ 'Jika Tertanggung Utama meninggal karena kecelakaan sebelum berusia PAD, PADplus, PADD, PADDplus_term, Manfaat yang diterima adalah sejumlah:', mapOutput.currency, ''+totalSA6.format(formatCurr)+'']);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal karena kecelakaan sebelum berusia '+padMaxTerm+', Manfaat yang diterima adalah sejumlah:', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA6.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal sebelum berusia '+ccbTerm+', Manfaat yang diterima adalah sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA2.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal setelah melampaui usia '+ccbTerm+', dan sebelum berusia 99, Manfaat yang diterima adalah sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+paaSA.format(formatCurr)+'', width:'*'}
                ]} ]);
            }else if((prulinkTerm != 0 && padTerm != 0 && ccbTerm == 0 && prulinkTerm < padTerm && padTerm < paaTerm) || (prulinkTerm != 0 && padPlusTerm != 0 && ccbTerm == 0 && prulinkTerm < padPlusTerm && padPlusTerm < paaTerm) || (prulinkTerm != 0 && paddTerm != 0 && ccbTerm == 0 && prulinkTerm < paddTerm && paddTerm < paaTerm) || (prulinkTerm != 0 && paddPlusTerm != 0 && ccbTerm == 0 && prulinkTerm < paddPlusTerm && paddPlusTerm < paaTerm) ){
                //10
                //console.log('masuk logic 10');
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal sebelum berusia '+prulinkTerm+', Manfaat yang diterima adalah sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA3.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal karena kecelakaan sebelum berusia '+prulinkTerm+', Manfaat yang diterima adalah sejumlah: ', width:200},
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    ''+totalSA7.format(formatCurr)+''
                ]} ]);
                //body.push([ 'Jika Tertanggung Utama meninggal karena kecelakaan setelah melampaui usia '+prulinkTerm+', dan sebelum berusia PAD, PADplus, PADD, PADDplus_term, Manfaat yang diterima adalah sejumlah: ', mapOutput.currency, ''+totalSA5.format(formatCurr)+'']);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal karena kecelakaan setelah melampaui usia '+prulinkTerm+', dan sebelum berusia '+padMaxTerm+', Manfaat yang diterima adalah sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA5.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal setelah melampaui usia '+prulinkTerm+', dan sebelum berusia 99, Manfaat yang diterima adalah sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+paaSA.format(formatCurr)+'', width:'*'}
                ]} ]);
            }else if((prulinkTerm != 0 && padTerm != 0 && ccbTerm == 0 && padTerm < prulinkTerm && prulinkTerm < paaTerm) || (prulinkTerm != 0 && padPlusTerm != 0 && ccbTerm == 0 && padPlusTerm < prulinkTerm && prulinkTerm < paaTerm) || (prulinkTerm != 0 && paddTerm != 0 && ccbTerm == 0 && paddTerm < prulinkTerm && prulinkTerm < paaTerm) || (prulinkTerm != 0 && paddPlusTerm != 0 && ccbTerm == 0 && paddPlusTerm < prulinkTerm && prulinkTerm < paaTerm)){
                //console.log('masuk logic 11');
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal karena kecelakaan sebelum berusia '+prulinkTerm+', Manfaat yang diterima adalah sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA7.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    'Jika Tertanggung Utama meninggal karena kecelakaan setelah melampaui usia '+prulinkTerm+' ,Manfaat yang diterima adalah sejumlah: ', 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    ''+totalSA3.format(formatCurr)+''
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal setelah melampaui usia '+prulinkTerm+', dan sebelum berusia 99, Manfaat yang diterima adalah sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+paaSA.format(formatCurr)+'', width:'*'}
                ]} ]);
            }else if((ccbTerm != 0 && prulinkTerm != 0 && ccbTerm == prulinkTerm && padTerm != 0 && ccbTerm < padTerm && padTerm < paaTerm) || (ccbTerm != 0 && prulinkTerm != 0 && ccbTerm == prulinkTerm && padPlusTerm != 0 && ccbTerm < padPlusTerm && padPlusTerm < paaTerm) || (ccbTerm != 0 && prulinkTerm != 0 && ccbTerm == prulinkTerm && paddTerm != 0 && ccbTerm < paddTerm && paddTerm < paaTerm) || (ccbTerm != 0 && prulinkTerm != 0 && ccbTerm == prulinkTerm && paddPlusTerm != 0 && ccbTerm < paddPlusTerm && paddPlusTerm < paaTerm)){
                //12
                // if((padTerm != 0 && ccbTerm < padTerm && padTerm < paaTerm) || (padPlusTerm != 0 && ccbTerm < padPlusTerm && padPlusTerm < paaTerm) || (paddTerm != 0 && ccbTerm < paddTerm && paddTerm < paaTerm) || (paddPlusTerm != 0 && ccbTerm < paddPlusTerm && paddPlusTerm < paaTerm)) {
                //console.log('masuk logic 12');
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal karena kecelakaan sebelum berusia '+prulinkTerm+', Manfaat yang diterima adalah sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA8.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal sebelum berusia '+prulinkTerm+', Manfaat yang diterima adalah sejumlah: ', width:200},
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA9.format(formatCurr)+'', width:'*'}
                ]} ]);
                //body.push([ 'Jika Tertanggung Utama meninggal karena kecelakaan setelah melampaui usia '+prulinkTerm+', dan sebelum berusia PAD, PADplus, PADD, PADDplus_term, Manfaat yang diterima adalah sejumlah: ', mapOutput.currency, ''+totalSA5.format(formatCurr)+'']);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal karena kecelakaan setelah melampaui usia '+prulinkTerm+', dan sebelum berusia '+padMaxTerm+', Manfaat yang diterima adalah sejumlah: ', width:200},
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA5.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[ 
                    {text:'Jika Tertanggung Utama meninggal setelah melampaui usia '+prulinkTerm+', dan sebelum berusia 99, Manfaat yang diterima adalah sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+paaSA.format(formatCurr)+'', width:'*'}
                ]} ]);
                // }                
            }else if((ccbTerm != 0 && padTerm != 0 && prulinkTerm != 0 && ccbTerm < padTerm && padTerm < paaTerm) || (ccbTerm != 0 && padPlusTerm != 0 && prulinkTerm != 0 && ccbTerm < padPlusTerm && padPlusTerm < paaTerm)  || (ccbTerm != 0 && paddTerm != 0 && prulinkTerm != 0 && ccbTerm < paddTerm && paddTerm < paaTerm) ||  (ccbTerm != 0 && paddPlusTerm != 0 && prulinkTerm != 0 && ccbTerm < paddPlusTerm && paddPlusTerm < paaTerm) ){
                //13
                //console.log('masuk logic 13');
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal karena kecelakaan sebelum berusia '+ccbTerm+', Manfaat yang diterima adalah sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA8.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal sebelum berusia '+ccbTerm+', Manfaat yang diterima adalah sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA9.format(formatCurr)+'', width:'*'}
                ]} ]);
                //body.push([ 'Jika Tertanggung Utama meninggal karena kecelakaan setelah melampaui usia '+ccbTerm+', dan sebelum berusia PAD, PADplus, PADD, PADDplus_term, Manfaat yang diterima adalah sejumlah: ', mapOutput.currency, ''+totalSA7.format(formatCurr)+'']);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal karena kecelakaan setelah melampaui usia '+ccbTerm+', dan sebelum berusia '+padMaxTerm+', Manfaat yang diterima adalah sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA7.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal setelah melampaui usia '+ccbTerm+', dan sebelum berusia '+prulinkTerm+', Manfaat yang diterima adalah sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA3.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal setelah melampaui usia '+prulinkTerm+', dan sebelum berusia 99, Manfaat yang diterima adalah sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+paaSA.format(formatCurr)+'', width:'*'}
                ]} ]);
            }else if((prulinkTerm != 0 && padTerm != 0 && ccbTerm != 0 && prulinkTerm < padTerm && padTerm < ccbTerm && ccbTerm < paaTerm) || (prulinkTerm != 0 && padPlusTerm != 0 && ccbTerm != 0 && prulinkTerm < padPlusTerm && padPlusTerm < ccbTerm && ccbTerm < paaTerm) || (prulinkTerm != 0 && paddTerm != 0 && ccbTerm != 0 && prulinkTerm < paddTerm && paddTerm < ccbTerm && ccbTerm < paaTerm) ||  (prulinkTerm != 0 && paddPlusTerm != 0 && ccbTerm != 0 && prulinkTerm < paddPlusTerm && paddPlusTerm < ccbTerm && ccbTerm < paaTerm)) {
                //14
                //console.log('masuk logic 14');
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal sebelum berusia '+prulinkTerm+', Manfaat yang diterima adalah sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA9.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal karena kecelakaan sebelum berusia '+prulinkTerm+', Manfaat yang diterima adalah sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA8.format(formatCurr)+'', width:'*'}
                ]} ]);
                //body.push([ 'Jika Tertanggung Utama meninggal karena kecelakaan setelah melampaui usia '+prulinkTerm+', dan sebelum berusia PAD, PADpus, PADD, PADDplus_term, Manfaat yang diterima adalah sejumlah: ', mapOutput.currency, ''+totalSA6.format(formatCurr)+'']);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal karena kecelakaan setelah melampaui usia '+prulinkTerm+', dan sebelum berusia '+padMaxTerm+', Manfaat yang diterima adalah sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA6.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal setelah melampaui usia '+prulinkTerm+', dan sebelum berusia '+ccbTerm+', Manfaat yang diterima adalah sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA2.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal setelah melampaui usia '+ccbTerm+', dan sebelum berusia 99, Manfaat yang diterima adalah sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+paaSA.format(formatCurr)+'', width:'*'}
                ]} ]);
            }else if((padTerm != 0 && ccbTerm != 0 && prulinkTerm != 0 && padTerm < ccbTerm && ccbTerm == prulinkTerm && prulinkTerm < paaTerm) || (padPlusTerm != 0 && ccbTerm != 0 && prulinkTerm != 0 && padPlusTerm < ccbTerm && ccbTerm == prulinkTerm && prulinkTerm < paaTerm) || (paddTerm != 0 && ccbTerm != 0 && prulinkTerm != 0 && paddTerm < ccbTerm && ccbTerm == prulinkTerm && prulinkTerm < paaTerm) || (paddPlusTerm != 0 && ccbTerm != 0 && prulinkTerm != 0 && paddPlusTerm < ccbTerm && ccbTerm == prulinkTerm && prulinkTerm < paaTerm)){
                //15
                //console.log('masuk logic 15');
                //body.push([ 'Jika Tertanggung Utama meninggal karena kecelakaan sebelum berusia PAD, PADplus, PADD, PADDplus_term, Manfaat yang diterima adalah sejumlah: ', mapOutput.currency, ''+totalSA8.format(formatCurr)+'']);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal karena kecelakaan sebelum berusia PAD, PADplus, PADD, PADDplus_term, Manfaat yang diterima adalah sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA8.format(formatCurr)+'', width:200}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal sebelum berusia '+ccbTerm+', Manfaat yang diterima sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA9.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal setelah melampaui usia '+ccbTerm+', dan sebelum berusia 99, Manfaat yang diterima adalah sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+paaSA.format(formatCurr)+'', width:'*'}
                ]} ]);
            }else if((padTerm != 0 && ccbTerm != 0 && prulinkTerm != 0 && padTerm < ccbTerm && ccbTerm < prulinkTerm && prulinkTerm < paaTerm) || (padPlusTerm != 0 && ccbTerm != 0 && prulinkTerm != 0 && padPlusTerm < ccbTerm && ccbTerm < prulinkTerm && prulinkTerm < paaTerm) || (paddTerm != 0 && ccbTerm != 0 && prulinkTerm != 0 && paddTerm < ccbTerm && ccbTerm < prulinkTerm && prulinkTerm < paaTerm) || (paddPlusTerm != 0 && ccbTerm != 0 && prulinkTerm != 0 && paddPlusTerm < ccbTerm && ccbTerm < prulinkTerm && prulinkTerm < paaTerm) ){
                //16
                //console.log('masuk logic 16');
                //body.push([ 'Jika Tertanggung Utama meninggal karena kecelakaan sebelum berusia PAD, PADplus, PADD, PADDplus_term, Manfaat yang diterima adalah sejumlah: ', mapOutput.currency, ''+totalSA8.format(formatCurr)+'']);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal karena kecelakaan sebelum berusia '+padMaxTerm+', Manfaat yang diterima adalah sejumlah: ', width:200},
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA8.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal sebelum berusia '+ccbTerm+', Manfaat yang diterima adalah sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA9.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal setelah melampaui usia '+ccbTerm+', dan sebelum berusia '+prulinkTerm+', Manfaat yang diterima adalah sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA3.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal setelah melampaui usia '+prulinkTerm+', dan sebelum berusia 99, Manfaat yang diterima adalah sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+paaSA.format(formatCurr)+'', width:'*'}
                ]} ]);
            }else if((padTerm != 0 && prulinkTerm != 0 && ccbTerm != 0 && padTerm < prulinkTerm && prulinkTerm < ccbTerm && ccbTerm < paaTerm) || (padPlusTerm != 0 && prulinkTerm != 0 && ccbTerm != 0 && padPlusTerm < prulinkTerm && prulinkTerm < ccbTerm && ccbTerm < paaTerm) || (paddTerm != 0 && prulinkTerm != 0 && ccbTerm != 0 && paddTerm < prulinkTerm && prulinkTerm < ccbTerm && ccbTerm < paaTerm) || (paddPlusTerm != 0 && prulinkTerm != 0 && ccbTerm != 0 && paddPlusTerm < prulinkTerm && prulinkTerm < ccbTerm && ccbTerm < paaTerm)){
                //17
                //console.log('masuk logic 17');
                // body.push([ 'Jika Tertanggung Utama meninggal karena kecelakaan sebelum berusia PAD, PADplus, PADD, PADDplus_term, Manfaat yang diterima adalah sejumlah: ', mapOutput.currency, ''+totalSA8.format(formatCurr)+'']);
                body.push([ {margin: [0,0,0,4], columns:[ 
                    {text:'Jika Tertanggung Utama meninggal karena kecelakaan sebelum berusia '+padMaxTerm+', Manfaat yang diterima adalah sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA8.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal sebelum berusia '+prulinkTerm+', Manfaat yang diterima adalah sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA9.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal setelah melampaui usia '+prulinkTerm+' dan sebelum usia '+ccbTerm+', Manfaat yang diterima adalah sejumlah: ', width:200},
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                     {text:''+totalSA2.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal setelah melampaui usia '+ccbTerm+', dan sebelum berusia 99, Manfaat yang diterima adalah sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+paaSA.format(formatCurr)+'', width:'*'}
                ]} ]);
            }else if((ccbTerm != 0 && padTerm != 0 && ccbTerm == padTerm && ccbTerm < paaTerm) || (ccbTerm != 0 && padPlusTerm != 0 && ccbTerm == padPlusTerm && ccbTerm < paaTerm) || (ccbTerm != 0 && paddTerm != 0 && ccbTerm == paddTerm && ccbTerm < paaTerm) || (ccbTerm != 0 && paddPlusTerm != 0 && ccbTerm == paddPlusTerm && ccbTerm < paaTerm)){
                //18
                //console.log('masuk logic 18');
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal sebelum berusia '+ccbTerm+', Manfaat yang diterima adalah sejumlah: ', width:200},
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA2.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal karena kecelakaan sebelum berusia '+ccbTerm+', Manfaat yang diterima adalah sejumlah: ', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+totalSA6.format(formatCurr)+'', width:'*'}
                ]} ]);
                body.push([ {margin: [0,0,0,4], columns:[
                    'Jika Tertanggung Utama meninggal setelah melampaui usia '+ccbTerm+', dan sebelum berusia 99, Manfaat yang diterima adalah sejumlah: ',
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+paaSA.format(formatCurr)+'', width:'*'}
                ]} ]);
            }else{
                //console.log('masuk logic default');
                body.push([ {margin: [0,0,0,4], columns:[
                    {text:'Jika Tertanggung Utama meninggal sebelum berusia 99, Manfaat yang diterima adalah sejumlah:', width:200}, 
                    {text:mapOutput.currency, width: 60, alignment:'center'}, 
                    {text:''+paaSA.format(formatCurr)+'', width:'*'}
                ]} ]);
            }
        }

        // //console.log(body);

        // //console.log("====================== Ringkasan Manfaat Meninggal (END) =====================");

        return body.transpose();
    }

    //Start Hal 2    
    function manfaatAsuransi(mapOutput){


        var body = [];
        var riderCount = 0;

        var planMapping={
            'A':250000,
            'B':425000,
            'C':600000,
            'D':900000,
            'E':1200000,
            'F':1800000,
            'G':2350000,
            'H':3000000,
            '0':0
        };
        var frequency;
        if(mapOutput.frequency.descriptionInd.toLowerCase() == 'bulanan'){
            frequency = 12;
        }else if(mapOutput.frequency.descriptionInd.toLowerCase() == 'tiga bulanan'){
            frequency = 4;
        }else if(mapOutput.frequency.descriptionInd.toLowerCase() == 'setengah tahunan'){
            frequency = 2;
        }else{
            frequency = 1;
        }

        var premiBerkala;
        var premiSaver;
        var premiTotal;
        var previousCode = '';

        //console.log('buat frekuensi == '+frequency);   

        body.push([{ text: 'MANFAAT ASURANSI \n   ', colSpan: 3, bold: true }, {text:'\n   ' +emptycol, margin:[0,0,0,2]},
                      { text: 'Sampai dengan usia \nterganggung', decoration: 'underline', bold: true, margin:[-40,0,0,0], alignment:'right'}, 
                      { text: 'Uang \nPertanggungan', decoration: 'underline', bold: true, alignment:'right'},
                      { text: 'Premi \nPertanggungan', decoration: 'underline', bold: true, alignment:'right'},
                      { text: 'Biaya Asuransi \nBulanan', decoration: 'underline', bold: true, alignment:'right'},
                      { text: 'Premi Berkala & Premi Top-up Berkala U1CR \nPremi '+mapOutput.frequency.descriptionInd, colSpan: 2, decoration: 'underline', bold: true}, '\n   ' +emptycol]);
         
         for(var x = 0; x < mapOutput.manfaatList.length; x++){
            //console.log(mapOutput.manfaatList[x]);
            var productName1 = mapOutput.manfaatList[x].name.substring(0,3); //PRU
            var productName2 = mapOutput.manfaatList[x].name.substring(3); //belakang
            var productCode = mapOutput.manfaatList[x].code;
            var coverageType = mapOutput.manfaatList[x].coverageType;
            var biayaBulanan = mapOutput.manfaatList[x].biayaBulanan;
            var annualPremi = mapOutput.manfaatList[x].annualPremi;
            var value;
            var inputValueList = mapOutput.manfaatList[x].itemInput;
            var term;
            var unit;
            var plan;

            if(mapOutput.tertanggungNameTT1 != undefined && mapOutput.tertanggungNameTT1 != ''){
                if(productCode == 'W3AR' || productCode == 'W1XR'){
                    if(productCode != previousCode){
                        productName2 = productName2+'-1';
                        previousCode = productCode;
                    }else{
                        productName2 = productName2+'-2';
                    }                    
                         
                }
            }

            for(var i = 0; i < inputValueList.length; i++){
                if(inputValueList[i].key == 'PDTERM'){
                    term = inputValueList[i].inputValue;
                }else if(inputValueList[i].key == 'PDSA'){
                    value = inputValueList[i].inputValue;
                }else if(inputValueList[i].key == 'PDUNIT'){
                    unit = inputValueList[i].inputValue;
                }else if(inputValueList[i].key == 'PDPLAN'){
                    plan = inputValueList[i].inputValue;
                    //console.log('plan =============================',plan);
                }
            }

            if(productCode == 'U1ZR' || productCode == 'U1ZD'){
                annualPremi = parseFloat(value)/parseFloat(mapOutput.rtMaxSAValue);
                //console.log('Premi pertanggungan U1ZR == ',annualPremi);
            }

            if(productCode == 'H1VR'){
                value = parseInt(unit) * 40000;
            }else if(productCode == 'H1TR'){
                value = planMapping[plan];
            }else if(productCode == 'W1MR' || productCode == 'W1MD' || productCode == 'S1FR' || productCode == 'S1FD'){
                value = parseFloat(mapOutput.premi.replace(/,/g , ""))*frequency;
            }else if(productCode == 'W1QR' || productCode == 'W1QD' || productCode == 'W3BR' || productCode == 'W3BD' || productCode == 'S1YR' || productCode == 'S1YD' || productCode == 'S1KR' || productCode == 'S1KD' || productCode == 'W1XR' || productCode == 'W1XD' || productCode == 'W3AR' || productCode == 'W3AD'){
                value = parseFloat(mapOutput.totalPremi.replace(/,/g , ""))*frequency;
            }

            // //console.log(productCode + ' - ' +productName + ' - '+coverageType + ' - '+value +' - '+term );

            if(coverageType == 'main'){
                 premiBerkala = mapOutput.totalPremiThn/frequency;
                 //console.log('premi berkala.........'+premiBerkala);
                 body.push([{ text: 'Dasar \nTambahan' }, {columns:[{text:productCode, margin:[-60,0,0,0], width:'*'}, {text:[{ text:productName1, font: 'frutiger' },{text:productName2, font: 'garamount'}], margin:[-90,0,0,0]}]},
                            { text: '99', alignment:'right'}, 
                            { text: ''+parseFloat(value).format(formatCurr)+'', alignment:'right'},
                            { text: ''+parseFloat(annualPremi).format(formatCurr)+'', alignment:'right'},
                            { text:''+parseFloat(biayaBulanan).format(formatCurr)+'', alignment:'right'},
                            { text: 'Premi Berkala ', alignment:'left'},
                            { text:''+mapOutput.premi+'', alignment:'right', margin: [-50, 0, 0, 0]}]);
            }else if(coverageType == 'rider'){
                
                if(riderCount == 0){
                    premiSaver = parseFloat(mapOutput.topupBerkala.replace(/,/g , ""))/frequency;
                    //console.log('premi berkala.........'+premiSaver);
                    body.push([{ text: emptycol }, {columns:[{text:productCode, margin:[-60,0,0,0], width:'*'}, {text:[{ text:productName1, font: 'frutiger' },{text:productName2, font: 'garamount'}], margin:[-90,0,0,0]}]},
                            { text: ''+term+'', alignment:'right'}, 
                            { text: ''+parseFloat(value).format(formatCurr)+'', alignment:'right'},
                            { text: ''+parseFloat(annualPremi).format(formatCurr)+'', alignment:'right'},
                            { text: ''+parseFloat(biayaBulanan).format(formatCurr)+'', alignment:'right'},
                            { text: 'Premi Top-up Berkala (PRUsaver)', alignment:'left'},
                            { text: ''+mapOutput.topupBerkala+'', alignment:'right', margin: [-50, 0, 0, 0], decoration:'underline'}]);    
                }else if(riderCount == 1){
                    premiTotal = premiBerkala+premiSaver;
                    //console.log('premi total.........'+premiTotal);
                    body.push([{ text: emptycol }, {columns:[{text:productCode, margin:[-60,0,0,0], width:'*'}, {text:[{ text:productName1, font: 'frutiger' },{text:productName2, font: 'garamount'}], margin:[-90,0,0,0]}]},
                            { text: ''+term+'', alignment:'right'}, 
                            { text: ''+parseFloat(value).format(formatCurr)+'', alignment:'right'},
                            { text: ''+parseFloat(annualPremi).format(formatCurr)+'', alignment:'right'},
                            { text: ''+parseFloat(biayaBulanan).format(formatCurr)+'', alignment:'right'},
                            { text: 'Total Premi ('+mapOutput.frequency.descriptionInd+')', alignment:'left'},
                            { text: ''+mapOutput.totalPremi+'', alignment:'right', margin: [-50, 0, 0, 0]}]);
                }else{
                

                    body.push([{ text: emptycol }, {columns:[{text:productCode, margin:[-60,0,0,0], width:'*'}, {text:[{ text:productName1, font: 'frutiger' },{text:productName2, font: 'garamount'}], margin:[-90,0,0,0]}]},
                            { text: ''+term+'', alignment:'right'}, 
                            { text: ''+parseFloat(value).format(formatCurr)+'', alignment:'right'},
                            { text: ''+parseFloat(annualPremi).format(formatCurr)+'', alignment:'right'},
                            { text: ''+parseFloat(biayaBulanan).format(formatCurr)+'', alignment:'right'},
                            { text: emptycol},
                            { text: emptycol, margin: [-50, 0, 0, 0]}]);
                }

                riderCount++;
                
            }    

         }

         if(riderCount == 0){
            premiSaver = parseFloat(mapOutput.topupBerkala.replace(/,/g , ""))/frequency;
            //console.log('premi berkala.........'+premiSaver);
            body.push([{ text: emptycol }, emptycol, emptycol,
                    { text: emptycol}, 
                    { text: emptycol},
                    emptycol,
                    emptycol,
                    { text: 'Premi Top-up Berkala (PRUsaver)', alignment:'left'},
                    { text: ''+mapOutput.topupBerkala+'', alignment:'right', margin: [-50, 0, 0, 0]}]);

            premiTotal = premiBerkala+premiSaver;
            //console.log('premi total.........'+premiTotal);
            body.push([{ text: emptycol }, emptycol, emptycol,
                    { text: emptycol}, 
                    { text: emptycol},
                    emptycol,
                    emptycol,
                    { text: 'Total Premi ('+mapOutput.frequency.descriptionInd+')', alignment:'left'},
                    { text: ''+mapOutput.totalPremi+'', alignment:'right', margin: [-50, 0, 0, 0]}]);        
         }else if(riderCount == 1){
            premiTotal = premiBerkala+premiSaver;
            //console.log('premi total.........'+premiTotal);
            body.push([{ text: emptycol }, emptycol, emptycol,
                    { text: emptycol}, 
                    { text: emptycol},
                    emptycol,
                    emptycol,
                    { text: 'Total Premi ('+mapOutput.frequency.descriptionInd+')', alignment:'left'},
                    { text: ''+mapOutput.totalPremi+'', alignment:'right', margin: [-50, 0, 0, 0]}]);
         }    
         /*body.push([{text:' (Manfaat asuransi, Frekuensi Pembayaran, Mata Uang Polis dan Jenis Dana Investasi tersebut di atas adalah bagian dari SPAJ yang akan digunakan sebagai acuan dalam proses penerbitan Polis/kontrak asuransi atau perubahan Polis yang berhubungan dengan Uang Pertanggungan, Manfaat Asuransi, Besar Premi, Jangka Waktu, Merokok/Tidak Merokok, Kelas Pekerjaan, Frekuensi Pembayaran, Mata Uang Polis dan Jenis Dana Investasi)', fontSize: 7}
                    '','','','','','','',''
            ]); */              

        return body.transpose();
    }


    /**
     * Transposes a given array.
     * @id Array.prototype.transpose
     * @author Shamasis Bhattacharya
     *
     * @type Array
     * @return The Transposed Array
     * @compat=ALL
     */
    Array.prototype.transpose = function() {

      // Calculate the width and height of the Array
      var a = this,
        w = a.length ? a.length : 0,
        h = a[0] instanceof Array ? a[0].length : 0;

      // In case it is a zero matrix, no transpose routine needed.
      if(h === 0 || w === 0) { return []; }

      /**
       * @var {Number} i Counter
       * @var {Number} j Counter
       * @var {Array} t Transposed data is stored in this array.
       */
      var i, j, t = [];

      // Loop through every item in the outer array (height)
      for(i=0; i<h; i++) {

        // Insert a new row (array)
        t[i] = [];

        // Loop through every item per item in outer array (width)
        for(j=0; j<w; j++) {

          // Save transposed data.
          t[i][j] = a[j][i];
        }
      }

      return t;
    };


  Number.prototype.format = function(n, x) {
    var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\.' : '$') + ')';
    return this.toFixed(Math.max(0, ~~n)).replace(new RegExp(re, 'g'), '$&,');
  };

    function ringkasanManfaat(mapOutput){

        // mapOutput.manfaatList = sortingRiderTopupMain(mapOutput.manfaatList);

        // //console.log("====================== Ringkasan Manfaat 2 (START) =====================");
        var body = [];

        if(mapOutput.productName.toLowerCase() == 'prulink assurance account'){
            //console.log('prulink assurance account');
            body.push([{
                margin: [0,0,0,5],
                columns: [
                    {
                      text: [{text:'PRU', font:'frutiger'}, {text:'link assurance account', font: 'garamount' },' (PAA)'], width: 200,
                    },
                    {
                        stack: [
                            { text: [
                                'Apabila Tertanggung Utama meninggal dunia atau Cacat Total dan Tetap dibayarkan sebesar Uang Pertanggungan PAA dan Nilai Tunai, apabila ada.',
                                '\nApabila Tertanggung Utama menderita Cacat Total dan Tetap akan dibayarkan Uang Pertanggungan PAA, maksimum sebesar Rp 2 miliar per jiwa. Apabila Manfaat Asuransi Cacat Total dan Tetap telah dibayarkan maka akan mengurangi Uang Pertanggungan PAA. Pembayaran Uang Pertanggungan Cacat Total dan Tetap akan dibagi 2 tahap sebagai berikut:',
                                '\nPembayaran Pertama, 180 hari dari tanggal diagnosa Cacat Total dan Tetap  sebesar 20% dari Uang Pertanggungan PAA yang akan mengurangi Uang Pertanggungan PAA ',
                                '\nPembayaran Kedua (satu tahun setelah Pembayaran Pertama) sebesar 80% dari Uang Pertanggungan PAA yang akan mengurangi Uang Pertanggungan PAA ',
                                '\nApabila Tertanggung Utama hidup sampai dengan Tanggal Akhir Pertanggungan maka akan dibayarkan Nilai Tunai, apabila ada.',
                                ],
                            },
                        ]
                    },
                ]
            }]);
        }

        for(var x = 0; x < mapOutput.manfaatList.length; x++){
            var productName = mapOutput.manfaatList[x].name;
            var productCode = mapOutput.manfaatList[x].code;
            var coverageType = mapOutput.manfaatList[x].coverageType;
            var value = mapOutput.manfaatList[x].itemInput[0].inputValue;
            var term = mapOutput.manfaatList[x].term;

            // //console.log(productCode + ' - ' +productName + ' - '+coverageType + ' - '+value +' - '+term );
            /*
            if(productCode == 'U1ZR'){
                body.push([{
                    columns: [
                        {
                          text: 'PRUlink assurance account (PAA)', width: 200,
                        },
                        {
                            stack: [
                                { text: [
                                    'Apabila Tertanggung Utama meninggal dunia atau Cacat Total dan Tetap dibayarkan sebesar Uang Pertanggungan PAA dan Nilai Tunai, apabila ada.',
                                    '\nApabila Tertanggung Utama menderita Cacat Total dan Tetap akan dibayarkan Uang Pertanggungan PAA, maksimum sebesar Rp 2 miliar per jiwa. Apabila Manfaat Asuransi Cacat Total dan Tetap telah dibayarkan maka akan mengurangi Uang Pertanggungan PAA. Pembayaran Uang Pertanggungan Cacat Total dan Tetap akan dibagi 2 tahap sebagai berikut:',
                                    '\nPembayaran Pertama, 180 hari dari tanggal diagnosa Cacat Total dan Tetap  sebesar 20% dari Uang Pertanggungan PAA yang akan mengurangi Uang Pertanggungan PAA ',
                                    '\nPembayaran Kedua (satu tahun setelah Pembayaran Pertama) sebesar 80% dari Uang Pertanggungan PAA yang akan mengurangi Uang Pertanggungan PAA ',
                                    '\nApabila Tertanggung Utama hidup sampai dengan Tanggal Akhir Pertanggungan maka akan dibayarkan Nilai Tunai, apabila ada.',
                                    ],
                                },
                            ]
                        },
                    ]
                }]);                 
            }else 
            */

            if(productCode == 'U1CR' || productCode == 'U1CD'){
                body.push([{
                    margin: [0,0,0,5],
                    columns: [
                        {
                          text: [{text:'PRU', font:'frutiger'}, {text:'saver', font: 'garamount' },' (Premi Top-up Berkala)'], width: 200,
                        },
                        {
                            stack: [
                                { text: [
                                    'Bagian dari Premi Berkala yang merupakan tambahan dana investasi.',
                                    ],
                                },
                            ]
                        },
                    ]
                }]);
            }else if(productCode == 'C1KR' || productCode == 'C1KD'){
                body.push([{
                    margin: [0,0,0,5],
                    columns: [
                        {
                          text: [{text:'PRU', font:'frutiger'}, {text:'crisis cover 34', font: 'garamount' },' (Premi Top-up Berkala)'], width: 200,
                        },
                        {
                            stack: [
                                { text: [
                                    'Apabila Tertanggung Utama memenuhi kriteria salah satu dari 34 Kondisi Kritis, pada saat ',{text:'PRU', font:'frutiger'}, {text:'crisis cover 34', font: 'garamount' },' telah berlaku selama 90 hari atau lebih, dan usia Tertanggung Utama tidak melebihi '+''+term+''+' tahun, ',
                                    '\nApabila Tertanggung Utama memenuhi kriteria salah satu dari 34 Kondisi Kritis, pada saat ',{text:'PRU', font:'frutiger'}, {text:'crisis cover 34', font: 'garamount' },' telah berlaku selama 90 hari atau lebih, dan usia Tertanggung Utama tidak melebihi '+''+term+''+' tahun, dibayarkan Uang Pertanggungan ',{text:'PRU', font:'frutiger'}, {text:'crisis cover 34', font: 'garamount' },' yang akan mengurangi Uang Pertanggungan Asuransi Dasar PAA. Khusus untuk manfaat Angioplasti dan penatalaksanaan invasif lainnya untuk pembuluh darah ',
                                    '\njantung, manfaat yang dibayarkan adalah 10% Uang Pertanggungan ',{text:'PRU', font:'frutiger'}, {text:'crisis cover 34', font: 'garamount' },'.',
                                    ],
                                },
                            ]
                        },
                    ]
                }]);
            }else if(productCode == 'C1TR' || productCode == 'C1TD'){
                body.push([{
                    margin: [0,0,0,5],
                    columns: [
                        {
                          text: [{text:'PRU', font:'frutiger'}, {text:'multiple crisis cover', font: 'garamount' }], width: 200,
                        },
                        {
                            stack: [
                                { text: [
                                    'Apabila Tertanggung Utama memenuhi kriteria salah satu dari 34 Kondisi Kritis sebanyak maksimum 3 Kondisi Kritis dalam kelompok yang berbeda, pada saat ',{text:'PRU', font:'frutiger'}, {text:'multiple crisis cover', font: 'garamount' },' telah berlaku selama 90 hari atau  ',
                                    '\nlebih, dan usia Tertanggung Utama tidak melebihi '+''+term+''+' tahun, dibayarkan Uang Pertanggungan ',{text:'PRU', font:'frutiger'}, {text:'multiple crisis cover', font: 'garamount' },' yang tidak akan mengurangi Uang Pertanggungan Asuransi Dasar PAA.',
                                    '\nBerikut beberapa ketentuan dalam ',{text:'PRU', font:'frutiger'}, {text:'multiple crisis cover', font: 'garamount' },':',
                                    '\n1. Ketiga puluh empat Kondisi Kritis dikelompokkan menjadi 8 kelompok yang berbeda.',
                                    '\n2. Tertanggung Utama tetap hidup dalam kurun waktu 14 (empat belas) hari sejak kriteria klaim atas Kondisi Kritis terpenuhi.',
                                    '\n3. Klaim kelompok kelas H (Angioplasti) hanya dapat diajukan 1 kali sepanjang pertanggungan dan tidak mengurangi 3 kali kesempatan untuk melakukan klaim Kondisi Kritis, pembayaran klaim ',
                                    '\n   adalah 10% Uang Pertanggungan ',{text:'PRU', font:'frutiger'}, {text:'multiple crisis cover', font: 'garamount' },'.',
                                    '\n4. Klaim kelompok kelas A (Kanker) dapat diajukan sebanyak 2 kali sepanjang pertanggungan dengan mengindahkan periode bebas kanker 5 tahun dari klaim kanker pertama ke klaim Kanker kedua.',
                                    '\n5. Pengajuan klaim Kondisi Kritis kelompok kelas B setelah pengajuan klaim Kondisi Kritis kelompok kelas A dikenai Periode Bebas Kanker 5 Tahun.',
                                    ],
                                },
                            ]
                        },
                    ]
                }]);
            }else if(productCode == 'I1DR'){
                body.push([{
                    margin: [0,0,0,5],
                    columns: [
                        {
                          text: [{text:'PRU', font:'frutiger'}, {text:'crisis income', font: 'garamount'}], width: 200,
                        },
                        {
                            stack: [
                                { text: [
                                    'Apabila Tertanggung Utama memenuhi kriteria salah satu dari 33 Kondisi Kritis, pada saat ',{text:'PRU', font:'frutiger'}, {text:'crisis income', font: 'garamount' },' telah berlangsung 90 hari atau lebih, dan usia Tertanggung Utama tidak melebihi '+''+term+''+' tahun, akan dibayarkan manfaat pendapatan sebesar Uang ',
                                    '\nPertanggungan ',{text:'PRU', font:'frutiger'}, {text:'crisis income', font: 'garamount' },' sampai Tertanggung Utama mencapai usia '+''+term+''+' tahun',                                    
                                    ],
                                },
                            ]
                        },
                    ]
                }]);
            }else if(productCode == 'C106' ||productCode == 'C107'){
                body.push([{
                    margin: [0,0,0,5],
                    columns: [
                        {
                          text: [{text:'PRU', font:'frutiger'}, {text:'early stage crisis cover plus', font: 'garamount'}], width: 200,
                        },
                        {
                            stack: [
                                { text: [
                                    'Apabila Tertanggung Utama memenuhi kriteria salah satu dari Kondisi Kritis untuk tiap jenis stadium dan kriteria Kondisi Kritis, pada saat ', {text:'PRU', font:'frutiger'}, {text:'early stage crisis cover plus', font: 'garamount'},' telah berlaku selama 90 hari dan usia Tertanggung Utama tidak melebihi '+''+term+''+' tahun, ',
                                    '\ndibayarkan Uang Pertanggungan ', {text:'PRU', font:'frutiger'}, {text:'early stage crisis cover plus', font: 'garamount'},' yang tidak akan mengurangi Uang Pertanggungan Asuransi Dasar PAA',                                    
                                    '\nBeberapa ketentuan dalam ', {text:'PRU', font:'frutiger'}, {text:'early stage crisis cover plus', font: 'garamount'},':',
                                    '\n1. Kondisi Kritis dikelompokkan dalam 3 jenis stadium yaitu stadium awal (38 jenis kondisi), stadium menengah (26 jenis kondisi) dan stadium akhir (48 jenis kondisi).',
                                    '\n2. Tertanggung Utama tetap hidup dalam kurun waktu 14 hari sejak kriteria klaim atas Kondisi Kritis terpenuhi.',
                                    '\n3. Klaim pada stadium awal dapat dibayarkan maksimum sebanyak 2 kali selama masa pertanggungan, pembayaran klaim adalah 50% Uang Pertanggungan ', {text:'PRU', font:'frutiger'}, {text:'early stage crisis cover plus', font: 'garamount'},' untuk setiap pengajuan klaim.',
                                    '\n4. Klaim pada stadium menengah atau stadium akhir hanya dibayarkan 1 kali selama masa pertanggungan, pembayaran klaim adalah 100% Uang Pertanggungan ', {text:'PRU', font:'frutiger'}, {text:'early stage crisis', font: 'garamount'},
                                    '\n   cover plus. Kecuali manfaat pada poin 3 di atas sudah dibayarkan maka pembayaran klaim adalah 50% Uang Pertanggungan ', {text:'PRU', font:'frutiger'}, {text:'early stage crisis cover plus', font: 'garamount'},'.',
                                    '\n5. Klaim Angioplasty dan Penatalaksanaan Invasif Lainnya untuk Penyakit Pembuluh Darah Jantung dan Komplikasi Diabetes hanya dapat dibayarkan 1 kali selama masa pertanggungan. ',
                                    '\n   Pembayaran klaim adalah 10% dari Uang Pertanggungan ', {text:'PRU', font:'frutiger'}, {text:'early stage crisis cover plus', font: 'garamount'},' atau maksimal Rp 75 juta/ USD 9.375 untuk Angioplasty dan Penatalaksanaan Invasif',
                                    '\n   Lainnya untuk Penyakit Pembuluh Darah Jantung dan 20% dari Uang Pertanggungan ', {text:'PRU', font:'frutiger'}, {text:'early stage crisis cover plus', font: 'garamount'},' atau maksimal Rp 200 juta / USD 25.000 untuk Komplikasi ',
                                    '\n   Diabetes. Pembayaran atas kedua kondisi kritis tersebut tidak akan mengurangi jumlah Uang Pertanggungan ', {text:'PRU', font:'frutiger'}, {text:'early stage crisis cover plus', font: 'garamount'},'.',
                                    '\n6. Klaim untuk manfaat tambahan 5 jenis Penyakit Kritis Catastrophic hanya dapat dibayarkan 1 kali selama masa Pertanggungan. Pembayaran klaim adalah 20% dari Uang Pertanggungan ',
                                    '\n   ', {text:'PRU', font:'frutiger'}, {text:'early stage crisis cover plus', font: 'garamount'},' untuk Penyakit Kritis Catastrophic selama masa Pertanggungan, dan tidak akan mengurangi jumlah Uang Pertanggungan ', {text:'PRU', font:'frutiger'}, {text:'early stage crisis cover plus', font: 'garamount'},'.',
                                    ],
                                },
                            ]
                        },
                    ]
                }]);
            }else if(productCode == 'T1JR' || productCode == 'T1JD'){
                body.push([{
                    margin: [0,0,0,5],
                    columns: [
                        {
                          text: [{text:'PRU', font:'frutiger'}, {text:'link term', font: 'garamount'}], width: 200,
                        },
                        {
                            stack: [
                                { text: [
                                    'Apabila Tertanggung Utama meninggal dunia pada saat usia Tertanggung Utama tidak melebihi '+''+term+''+' tahun, dibayarkan Uang Pertanggungan ',{text:'PRU', font:'frutiger'}, {text:'link term', font: 'garamount'},
                                    ],
                                },
                            ]
                        },
                    ]
                }]);
            }else if(productCode == 'P1CR' || productCode == 'P1CD'){
                body.push([{
                    margin: [0,0,0,5],
                    columns: [
                        {
                          text: [{text:'PRU', font:'frutiger'}, {text:'personal accident death', font: 'garamount'}], width: 200,
                        },
                        {
                            stack: [
                                { text: [
                                    'Apabila Tertanggung Utama meninggal dunia karena kecelakaan pada saat usia Tertanggung Utama tidak melebihi '+''+term+''+' tahun dibayarkan Uang Pertanggungan ',{text:'PRU', font:'frutiger'}, {text:'personal accident death', font: 'garamount'},'.',
                                    ],
                                },
                            ]
                        },
                    ]
                }]);
            }else if(productCode == 'P1DR' || productCode == 'P1DD'){
                body.push([{
                    margin: [0,0,0,5],
                    columns: [
                        {
                          text: [{text:'PRU', font:'frutiger'}, {text:'personal accident death & disablement', font: 'garamount'}], width: 200,
                        },
                        {
                            stack: [
                                { text: [
                                    'Apabila Tertanggung Utama meninggal dunia/Cacat karena Kecelakaan pada saat usia Tertanggung Utama tidak melebihi '+''+term+''+' tahun dibayarkan Uang Pertanggungan',{text:'PRU', font:'frutiger'}, {text:'personal accident death & disablement', font: 'garamount'},'. ',
                                    ],
                                },
                            ]
                        },
                    ]
                }]);
            }else if(productCode == 'P1QR' || productCode == 'P1QD'){
                body.push([{
                    margin: [0,0,0,5],
                    columns: [
                        {
                          text: [{text:'PRU', font:'frutiger'}, {text:'personal accident death plus', font: 'garamount'}], width: 200,
                        },
                        {
                            stack: [
                                { text: [
                                    'Apabila Tertanggung Utama meninggal dunia atau mengalami patah tulang atau luka bakar atau menjalani rawat jalan darurat karena kecelakaan pada saat usia Tertanggung Utama tidak melebihi '+''+term+''+' tahun ',
                                    '\ndibayarkan Uang Pertanggungan ',{text:'PRU', font:'frutiger'}, {text:'personal accident death plus', font: 'garamount'},'PRUpersonal accident death plus yang besarnya sesuai persentase masing-masing manfaat.',
                                    ],
                                },
                            ]
                        },
                    ]
                }]);
            }else if(productCode == 'P1RR' || productCode == 'P1RD'){
                body.push([{
                    margin: [0,0,0,5],
                    columns: [
                        {
                          text: [{text:'PRU', font:'frutiger'}, {text:'personal accident death & disablement plus', font: 'garamount'}], width: 200,
                        },
                        {
                            stack: [
                                { text: [
                                    'Apabila Tertanggung Utama meninggal dunia atau mengalami Cacat Tetap atau patah tulang atau luka bakar atau menjalani rawat jalan darurat karena kecelakaan pada saat usia Tertanggung Utama tidak melebihi '+''+term+''+' tahun dibayarkan Uang Pertanggungan ',
                                    '\n',{text:'PRU', font:'frutiger'}, {text:'personal accident death & disablement plus', font: 'garamount'},' plus yang besarnya sesuai persentase masing-masing manfaat.',
                                    ],
                                },
                            ]
                        },
                    ]
                }]);
            }else if(productCode == 'H1VR'){
                body.push([{
                    margin: [0,0,0,5],
                    columns: [
                        {
                          text: [{text:'PRU', font:'frutiger'}, {text:'med cover', font: 'garamount'}], width: 200,
                        },
                        {
                            stack: [
                                { text: [
                                    'Memberikan manfaat harian Rawat Inap, ICU, Pembedahan untuk Tertanggung Utama setelah ',{text:'PRU', font:'frutiger'}, {text:'med cover', font: 'garamount'},' berlaku selama 30 hari atau lebih, dengan minimum 2X24 jam, maksimum rawat inap 100 hari dalam satu ',
                                    '\ntahun, sampai dengan Tertanggung Utama berusia '+''+term+''+' tahun.',
                                    ],
                                },
                            ]
                        },
                    ]
                }]);
            }else if(productCode == 'H1TR'){
                body.push([{
                    margin: [0,0,0,5],
                    columns: [
                        {
                          text: [{text:'PRU', font:'frutiger'}, {text:'hospital & surgical cover plus', font: 'garamount'}], width: 200,
                        },
                        {
                            stack: [
                                { text: [
                                    'Memberikan manfaat harian Rawat Inap, ICU, Pembedahan untuk Tertanggung Utama setelah ',{text:'PRU', font:'frutiger'}, {text:'hospital & surgical cover plus', font: 'garamount'},' berlaku selama 30 hari atau lebih dengan minimum 1x24jam 1x6jam, maksimum rawat inap ',
                                    '\n150 hari dalam satu tahun termasuk perawatan di ICU maksimum selama 45 hari, sampai dengan Tertanggung Utama '+''+term+''+' tahun, sesuai dengan biaya rawat inap harian di Rumah Sakit dengan maksimal ',
                                    '\nUang Pertanggungan harian ',{text:'PRU', font:'frutiger'}, {text:'hospital & surgical cover plus', font: 'garamount'},'.',
                                    ],
                                },
                            ]
                        },
                    ]
                }]);
            }else if(productCode == 'W1QR' ||productCode == 'W1QD'){
                body.push([{
                    margin: [0,0,0,5],
                    columns: [
                        {
                          text: [{text:'PRU', font:'frutiger'}, {text:'payor 33', font: 'garamount'}], width: 200,
                        },
                        {
                            stack: [
                                { text: [
                                    'Apabila Tertanggung Utama memenuhi kriteria salah satu dari 33 Kondisi Kritis sebelum Tertanggung Utama berusia '+''+term+''+' tahun (setelah ',{text:'PRU', font:'frutiger'}, {text:'payor 33', font: 'garamount'},' berlaku selama 90 hari atau lebih), Penanggung akan ',
                                    '\nmembayarkan Premi Berkala & Premi Top-up Berkala (',{text:'PRU', font:'frutiger'}, {text:'saver', font: 'garamount'},') s.d usia '+''+term+''+' tahun. ',
                                    ],
                                },
                            ]
                        },
                    ]
                }]);
            }else if(productCode == 'W1MR' ||productCode == 'W1MD'){
                body.push([{
                    margin: [0,0,0,5],
                    columns: [
                        {
                          text: [{text:'PRU', font:'frutiger'}, {text:'waiver 33', font: 'garamount'}], width: 200,
                        },
                        {
                            stack: [
                                { text: [
                                    'Apabila Tertanggung Utama memenuhi kriteria salah satu dari 33 Kondisi Kritis (setelah ',{text:'PRU', font:'frutiger'}, {text:'waiver 33', font: 'garamount'},' berlaku selama 90 hari atau lebih), sebelum Tertanggung Utama berusia '+''+term+''+' tahun, Penanggung akan ',
                                    '\nmembayarkan Premi Berkala s.d. usia '+''+term+''+' tahun.',
                                    ],
                                },
                            ]
                        },
                    ]
                }]);
            }else if(productCode == 'S1KR' ||productCode == 'S1KD'){
                body.push([{
                    margin: [0,0,0,5],
                    columns: [
                        {
                          text: [{text:'PRU', font:'frutiger'}, {text:'spouse payor 33', font: 'garamount'}], width: 200,
                        },
                        {
                            stack: [
                                { text: [
                                    'Apabila Suami/Istri dari Tertanggung Utama memenuhi kriteria salah satu dari 33 Kondisi Kritis (setelah ',{text:'PRU', font:'frutiger'}, {text:'spouse payor 33', font: 'garamount'},' berlaku selama 90 hari atau lebih)/Cacat Total dan Tetap, sebelum usia Suami/Istri dari ',
                                    '\nTertanggung Utama 70 tahun/meninggal dunia, sebelum usia Tertanggung Utama '+''+term+''+' tahun, Penanggung akan membayarkan Premi Berkala & Premi Top-up Berkala (',{text:'PRU', font:'frutiger'}, {text:'saver', font: 'garamount'},') s.d usia Tertanggung Utama '+''+term+''+' tahun. ',
                                    ],
                                },
                            ]
                        },
                    ]
                }]);
            }else if(productCode == 'S1FR' ||productCode == 'S1FD'){
                body.push([{
                    margin: [0,0,0,5],
                    columns: [
                        {
                          text: [{text:'PRU', font:'frutiger'}, {text:'spouse waiver 33', font: 'garamount'}], width: 200,
                        },
                        {
                            stack: [
                                { text: [
                                    'Apabila Suami/Istri dari Tertanggung Utama memenuhi kriteria salah satu dari 33 Kondisi Kritis (setelah ',{text:'PRU', font:'frutiger'}, {text:'spouse waiver 33', font: 'garamount'},' berlaku selama 90 hari atau lebih)/Cacat Total dan Tetap, sebelum usia Suami/Istri dari ',
                                    '\nTertanggung Utama 70 tahun/meninggal dunia, sebelum Tertanggung Utama berusia '+''+term+''+' tahun, Penanggung akan membayarkan Premi Berkala s.d. usia Tertanggung Utama '+''+term+''+' tahun. ',
                                    ],
                                },
                            ]
                        },
                    ]
                }]);
            }else if(productCode == 'W1XR' ||productCode == 'W1XD'){
                body.push([{
                    margin: [0,0,0,5],
                    columns: [
                        {
                          text: [{text:'PRU', font:'frutiger'}, {text:'parent payor 33', font: 'garamount'}], width: 200,
                        },
                        {
                            stack: [
                                { text: [
                                    'Apabila Ayah dan/atau Ibu dari Tertanggung Utama memenuhi kriteria salah satu dari 33 Kondisi Kritis (setelah ',{text:'PRU', font:'frutiger'}, {text:'parent payor 33', font: 'garamount'},' berlaku selama 90 hari atau lebih)/Cacat Total dan Tetap, sebelum usia Ayah dan/atau ',
                                    '\nIbu dari Tertanggung Utama 70 tahun/meninggal dunia, Penanggung akan membayarkan sebesar Premi Berkala & Premi Top-up Berkala (',{text:'PRU', font:'frutiger'}, {text:'saver', font: 'garamount'},') s.d. usia Tertanggung Utama '+''+term+''+' tahun, sesuai dengan usia ',
                                    '\nyang dipilih. ',
                                    ],
                                },
                            ]
                        },
                    ]
                }]);
            }else if(productCode == 'C103' ||productCode == 'C104'){
                body.push([{
                    margin: [0,0,0,5],
                    columns: [
                        {
                          text: [{text:'PRU', font:'frutiger'}, {text:'juvenile crisis cover', font: 'garamount'}], width: 200,
                        },
                        {
                            stack: [
                                { text: [
                                    'Apabila Tertanggung Utama memenuhi kriteria salah satu dari 32 Kondisi Kritis, pada saat ',{text:'PRU', font:'frutiger'}, {text:'juvenile crisis cover', font: 'garamount'},' telah berlaku selama 90 hari atau lebih, dan usia Tertanggung Utama tidak melebihi 18 tahun, dibayarkan ',
                                    '\nUang Pertanggungan ',{text:'PRU', font:'frutiger'}, {text:'juvenile crisis cover', font: 'garamount'},' yang tidak akan mengurangi Uang Pertanggungan Asuransi Dasar PAA.',
                                    ],
                                },
                            ]
                        },
                    ]
                }]);
            }else if(productCode == 'W3BR' ||productCode == 'W3BD'){
                body.push([{
                    margin: [0,0,0,5],
                    columns: [
                        {
                          text: [{text:'PRU', font:'frutiger'}, {text:'early stage payor', font: 'garamount'}], width: 200,
                        },
                        {
                            stack: [
                                { text: [
                                    'Apabila Tertanggung Utama memenuhi kriteria salah satu dari 33 Kondisi Kritis baik stadium awal (38 jenis kondisi), stadium menengah (26 jenis kondisi) ataupun stadium akhir (48 jenis kondisi), setelah ',{text:'PRU', font:'frutiger'}, {text:'early stage payor', font: 'garamount'},
                                    '\nberlaku selama 90 hari atau lebih, Penanggung akan membayarkan Premi Berkala & Premi Top-up Berkala (',{text:'PRU', font:'frutiger'}, {text:'saver', font: 'garamount'},') jika ada selama periode tertentu maksimal s.d usia Tertanggung Utama '+''+term+''+' tahun. ',
                                    '\nPenanggung akan membayarkan Premi Berkala & Premi Top-up Berkala (',{text:'PRU', font:'frutiger'}, {text:'saver', font: 'garamount'},') selama 2 tahun jika Tertanggung Utama terdiagnosa Kondisi Kritis stadium awal, 3 tahun jika terdiagnosa Kondisi Kritis stadium ',
                                    '\nmenengah, ataupun s.d usia '+''+term+''+' tahun jika terdiagnosa Kondisi Kritis stadium akhir.',
                                    ],
                                },
                            ]
                        },
                    ]
                }]);
            }else if(productCode == 'S1YR' ||productCode == 'S1YD'){
                body.push([{
                    margin: [0,0,0,5],
                    columns: [
                        {
                          text: [{text:'PRU', font:'frutiger'}, {text:'early stage spouse payor', font: 'garamount'}], width: 200,
                        },
                        {
                            stack: [
                                { text: [
                                    'Apabila Suami/Istri dari Tertanggung Utama memenuhi kriteria salah satu dari 33 Kondisi Kritis baik stadium awal (38 jenis kondisi), stadium menengah (26 jenis kondisi) ataupun stadium akhir (48 jenis kondisi) setelah ',
                                    '\n',{text:'PRU', font:'frutiger'}, {text:'early stage spouse payor', font: 'garamount'},' berlaku selama 90 hari atau lebih/Cacat Total dan Tetap, sebelum usia Suami/Istri dari Tertanggung Utama 70 tahun/meninggal dunia, Penanggung akan membayarkan Premi Berkala & Premi ',
                                    '\nTop-up Berkala (',{text:'PRU', font:'frutiger'}, {text:'early stage spouse payor', font: 'garamount'},') jika ada selama periode tertentu maksimal s.d usia Tertanggung Utama '+''+term+''+' tahun. Penanggung akan membayarkan Premi Berkala & Premi Top-up Berkala (',{text:'PRU', font:'frutiger'}, {text:'early stage spouse payor', font: 'garamount'},') selama 2 ',
                                    '\ntahun jika Suami/Istri dari Tertanggung Utama terdiagnosa Kondisi Kritis stadium awal, 3 tahun jika terdiagnosa Kondisi Kritis stadium menengah, ataupun s.d usia Tertanggung Utama '+''+term+''+' tahun jika terdiagnosa ',
                                    '\nKondisi Kritis stadium akhir/Cacat Total dan Tetap, sebelum usia Suami/Istri dari Tertanggung Utama 70 tahun/meninggal dunia.',
                                    ],
                                },
                            ]
                        },
                    ]
                }]);
            }else if(productCode == 'W3AR' ||productCode == 'W3AD'){
                body.push([{
                    margin: [0,0,0,5],
                    columns: [
                        {
                          text: [{text:'PRU', font:'frutiger'}, {text:'early stage parent payor', font: 'garamount'}], width: 200,
                        },
                        {
                            stack: [
                                { text: [
                                    'Apabila Ayah dan/atau Ibu dari Tertanggung Utama memenuhi kriteria salah satu dari 33 Kondisi Kritis baik stadium awal (38 jenis kondisi), stadium menengah (26 jenis kondisi) ataupun stadium akhir (48 jenis kondisi) ',
                                    '\nsetelah ',{text:'PRU', font:'frutiger'}, {text:'early stage parent payor', font: 'garamount'},' berlaku selama 90 hari atau lebih/Cacat Total dan Tetap, sebelum usia Ayah dan/atau Ibu dari Tertanggung Utama 70 tahun/meninggal dunia, Penanggung akan membayarkan ',
                                    '\nsebesar Premi Berkala & Premi Top-up Berkala (',{text:'PRU', font:'frutiger'}, {text:'early stage parent payor', font: 'garamount'},') selama periode tertentu maksimal s.d. usia Tertanggung Utama '+''+term+''+' tahun. Penanggung akan membayarkan Premi Berkala & Premi Top-up Berkala ',
                                    '\n(',{text:'PRU', font:'frutiger'}, {text:'early stage parent payor', font: 'garamount'},') selama 2 tahun jika Ayah dan/atau Ibu dari Tertanggung Utama terdiagnosa Kondisi Kritis stadium awal, 3 tahun jika terdiagnosa Kondisi Kritis stadium menengah, ataupun s.d usia Tertanggung Utama '+''+term+''+' tahun ',
                                    '\njika terdiagnosa Kondisi Kritis stadium akhir/Cacat Total dan Tetap, sebelum usia Ayah dan/atau Ibu dari Tertanggung Utama 70 tahun/meninggal dunia.',
                                    ],
                                },
                            ]
                        },
                    ]
                }]);
            }else if(productCode == 'C1WR' ||productCode == 'C1WD'){
                body.push([{
                    margin: [0,0,0,5],
                    columns: [
                        {
                          text: [{text:'PRU', font:'frutiger'}, {text:'crisis cover benefit plus 61', font: 'garamount'}], width: 200,
                        },
                        {
                            stack: [
                                { text: [
                                    'Apabila Tertanggung Utama memenuhi kriteria salah satu dari 61 Kondisi Kritis atau meninggal dunia, pada saat ',{text:'PRU', font:'frutiger'}, {text:'crisis cover benefit plus 61', font: 'garamount'},' telah berlaku selama 90 hari atau lebih, dan usia Tertanggung Utama tidak ',
                                    '\nmelebihi '+''+term+''+' tahun, dibayarkan Uang Pertanggungan ',{text:'PRU', font:'frutiger'}, {text:'crisis cover benefit plus 61', font: 'garamount'},' yang tidak akan mengurangi Uang Pertanggungan Asuransi Dasar PAA. Khusus untuk manfaat Angioplasti dan ',
                                    '\npenatalaksanaan invasif lainnya untuk pembuluh darah jantung, manfaat yang dibayarkan adalah 10% Uang Pertanggungan ',{text:'PRU', font:'frutiger'}, {text:'crisis cover benefit plus 61', font: 'garamount'},' hingga maksimal Rp 200 juta/USD 20,000.',                                    
                                    ],
                                },
                            ]
                        },
                    ]
                }]);
            }



         }

        // //console.log(body);
        // //console.log("====================== Ringkasan Manfaat 2 (END) =====================");
        return body.transpose();
    }
    //End Hal 2


    //------------------------------------------------------------------------------------------  ANGEN PRIANGGODO ------------------------------------------------------------------------------------------------
    //START FUNCTION TABEL PER FUND
    function getFund(mapOutput){
        var mapFund = mapOutput.output.output.FUNDMAP;
        var dataTopUp = mapOutput.dataTopUp;
        var dataPenarikan = mapOutput.dataPenarikan;
        var dataFund = mapOutput.dataFund;

        //console.log('mapFund == ',mapFund);
        ////console.log('dataTopUp == ',dataTopUp);
        ////console.log('dataPenarikan == ',dataPenarikan);
        ////console.log('dataFund == ',dataFund);
        var bdben = [];
        var body = [];

        for(var fundCd in mapFund){
            var fundObj = $rootScope.FUND[fundCd];
            var fundCode = fundObj.code;
            var fundname1 = fundObj.descriptionInd.substring(0,3);
            var fundname2 = fundObj.descriptionInd.substring(3,7);
            var fundname3 = fundObj.descriptionInd.substring(7);

            ////console.log('fundObj == ',fundObj);
            bdben = getCashValueOrDeathBenefit('CLIENT', mapFund[fundCd], dataTopUp, dataPenarikan, dataFund, fundCode, mapOutput.totalPenarikan);
            ////console.log(JSON.stringify(bdben.body1));
            //var bn1 = bdben.body1;
            var mapBody = [
                            {
                                columns: [
                                    { text: [{text:'PRU', font:'frutiger'}, {text:'link assurance account', font: 'garamount'}], fontSize: 19, width: 260},
                                    {
                                        width: '*',
                                        margin: [0,3,0,0],
                                        table: {
                                            widths: [ 'auto', 2],
                                            body: [
                                                    [{text:'RINGKASAN ILUSTRASI INI BUKAN MERUPAKAN SEBUAH KONTRAK ASURANSI', style: 'subheader', alignment:'center',margin:[30,0,30,0]}],
                                            ]
                                                                
                                        },
                                    },
                                ],
                            },
                            {text:['ILUSTRASI MANFAAT NILAI TUNAI - ', { text:fundname1, font: 'frutiger' },{text:fundname2, font: 'garamount'},fundname3], alignment:'left', margin: [0, 3, 0, 5], fontSize:10, bold: true},
                            
                            {
                                columns: [
                                    {
                                        style: 'hal3Table',
                                        headerRows: 3,
                                        alignment: 'center',
                                        margin: [0, -1, 10, 0],
                                        table: {
                                                widths: [20, 24, 40, 40, 40, '*' ,'*' ,'*'],
                                                body: [
                                                        [
                                                            {rowSpan: 3, text: 'Awal Tahun', margin:[0,12,0,0], alignment: 'center'},
                                                            {rowSpan: 3, text: 'Usia (Tahun) \n#', margin:[0,12,0,0], alignment: 'center'},
                                                            {colSpan: 3, text: 'RINGKASAN TRANSAKSI SESUAI MASA PEMBAYARAN PREMI YANG DIKEHENDAKI ('+mapOutput.rencanaPembayaran+' tahun)', alignment:'center', bold: true, alignment: 'center'}, '', '',
                                                            {colSpan: 3, text: 'ILUSTRASI MANFAAT', alignment: 'center', bold:true, alignment: 'center'},'','',
                                                        ],
                                                        [
                                                            '', '',
                                                            {rowSpan: 2, text:'Premi pada awal tahun \n(000)', alignment: 'center'},
                                                            {rowSpan: 2, text:'Top-Up premi tunggal \n(000)', alignment: 'center'},
                                                            {rowSpan: 2, text:'Penarikan \n(000)', alignment: 'center'},
                                                            {colSpan: 3, text: 'Nilai Tunai (000) merupakan nilai pada akhir tahun polis. Sesuai Masa Pembayaran Premi yang dikehendaki ('+mapOutput.rencanaPembayaran+' tahun)', alignment: 'center'},
                                                            '','',
                                                        ],
                                                        ['','','', '', '',{text:'Rendah', alignment: 'center'}, {alignment: 'center',text:'sedang'}, {text:'Tinggi', alignment: 'center'}],
                                                ]
                                        },
                                        layout: {
                                                        hLineWidth: function(i, node) {
                                                                return (i === 0 || i === node.table.body.length) ? 1 : 1;
                                                        },
                                                        vLineWidth: function(i, node) {
                                                                return (i === 0 || i === node.table.widths.length) ? 1: 1;
                                                        },
                                                        hLineColor: function(i, node) {
                                                                return (i === 0 || i === node.table.body.length) ? 'black' : 'black';
                                                        },
                                                        vLineColor: function(i, node) {
                                                                return (i === 0 || i === node.table.widths.length) ? 'black' : 'black';
                                                        },
                                            paddingLeft: function(i, node) { return 1; },
                                            paddingRight: function(i, node) { return 1; },
                                            paddingTop: function(i, node) { return 1; },
                                            paddingBottom: function(i, node) { return 1 },
                                        }
                                    },
                                    {
                                        style: 'hal3Table',
                                        headerRows: 3,
                                        alignment: 'center',
                                        margin: [0, -1, 10, 0],
                                        table: {
                                                widths: [20, 24, 40, 40, 40, '*' ,'*' ,'*'],
                                                body: [
                                                        [
                                                            {rowSpan: 3, text: 'Awal Tahun', margin:[0,12,0,0], alignment: 'center'},
                                                            {rowSpan: 3, text: 'Usia (Tahun) \n#', margin:[0,12,0,0], alignment: 'center'},
                                                            {colSpan: 3, text: 'RINGKASAN TRANSAKSI SESUAI MASA PEMBAYARAN PREMI YANG DIKEHENDAKI (99 tahun)', alignment:'center', bold: true, alignment: 'center'}, '', '',
                                                            {colSpan: 3, text: 'ILUSTRASI MANFAAT', alignment: 'center', bold:true, alignment: 'center'},'','',
                                                        ],
                                                        [
                                                            '', '',
                                                            {rowSpan: 2, text:'Premi pada awal tahun \n(000)', alignment: 'center'},
                                                            {rowSpan: 2, text:'Top-Up premi tunggal \n(000)', alignment: 'center'},
                                                            {rowSpan: 2, text:'Penarikan \n(000)', alignment: 'center'},
                                                            {colSpan: 3, text: 'Nilai Tunai (000) merupakan nilai pada akhir tahun polis. Sesuai Masa Pembayaran Premi yang dikehendaki (99 tahun)', alignment: 'center'},
                                                            '','',
                                                        ],
                                                        ['','','', '', '',{text:'Rendah', alignment: 'center'}, {alignment: 'center',text:'sedang'}, {text:'Tinggi', alignment: 'center'}],
                                                ]
                                        },
                                        layout: {
                                                        hLineWidth: function(i, node) {
                                                                return (i === 0 || i === node.table.body.length) ? 1 : 1;
                                                        },
                                                        vLineWidth: function(i, node) {
                                                                return (i === 0 || i === node.table.widths.length) ? 1: 1;
                                                        },
                                                        hLineColor: function(i, node) {
                                                                return (i === 0 || i === node.table.body.length) ? 'black' : 'black';
                                                        },
                                                        vLineColor: function(i, node) {
                                                                return (i === 0 || i === node.table.widths.length) ? 'black' : 'black';
                                                        },
                                            paddingLeft: function(i, node) { return 1; },
                                            paddingRight: function(i, node) { return 1; },
                                            paddingTop: function(i, node) { return 1; },
                                            paddingBottom: function(i, node) { return 1 },
                                        }
                                    },
                                ]
                            },
                            {
                                columns: [
                                        {
                                            style: 'hal3Table',
                                            margin: [0, -1, 10, 0],
                                            table: {
                                                    widths: [20, 24, 40, 40, 40, '*' ,'*' ,'*'],
                                                    body: bdben[0]
                                            },
                                            layout: {
                                                        hLineWidth: function(i, node) {
                                                                return (i === 0 || i === node.table.body.length) ? 1 : 1;
                                                        },
                                                        vLineWidth: function(i, node) {
                                                                return (i === 0 || i === node.table.widths.length) ? 1: 1;
                                                        },
                                                        hLineColor: function(i, node) {
                                                                return (i === 0 || i === node.table.body.length) ? 'black' : 'white';
                                                        },
                                                        vLineColor: function(i, node) {
                                                                return (i === 0 || i === node.table.widths.length) ? 'black' : 'black';
                                                        },
                                                                        paddingLeft: function(i, node) { return 1; },
                                                                        paddingRight: function(i, node) { return 1; },
                                                                        paddingTop: function(i, node) { return 1; },
                                                                        paddingBottom: function(i, node) { return 1 },
                                            }
                                        },
                                        {
                                            style: 'hal3Table',
                                            margin: [0, -1, 10, 0],
                                            table: {
                                                    widths: [20, 24, 40, 40, 40, '*' ,'*' ,'*'],
                                                    body: bdben[1]
                                            },
                                            layout: {
                                                        hLineWidth: function(i, node) {
                                                                return (i === 0 || i === node.table.body.length) ? 1 : 1;
                                                        },
                                                        vLineWidth: function(i, node) {
                                                                return (i === 0 || i === node.table.widths.length) ? 1: 1;
                                                        },
                                                        hLineColor: function(i, node) {
                                                                return (i === 0 || i === node.table.body.length) ? 'black' : 'white';
                                                        },
                                                        vLineColor: function(i, node) {
                                                                return (i === 0 || i === node.table.widths.length) ? 'black' : 'black';
                                                        },
                                                                        paddingLeft: function(i, node) { return 1; },
                                                                        paddingRight: function(i, node) { return 1; },
                                                                        paddingTop: function(i, node) { return 1; },
                                                                        paddingBottom: function(i, node) { return 1 },
                                            }
                                        },
                                    ]
                            },
                            {
                                columns: [
                                    { 
                                        stack: [
                                            { text: 'Asumsi tingkat hasil investasi yang digunakan adalah sebagai berikut:', alignment: 'left'},
                                            {
                                                table: {
                                                    widths: [180,30,30,30],
                                                    body: [
                                                            ['Dana Investasi','Rendah**', 'Sedang**', 'Tinggi**'],
                                                            [fundObj.descriptionInd, fundObj.lowRate + ' %', fundObj.mediumRate + ' %', fundObj.highRate + ' %'],
                                                    ]
                                                }, 
                                                layout: {
                                                paddingLeft: function(i, node) { return 1; },
                                                paddingRight: function(i, node) { return 1; },
                                                paddingTop: function(i, node) { return 1; },
                                                paddingBottom: function(i, node) { return 1 },
                                            } 
                                            },
                                            'Biaya Pengelolaan Dana Investasi : 2,0% atau jumlah lain sampai dengan 2% sebagaimana diatur dalam polis asuransi Anda (jika pengajuan Anda disetujui)',
                                            '# Masa Asuransi sampai dengan Tertanggung Utama mencapai usia 99 tahun',
                                            '** Asumsi tinggi rendahnya tingkat hasil investasi ini hanya bertujuan untuk ilustrasi saja dan bukan merupakan tolok ukur untuk perhitungan rata-rata tingkat hasil investasi yang terendah dan tertinggi. ',
                                            'Lihat keterangan no. 5 pada "Hal-hal penting" di halaman terakhir.',
                                        ]
                                    },
                                    {
                                        stack: [
                                            '*** Menunjukkan bahwa Nilai Tunai pada tahun tersebut tidak mencukupi untuk membayar Biaya Asuransi dan Administrasi, dan oleh karena itu Polis akan batal (lapse). Supaya Manfaat Polis dapat terus berlanjut, maka Anda diminta untuk melanjutkan pembayaran premi tahunan seperti dinyatakan dalam ilustrasi ini.',
                                            {text:['']},
                                        ]
                                    },
                                ],
                            },
                            {
                                stack:[
                                    /*{
                                        margin:[0,-10,0,-10],
                                        table: {
                                                widths: ['*'],
                                                body: [[' '], [' ']]
                                        },
                                        layout:lineFullWidth()
                                    },*/
                                    {
                                        pageBreak: 'after',
                                        absolutePosition : { x :25,y :525 },
                                        columns: [
                                            {
                                                table: {
                                                        body: [
                                                                ['Disajikan',mapOutput.agentName,''],
                                                                [{text:'Tanggal', margin: [0,0,0,16]},{text: mapOutput.QuotationDate},''],
                                                                ['','',''],
                                                                ['','',''],
                                                                [ mapOutput.docIdStandard, mapOutput.versi, {text: mapOutput.substandardValue, fontSize: 5, margin:[0,-3,0,0]} ],
                                                        ]            
                                                },layout: whiteNoSpace()
                                            },
                                            {
                                                
                                                table: {
                                                        body: [
                                                                [{text:'Kode Agen/FSC', margin: [100,0,50,24]},mapOutput.agentId,''],
                                                                ['','',''],
                                                                ['','',''],
                                                                ['','',''],
                                                                ['','',''],
                                                        ]            
                                                },layout: whiteNoSpace()
                                            },
                                        ],
                                    }
                                ]
                            },
                        ];
            body.push(mapBody);
        }
        return body;
    }

    //END FUNCTION TABLE PER FUND

    //START FUNCTION TABEL NILAI TOTAL FUND
    function getCashValueOrDeathBenefit(type, tmpClientBenefit, dataTopUp, dataPenarikan, dataFund, fundCode, totalPenarikan){

        //console.log(dataTopUp);
        //console.log(dataPenarikan);
        //console.log(dataFund);
        //console.log(fundCode);

        var body1 = [];        
		var body2 = [];
        var allbody = [];
        var nilaiTopup;
        var nilaiTarik;
        var percentage = 1;
        if(fundCode != ''){
            for (fund = 0; fund < dataFund.length; fund++){
                var data = dataFund[fund].split('|');
                if(fundCode == data[0]){
                    percentage = parseInt(data[1])/100;
                }
            }
        }

        for(var i = 0; i < tmpClientBenefit.length; i++){
            if((i >= 0 && i <= 29) || (parseInt(tmpClientBenefit[i].year) % 5 == 0)){

                var tmp = tmpClientBenefit[i];
                ////console.log("tmpClientBenefit[i] ", tmpClientBenefit[i]);
                var tmpBenefit1 = {};
                var tmpBenefit2 = {};
                
                //implement topup

                if(dataTopUp != undefined){
                    for(topup = 0; topup < dataTopUp.length; topup++){
                        var data = dataTopUp[topup].split('|');
                        //console.log('data topup == ',data);
                        if(data[0] == tmp.year){
                            nilaiTopup = (parseFloat(data[1])*percentage)/1000;
                            break;
                        }else{
                            nilaiTopup = '';
                        }
                    }    
                }

                //console.log('nilai topup '+i + ' == ',nilaiTopup);

                //implement penarikan

                if(dataPenarikan != undefined){
                    for(tarik = 0; tarik < dataPenarikan.length; tarik++){
                        var data = dataPenarikan[tarik].split('|');
                        //console.log('data tarik == ',data);
                        if(data[0] == tmp.year){
                            nilaiTarik = (parseFloat(data[1])*percentage)/1000;
                            break;
                        }else{
                            nilaiTarik = '';
                        }
                    }    
                }

                ////console.log('nilai tarik '+i + ' == ',nilaiTarik);

                tmpBenefit1 = {
                    year : tmp.year,
                    customerAge : tmp.customerAge,
                    premi : tmp.premiClient,
                    low : tmp.lowClient,
                    med : tmp.medClient,
                    high : tmp.highClient,
                    topup : nilaiTopup==undefined?'':nilaiTopup,
                    tarik : nilaiTarik==undefined?'':nilaiTarik
                };

                tmpBenefit2 = {
                    year : tmp.year,
                    customerAge : tmp.customerAge,
                    premi : tmp.premiAlt,
                    low : tmp.lowAlt,
                    med : tmp.medAlt,
                    high : tmp.highAlt,
                    topup : nilaiTopup==undefined?'':nilaiTopup,
                    tarik : nilaiTarik==undefined?'':nilaiTarik
                };

                /*if(type == 'CLIENT'){
                    tmpBenefit = {
                        year : tmp.year,
                        customerAge : tmp.customerAge,
                        premi : tmp.premiClient,
                        low : tmp.lowClient,
                        med : tmp.medClient,
                        high : tmp.highClient,
                        topup : nilaiTopup==undefined?'':nilaiTopup,
                        tarik : nilaiTarik==undefined?'':nilaiTarik
                    };
                }else{
                    tmpBenefit = {
                        year : tmp.year,
                        customerAge : tmp.customerAge,
                        premi : tmp.premiAlt,
                        low : tmp.lowAlt,
                        med : tmp.medAlt,
                        high : tmp.highAlt,
                        topup : nilaiTopup==undefined?'':nilaiTopup,
                        tarik : nilaiTarik==undefined?'':nilaiTarik
                    };
                }*/

                ////console.log('tmpBenefit == ',tmpBenefit);

                if(parseInt(tmpBenefit1.year) <= 10 && parseFloat(totalPenarikan) == 0){
                    body1.push([
                        {
                            text : tmpBenefit1.year, alignment : 'center'
                        },
                        {
                            text : tmpBenefit1.customerAge, alignment : 'center'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit1.premi))==true?'':parseFloat(tmpBenefit1.premi).format(), alignment : 'right'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit1.topup))==true?'':parseFloat(tmpBenefit1.topup).format(), alignment : 'right'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit1.tarik))==true?'':parseFloat(tmpBenefit1.tarik).format(), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit1.low).format(), alignment:'right'
                            text : (tmpBenefit1.low <= 0) ? '0' : parseFloat(tmpBenefit1.low).format(formatCurr), alignment:'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit1.med).format(), alignment : 'right'
                            text : (tmpBenefit1.med <= 0) ? '0' : parseFloat(tmpBenefit1.med).format(formatCurr), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit1.high).format(), alignment : 'right'
                            text : (tmpBenefit1.high <= 0) ? '0' : parseFloat(tmpBenefit1.high).format(formatCurr), alignment : 'right'
                        }
                    ]);
                }else if(parseInt(tmpBenefit1.year) <= 10 && parseFloat(totalPenarikan) > 0){
                    body1.push([
                        {
                            text : tmpBenefit1.year, alignment : 'center'
                        },
                        {
                            text : tmpBenefit1.customerAge, alignment : 'center'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit1.premi))==true?'':parseFloat(tmpBenefit1.premi).format(), alignment : 'right'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit1.topup))==true?'':parseFloat(tmpBenefit1.topup).format(), alignment : 'right'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit1.tarik))==true?'':parseFloat(tmpBenefit1.tarik).format(), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit1.low).format(), alignment:'right'
                            text : (tmpBenefit1.low <= 0) ? '0' : parseFloat(tmpBenefit1.low).format(formatCurr), alignment:'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit1.med).format(), alignment : 'right'
                            text : (tmpBenefit1.med <= 0) ? '0' : parseFloat(tmpBenefit1.med).format(formatCurr), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit1.high).format(), alignment : 'right'
                            text : (tmpBenefit1.high <= 0) ? '0' : parseFloat(tmpBenefit1.high).format(formatCurr), alignment : 'right'
                        }
                    ]);
                }else{
                    body1.push([
                        {
                            text : tmpBenefit1.year, alignment : 'center'
                        },
                        {
                            text : tmpBenefit1.customerAge, alignment : 'center'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit1.premi))==true?'':parseFloat(tmpBenefit1.premi).format(), alignment : 'right'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit1.topup))==true?'':parseFloat(tmpBenefit1.topup).format(), alignment : 'right'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit1.tarik))==true?'':parseFloat(tmpBenefit1.tarik).format(), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit1.low).format(), alignment:'right'
                            text : (tmpBenefit1.low <= 0) ? '***' : parseFloat(tmpBenefit1.low).format(formatCurr), alignment:'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit1.med).format(), alignment : 'right'
                            text : (tmpBenefit1.med <= 0) ? '***' : parseFloat(tmpBenefit1.med).format(formatCurr), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit1.high).format(), alignment : 'right'
                            text : (tmpBenefit1.high <= 0) ? '***' : parseFloat(tmpBenefit1.high).format(formatCurr), alignment : 'right'
                        }
                    ]);
                }
                

                if(parseInt(tmpBenefit2.year) <= 10 && parseFloat(totalPenarikan) == 0){
                    body2.push([
                        {
                            text : tmpBenefit2.year, alignment : 'center'
                        },
                        {
                            text : tmpBenefit2.customerAge, alignment : 'center'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit2.premi))==true?'':parseFloat(tmpBenefit2.premi).format(), alignment : 'right'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit2.topup))==true?'':parseFloat(tmpBenefit2.topup).format(), alignment : 'right'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit2.tarik))==true?'':parseFloat(tmpBenefit2.tarik).format(), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit2.low).format(), alignment:'right'
                            text : (tmpBenefit2.low <= 0) ? '0' : parseFloat(tmpBenefit2.low).format(formatCurr), alignment:'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit2.med).format(), alignment : 'right'
                            text : (tmpBenefit2.med <= 0) ? '0' : parseFloat(tmpBenefit2.med).format(formatCurr), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit2.high).format(), alignment : 'right'
                            text : (tmpBenefit2.high <= 0) ? '0' : parseFloat(tmpBenefit2.high).format(formatCurr), alignment : 'right'
                        }
                    ]);                    
                }else if(parseInt(tmpBenefit2.year) <= 10 && parseFloat(totalPenarikan) > 0){
                    body2.push([
                        {
                            text : tmpBenefit2.year, alignment : 'center'
                        },
                        {
                            text : tmpBenefit2.customerAge, alignment : 'center'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit2.premi))==true?'':parseFloat(tmpBenefit2.premi).format(), alignment : 'right'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit2.topup))==true?'':parseFloat(tmpBenefit2.topup).format(), alignment : 'right'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit2.tarik))==true?'':parseFloat(tmpBenefit2.tarik).format(), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit2.low).format(), alignment:'right'
                            text : (tmpBenefit2.low <= 0) ? '0' : parseFloat(tmpBenefit2.low).format(formatCurr), alignment:'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit2.med).format(), alignment : 'right'
                            text : (tmpBenefit2.med <= 0) ? '0' : parseFloat(tmpBenefit2.med).format(formatCurr), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit2.high).format(), alignment : 'right'
                            text : (tmpBenefit2.high <= 0) ? '0' : parseFloat(tmpBenefit2.high).format(formatCurr), alignment : 'right'
                        }
                    ]);
                }else{
                    body2.push([
                        {
                            text : tmpBenefit2.year, alignment : 'center'
                        },
                        {
                            text : tmpBenefit2.customerAge, alignment : 'center'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit2.premi))==true?'':parseFloat(tmpBenefit2.premi).format(), alignment : 'right'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit2.topup))==true?'':parseFloat(tmpBenefit2.topup).format(), alignment : 'right'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit2.tarik))==true?'':parseFloat(tmpBenefit2.tarik).format(), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit2.low).format(), alignment:'right'
                            text : (tmpBenefit2.low <= 0) ? '***' : parseFloat(tmpBenefit2.low).format(formatCurr), alignment:'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit2.med).format(), alignment : 'right'
                            text : (tmpBenefit2.med <= 0) ? '***' : parseFloat(tmpBenefit2.med).format(formatCurr), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit2.high).format(), alignment : 'right'
                            text : (tmpBenefit2.high <= 0) ? '***' : parseFloat(tmpBenefit2.high).format(formatCurr), alignment : 'right'
                        }
                    ]);                    
                }    

            }
            if(body1.length == 32){
                break;
            }
        }
        ////console.log("allbody.body1 ", body1);
        allbody.push(body1);
        allbody.push(body2);
        return allbody;
    }
    //END FUNCTION TABEL NILAI TOTAL FUND

    function getFundAndRate(mapOutput){
        var mapFund = mapOutput.output.output.FUNDMAP;
        var body = [];
        var tmp = ['Dana Investasi','Rendah**', 'Sedang**', 'Tinggi**'];
        body.push(tmp);

        for(var fundCd in mapFund){
            var fundObj = $rootScope.FUND[fundCd];
            tmp = [fundObj.descriptionInd, fundObj.lowRate + ' %', fundObj.mediumRate + ' %', fundObj.highRate + ' %'];
            // tmp.push([
            //     fundObj.descriptionInd
            // ]);
            // tmp.push([
            //     fundObj.lowRate + ' %'
            // ]);
            // tmp.push([
            //     fundObj.mediumRate + ' %'
            // ]);
            // tmp.push([
            //     fundObj.highRate + ' %'
            // ]);
            body.push(tmp);
        }
        // //console.log(body);
        return body;
    }

    ////////////////HALAMAN Pru H - S

        var PruHSManfaat = {
            'A1':'250|425|600|900|1200|1800|2350|3000',
            'A2':'500|850|1200|1800|2400|3600|4700|6000',
            'A3':'100|150|200|300|450|500|600|700',
            'A4':'150|175|250|375|500|750|1000|1250',
            'A51':'30000|50000|70000|105000|140000|210000|280000|350000',
            'A52':'16500|30000|45000|65000|85000|125000|170000|210000',
            'A53':'10500|18500|27500|40000|55000|80000|105000|150000',
            'A54':'6000|10000|15000|25000|30000|45000|56000|70000',
            'A6':'4500|7500|10000|15000|21500|32500|43000|50000',
            'A7':'115|200|300|350|350|350|350|350',
            'A8':'230|300|400|450|550|700|900|1150',
            'A9':'720|1250|1800|2700|3600|5400|7200|9000',
            'A10':'720|1250|1800|2700|3600|5400|7200|9000',
            'A11':'50|100|125|200|250|375|500|625',
            'A12':'300|350|400|450|500|550|600|650',
            'B1':'2000|3500|5000|7500|10000|15000|20000|25000',
            'B2':'21600|37800|54000|81000|108000|162000|216000|270000',
            'B3':'6000|10500|15000|22500|30000|45000|60000|75000',
            'C1':'12500|15000|25000|30000|35000|40000|45000|50000',
    }

    function PRUHSManfaatNilai(mapOutput){

        var A1_array = PruHSManfaat.A1.split('|');
        var A2_array = PruHSManfaat.A2.split('|');
        var A3_array = PruHSManfaat.A3.split('|');
        var A4_array = PruHSManfaat.A4.split('|');
        var A51_array = PruHSManfaat.A51.split('|');
        var A52_array = PruHSManfaat.A52.split('|');
        var A53_array = PruHSManfaat.A53.split('|');
        var A54_array = PruHSManfaat.A54.split('|');
        var A6_array = PruHSManfaat.A6.split('|');
        var A7_array = PruHSManfaat.A7.split('|');
        var A8_array = PruHSManfaat.A8.split('|');
        var A9_array = PruHSManfaat.A9.split('|');
        var A10_array = PruHSManfaat.A10.split('|');
        var A11_array = PruHSManfaat.A11.split('|');
        var A12_array = PruHSManfaat.A12.split('|');
        var B1_array = PruHSManfaat.B1.split('|');
        var B2_array = PruHSManfaat.B2.split('|');
        var B3_array = PruHSManfaat.B3.split('|');
        var C1_array = PruHSManfaat.C1.split('|');

        for(var x = 0; x < mapOutput.manfaatList.length; x++){
            var productName = mapOutput.manfaatList[x].name;
            var productCode = mapOutput.manfaatList[x].code;
            var coverageType = mapOutput.manfaatList[x].coverageType;
            var value = mapOutput.manfaatList[x].itemInput[0].inputValue;
            var term = mapOutput.manfaatList[x].term;


            if(productCode == 'H1TR'){
                //PRU Hospital And surgical Plus

                if(value == 'A'){
                    mapOutput.A1_value = A1_array[0];
                    mapOutput.A2_value = A2_array[0];
                    mapOutput.A3_value = A3_array[0];
                    mapOutput.A4_value = A4_array[0];
                    mapOutput.A51_value = A51_array[0];
                    mapOutput.A52_value = A52_array[0];
                    mapOutput.A53_value = A53_array[0];
                    mapOutput.A54_value = A54_array[0];
                    mapOutput.A6_value = A6_array[0];
                    mapOutput.A7_value = A7_array[0];
                    mapOutput.A8_value = A8_array[0];
                    mapOutput.A9_value = A9_array[0];
                    mapOutput.A10_value = A10_array[0];
                    mapOutput.A11_value = A11_array[0];
                    mapOutput.A12_value = A12_array[0];
                    mapOutput.B1_value = B1_array[0];
                    mapOutput.B2_value = B2_array[0];
                    mapOutput.B3_value = B3_array[0];
                    mapOutput.C1_value = C1_array[0];
                    mapOutput.totalManfaatPRUHS = 135000;

                }else if(value == 'B'){
                    mapOutput.A1_value = A1_array[1];
                    mapOutput.A2_value = A2_array[1];
                    mapOutput.A3_value = A3_array[1];
                    mapOutput.A4_value = A4_array[1];
                    mapOutput.A51_value = A51_array[1];
                    mapOutput.A52_value = A52_array[1];
                    mapOutput.A53_value = A53_array[1];
                    mapOutput.A54_value = A54_array[1];
                    mapOutput.A6_value = A6_array[1];
                    mapOutput.A7_value = A7_array[1];
                    mapOutput.A8_value = A8_array[1];
                    mapOutput.A9_value = A9_array[1];
                    mapOutput.A10_value = A10_array[1];
                    mapOutput.A11_value = A11_array[1];
                    mapOutput.A12_value = A12_array[1];
                    mapOutput.B1_value = B1_array[1];
                    mapOutput.B2_value = B2_array[1];
                    mapOutput.B3_value = B3_array[1];
                    mapOutput.C1_value = C1_array[1];
                    mapOutput.totalManfaatPRUHS = 200000;

                }else if(value == 'C'){
                    mapOutput.A1_value = A1_array[2];
                    mapOutput.A2_value = A2_array[2];
                    mapOutput.A3_value = A3_array[2];
                    mapOutput.A4_value = A4_array[2];
                    mapOutput.A51_value = A51_array[2];
                    mapOutput.A52_value = A52_array[2];
                    mapOutput.A53_value = A53_array[2];
                    mapOutput.A54_value = A54_array[2];
                    mapOutput.A6_value = A6_array[2];
                    mapOutput.A7_value = A7_array[2];
                    mapOutput.A8_value = A8_array[2];
                    mapOutput.A9_value = A9_array[2];
                    mapOutput.A10_value = A10_array[2];
                    mapOutput.A11_value = A11_array[2];
                    mapOutput.A12_value = A12_array[2];
                    mapOutput.B1_value = B1_array[2];
                    mapOutput.B2_value = B2_array[2];
                    mapOutput.B3_value = B3_array[2];
                    mapOutput.C1_value = C1_array[2];
                    mapOutput.totalManfaatPRUHS = 300000;

                }else if(value == 'D'){
                    mapOutput.A1_value = A1_array[3];
                    mapOutput.A2_value = A2_array[3];
                    mapOutput.A3_value = A3_array[3];
                    mapOutput.A4_value = A4_array[3];
                    mapOutput.A51_value = A51_array[3];
                    mapOutput.A52_value = A52_array[3];
                    mapOutput.A53_value = A53_array[3];
                    mapOutput.A54_value = A54_array[3];
                    mapOutput.A6_value = A6_array[3];
                    mapOutput.A7_value = A7_array[3];
                    mapOutput.A8_value = A8_array[3];
                    mapOutput.A9_value = A9_array[3];
                    mapOutput.A10_value = A10_array[3];
                    mapOutput.A11_value = A11_array[3];
                    mapOutput.A12_value = A12_array[3];
                    mapOutput.B1_value = B1_array[3];
                    mapOutput.B2_value = B2_array[3];
                    mapOutput.B3_value = B3_array[3];
                    mapOutput.C1_value = C1_array[3];
                    mapOutput.totalManfaatPRUHS = 450000;

                }else if(value == 'E'){
                    mapOutput.A1_value = A1_array[4];
                    mapOutput.A2_value = A2_array[4];
                    mapOutput.A3_value = A3_array[4];
                    mapOutput.A4_value = A4_array[4];
                    mapOutput.A51_value = A51_array[4];
                    mapOutput.A52_value = A52_array[4];
                    mapOutput.A53_value = A53_array[4];
                    mapOutput.A54_value = A54_array[4];
                    mapOutput.A6_value = A6_array[4];
                    mapOutput.A7_value = A7_array[4];
                    mapOutput.A8_value = A8_array[4];
                    mapOutput.A9_value = A9_array[4];
                    mapOutput.A10_value = A10_array[4];
                    mapOutput.A11_value = A11_array[4];
                    mapOutput.A12_value = A12_array[4];
                    mapOutput.B1_value = B1_array[4];
                    mapOutput.B2_value = B2_array[4];
                    mapOutput.B3_value = B3_array[4];
                    mapOutput.C1_value = C1_array[4];
                    mapOutput.totalManfaatPRUHS = 550000;

                }else if(value == 'F'){
                    mapOutput.A1_value = A1_array[5];
                    mapOutput.A2_value = A2_array[5];
                    mapOutput.A3_value = A3_array[5];
                    mapOutput.A4_value = A4_array[5];
                    mapOutput.A51_value = A51_array[5];
                    mapOutput.A52_value = A52_array[5];
                    mapOutput.A53_value = A53_array[5];
                    mapOutput.A54_value = A54_array[5];
                    mapOutput.A6_value = A6_array[5];
                    mapOutput.A7_value = A7_array[5];
                    mapOutput.A8_value = A8_array[5];
                    mapOutput.A9_value = A9_array[5];
                    mapOutput.A10_value = A10_array[5];
                    mapOutput.A11_value = A11_array[5];
                    mapOutput.A12_value = A12_array[5];
                    mapOutput.B1_value = B1_array[5];
                    mapOutput.B2_value = B2_array[5];
                    mapOutput.B3_value = B3_array[5];
                    mapOutput.C1_value = C1_array[5];
                    mapOutput.totalManfaatPRUHS = 700000;

                }else if(value == 'G'){
                    mapOutput.A1_value = A1_array[6];
                    mapOutput.A2_value = A2_array[6];
                    mapOutput.A3_value = A3_array[6];
                    mapOutput.A4_value = A4_array[6];
                    mapOutput.A51_value = A51_array[6];
                    mapOutput.A52_value = A52_array[6];
                    mapOutput.A53_value = A53_array[6];
                    mapOutput.A54_value = A54_array[6];
                    mapOutput.A6_value = A6_array[6];
                    mapOutput.A7_value = A7_array[6];
                    mapOutput.A8_value = A8_array[6];
                    mapOutput.A9_value = A9_array[6];
                    mapOutput.A10_value = A10_array[6];
                    mapOutput.A11_value = A11_array[6];
                    mapOutput.A12_value = A12_array[6];
                    mapOutput.B1_value = B1_array[6];
                    mapOutput.B2_value = B2_array[6];
                    mapOutput.B3_value = B3_array[6];
                    mapOutput.C1_value = C1_array[6];
                    mapOutput.totalManfaatPRUHS = 900000;

                }else if(value == 'H'){
                    mapOutput.A1_value = A1_array[7];
                    mapOutput.A2_value = A2_array[7];
                    mapOutput.A3_value = A3_array[7];
                    mapOutput.A4_value = A4_array[7];
                    mapOutput.A51_value = A51_array[7];
                    mapOutput.A52_value = A52_array[7];
                    mapOutput.A53_value = A53_array[7];
                    mapOutput.A54_value = A54_array[7];
                    mapOutput.A6_value = A6_array[7];
                    mapOutput.A7_value = A7_array[7];
                    mapOutput.A8_value = A8_array[7];
                    mapOutput.A9_value = A9_array[7];
                    mapOutput.A10_value = A10_array[7];
                    mapOutput.A11_value = A11_array[7];
                    mapOutput.A12_value = A12_array[7];
                    mapOutput.B1_value = B1_array[7];
                    mapOutput.B2_value = B2_array[7];
                    mapOutput.B3_value = B3_array[7];
                    mapOutput.C1_value = C1_array[7];
                    mapOutput.totalManfaatPRUHS = 1200000;
                }

                break;

            }
        }

        return mapOutput;    
    }

    function pruHSOutput(mapOutput){
        PRUHSManfaatNilai(mapOutput);

        var body = [];
        var data = [
            {
                columns: [
                    { text: [{text:'PRU', font:'frutiger'}, {text:'link assurance account', font: 'garamount'}], fontSize: 19, width: 260},
                    {
                        width: '*',
                        margin: [0,3,0,0],
                        table: {
                            widths: [ 'auto', 2],
                            body: [
                                    [{text:'RINGKASAN ILUSTRASI INI BUKAN MERUPAKAN SEBUAH KONTRAK ASURANSI', style: 'subheader', alignment:'center',margin:[30,0,30,0]}],
                            ]
                                                
                        },
                    },
                ],
            },
            {text: ['MANFAAT',{text:'PRU', font:'frutiger'}, {text:'hospital & surgical cover plus', font: 'garamount'}], margin: [0, 3, 0, 5], fontSize:10, bold: true},
            {
                columns: [
                    {
                        stack: [

                            {
                                margin: [0, 0, 10, 0],
                                headerRows: 2,
                                style: 'hal3Table',
                                table: {
                                    widths: [10, 125, 155, '*'],
                                    body: [
                                        [{rowSpan: 2, text: 'No'},{text: 'Manfaat', alignment: 'center', bold: true}, {rowSpan: 2, text:'Deskripsi', alignment: 'center', bold: true}, {rowSpan: 2, text: 'Dalam Ribuan Rupiah', alignment: 'center', bold: true}],
                                        ['',{text: 'Rawat Inap', alignment: 'center', bold: true}, '', '',],
                                        [{text:'1', alignment:'center'},'Biaya kamar & akomodasinya','Per orang/hari-max 150 hari/tahun',{text: mapOutput.A1_value, alignment:'center'}],
                                        [{text:'2', alignment:'center'},'Biaya Unit Perawatan Intensif/Intensive Care Unit (ICU)','Per orang/hari-max 45 hari/tahun',{text: mapOutput.A2_value, alignment:'center'}],
                                        [{text:'3', alignment:'center'},'Biaya Kunjungan Dokter Umum','Max. 2 kunjungan per hari dan tidak melebihi 150 hari per tahun',{text: mapOutput.A3_value, alignment:'center'}],
                                        [{text:'4', alignment:'center'},'Biaya Kunjungan Dokter Spesialis','Max. 2 kunjungan per hari dan tidak melebihi 150 hari per tahun',{text: mapOutput.A4_value, alignment:'center'}],
                                        [{rowSpan: 5, text: '5', alignment:'center'},'Biaya Tindakan Bedah \n(Ahli Bedah, Kamar Operasi, Ahli Anastesi)','',''],
                                        ['','Tipe 4',{rowSpan: 4, text: 'Maksimal per 1 kali Tindakan Bedah'},{text: mapOutput.A51_value, alignment:'center'}],
                                        ['','Tipe 3','',{text: mapOutput.A52_value, alignment:'center'}],
                                        ['','Tipe 2','',{text: mapOutput.A53_value, alignment:'center'}],
                                        ['','Tipe 1','',{text: mapOutput.A54_value, alignment:'center'}],
                                        [{text:'6', alignment:'center'},'Biaya Aneka Perawatan Rumah Sakit','Max. per 1 kali ketidakmampuan',{text: mapOutput.A6_value, alignment:'center'}],
                                        [{text:'7', alignment:'center'},'Biaya Perawatan oleh Juru Rawat setelah Rawat Inap','Per hari, maksimal 120 hari per tahun dan tidak melebihi 180 hari selama berlakunya masa pertanggungan ',{text: mapOutput.A7_value, alignment:'center'}],
                                        [{text:'8', alignment:'center'},'Biaya Ambulan Lokal','Max. per 1 kali ketidakmampuan',{text: mapOutput.A8_value, alignment:'center'}],
                                        [{text:'9', alignment:'center'},'Biaya Perawatan sebelum Rawat Inap','Max. per 1 kali ketidakmampuan, maksimal 30 hari sebelum rawat inap',{text: mapOutput.A9_value, alignment:'center'}],
                                        [{text:'10', alignment:'center'},'Biaya Perawatan setelah Rawat Inap','Max. per 1 kali ketidakmampuan, 90 hari setelah rawat inap',{text: mapOutput.A10_value, alignment:'center'}],
                                        [{text:'11', alignment:'center'},'Biaya Pendamping untuk Tertanggung berusia dibawah 15 tahun','Per hari, maksimal 14 (empat belas) hari per tahun',{text: mapOutput.A11_value, alignment:'center'}],
                                        [{text:'12', alignment:'center'},'Biaya Fisioterapi','Per hari, maksimal 90 hari per tahun Polis, terjadi 30 hari sebelum rawat inap, selama rawat inap, dan 90 hari setelah rawat inap ',{text: mapOutput.A12_value, alignment:'center'}],
                                        ['',{text:'Rawat Jalan', alignment:'center', bold: true},'',''],
                                        [{text:'1', alignment:'center'},'Biaya Rawat Jalan Darurat (hanya untuk kecelakaan)','Max. per tahun Polis',{text: mapOutput.B1_value, alignment:'center'}],
                                        [{text:'2', alignment:'center'},'Biaya Perawatan Kanker','Max. per tahun Polis',{text: mapOutput.B2_value, alignment:'center'}],
                                        [{text:'3', alignment:'center'},'Biaya Perawatan Cuci Darah (Dialisis)','Max. per tahun Polis',{text: mapOutput.B3_value , alignment:'center'}],
                                        ['',{colSpan: 2, text:'Total Maksimal Manfaat Per Tahun', alignment: 'center', bold: true},''+mapOutput.totalManfaatPRUHS+'',{text:''+mapOutput.totalManfaatPRUHS+'', alignment:'center', bold: true}],
                                        ['',{text:'Manfaat Tambahan', bold: true},'','',],
                                        [{text:'1', alignment:'center'},'Manfaat Meninggal Dunia akibat Kecelakaan','Maksimal 90 hari setelah terjadinya kecelakaan',{text: mapOutput.C1_value, alignment:'center'}],
                                    ]
                                },
                                layout: {             
                                paddingLeft: function(i, node) { return 1; },
                                paddingRight: function(i, node) { return 1; },
                                paddingTop: function(i, node) { return 1; },
                                paddingBottom: function(i, node) { return 1 },
                                },
                            },
                            {text: 'Pengecualian', fontSize: 4, bold: true, margin:[0, 2, 0, 1]},
                            {text: ['Asuransi Tambahan ',{text:'PRU', font:'frutiger'}, {text:'hospital & surgical cover plus', font: 'garamount'},' tidak berlaku untuk hal-hal yang disebabkan secara langsung ataupun tidak langsung, sebagian atau seluruh, sebagaimana tercantum di bawah ini :'], fontSize: 5},
                            {
                                style: 'pengecualian',
                                table: {
                                    body: [
                                        ['1','Kondisi Yang Telah Ada Sebelumnya;'],
                                        ['2',{text: ['Rawat Inap atau Tindakan Bedah apa pun untuk Penyakit yang terjadi dalam 12 (dua belas) bulan pertama sejak Tanggal Mulai Pertanggungan Asuransi Tambahan ',{text:'PRU', font:'frutiger'}, {text:'hospital & surgical cover plus', font: 'garamount'},', atau tanggal Pemulihan Polis dan Asuransi Tambahan ',{text:'PRU', font:'frutiger'}, {text:'hospital & surgical cover plus', font: 'garamount'},' yang turut dipulihkan, tergantung tanggal mana yang paling akhir, baik Tertanggung telah mengetahui atau tidak mengetahui, yaitu: \nSemua jenis hernia; Semua jenis tumor jinak/benjolan/kista; Tuberkulosis; Wasir; Penyakit pada tonsil atau adenoid; Kondisi abnormal rongga hidung, sekat hidung atau kerang hidung (turbinates), termasuk sinus; Penyakit kelenjar gondok (tiroid); Hysterektomi (dengan atau tanpa salpingo - ooforektomi); Penyakit tekanan darah tinggi; Penyakit jantung dan pembuluh darah (kardiovaskuler); Fistula di anus; Batu pada sistem saluran empedu; Batu ginjal, saluran kemih atau kandung kemih; Katarak; Tukak pada lambung atau usus dua belas jari; Semua jenis kelainan sistem reproduksi, termasuk endometriosis, fibroid, atau miom di rahim; Diskus Intervertebrata yang menonjol; dan/atau Penyakit Kencing Manis;']}],
                                        ['3','Semua perawatan yang diperoleh di Amerika Serikat, Jepang dan Kanada, atau'],
                                        ['4','Setiap Ketidakmampuan  yang dimulai atau terjadi dalam Masa Tunggu kecuali diakibatkan oleh Kecelakaan;'],
                                        ['5','Biaya yang tidak sesuai dengan kenyataan dan keperluan, dan bukan Biaya Wajar Yang Dibebankan pada perawatan suatu Penyakit, Cedera, atau Ketidakmampuan, atau merupakan pilihan pembedahan atau perawatan yang tidak Diperlukan Secara Medis;'],
                                        ['6','Biaya yang timbul dari upaya donor organ dan jaringan tubuh;'],
                                        ['7','Rawat jalan atas Cedera, Penyakit, atau Ketidakmampuan yang tidak berhubungan dengan Cedera, Penyakit, atau Ketidakmampuan yang memerlukan Rawat Inap, kecuali rawat jalan yang disebabkan karena Kecelakaan atau rawat jalan yang merupakan bagian dari suatu Tindakan Bedah Rawat Jalan;'],
                                        ['8','Biaya Perawatan Sebelum Rawat Inap dan Biaya Perawatan Setelah Rawat Inap, sehubungan dengan Tindakan Bedah Rawat Jalan;'],
                                        ['9','Penyakit, Cedera, atau Ketidakmampuan yang disebabkan oleh tindakan percobaan bunuh diri atau pencederaan diri, baik dilakukan dalam keadaan waras ataupun tidak waras;'],
                                        ['10','Perawatan untuk mengatasi kegemukan, penurunan berat badan atau menambah berat badan, bulimia, anoreksia nervosa;'],
                                        ['11','Pemeriksaan mata, kesalahan refraksi mata termasuk rabun jauh (myopia), pembelian / penyewaan kacamata / lensa / alat bantu pendengaran;'],
                                        
                                    ]
                                },
                                layout: whiteNoSpace()
                            },
                        ],
                    },
                    {
                        stack: [
                            {
                                style: 'pengecualian',
                                table: {
                                    body: [
                                        ['12','Perawatan dan pembedahan perubahan jenis kelamin;'],
                                        ['13','Semua jenis perawatan, pemeriksaan, pengobatan atau pembedahan gigi termasuk bedah mulut, gusi, atau struktur penyangga gigi secara langsung, dan pengobatan yang berhubungan dengan gigi, kecuali yang diakibatkan oleh Kecelakaan;'],
                                        ['14','Pemasangan gigi palsu karena sebab apapun;'],
                                        ['15',{text: ['Kanker yang diketahui gejalanya oleh Peserta Yang Diasuransikan yang telah didiagnosis atau mendapat pengobatan dalam 90 (sembilan puluh) hari kalender sejak Tanggal Mulai Pertanggungan Asuransi Tambahan ',{text:'PRU', font:'frutiger'}, {text:'hospital & surgical cover plus', font: 'garamount'},', atau tanggal Pemulihan Polis terakhir, tergantung tanggal mana yang paling akhir;']}],
                                        ['16','Perawatan kehamilan/upaya untuk hamil, termasuk melahirkan, diagnosis dan perawatan ketidaksuburan, keguguran, aborsi, sterilisasi (vasektomi/MOP dan tubektomi/MOW) dan kontrasepsi, metode pengaturan kelahiran, pengujian atau pengobatan impotensi, termasuk semua komplikasi yang terjadi karenanya;'],
                                        ['17','Sunat dengan segala konsekuensi selain sunat yang dilaksanakan sehubungan dengan Kecelakaan atau Penyakit yang diderita oleh Peserta Yang Diasuransikan;'],
                                        ['18','Perawatan/pengobatan yang timbul sehubungan dengan atau yang diakibatkan oleh Kelainan Bawaan, cacat bawaan, atau penyakit keturunan, baik diketahui ataupun tidak diketahui;'],
                                        ['19','Tindakan Bedah yang dilakukan semata-mata keinginan Peserta Yang Diasuransikan tanpa ada Cedera atau Penyakit, pembedahan percobaan (explorative), pembedahan untuk tujuan kosmetik, atau pembedahan plastik, kecuali disebabkan oleh Cedera atau Penyakit;'],
                                        ['20','Biaya pemeriksaan kesehatan rutin (medical check up), biaya pemeriksaan atau pengobatan yang tidak berhubungan dengan diagnosis/alasan Rawat Inap, biaya rehabilitasi tanpa rekomendasi Dokter, biaya preventif atau pencegahan Penyakit, termasuk imunisasi dan vaksinasi, food supplement, biaya istirahat, biaya telekomunikasi, biaya penyewaan televisi berikut salurannya, biaya lemari pendingin termasuk isinya dan biaya lain yang tidak berhubungan dengan perawatan medis;'],
                                        ['21','Rawat Inap di Rumah Sakit yang bertujuan hanya untuk diagnostik, pemeriksaan sinar X, pemeriksaan fisik umum;'],
                                        ['22','Perawatan yang tidak dilakukan di Rumah Sakit atau Klinik, perawatan di spa/sauna/salon;'],
                                        ['23','Perawatan yang terjadi karena keadaan kesehatan yang berhubungan dengan proses penuaan usia lanjut (geriatrik) keadaan mental yang berhubungan dengan proses penuaan usia lanjut (psiko-geriatrik);'],
                                        ['24','Pengobatan Peserta Yang Diasuransikan yang berhubungan dengan kelainan jiwa, cacat mental, neurosis, psikosomatis, psikosis atau suatu pengobatan yang dilakukan di rumah sakit jiwa atau di bagian psikiatri suatu Rumah Sakit atau pengobatan yang dilakukan oleh seorang psikiater;'],
                                        ['25','Penyakit, Cedera atau Ketidakmampuan yang terjadi pada saat Peserta Yang Diasuransikan di bawah pengaruh narkotika, alkohol, psikotropika, racun, gas atau bahan sejenis, atau obat selain digunakan sebagai obat menurut resep yang dikeluarkan oleh Dokter;'],
                                        ['26','Cedera atau Penyakit yang timbul sebagai akibat langsung atau tidak langsung dari terorisme, perang, invasi, serangan musuh asing, tindak kekerasan perang baik yang diumumkan atau tidak diumumkan, perang sipil, pemberontakan, revolusi, keikutsertaan langsung dalam huruhara, perkelahian, pemogokan dan keributan massa, tindakan tentara atau militer, perampasan kekuasaan, atau tugas aktif dalam angkatan bersenjata atau kepolisian;'],
                                        ['27','Cedera atau Penyakit akibat reaksi nuklir, radiasi dan kontaminasinya;'],
                                        ['28','Semua Penyakit akibat hubungan seksual atau penyimpangan seksual;'],
                                        ['29','Peserta Yang Diasuransikan berpartisipasi dalam kegiatan berbahaya atau olahraga termasuk namun tidak terbatas pada jenis balap atau adu kecepatan (selain berjalan kaki atau berenang), potholing, panjat tebing, gunung, mendaki membutuhkan penggunaan tali atau panduan, menyelam ke kedalaman lebih dari 30 meter, kegiatan bawah air yang melibatkan penggunaan peralatan bawah air pernapasan, sky diving, cliff diving, bungee jumping, BASE jumping (Building Antena Span Earth), paralayang, gantole dan terjun payung;'],
                                        ['30','Cedera atau penyakit yang disebabkan oleh penerbangan atau kegiatan udara lainnya, kecuali sebagai penumpang yang terdaftar dalam manifes dengan membayar tarif pada maskapai penerbangan sipil komersial, atau perusahaan sewa yang mempunyai ijin dan beroperasi dalam penerbangan rutin; '],
                                        ['31','Cedera yang disebabkan oleh tindak pidana kejahatan atau percobaan tindak pidana kejahatan yang dilakukan oleh Peserta Yang Diasuransikan, kecuali dibuktikan sebaliknya dengan putusan pengadilan; '],
                                        ['32','Cedera yang disebabkan oleh tindak pidana pelanggaran atau tindak pidana percobaan pelanggaran oleh Peserta Yang Diasuransikan, kecuali dibuktikan sebaliknya dengan putusan pengadilan;'],
                                        ['33','Cedera yang disebabkan oleh pelanggaran peraturan perundang-undangan oleh Peserta Yang Diasuransikan, kecuali dibuktikan sebaliknya dengan putusan pengadilan;'],
                                        ['34','Cedera yang disebabkan oleh perlawanan oleh Peserta Yang Diasuransikan dalam hal terjadi penahanan Peserta Yang Diasuransikan atau orang lain oleh pihak yang berwenang;'],
                                        ['35','Biaya perawatan yang disebabkan oleh atau berhubungan dengan: Acquired Immune Deficiency Syndrome (AIDS); Infeksi karena Human Immuno-deficiency Virus (HIV); atau Penyakit lainnya yang disebabkan oleh atau komplikasi dari Penyakit AIDS dan atau HIV;'],
                                        ['36','Perawatan dan pengobatan eksperimental, tradisional dan/atau alternatif, yakni dan tidak terbatas pada sinshe, ahli patah tulang, paranormal, chiropractor, naturopati, holistik, akupuntur dan sejenisnya;'],
                                        ['37','Apabila Peserta Yang Diasuransikan meninggal dunia karena Kecelakaan oleh salah satu dari hal-hal sebagaimana dibawah ini, Pengelola tidak berkewajiban untuk melakukan pembayaran apa pun;'],
                                    ]
                                },
                                layout: whiteNoSpace()
                            },

                            { 
                                style: 'pengecualian',
                                margin: [12, 0, 0, 0],
                                type: 'upper-roman',
                                ol: [
                                    'perang, invasi, tindakan bermusuhan dari militer atau tentara asing baik dinyatakan maupun tidak dinyatakan, perang saudara, pemberontakan, revolusi, perlawanan terhadap pemerintah, perebutan kekuasaan oleh militer atau tentara, ikut serta dalam huru hara, pemogokan atau kerusuhan sipil;',
                                    'tindak pidana kejahatan atau percobaan tindak pidana kejahatan oleh pihak yang berhak atas Manfaat Asuransi, kecuali dibuktikan sebaliknya dengan putusan pengadilan;',
                                    'tindak pidana pelanggaran atau percobaan tindak pidana pelanggaran oleh atau pihak yang berhak atas Manfaat Asuransi, kecuali dibuktikan sebaliknya dengan putusan pengadilan; ',
                                    'perlawanan oleh Tertanggung dalam hal terjadi penahanan Tertanggung atau orang lain oleh pihak yang berwenang; ',
                                    'tindakan bunuh diri, percobaan bunuh diri atau pencederaan diri oleh Tertanggung, baik yang dilakukan dalam keadaan waras atau sadar, atau dalam keadaaan tidak waras atau tidak sadar, dengan ketentuan bahwa tindakan tersebut dapat Penanggung simpulkan dari dokumen yang disampaikan dan diterima oleh Kami atas diri oleh Tertanggung; ',
                                    'keterlibatan dalam suatu perkelahian bukan untuk membela diri; ',
                                    'hukuman mati berdasarkan putusan pengadilan; ',
                                    'cedera yang diakibatkan oleh atau akibat dari kelainan jiwa;',
                                    'penggunaan mesin penggergajian kayu jenis apa pun, kecuali peralatan portabel yang digunakan dengan tangan dan hanya untuk keperluan pribadi serta tidak mendapatkan imbalan; ',
                                    'Tertanggung berada dalam suatu penerbangan bukan sebagai penumpang yang terdaftar dalam manifes dan/atau sebagai awak pesawat maskapai penerbangan sipil komersial yang berlisensi dan beroperasi dalam penerbangan; ',
                                    'Tertanggung berpartisipasi dalam kegiatan berbahaya atau olahraga termasuk namun tidak terbatas pada jenis balap atau adu kecepatan (selain berjalan kaki atau berenang), potholing, panjat tebing, gunung, mendaki membutuhkan penggunaan tali atau panduan, menyelam ke kedalaman lebih dari 30 meter, kegiatan bawah air yang melibatkan penggunaan peralatanbawah air pernapasan, sky diving, menyelam tebing, bungee jumping, BASE (Building Antena Span Earth) melompat, paralayang, gantole dan terjun payung;',
                                    'Tertanggung berada dalam penugasan pada dinas militer atau tentara atau kepolisian; atau ',
                                    'Tertanggung di bawah pengaruh atau terlibat dalam penyalahgunaan narkotika, psikotropika, alkohol, racun, gas, bahan sejenis, atau obat, kecuali apabila zat atau bahan tersebut digunakan sebagai obat dalam resep Dokter.',
                                ]
                            },
                        ],
            
                    },              
                ]  
            },
            {
                stack:[
                    /*{
                        margin:[0,-10,0,-10],
                        table: {
                                widths: ['*'],
                                body: [[' '], [' ']]
                        },
                        layout:lineFullWidth()
                    },*/
                    {
                        pageBreak: 'after',
                        absolutePosition : { x :25,y :525 },
                        columns: [
                            {
                                table: {
                                        body: [
                                                ['Disajikan',mapOutput.agentName,''],
                                                [{text:'Tanggal', margin: [0,0,0,16]},{text: mapOutput.QuotationDate},''],
                                                ['','',''],
                                                ['','',''],
                                                [ mapOutput.docIdStandard, mapOutput.versi, {text: mapOutput.substandardValue, fontSize: 5, margin:[0,-3,0,0]} ],
                                        ]            
                                },layout: whiteNoSpace()
                            },
                            {
                                
                                table: {
                                        body: [
                                                [{text:'Kode Agen/FSC', margin: [100,0,50,24]},mapOutput.agentId,''],
                                                ['','',''],
                                                ['','',''],
                                                ['','',''],
                                                ['','',''],
                                        ]            
                                },layout: whiteNoSpace()
                            },
                        ],
                    }
                ]
            },
        ];

        if(mapOutput.pruHSFlag){
            body.push(data);    
        }else{
            body.push([]);
        }
        

        return body;
    }

    function subStandard1(mapOutput){

        var body = [];
        var data = [
            {
                columns: [
                    { text: [{text:'PRU', font:'frutiger'}, {text:'link assurance account', font: 'garamount'}], fontSize: 19, width: 260},
                    {
                        width: '*',
                        margin: [0,3,0,0],
                        table: {
                            widths: [ 'auto', 2],
                            body: [
                                    [{text:'RINGKASAN ILUSTRASI INI BUKAN MERUPAKAN SEBUAH KONTRAK ASURANSI', style: 'subheader', alignment:'center',margin:[30,0,30,0]}],
                            ]
                                                
                        },
                    },
                ],
            },
            {
                stack: [
                    { text: 'SURAT PERNYATAAN PERSETUJUAN ATAS KEPUTUSAN SUBSTANDARD', alignment: 'center', fontSize: 10, bold: true},
                    { text: 'YANG DIBERIKAN ATAS SPAJ/POLIS NOMOR: '+mapOutput.SPAJNo, alignment: 'center', fontSize: 10, bold: true},
                ], margin:[0,10,0,10]
            },
            {
                stack: [

                    {text: 'Saya, yang bertanda tangan di bawah ini:', margin:[0,0,0,10]},
                    {text: 'Nama Calon Pemegang Polis: …………………………………………………………………'},
                    {text: '(mohon diisi dengan nama yang sama dengan yang tertulis di Kartu Identitas Diri)'},
                    {text: 'telah sepenuhnya memahami penjelasan dari Agen/FCS saya mengenai keputusan substandard yang diberikan atas SPAJ/Polis Nomor: '+mapOutput.SPAJNo+', dan menyetujui bahwa:'},
                    
                ], margin:[0,0,0,10]
            },
            {
                ol: [
                    { text: 'Besar Proyeksi Nilai Tunai dan Manfaat Meninggal, Alokasi Dana Investasi dan Jenis Dana Investasi yang akan berlaku pada Polis saya adalah yang sesuai dengan yang tertera pada ilustrasi substandard terlampir, bukan seperti yang saya tuliskan di SPAJ maupun pada Ilustrasi Standard ', margin:[0,0,0,10]},
                    { text: 'Sehubungan dengan nomor 1 di atas, dalam hal terdapat perubahan Alokasi Dana Investasi maupun perubahan Jenis Dana Investasi, maka harga unit yang digunakan pada Premi/Kontribusi Tunggal SPAJ ini (beserta pengajuan Top-up yang saya lampirkan sebelumnya, jika ada) akan mengikuti tanggal perhitungan harga unit berikutnya setelah diterimanya surat persetujuan substandard di Kantor Pusat atau teridentifikasinya seluruh pembayaran premi/kontribusi pertama untuk SPAJ ini, mana yang paling akhir. ', margin:[0,0,0,10]},
                    { text: 'Ilustrasi substandard terlampir menggunakan usia berikutnya, sesuai dengan tanggal ilustrasi ini dibuat. Apabila ilustrasi ini diterima di Kantor Pusat pada waktu usia Tertanggung/Peserta sudah berubah maka Polis akan diterbitkan dengan menggunakan usia Tertanggung/Peserta yang terbaru.', margin:[0,0,0,10]},
                    { text: 'Surat pernyataan ini akan menjadi bagian yang tidak terpisahkan dari Polis saya.'},
                ],
                margin: [0,0,0,8],
            },
            {
                margin: [0,0,0,10],
                stack: [
                    {text: 'Ketentuan Tambahan', bold: true, margin: [0,0,0,5]},
                    {bold: true, columns: [
                        {text: mapOutput.Pengecualian},
                        {text: ''},
                    ]}
                ],
            },
            {
                stack:[
                    {text: '......................, ............................ 20.…'},
                    {text: 'Tanda Tangan Calon Pemegang Polis,', margin:[0,0,0,10]},
                    {
                        margin: [390,0,0,10],
                        table: {
                            widths: [ 400, 2],
                            body: [
                                    ['Mohon diketahui bahwa surat pernyataan ini baru dapat diproses apabila tanda tangan Calon Pemegang Polis sama \ndengan tanda tangan yang tertera di foto kopi Kartu Identitas yang dilampirkan bersama dengan SPAJ.'],
                            ]
                                                
                        },
                    },
                    {text:'(.......................................................……………….)'},
                    {text:'Nama Lengkap'},
                    {text:'Saya telah memahami isi ilustrasi.'},
                ]
            },
            {
                stack:[
                    /*{
                        margin:[0,-10,0,-10],
                        table: {
                                widths: ['*'],
                                body: [[' '], [' ']]
                        },
                        layout:lineFullWidth()
                    },*/
                    {
                        pageBreak: 'after',
                        absolutePosition : { x :25,y :525 },
                        columns: [
                            {
                                table: {
                                        body: [
                                                ['Disajikan',mapOutput.agentName,''],
                                                [{text:'Tanggal', margin: [0,0,0,16]},{text: mapOutput.QuotationDate},''],
                                                ['','',''],
                                                ['','',''],
                                                [ mapOutput.docIdStandard, mapOutput.versi, {text: mapOutput.substandardValue, fontSize: 5, margin:[0,-3,0,0]} ],
                                        ]            
                                },layout: whiteNoSpace()
                            },
                            {
                                
                                table: {
                                        body: [
                                                [{text:'Kode Agen/FSC', margin: [100,0,50,24]},mapOutput.agentId,''],
                                                ['','',''],
                                                ['','',''],
                                                ['','',''],
                                                ['','',''],
                                        ]            
                                },layout: whiteNoSpace()
                            },
                        ],
                    }
                ]
            },
        ];

        if(mapOutput.substandardFlag){
            body.push(data);    
        }else{
            body.push([]);
        }
        

        return body;
    }

    function subStandard2(mapOutput){

        var body = [];
        var data = [
            {
                columns: [
                    { text: [{text:'PRU', font:'frutiger'}, {text:'link assurance account', font: 'garamount'}], fontSize: 19, width: 260},
                    {
                        width: '*',
                        margin: [0,3,0,0],
                        table: {
                            widths: [ 'auto', 2],
                            body: [
                                    [{text:'RINGKASAN ILUSTRASI INI BUKAN MERUPAKAN SEBUAH KONTRAK ASURANSI', style: 'subheader', alignment:'center',margin:[30,0,30,0]}],
                            ]
                                                
                        },
                    },
                ],
            },
            {
                stack: [
                    { text: 'SURAT PERNYATAAN PERSETUJUAN ATAS KEPUTUSAN SUBSTANDARD', alignment: 'center', fontSize: 10, bold: true},
                    { text: 'YANG DIBERIKAN ATAS SPAJ/POLIS NOMOR: '+mapOutput.SPAJNo, alignment: 'center', fontSize: 10, bold: true},
                ], margin:[0,10,0,10]
            },
            {
                stack:[
                    {text: 'Saya, yang bertanda tangan di bawah ini:', margin:[0,0,0,10]},
                    {text: 'Nama Calon Pemegang Polis: …………………………………………………………………'},
                    {text: '(mohon diisi dengan nama yang sama dengan yang tertulis di Kartu Identitas Diri)'},
                    {text: 'menyatakan bahwa saya tidak menyetujui keputusan substandard <Exclusion Selection> yang diberikan atas SPAJ/Polis saya.', margin:[0,0,0,7]},
                    {text: 'Dalam hal Premi/Kontribusi Tunggal yang telah saya setorkan, mohon ditransfer ke rekening dengan data sebagai berikut:', margin:[0,0,0,20]},
                    {text: 'Nama Bank                   :', margin:[0,0,0,17]},
                    {text: 'Nama Cabang Bank            :', margin:[0,0,0,17]},
                    {text: 'Nomor Rekening              :', margin:[0,0,0,17]},
                    {text: 'Mata Uang Rekening          :', margin:[0,0,0,17]},
                    {text: 'Atas nama                   :'},
                    {text: '(hanya dapat diproses jika atas nama Calon Pemegang Polis)', margin:[0,0,0,66]},
                    {text: '......................, ............................ 20.…'},
                    {text: 'Tanda Tangan Calon Pemegang Polis,', margin:[0,0,0,10]},
                    {
                        margin: [380,0,0,10],
                        table: {
                            widths: [ 400, 2],
                            body: [
                                    ['Mohon diketahui bahwa surat pernyataan ini baru dapat diproses apabila tanda tangan Calon Pemegang Polis sama \ndengan tanda tangan yang tertera di foto kopi Kartu Identitas yang dilampirkan bersama dengan SPAJ.'],
                            ]
                                                
                        },
                    },
                    {text:'(.......................................................……………….)'},
                    {text:'Nama Lengkap'},
                    {text:'Saya telah memahami isi ilustrasi.'},
                ]
            },
            {
                stack:[
                    /*{
                        margin:[0,-10,0,-10],
                        table: {
                                widths: ['*'],
                                body: [[' '], [' ']]
                        },
                        layout:lineFullWidth()
                    },*/
                    {
                        pageBreak: 'after',
                        absolutePosition : { x :25,y :525 },
                        columns: [
                            {
                                table: {
                                        body: [
                                                ['Disajikan',mapOutput.agentName,''],
                                                [{text:'Tanggal', margin: [0,0,0,16]},{text: mapOutput.QuotationDate},''],
                                                ['','',''],
                                                ['','',''],
                                                [ mapOutput.docIdStandard, mapOutput.versi, {text: mapOutput.substandardValue, fontSize: 5, margin:[0,-3,0,0]} ],
                                        ]            
                                },layout: whiteNoSpace()
                            },
                            {
                                
                                table: {
                                        body: [
                                                [{text:'Kode Agen/FSC', margin: [100,0,50,24]},mapOutput.agentId,''],
                                                ['','',''],
                                                ['','',''],
                                                ['','',''],
                                                ['','',''],
                                        ]            
                                },layout: whiteNoSpace()
                            },
                        ],
                    }
                ]
            },
        ];

        if(mapOutput.substandardFlag){
            body.push(data);    
        }else{
            body.push([]);
        }

        return body;
    }

    function backDated(mapOutput){
        var body = [];
        var data = [
            {
                columns: [
                    { text: [{text:'PRU', font:'frutiger'}, {text:'link assurance account', font: 'garamount'}], fontSize: 19, width: 260},
                    {
                        width: '*',
                        margin: [0,3,0,0],
                        table: {
                            widths: [ 'auto', 2],
                            body: [
                                    [{text:'RINGKASAN ILUSTRASI INI BUKAN MERUPAKAN SEBUAH KONTRAK ASURANSI', style: 'subheader', alignment:'center',margin:[30,0,30,0]}],
                            ]
                                                
                        },
                    },
                ],
            },
            {
                stack: [
                    { text: 'KETENTUAN BACKDATE', alignment: 'center', fontSize: 10, bold: true},
                    { text: 'YANG DIBERIKAN ATAS SPAJ/NOMOR POLIS: '+mapOutput.SPAJNo, alignment: 'center', fontSize: 10, bold: true},
                ], margin:[0,20,0,20]
            },
            {
                ol: [
                    { text: 'Calon Pemegang Polis mengerti bahwa seluruh manfaat asuransi, termasuk masa tunggu, adalah sejak tanggal Polis diterbitkan.', margin:[0,0,0,10]},
                    { text: 'Calon Pemegang Polis mengerti bahwa besarnya premi asuransi yang harus dibayarkan adalah sejak tanggal backdate yang diajukan (maksimal tanggal 27 setiap bulannya) sampai dengan tanggal jatuh tempo pembayaran berikutnya yang terdekat dengan tanggal Polis diterbitkan. ', margin:[0,0,0,10]},
                    { text: 'Calon Pemegang Polis mengerti bahwa tanggal jatuh tempo pembayaran premi adalah sesuai dengan tanggal backdate yang diajukan.', margin:[0,0,0,10]},
                    { text: 'Calon Pemegang Polis mengerti bahwa harga unit yang akan diberlakukan untuk premi lanjutan setelah bulan backdate adalah harga unit setelah Polis terbit.', margin:[0,0,0,10]},
                    { text: 'Calon Pemegang Polis mengerti bahwa biaya asuransi akan dibebankan secara bulanan mengikuti usia berikutnya.', margin:[0,0,0,10]},
                    { text: 'Calon Pemegang Polis mengerti bahwa jika ada pemeriksaan medis maka akan menggunakan usia ulang tahun berikut (next birthday) bukan usia backdate. ', margin:[0,0,0,10]},
                    { text: 'Untuk backdate ke usia 70: Calon Pemegang Polis mengerti bahwa manfaat Cacat Total dan Tetap tidak berlaku. \n\nCatatan: \nUntuk ketentuan no. 2: mohon untuk diperhatikan, jika frekuensi pembayarannya bulanan maka total premi yang harus dibayar dihitung sejak bulan backdate sampai dengan bulan Polis diterbitkan.\nHal ini penting mengingat banyaknya case-case backdate yang langsung batal (lapse) setelah Polis diterbitkan (issued) karena hanya melakukan pembayaran premi pertama.', margin:[0,0,0,10]},
                ],
                margin: [0,0,40,0],
            }, 

                    /*{absolutePosition : { x :420,y :465 }},*/
            {
                pageBreak: 'after',
                absolutePosition : { x :25,y :515 },
                stack:[
                    {
                        table: {

                                body: [
                                        [
                                            {text:'Disajikan', margin:[0,0,24,0]},{text:mapOutput.agentName, width: 100},'',
                                            {text:'Kode Agen/FSC', margin: [24,0,0,0], alignment:'right'},
                                            {text:mapOutput.agentId, alignment:'center'},''                      
                                        ],
                                        [{text:'Tanggal'},{text: mapOutput.QuotationDate},'','','',''],
                                        [
                                            '','',
                                            {text:'Tanda Tangan Agen/SFC', margin: [12,0,0,0]},
                                            '________________________________________________________________',
                                            'Tanda Tangan Calon Pemegang Polis',
                                            '________________________________________________________________',
                                        ],
                                        [   
                                            '','','',
                                            {margin: [0,0,0,8], fontSize: 6, italics: true, text:'Saya telah menjelaskan isi ilustrasi ini kepada Calon Pemegang Polis'},
                                            '',{fontSize: 6, italics: true, text:'Saya telah memahami isi ilustrasi ini'}
                                        ],
                                        [ 
                                            mapOutput.docIdBackdated, 
                                            {
                                                columns:[
                                                {text: mapOutput.versi, italics: true},
                                                {text: '[10-Feb-2017', italics: true},
                                                {text: 'Agency]', italics: true},
                                                ],
                                            },
                                            {text: mapOutput.substandardValue, fontSize: 5, margin:[0,-3,0,0]},
                                            '','','' 
                                        ],
                                ]            
                        },layout: whiteNoSpace()
                        
                    },
                ],
            },
        ];

        if(mapOutput.backDatedFlag){
            body.push(data);    
        }else{
            body.push([]);
        }

        return body;   

    }

    function pruCCB61Output(mapOutput){

        var body = [];
        var data = [
            {
                columns: [
                    { text: [{text:'PRU', font:'frutiger'}, {text:'link assurance account', font: 'garamount'}], fontSize: 19, width: 260},
                    {
                        width: '*',
                        margin: [0,3,0,0],
                        table: {
                            widths: [ 'auto', 2],
                            body: [
                                    [{text:'RINGKASAN ILUSTRASI INI BUKAN MERUPAKAN SEBUAH KONTRAK ASURANSI', style: 'subheader', alignment:'center',margin:[30,0,30,0]}],
                            ]
                                                
                        },
                    },
                ],
            },

            {text:['Tabel Kondisi Kritis ',{text:'PRU', font:'frutiger'}, {text:'crisis cover benefit plus 61', font: 'garamount'}], margin: [0, 3, 0, 5], fontSize:10, bold: true},


            {
                columns: [
                    [
                        {
                            margin: [0, 0, 10, 0],
                            style: 'hal3Table',
                            table: {
                                    widths: [ 12,'*',12,'*'],
                                    body: [
                                            [{colSpan: 4, alignment:'center', text:'Kondisi Kritis'},'','',''],
                                            [{alignment:'center', text:'1'},'Kanker', {alignment:'center', text:'32'}, 'Poliomyelitis',],
                                            [{alignment:'center', text:'2'},'Penyakit Hati Kronis', {alignment:'center', text:'33'}, 'Lupus Eritematosus Sistemik',],
                                            [{alignment:'center', text:'3'},'Penyakit Paru Kronik', {alignment:'center', text:'34'}, 'Hilangnya Kemampuan Hidup Mandiri',],
                                            [{alignment:'center', text:'4'},'Koma', {alignment:'center', text:'35'}, 'Pankreatitis (Pembengkakan Pankreas) Kambuhan Kronis',],
                                            [{alignment:'center', text:'5'},'Disabling Primary Pulmonary Hypertension', {alignment:'center', text:'36'}, 'Rheumatoid Arthritis Kronis',],
                                            [{alignment:'center', text:'6'},'Kehilangan Pendengaran secara Total', {alignment:'center', text:'37'}, 'Penyakit Kista MedulerPenyakit Kista Meduler',],
                                            [{alignment:'center', text:'7'},'Serangan Jantung', {alignment:'center', text:'38'}, 'Skeleroderma Progresif',],
                                            [{alignment:'center', text:'8'},'Kardiomiopati Parah', {alignment:'center', text:'39'}, 'Penyakit Tangan, Kaki, dan Mulut dengan Komplikasi Kronis (mengancam jiwa)',],
                                            [{alignment:'center', text:'9'},'Stroke', {alignment:'center', text:'40'}, 'Penyakit Kawasaki (Proteksi akan berhenti pada usia 18)',],
                                            [{alignment:'center', text:'10'},'Penyakit Alzheimer', {alignment:'center', text:'41'}, 'Penyakit Wilson (Proteksi akan berhenti pada usia 18)',],
                                            [{alignment:'center', text:'11'},'Pembedahan terbuka pada Pembuluh Darah Aorta', {alignment:'center', text:'42'}, 'Necrotising Fasciitis (Jaringan tubuh yang mati disebabkan oleh Infeksi Bakteri)',],
                                            [{alignment:'center', text:'12'},'Anemia Aplastik Yang Tidak Dapat Dipulihkan', {alignment:'center', text:'43'}, 'Elephantiasis (Penyakit Kaki Gajah)',],
                                            [{alignment:'center', text:'13'},'Meningitis Bakteri Berat', {alignment:'center', text:'44'}, 'Chronic Adrenal Insufficiency (Insufisiensi Adrenal Akut) (Penyakit Addisions)',],
                                            [{alignment:'center', text:'14'},'Tumor Jinak di Otak', {alignment:'center', text:'45'}, 'Putusnya Akar-Akar Saraf Plexus Brakhialis',],
                                            [{alignment:'center', text:'15'},'Tindakan Bedah Bypass Pembuluh Darah Jantung (Coronary Artery Bypass Grafting)', {alignment:'center', text:'46'}, 'HIV yang disebabkan oleh pekerjaan',],
                                            [{alignment:'center', text:'16'},'Penyakit Crohn', {alignment:'center', text:'47'}, 'Severe Creutzfeld-Jacob Disease (Gangguan Saraf Degenatif)',],
                                            [{alignment:'center', text:'17'},'Ensefalitis', {alignment:'center', text:'48'}, 'Severance of Limbs (Kehilangan Anggota Tubuh)',],
                                            [{alignment:'center', text:'18'},'Hepatitis Virus Fulminan', {alignment:'center', text:'49'}, 'Terminal Illness',],
                                            [{alignment:'center', text:'19'},'Pembedahan Katup Jantung secara Terbuka', {alignment:'center', text:'50'}, 'Myasthenia Gravis (Penyakit Autoimun yang menyebabkan kelemahan pada otot)',],
                                            [{alignment:'center', text:'20'},'HIV karena Transfusi Darah', {alignment:'center', text:'51'}, 'Meningeal Tuberculosis (Meningitis Tuberkulosa)',],
                                            [{alignment:'center', text:'21'},'Gagal Ginjal', {alignment:'center', text:'52'}, 'Progressive Supranuclear Palsy',],
                                            [{alignment:'center', text:'22'},'Kehilangan Kemampuan Bicara', {alignment:'center', text:'53'}, 'Cerebral Aneurysm Requiring Brain Surgery (Kelainan Pembuluh Darah Otak yang membutuhkan pembedahan otak)',],
                                            [{alignment:'center', text:'23'},'Luka Bakar', {alignment:'center', text:'54'}, 'Angioplasty and Other Invasive Treatment for Coronary Artery (Angioplasti dan penatalaksanaan invasif padapembuluh darah jantung)',],
                                            [{alignment:'center', text:'24'},'Trauma Kepala Berat', {alignment:'center', text:'55'}, 'Hepatitis Autoimun Kronis (Pembedahan untuk Skoliosis Idiopatik)',],
                                            [{alignment:'center', text:'25'},'Transplantasi Organ Penting', {alignment:'center', text:'56'}, 'Surgery for Idiopathic Scoliosis',],
                                            [{alignment:'center', text:'26'},'Penyakit Motor Neuron', {alignment:'center', text:'57'}, 'Dissecting Aortic Aneurysm (pembedahan Aneurisma Aorta)',],
                                            [{alignment:'center', text:'27'},'Sklerosis Multipel', {alignment:'center', text:'58'}, 'Stroke Requiring Carotid Endarterectomy Surgery (Stroke yang membutuhkan pembedahan Endarterektomi karotis)',],
                                            [{alignment:'center', text:'28'},'Muscular Dystrophy', {alignment:'center', text:'59'}, 'Hilangnya Penglihatan Total',],
                                            [{alignment:'center', text:'29'},'Penyakit Serius Lainnya pada Pembuluh Darah Koroner Jantung', {alignment:'center', text:'60'}, 'Ulcerative colitis Berat',],
                                            [{alignment:'center', text:'30'},'Kelumpuhan', {alignment:'center', text:'61'}, 'Infective Endocarditis (Endokarditis Infektif)',],
                                            [{alignment:'center', text:'31'},'Penyakit Parkinson', {alignment:'center', text:''}, '',],
                                        ]
                                                            
                            },

                            layout: {             
                                paddingLeft: function(i, node) { return 1; },
                                paddingRight: function(i, node) { return 1; },
                                paddingTop: function(i, node) { return 1; },
                                paddingBottom: function(i, node) { return 1 },
                            }
                        },
                    ],
                    {
                        stack: [
                            [
                                { margin:[0,0,0,3], text: ['Pengecualian ',{text:'PRU', font:'frutiger'}, {text:'crisis cover benefit plus 61', font: 'garamount'}]},
                                { margin:[0,0,0,3], text: ['Ketentuan dalam Asuransi Tambahan ',{text:'PRU', font:'frutiger'}, {text:'crisis cover benefit plus 61', font: 'garamount'},' tidak berlaku untuk:']},
                                {table: {
                                    body: [
                                        ['a',{ margin:[0,0,0,3], text:'Kondisi Kritis yang dialami Tertanggung Utama dalam Masa Tunggu;'}],
                                        ['b',{ margin:[0,0,0,3], text: ['Kondisi Kritis yang telah dialami oleh Tertanggung Utama sebelum Tanggal Mulai Pertanggungan Asuransi Tambahan ',{text:'PRU', font:'frutiger'}, {text:'crisis cover benefit plus 61', font: 'garamount'},', atau tanggal Pemulihan Polis yang terakhir, tergantung pada tanggal yang paling akhir;']}],
                                        ['c',{ margin:[0,0,0,3], text:'Kondisi Kritis yang dialami oleh Tertanggung Utama disebabkan hal di bawah ini:'}],
                                    ]
                                    },layout:{
                                            hLineWidth: function(i, node) {
                                                    return (i === 0 || i === node.table.body.length) ? 0 : 1;
                                            },
                                            vLineWidth: function(i, node) {
                                                    return (i === 0 || i === node.table.widths.length) ? 0: 1;
                                            },
                                            hLineColor: function(i, node) {
                                                    return (i === 0 || i === node.table.body.length) ? 'black' : 'white';
                                            },
                                            vLineColor: function(i, node) {
                                                    return (i === 0 || i === node.table.widths.length) ? 'black' : 'white';
                                            },
                                        } 
                                },
                                {
                                    margin:[10,0,0,3],
                                    ol: [
                                        'Tindak pidana kejahatan atau percobaan tindak pidana kejahatan oleh pihak yang berhak atas Manfaat Asuransi, kecuali dibuktikan sebaliknya dengan putusan pengadilan;',
                                        'Tindak pidana pelanggaran atau percobaan tindak pidana pelanggaran oleh pihak yang berhak atas Manfaat Asuransi, kecuali dibuktikan sebaliknya dengan putusan pengadilan;',
                                        'Perlawanan oleh Tertanggung Utama dalam hal terjadi penahanan Tertanggung Utama atau orang lain oleh pihak yang berwenang;',
                                        'Pelanggaran peraturan perundang-undangan (pelanggaran atau percobaan pelanggaran yang mana tidak perlu dibuktikan dengan adanya suatu putusan pengadilan) oleh Tertanggung Utama;',
                                        'Cacat bawaan dan/atau kelainan bawaan, baik yang diketahui atau tidak diketahui oleh Pemegang Polis atau Tertanggung Utama;',
                                        'Percobaan bunuh diri, dugaan bunuh diri atau pencederaan diri oleh Tertanggung Utama, baik yang dilakukan dalam keadaan waras atau sadar, atau dalam keadaaan tidak waras atau tidak sadar, dengan ketentuan bahwa tindakan tersebut dapat Penanggung simpulkan dari dokumen medis atas diri Tertanggung Utama;',
                                        'Tertanggung Utama berada dalam suatu penerbangan bukan sebagai penumpang yang terdaftar dalam manifes dan/atau sebagai awak pesawat maskapai penerbangan sipil komersial yang berlisensi dan beroperasi dalam penerbangan rutin;',
                                        'Tertanggung Utama mengikuti suatu kegiatan dan/atau cabang olahraga berbahaya antara lain bungee jumping, menyelam, semua jenis balapan, olahraga udara termasuk gantole, balon udara, terjun payung, dan sky diving, dan kegiatan atau olahraga berbahaya lainnya, kecuali telah disetujui secara tertulis oleh Penanggung sebelum kegiatan dan/atau cabang olahraga tersebut dilakukan;',
                                        'Perang, invasi, tindakan bermusuhan dari militer atau tentara asing baik dinyatakan maupun tidak, perang saudara, pemberontakan, revolusi, perlawanan terhadap pemerintah, perebutan kekuasaan oleh tentara atau militer, ikut serta dalam huru hara, pemogokan atau kerusuhan sipil;',
                                        'Tertanggung Utama berada di bawah pengaruh atau terlibat dalam penyalahgunaan narkotika, psikotropika, alkohol, racun, gas, bahan sejenis, atau obat, kecuali apabila zat atau bahan tersebut digunakan sebagai obat dalam resep Dokter;',
                                        'Kelainan jiwa, cacat mental, neurosis, psikosomatis atau psikosis; atau',
                                        'Tertanggung Utama mengidap Acquired Immune Deficiency Syndrome (AIDS) atau Human Immuno-deficiency Virus (HIV), kecuali infeksi HIV tersebut dibuktikan berasal dari transfusi darah kepada Tertanggung Utama oleh lembaga transfusi darah yang telah membuktikan sumber darah terinfeksi HIV tersebut.',
                                ]},
                                { margin:[0,0,0,3], text:'d.   Tertanggung Utama meninggal dunia yang disebabkan oleh hal-hal di bawah ini:'},
                                {
                                    margin:[10,0,0,0],
                                    ol: [
                                        'Tindakan bunuh diri, percobaan bunuh diri, dugaan bunuh diri atau pencederaan diri oleh Tertanggung Utama baik yang dilakukan dalam keadaan waras atau sadar, atau dalam keadaaan tidak waras atau tidak sadar, dengan ketentuan bahwa tindakan tersebut dapat Penanggung simpulkan dari dokumen medis atas diri Tertanggung Utama;',
                                        'Tindak pidana kejahatan atau percobaan tindak pidana kejahatan oleh pihak yang berhak atas Manfaat Asuransi, kecuali dibuktikan sebaliknya dengan putusan pengadilan;',
                                        'Tindak pidana pelanggaran atau percobaan tindak pidana pelanggaran oleh pihak yang berhak atas Manfaat Asuransi, kecuali dibuktikan sebaliknya dengan putusan pengadilan;',
                                        'Perlawanan oleh Tertanggung Utama dalam hal terjadi penahanan Tertanggung Utama atau orang lain oleh pihak yang berwenang;',
                                        'Pelanggaran peraturan perundang-undangan (pelanggaran atau percobaan pelanggaran yang mana tidak perlu dibuktikan dengan adanya suatu putusan pengadilan) oleh Tertanggung Utama; atau',
                                        'Hukuman mati berdasarkan putusan pengadilan.',
                                ]},
                            ]
                        ],
                    },
                ]
            },
            {
                stack:[
                    /*{
                        margin:[0,-10,0,-10],
                        table: {
                                widths: ['*'],
                                body: [[' '], [' ']]
                        },
                        layout:lineFullWidth()
                    },*/
                    {
                        pageBreak: 'after',
                        absolutePosition : { x :25,y :525 },
                        columns: [
                            {
                                table: {
                                        body: [
                                                ['Disajikan',mapOutput.agentName,''],
                                                [{text:'Tanggal', margin: [0,0,0,16]},{text: mapOutput.QuotationDate},''],
                                                ['','',''],
                                                ['','',''],
                                                [ mapOutput.docIdStandard, mapOutput.versi, {text: mapOutput.substandardValue, fontSize: 5, margin:[0,-3,0,0]} ],
                                        ]            
                                },layout: whiteNoSpace()
                            },
                            {
                                
                                table: {
                                        body: [
                                                [{text:'Kode Agen/FSC', margin: [100,0,50,24]},mapOutput.agentId,''],
                                                ['','',''],
                                                ['','',''],
                                                ['','',''],
                                                ['','',''],
                                        ]            
                                },layout: whiteNoSpace()
                            },
                        ],
                    }
                ]
            },
        ];

        if(mapOutput.pruCCB61Flag){
            body.push(data);    
        }else{
            body.push([]);
        }

        return body;
    }

    function pruMedCoverOutput(mapOutput){
        var body = [];
        var data = [
            {
                columns: [
                    { text: [{text:'PRU', font:'frutiger'}, {text:'link assurance account', font: 'garamount'}], fontSize: 19, width: 260},
                    {
                        width: '*',
                        margin: [0,3,0,0],
                        table: {
                            widths: [ 'auto', 2],
                            body: [
                                    [{text:'RINGKASAN ILUSTRASI INI BUKAN MERUPAKAN SEBUAH KONTRAK ASURANSI', style: 'subheader', alignment:'center',margin:[30,0,30,0]}],
                            ]
                                                
                        },
                    },
                ],
            },

            {text:['Pengecualian ',{text:'PRU', font:'frutiger'}, {text:'med cover', font: 'garamount'}], margin: [0, 3, 0, 5], fontSize:10, bold: true},

            {
                columns: [
                    {
                        stack: [
                            {text: ['Asuransi Tambahan ',{text:'PRU', font:'frutiger'}, {text:'med cover', font: 'garamount'},' tidak berlaku untuk hal yang disebabkan secara langsung ataupun tidak langsung baik sebagian ataupun seluruhnya terhadap hal-hal sebagaimana tercantum di bawah ini:']},
                            {
                                margin: [0, 0, 10, 0],
                                table: {
                                    body: [
                                        ['1','Kondisi Yang Telah Ada Sebelumnya;'],
                                        ['2',{text: ['Penyakit/pembedahan tertentu yang terjadi dalam 12 (dua belas) bulan pertama sejak Tanggal Mulai Pertanggungan Asuransi Tambahan ',{text:'PRU', font:'frutiger'}, {text:'med cover', font: 'garamount'},' cover atau tanggal pemulihan terakhir (mana yang lebih akhir), baik Peserta Yang Diasuransikan telah mengetahuinya ataupun tidak, mencakup: \nSemua jenis hernia; Semua jenis tumor jinak atau benjolan atau kista; Tuberkulosis; Wasir; Penyakit pada tonsil atau adenoid; Kondisi abnormal rongga hidung, sekat hidung, atau kerang hidung (turbinates), termasuk sinus; Penyakit kelenjar gondok (tiroid); Hysterektomi (dengan atau tanpa salpingo – ooforektomi); Penyakit tekanan darah tinggi; Penyakit jantung dan pembuluh darah (kardiovaskuler); Fistula di anus; Batu pada sistem saluran empedu; Batu pada ginjal, saluran kemih atau kandung kemih; Katarak; Tukak pada lambung atau usus dua belas jari; Semua jenis kelainan sistem reproduksi, termasuk endometriosis, fibroid, atau miom  di rahim; Diskus  Intervertebrata yang menonjol; dan/atau Penyakit Kencing Manis;']}],
                                        ['3','Setiap Ketidakmampuan yang dimulai atau terjadi dalam Masa Tunggu, kecuali diakibatkan oleh Kecelakaan;'],
                                        ['4','Tindakan Bedah yang dilakukan semata-mata keinginan Peserta Yang Diasuransikan tanpa ada Cedera atau Penyakit, pembedahan percobaan (explorative), pembedahan untuk tujuan kosmetik atau bedah plastik, kecuali disebabkan oleh Cedera atau Penyakit;'],
                                        ['5','Semua jenis perawatan, pemeriksaan, pengobatan atau pembedahan gigi termasuk bedah mulut, gusi, atau struktur penyangga gigi secara langsung, dan pengobatan yang terkait dengan gigi, kecuali yang diakibatkan oleh Kecelakaan;'],
                                        ['6','Donor organ dan jaringan tubuh;'],
                                        ['7','Perawatan dan Tindakan Bedah karena perubahan kelamin;'],
                                        ['8','Perawatan kehamilan/upaya untuk hamil, termasuk melahirkan, diagnosis dan perawatan ketidaksuburan, keguguran, aborsi, sterilisasi (vasektomi/MOP dan tubektomi/MOW) dan kontrasepsi, metode pengaturan kelahiran, pengujian atau pengobatan impotensi, temasuk semua komplikasi yang terjadi karenanya;'],
                                        ['9','Sunat dengan segala konsekuensi selain sunat yang dilaksanakan sehubungan dengan kecelakaan atau Penyakit yang diderita oleh Peserta Yang Diasuransikan;'],
                                        ['10','Perawatan/pengobatan yang timbul sehubungan dengan atau yang diakibatkan oleh Kelainan Bawaan, cacat bawaan, atau penyakit keturunan, baik diketahui atau pun tidak diketahui;'],
                                        ['11','Perawatan yang tidak dilakukan di Rumah Sakit atau Klinik, perawatan di spa/sauna/salon;'],
                                        ['12','Rawat inap di Rumah Sakit yang bertujuan hanya untuk diagnostik, pemeriksaan sinar X, pemeriksaan fisik umum;'],
                                        ['13','Perawatan yang terjadi karena keadaan kesehatan yang berhubungan dengan proses penuaan (geriatrik), keadaan mental yang berhubungan dengan proses penuaan (psiko-geriatrik);'],
                                        ['14','Pengobatan Peserta Yang Diasuransikan berhubungan dengan kelainan jiwa, cacat mental, neurosis, psikosomatis, psikosis, atau suatu pengobatan yang dilakukan di rumah sakit jiwa atau di bagian psikiatri suatu Rumah Sakit atau pengobatan yang dilakukan oleh seorang psikiater;'],
                                        ['15','Semua Penyakit akibat hubungan seksual atau penyimpangan seksual;'],
                                        ['16','Cedera atau Penyakit akibat reaksi nuklir, radiasi, dan kontaminasinya; '],
                                        ['17','Perawatan untuk mengatasi kegemukan, penurunan berat badan atau menambah berat badan, bulimia atau anoreksia nervosa;'],
                                        ['18','Biaya perawatan yang disebabkan oleh atau berhubungan dengan Acquired Immune Deficiency  Syndrome (AIDS); Infeksi karena Human Immunodeficiency Virus (HIV); atau Penyakit lainnya yang disebabkan oleh atau komplikasi dari Penyakit AIDS dan HIV;'],
                                        
                                    ]
                                },
                                layout: whiteNoSpacePadBot()
                            },
                        ],
                    },
                    {
                        stack: [
                            
                            {
                                table: {
                                    body: [
                                        ['19','Penyakit, Cedera atau Ketidakmampuan yang terjadi pada saat Peserta Yang Diasuransikan di bawah pengaruh narkotika, alkohol, psikotropika, racun, gas atau bahan sejenis, atau obat selain digunakan sebagai obat menurut resep yang dikeluarkan oleh Dokter;'],
                                        ['20','Penyakit, Cedera, atau Ketidakmampuan yang disebabkan oleh tindakan percobaan bunuh diri, dugaan bunuh diri atau pencederaan diri, baik dilakukan dalam keadaan waras ataupun tidak waras;'],
                                        ['21','Cedera yang disebabkan oleh:'],
                                        ['',{
                                            stack:[
                                                'a.  tindak pidana kejahatan atau percobaan tindak pidana kejahatan yang dilakukan oleh Peserta Yang Diasuransikan, kecuali dibuktikan sebaliknya dengan putusan pengadilan; ',
                                                'b.  tindak pidana pelanggaran atau tindak pidana percobaan pelanggaran oleh Peserta Yang Diasuransikan, kecuali dibuktikan sebaliknya dengan putusan pengadilan; ',
                                                'c.  pelanggaran peraturan perundang-undangan oleh Peserta Yang Diasuransikan, kecuali dibuktikan sebaliknya dengan putusan pengadilan;',
                                                'd.  perlawanan oleh Peserta Yang Diasuransikan dalam hal terjadi penahanan Peserta Yang Diasuransikan atau orang lain oleh pihak yang berwenang;',
                                                'e.  tindak kejahatan atau percobaan tindak kejahatan oleh pihak yang berkepentingan atas Polis; atau',
                                                'f.  keterlibatan dalam suatu perkelahian bukan untuk membela diri;',
                                            ]
                                        }],
                                        ['22','Peserta Yang Diasuransikan berpartisipasi dalam kegiatan berbahaya atau olahraga termasuk namun tidak terbatas pada jenis balap atau kecepatan (selain berjalan kaki atau berenang), potholing, panjat tebing, gunung, mendaki membutuhkan penggunaan tali atau panduan, menyelam ke kedalaman lebih dari 30 meter, kegiatan bawah air yang melibatkan penggunaan peralatan bawah air pernapasan, sky diving, cliff diving, bungee jumping, BASE jumping (Building Antena Span Earth), paralayang, gantole dan terjun payung; '],
                                        ['23','Penugasan pada dinas militer atau kepolisian;'],
                                        ['24','Cedera atau Penyakit yang timbul sebagai akibat langsung atau tidak langsung dari terorisme, perang, invasi, serangan musuh asing, tindak kekerasan, perang baik yang diumumkan atau tidak diumumkan, perang sipil, pemberontakan, revolusi, keikutsertaan dalam huru hara, perkelahian, pemogokan dan keributan massa, tindakan tentara atau militer, dan perampasan kekuasaan; atau '],
                                        ['25','Cedera atau Penyakit yang disebabkan oleh penerbangan atau kegiatan udara lainnya, kecuali sebagai penumpang yang terdaftar dalam manifes dengan membayar tarif pada maskapai penerbangan sipil komersial, atau perusahaan sewa yang mempunyai ijin dan beroperasi dalam penerbangan rutin.'],
                                    ]
                                },
                                layout: whiteNoSpacePadBot()
                            },
                        ],
            
                    },              
                ]  
            },
            {
                stack:[
                    /*{
                        margin:[0,-10,0,-10],
                        table: {
                                widths: ['*'],
                                body: [[' '], [' ']]
                        },
                        layout:lineFullWidth()
                    },*/
                    {
                        pageBreak: 'after',
                        absolutePosition : { x :25,y :525 },
                        columns: [
                            {
                                table: {
                                        body: [
                                                ['Disajikan',mapOutput.agentName,''],
                                                [{text:'Tanggal', margin: [0,0,0,16]},{text: mapOutput.QuotationDate},''],
                                                ['','',''],
                                                ['','',''],
                                                [ mapOutput.docIdStandard, mapOutput.versi, {text: mapOutput.substandardValue, fontSize: 5, margin:[0,-3,0,0]} ],
                                        ]            
                                },layout: whiteNoSpace()
                            },
                            {
                                
                                table: {
                                        body: [
                                                [{text:'Kode Agen/FSC', margin: [100,0,50,24]},mapOutput.agentId,''],
                                                ['','',''],
                                                ['','',''],
                                                ['','',''],
                                                ['','',''],
                                        ]            
                                },layout: whiteNoSpace()
                            },
                        ],
                    }
                ]
            },
        ];

        if(mapOutput.pruMedCoverFlag){
            body.push(data);    
        }else{
            body.push([]);
        }

        return body;   
    }


    //------------------------------------------------------------------------------------------  ANGEN PRIANGGODO ------------------------------------------------------------------------------------------------
    function createDocumentDefinition(mapOutput) {
        // //console.log(mapOutput);      
       
            mapOutput.A1_value = mapOutput.A1_value ? mapOutput.A1_value : '';
            mapOutput.A2_value = mapOutput.A2_value ? mapOutput.A2_value : '';
            mapOutput.A3_value = mapOutput.A3_value ? mapOutput.A3_value : '';
            mapOutput.A4_value = mapOutput.A4_value ? mapOutput.A4_value : '';
            mapOutput.A51_value = mapOutput.A51_value ? mapOutput.A51_value : '';
            mapOutput.A52_value = mapOutput.A52_value ? mapOutput.A52_value : '';
            mapOutput.A53_value = mapOutput.A53_value ? mapOutput.A53_value : '';
            mapOutput.A54_value = mapOutput.A54_value ? mapOutput.A54_value : '';
            mapOutput.A6_value = mapOutput.A6_value ? mapOutput.A6_value : '';
            mapOutput.A7_value = mapOutput.A7_value ? mapOutput.A7_value : '';
            mapOutput.A8_value = mapOutput.A8_value ? mapOutput.A8_value : '';
            mapOutput.A9_value = mapOutput.A9_value ? mapOutput.A9_value : '';
            mapOutput.A10_value = mapOutput.A10_value ? mapOutput.A10_value : '';
            mapOutput.A11_value = mapOutput.A11_value ? mapOutput.A11_value : '';
            mapOutput.A12_value = mapOutput.A12_value ? mapOutput.A12_value : '';
            mapOutput.B1_value = mapOutput.B1_value ? mapOutput.B1_value : '';
            mapOutput.B2_value = mapOutput.B2_value ? mapOutput.B2_value : '';
            mapOutput.B3_value = mapOutput.B3_value ? mapOutput.B3_value : '';
            mapOutput.C1_value = mapOutput.C1_value ? mapOutput.C1_value : '';

        PRUHSManfaatNilai(mapOutput);  

        pdfMake.fonts = {
           garamount: {
             normal: 'AGaramondPro-Italic.ttf',
             bold: 'AGaramondPro-Italic.ttf',
             italics: 'AGaramondPro-Italic.ttf',
             bolditalics: 'AGaramondPro-Italic.ttf'
           },
           frutiger: {
             normal: 'FrutigerLinotype-Bold.ttf',
             bold: 'FrutigerLinotype-Bold.ttf',
             italics: 'FrutigerLinotype-Bold.ttf',
             bolditalics: 'FrutigerLinotype-Bold.ttf'
           },
            Roboto: {
            normal: 'Roboto-Regular.ttf',
            bold: 'Roboto-Medium.ttf',
            italics: 'Roboto-Italic.ttf',
            bolditalics: 'Roboto-Italic.ttf'
           }
        }

        var dd = {
            pageSize: 'A4',
            pageOrientation: 'landscape',
            pageMargins: [ 30, 10, 15, 10 ],
            footer: function(page, pages) { 
                return { 
                    stack: [ 
                        {image: textToBase64Barcode(page.toString() + '-' + pages.toString() + '-' +docId), width: 120, height: 15, alignment: 'center', margin:[0,-10,0,0]},
                        {  
                            margin: [0, -12,10,0],
                            alignment: 'right',
                            text: [
                                { text: page.toString()},
                                ' / ',
                                { text: pages.toString()}
                            ]
                        }
                    ],
                };
            },

            content: [
                {stack:getOutputSQS(mapOutput)}

            ],

            images: {
                prudent: ' data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/4QBaRXhpZgAATU0AKgAAAAgABQMBAAUAAAABAAAASgMDAAEAAAABAAAAAFEQAAEAAAABAQAAAFERAAQAAAABAAAOw1ESAAQAAAABAAAOwwAAAAAAAYagAACxj//bAEMAAgEBAgEBAgICAgICAgIDBQMDAwMDBgQEAwUHBgcHBwYHBwgJCwkICAoIBwcKDQoKCwwMDAwHCQ4PDQwOCwwMDP/bAEMBAgICAwMDBgMDBgwIBwgMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDP/AABEIAEkBhAMBIgACEQEDEQH/xAAfAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgv/xAC1EAACAQMDAgQDBQUEBAAAAX0BAgMABBEFEiExQQYTUWEHInEUMoGRoQgjQrHBFVLR8CQzYnKCCQoWFxgZGiUmJygpKjQ1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4eLj5OXm5+jp6vHy8/T19vf4+fr/xAAfAQADAQEBAQEBAQEBAAAAAAAAAQIDBAUGBwgJCgv/xAC1EQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2gAMAwEAAhEDEQA/AP38orxn9rj9vf4a/sQf8I//AMLC1a80v/hJ/tP9n+RYy3Xm+R5XmZ8tTtx50fXrn2NeND/gvZ+zYT/yNerj/uBXf/xuuOtmWFpTdOpUimujaTPssq8O+KMzwscdl2X1qtKV+WcKc5Rdm07NJp2aafmmj7Lor5B0r/gut+zPqdwI28d3VqzHAM+h36qfxEJA/GvoD4G/tOeBv2kvDsmqeCfE2i+JLOFwkzWVyHaBjyBIhw6E+jAEiqoY7DVny0akZPsmmcec8FcQ5TS9tmmBrUYXtzTpzjG/q0l+J31FfLHxi/4LI/Ar4DfE7WPCHibxFqNnrmhT/Z7yGPSbmZY3wDgMqFTwRyDXNj/gvb+zYT/yNer/APgiu/8A43WMs1wUZOMqsU1o9UerhfC/jDE0YYjD5ZXlCaUoyVKbTTV000rNNap9UfZdFfJfhr/gt7+zZ4ovY7eL4hR2s0pwPtml31si/wC87whB+dfSXgr4paH8SvDUOseHdU0vXtMuVDQ3Wn3iXEEvJBw6ZHGK6KGKoVv4M1L0aZ4WdcK51k6TzbB1aClovaU5wTfk5JJ/I6KivkHxD/wXL/Z38K+JL/Sb7xRqkd9pt1JZzqujXbIskblGwwj5GQeRX1h4b8Q2/ivQrPUrNi9rfwJcwsQQSjqGXg9ODRRxVGs2qU1K29new864VznKIU6ua4WpRjU1g5wlFStZvlule11t3Reoorgv2kf2k/Cf7J/wsuvGXjS8uLDQbOaKCWaG2e4ZXkYKg2oCeSfStqlSMIuc3ZLdnlYLBYjGYiGEwkHOpNqMYxTbk3okktW29kjvaK+M/wDh/b+zZ/0NWsf+CK7/APjdKP8AgvZ+zYT/AMjZqw9zoV3gf+Q64P7XwP8Az+j/AOBI+4/4hLxr/wBCnEf+CZ//ACJ9l0V8ueA/+CzP7OXxCvFt7X4kaZYysQP+Jnb3GnoM/wC3NGqfrX0f4Z8ZaX400G21PR9Q0/VNPvEEkFzaXKTwzKehV1JDD3FddHE0q2tKSl6NM+XzjhrN8pajmuFqUG9vaQlC/pzJX+RqUV4N+05/wUo+EX7Hnjuz8N/EDxJNourX1kuoQRJpt3dB4Wd0DboomUZZHGCc/L0wRnzj/h+z+zL/AND5df8Agg1H/wCMVjUzDCwk4TqRTXRtf5nrZf4fcUY/DxxeBy6vUpT1jKNKcotbXTUWnr2PsCivj/8A4fs/sy/9D5df+CDUf/jFanh3/gtB+z/4w07XLzSfFt1fW/hvTzqupMNHvo2t7YTRQbwGhG795PEuBz82egNTHMsI9FVj/wCBLpr3Oir4Z8XUo81XK8RFXSu6NRK7aS1ceraS8z6sor5l+Af/AAV3+Bn7SXxNsfCHhnxVI2ualuFpDeWM9otwyjOxXkQLvIBIXOTjjNfS0M4m6fXr2roo4ilWjzUpKS7p3Pn874fzPJ66wubYedCo1dRqRcW13tJJ20JKKK5P45fGrw/+zr8KNY8aeKbqSz0DQY1lvJo4XmaNWkWMYVAWPzOvQVpKSiuaWx5uGw9XEVo4ehFynNqMUldtt2SS6tvRI6yivjP/AIf3/s27sf8ACVax07aFd8f+Q6P+H9v7Nn/Q1ax/4Irv/wCN1wf2xgf+f0f/AAJH3n/EJeNv+hTiP/BM/wD5E+zKK+M/+H9v7Nn/AENWsf8Agiu//jdH/D+39mz/AKGrWP8AwRXf/wAbo/tfA/8AP6P/AIEg/wCIS8bf9CnEf+CZ/wDyJ9mUV8faF/wXS/Z18S65Z6bZ+KNWku9QnS2hVtEu1DO7BVGfL45IpNY/4Lqfs6aDrF3YXXirVEurKd7eRRol4w3KxU4Pl+oNP+1cE1f2sfvRl/xCzjFVPZf2XiOa17eyne17Xty7XPsKiqXhrxBa+LPDmn6rYuZLPU7aO7t3KlS0cihlODyMgjg81bll8tc8fia9Ba7Hwk4yhJxmrNb+Q6ivlT4l/wDBaD9n/wCEvxI1jwprXiy6j1jQbx7C8WHS7meKOZG2uvmJGVO1sg4JwQa+odH1m313T7e6tZI5re6jWaKSNtyyIwBDA9wQQc1hRxVGq2qUlJrezvY9rNuGc3yqlSrZlhqlGNVXg5wlFTWjvFtK6s1t3XctUUV8h+L/APguH+z74E8V6pomp+JdSh1LR7yWxuo10e7dUlidkcBhHg4ZSMjg0sRiqNBc1aSivN2KyPhfOM6nOGUYWpXcFeSpwlKyezdk7X8z68oqvpWpJq+nxXMf+rmUOh9QQCP51NI4jQscADqSa6DwdVox1FVdJ1q0160W4sbq3vLds7ZIJBIhwSDgjjqCPwqrr3i/T/C1hNd6leWen2duf3k9zOsMcY9WZsAfjR5lcsubks77W637epqVzfxasvEN/wDDbXo/Cc9la+KGsJxpE14he3juzEwhaQDqgcrn2z1o8GfGHwr8R/N/4R3xJoGvmD/W/wBm6jDdeX/veWxx+NcPqv7ZnhPRP2sh8HbyQ2niabQU161kuJUjgvFaV4zBGSctKAhfaAflyf4TWcq0IpNtauy9ex3UcnxteVSnSpScqcXOSSd4xW8mt0ldXZ8h+Jf+CnX7THwC1m11L4nfs5yWPgrTQq67f6TJJdSQqDiS4SRXeJUHLBX4IGPMGdw9f+Jv/BRPwH+0p8JpvC3wY+LHhmz+KPiy0VvDMV5AdxuFZZPIlSWMrG7qjxgSDOWyASBX1TqeqWVvYzSXklrFaqpMzzyKsar33E8Yx61+U/8AwUP/AGcf2VJ/Ft14w8EfF/wf8M/iJp8y3tvDo12t9p0t3GwZGeC1V3gk3KPmjxjqY2JJOlTEUafvVpKPq0vzOPL8izjMG6WV0Z4h9oRlJ/LlTPbvA3/Ba6b4Z/EzQfh/8d/hb4k+GXibUGjtpb8yLcac7EhPPXofJL5yUMgX+8cE19v6J8R9D8ReLNY0Gz1Wxudc8PiA6nYxShprATqXh8xeq71UlSeoBr83P2wf29P2Tv26fg54e8L+OvHl7ZappF1bag2o6VoF6yxTqu2eONpIA3lSAuPug/cbGVAroNc+KXgT9qj9vH4e/Eb4K/Hrwx4VmAjs/F+nz3E1hdeJbeF8wxLazIq3DlXljy/KKVZclQK56eZYKtJRp1Y37XTPocd4ecYZbRliMdlteNNW96VKcbLrduKStvd20P0eoqO2k82BW9ffNSV0HzQUUUUAfk7/AMHQX/ND/wDuPf8AuNrxf/gjX/wTc+Hf7dngrxvf+Nv7f8/w/fWttbf2dei3G2SORm3Ao2eVHpXtH/B0F/zQ/wD7j3/uNre/4Njv+SYfFj/sK2H/AKJmr88qUKVbiSVOtFSTWz/wI/0AwOeZhk/0dcPj8rrSo1oyaU4O0lfGTTs13Wj8mdJ8Y/8Ag3M+Fep+Br1fBuv+LdD8RLGWs5r+6ju7MyDoJE8pW2nplWBHXnGD+Zfwi+K3xB/4Jpfta3DxyTaXr3hTUG0/W9PWTMOowpIPNhbsyOBlWHTKsORX9Jmoti3r+dH/AIK4+K9O8a/8FGfilfaTIs1ouoQ2hdDkGWC0ggm/KWNx9Qa04oy/D4KnTxWEXJLmtp10v+FvxOH6MfHeecYY3H8McUVHjMLKi5P2nvNPmjDl5nraSk2k27ON42d75P8AwU68TWfjP9u34iaxpsnm6fq17De2z/345LaJ1P4hhX39+wf/AMETvgz+0Z+yH4H8beIT4uXWvEWn/abr7Lqaxw7t7L8qmM4GF6ZNfmX+1Dod34Z+ME2n6grR31hpWlW9wrA7lkXTrZWBzznIr98v+CSdwq/8E5vhSPm40j0/6ayVycP4Wlisyr/WIKW7s11cj6rx74hzXhnw8yV5Fip0ZL2UHKEnFyiqD0bW6bSZ8Rft4/8ABAHw78M/gdrHi74Wat4in1Hw7bSX91pWqTR3C3lvGpZxCyIjLIqgsAd27GBg4r5P/wCCS37autfsn/tTaDZnULr/AIQ3xdfRaVrNh5n7n96wjjuQvQPGzKdwGSgZe/H7pftafHLw/wDAP9nbxh4m8RXVvb2On6XOQkrAG6kZCscKgn5mdiFA7k1/OV+yZ8Pb34q/tQeAPD+nxPNc6l4gsosAZKp5yl3P+yqBmJ7BTWmfYWngcdQqYJcsm9l6q2nnqrHn+BvE+ZcbcD5zguMpvEYenF8tSpa+sJSkua29PljKMt4t6vYyfj0f+L7eM8HP/E+vefX/AEh6/ps+Ccap8J/C+0Y/4k9p/wCiUr+ZT4/4/wCF8+Ndv3f7evsfT7Q9f02fBb/kk/hf/sD2n/olK6ODf4+Iv5fmz5/6YH/Il4ef92p/6RQOpr4t/wCC+/8Ayjc8Sf8AYV03/wBKEr7Sr4t/4L7/APKNzxJ/2FdN/wDShK+rzr/cK3+F/kfy34O/8l1lH/YTR/8AS4n5S/8ABKD9kfwv+2p+1O3g3xfJq0ekjRrm/wA6dOsM3mRtGF+ZlYY+c8Y9Oa/Sq7/4N0fgVcwYj1L4iW7N0ZNVtyw/76tyP0r4p/4N3/8AlIK3/Ys3/wD6HBX7sV81wrluEr4HnrU1J8z1a9D+kfpPeJHFORcbPBZNj6tCl7KnLlhK0bvmu7ba2Vz8Zv2t/wDg3g8SfD7TLzVvhT4ifxdb24aQ6NqkS29+EHQRzDEUzexWP2yeD8nfsaftxfED9gb4vxXGm3eqLpNte+Vrnhy5kZbe6AbbKrRt/q5hggPgMrDnIyp/pGnh87Hp3r8J/wDg4A+Adp8H/wBtuPXtPt47ez8eaXHqcqxrhftSM0MxA9WCRufVnY96w4gyWngIxx+Bbg4tXSffr9+6Pc8BfF7G8c4mrwPxtGGKhVpycJSilJ8q96MrWTfLeUZJKScXdu6tJ/wXs+KOj/Gz4+fDTxd4fuvtmjeIvAVpfWkxGGZHu7sgMP4WHQg8ggjtW9/wSQ/4JVfDn9u34A694o8Yal4ws9S0vxBJpcSaTdwQwtEtvbyAkSQOd26Vuc4wBx6/C/jD4gXXjDwj4V025kkkXwtYy6db7jnbE91Nc4HoN878e9fqh/wQB/aU+HfwX/ZV8Uaf4v8AHXg3wvf3Hiya4ittX1q2sZpIjaWih1SV1JXcrDIGMgjsa8zK62Hx2bOriUuWSvZ7Xsv10P0vxIy/PeCvCujlvD1SpGvQqKEZU1ebg6k7OyT3i4t6bnpP/EN78Dv+hi+J/wD4MbP/AORa86/bN/4JI/Dj9hL9ib4u+MPCOqeML7Ur3QrbSXTVruCWERSapYyMQI4UO7MS856E8V94/wDDfvwO/wCiw/C7/wAKzT//AI9Xgn/BVP8AaO8A/HD/AIJu/Fyz8G+NPCviu4sbKxmuU0fV7a+Nuh1C3wXETttztIGeuK+txWX5dTozqUIx5lGVrWvs+x/KfCfH3iPis/y7DZxiMS8PPEYdTU4yUWnWhpJtJWvbqfg7pOsXXh7Wba/sbmezvbKZZ7e4hcxyQyKQysrDkMCAQRyMV++n/BJP/gpTpf7bXwqg0fWr2KD4leHrVU1a1YCP7fGpCC8iHQq2V3gfcc9ACpP5G/8ABOn9i6P9unxf488JQ3aafren+GJdW0a4kJ8pbuO6tkVJMc+W6yOpIyRuDYOMV534E8Z+OP2Hf2krfUoIrrw/4z8D6jtntZ12/Mpw8Mgzho5FypwcMrZBwQa+IyfHV8sccS1elU0fy/Vfij+0PF7gnI/EWnieHKU1DM8ElOm3o7Timr96c37srfDJJ9k/6e0OR6180f8ABYsZ/wCCafxW/wCwdB/6WQVX/wCCY/8AwUa0H9uz4NwySTQWPjzRYlTXtKXgq33RcRDvDIRkY+6SVPQE2P8AgsQc/wDBNL4rf9g6D/0rgr9KxGIp18BOtSd4uL/Jn+cvDvD+PyPjvBZVmlN061LE0VKL/wCvkdV3TWqa0aaa0Pyf/wCCP3/BP/wT+3n4u8cWPjS78RWkHhu1tJ7Y6TcRwsxleVW3745M/cXGMd+ua+8l/wCDdL4C7M/2v8Tt3/YTtsf+kteA/wDBtD/yUP4t/wDYO07/ANHT1+wQ/wBT+FfO8NZTgq+AhUrU1KTvq/Vn7t9IjxS4tyXjzF5dlWYVaNGMaTUYyslzUoN2Xm22/M/nI/4Kj/so+G/2Mf2r7vwR4Vm1a40m3021u1fUZklnLyqS2WVEGOOOOPevq3/gmL/wR4+Ff7Y37J+k+OPFWoeNbbWL68urd49MvoYoNsUpRcK8DnOAM/MefSvI/wDg4F/5SIah/wBgHTv/AEBq/Q7/AIIH/wDKOvw3/wBhXUP/AEe1eXlOX4WrnNehOCcI81l0Vmj9Y8UOO+IMB4OZPneDxc4YqrKhz1E/elzUqjld+bSb80YPhz/g3w+B3hPxFp+qWWrfEdrrTbmO6iWfUrYxsyMGAIFsDjIHQivxX+Kq4+LfiQf9Ra6/9HPX9T0vQfWv5YPin/yVnxF/2Frr/wBHPVcX4HD4eFJYeCjdu9vRf5nH9E3jTPeIsbmc88xU8Q6cKSjzu/Ldzvb1sr+h/Tn+z9/yQbwT/wBgCw/9J464/wDbl/aJtP2Vv2ZfFvji4kRZtI0+T7DGzACe7f8AdwR475kZc46DJ7V1vwFkEXwB8Es3QaBYf+k8dflR/wAHHv7UX/CT/EPwp8J9OuC0Ph6NtZ1ZEPym4mGy3Rh/eSLe/wBLha+uzLMPqeAdfray9WtP8z+T/DPgWXF3HNPJ5L917SU6lv8An3BtyXlzaQT7yR+Zmranc65ql1fXk0lxdXkzTzzOctI7EszE+pJJr92f+CEP7XaftDfskW/hfULjd4i+Goj0qcO+Wmszk2sn0CKYv+2Of4q+Q/2c/wDgl3/wmP8AwR48a+KrjSzJ448UIvibRy8f7yG1st7RRoOu6eM3BBGNwmi/u14V/wAEY/2n1/Zo/bi8PrfXX2fw/wCMx/wj+oktiNTMy+RIe3yzCMFj91Xf3r4XJ/bZZi6M63w1kr/N6fNO33n9t+LX9keJPCebYTKFfEZTVfLbq6cbz5UvsyXtIRXWUE10P6Ewc1/L3+1Uuf2ofiR/2NOp/wDpXLX9QFpJ5kIO3b7V/L/+1T/ydD8Sf+xp1P8A9K5a9njj+DS9X+R+SfQqs8zzT/r3T/OR/Td4DXb4J0j/AGrKEn6+Wtcn+1fa+N7z9nLxlH8N3t4/HD6ZINHM23b5/YDd8u4jIUt8oYrnjNdZ4E/5EnR/+vGD/wBFrWtX2so88OW7V1ut/kfxnSxX1bHLEKMZck1Llkrxdne0l1i9muq0Pw0/ZD8XftqfsteDNQ8I+F/Dus+F/DFpLJdT3PizSY7PTtIySZJlubsJGqZyxAZlzkgEk519ej+DP7QV/NcftKftca54r8Rf8u1l4XsLptJ05+QSj/Y3gYe8ccee5Oc1+hH/AAV3/Z+8ZftV/s66T8P/AAZpcl1da9rts17fteR29rpVvGdzSzgtvkXOMIiscgHsM/Pk/wDwbRfDu48LQx2/xA8aQ6xsAlupEtpLZmxyVhEasoz2MhwO5618TXyfGU39XoJ1YRS+OTUeuiSavZW621P7KyXxX4TzGl/bueVY5biq05L/AGOjTlWtFRvOpVnCrKKlJtJRjGUlFt8y1Pgr4q/AKP8AZX8X2fjb4J/Hbwj4qsbdvNtryy1630jW7LvsktJZVeRTwMJuDc7kUcH2r4LfCJ/+C3PxIk8QX/iLWvAvxR8K6bAms6tbaUb/AEjVkjbZBLGVlj+y3GOsYJV9pdAMOB7z4A/4NnPCui+JIbjxN8TtZ1zTY5AzWljpcenySgHO0yNJLwehwoODwQea+3/2Nrn4U/8ACpY9N+DraCPC+g3EumyRab1guIztcTbvnMhPzFn+ZwQ2SCCXlfDteU28TFQptpuF27vo1Z+797J8QvH7JsPg6f8Aq9iZYvMYpxhinSjSlGDtzRqKUeWtzW+H2UYJ+98SufJ/h7/ggRovie2iHxL+MnxP8dLHgrGJ/scQx6rMbhvyYV00X/Bvh+z2kO0w+MpW/vvrXzH8kA/Svfv+Cgnwq+I3xp/Zvv8Aw38Lde/4RnxTqV5bINSGoy2DWtuJAZiJIkZzlRjau0kE/Nxtb8g9AXwl8M/iBplj4y0H9oT4iahrmrPolnq0/iEaJY6peRzCGQWmDKZAJPl3G5wcgkL0H1FPIcA9fZJ+uv5n8z47x046hU93MasE9f3bVKN/KNOKS+4+3PF3/BuT8FdZsJV0rXvH2j3WPkdb63uI1P8AtK0OSPYMPrXx/wDtxf8ABCjxV+yn4CbxZ4d8WWfjDR47y3tZLd7JrO+haeZIYiFDOsg8yRQTlSAc4IBr9af2d10n4D/sw3F9d6H4w8H6ZocF3qN9Z+JNW/tbULSOLe0jGYTzhk2oWUK+NpHyqSRXyL+yJ/wVY1/9v/8Aawk0O08RaX8MfCek7tRsdJn0YX194ktYmPm+fdu3lW2FAJ2LkZIDErk8mK4Xy+tBqNNRfdaWPrOG/pMcdZNiqVTEY6WIg2uanU5Zcy6rmceaN+6at2ez+7f2ePhvcfB34E+EfCt1ql1rdz4d0m30+W/uWzJdtHGFLnOepHAJOBgZPWt7xf440b4f6LJqWu6tpujafEwV7q+ukt4UJOAC7kAZPA5rQjO2D6DtX42f8FVfiN4p/wCCjX/BRbR/gP4FuJJNI8M3Q051Ln7KL4KXu7yUL/DAmY+ckGOTb9/B92lTS91bI/EM0zGpKcsTU96c5X6K7k7vbRfJWP2Ssb6HUrSO4t5Y54JlDxyRsGV1IyCCOCCO4orxr/gnz+zzr37Kn7LGh+AfEWtJr914eub2C2u1UrutDdStbjBJIPlFMrkhM7QSFBJQ99Bwk3FNqzPgf/g6C/5of/3Hv/cbXxp+wX/wU/8AG3/BPrw/4i0/wnovhnVofE1xDcXB1WKZ2jaJWVQnlyJwdxznNfZf/B0F/wA0P/7j3/uNrQ/4NpfDGm+IPhn8VWv9Osb5otUsAhuIFkKAxS5xuBxX5tjKNWrxDKFCfJKy1te3uLof6McLZzlWV+AOExudYNYuhGUuak5cik3i6iT5knblbT21sfPXxR/4OBvj18VPDF1ounWnhHwzJfIYftekafMbxA3B2NLLIqn0O3I7HPNQ/wDBMb/gkX4t/at+INt4u8fafqWh+AdPuRcTtfRtHdeIHDBvKjDDd5bfxynggkLlslf3M07whpOkSbrTS9OtW9YbZEP6CtDYv90flXvU+GpVKsauOrOpy7K1l+bPwjGfSKwmXZVXyzgjKKeXOtpKop887baPki72vZtvlu2knZr+cT/grFEtt/wUS+Kka/Kq6sFA9AIY8CvRP2fbv9tZvg14fHw6HxGPglbbGk/2fHH9m8ncfuEjON2a89/4K0f8pF/it/2Fx/6Jjr9rf+CSK/8AGuX4U8f8wj/2rJXzeU4H61mmIi6koWcn7rs/i6n9GeJnHD4Y8NcgxqwVDFc8KEeWvD2kV/s9+ZK6tLS1+zZ+C37SPxy+LHxF8T3GgfFDxN4r1TUPD93JDNp2rXUjCxuFJVx5RO1WByMgdPav1G/4IMfsQ/DvTfhTZ/Ga31X/AISfxjfLLZLui8qPw24yksKoSSZSpGZDjKONoAYluX/4ODP2DLW60K3+NnhbTfLvrV1s/FKQIP30RwsN2wHdDiN25JVo+yE180/8ESv23/8AhmT9pFPCeu3y23gvx9IlncNKf3dhe8i3n/2QxPlsemHUnhBisLR/s7OVDG+8nblk3e19pa/c+xhxNmVXj7wgni+DrYeUFetQpRUVLlV6tKyV0mmqkbazjaLvdo+Wf2go/J+PnjZSMbNfvhj0xcSV/TP8C5fP+D3hR+u7RrQ/+QUr+cX9vvwbJ4B/bc+LGmPCYEh8V6jLChGMQyXDyxfgY3U/Q1+/n/BPz4yaP8av2Q/h9rmlXkN2smh2lvdCNtzQXUUKRzRMOzLIrDn2PQiu7g/3cViKUt9Pwbv+Z8X9LSMsXwrw/mVFN0+V67pOdOlKKb81F272Pa6+K/8Agvu//Gt7xF76rp3/AKULX2kZlA+ntX5w/wDBxN8dtF8O/su6X4Dj1C1k1/xFq9vdGyWQGaO1hEjNMy/wqZPLUZxk5xnacfU55OMcvrOT+y183oj+YfBHB1sTx9lNOhFyarwk7dIwkpSb8kk22fI//Bu6pb/goI+B93wxfE+3zwV+7Ffiv/wbb+AbjUv2m/HHiT7PI1npPhv+zzLj5UluLiJ1GfUrbyfhmv2khkVYlG7OABXmcHx5ctUn1cmfo30tcdSr+IdanTd/Z0qUX68rl+UkSV+OP/BzLrVrP8bfhlpqsv2610a7uZV7iOWdVT8zDJ+Rr9XPjf8AHnwn+z34Bu/E3jDXLHQdFswfMubliNzYOERQCzuegRQWPYGv51f26f2qdU/bg/am1zxlLDMtvfTLY6NYgFmt7SMlYYwvPzNkuwHG+Rsdax4wxlOGE+rX96bVl5J3uev9Efg/HY3i1Z/yuOHwsJ3m9Iuc4uCins2lJyfZJX3R42wPkLwcZ6+tfWX7AP8AwSU8R/t/fCzVvFOj+LND8P2+k6q+lPBeQSySOywxS7wV42kSgY6/KfauP/b5/Zen/ZLs/hP4b1G3a28QX/gyLV9ZjYjdHdT3t2xjOOMxoI4z6mM1+kP/AAba/wDJn3i//scZ8/8AgFZV8nkuU06mYfVcWr+7dq7VnZP8L2P608ZPFbHYDw+/1p4ZqqEpVVGMrRmnHnlC6Uk1aSjdO17NHgn/ABDTeOP+ineEf/AO4rV8d/8ABLfxB/wT2/YF/aA1LWPFOj+I4/Emj6ZaxJYwSRmEx6lCxLb+oO4dK/YDzU9RXy5/wWidW/4Jm/FEL1+zWX/pwts19niOH8BhaNSvQg1JRlbVv7LR/HXDv0guN+Is7y/Js2xMZ0KuJw6klThG9q9OS1UU1qlsz87v+Dbtd37aHi1T0/4RCcf+TtnX1r/wWc/4JY2P7Svgi++I3guxaL4jaLbma5giBI1+2jXmPaOPPVR8jAZYLsOflK/Jf/Btz/yel4s/7FCf/wBLbOv2ynj81cYzXPw/gaWKyn2FZXTcvlruj3vH7jLM+FvFmWdZTNxqU4UvSUeRc0JLrGS3XzWqTP5k/wBnf4+eMv2Ev2jbXxFpcc2n6/4bupLPUtNulKLcIG2zWsy9gduD3VlBHKiv2M/bY/af8O/tdf8ABGzx9408M3KyWOpaTbia3ZlM1hOLq38yCUD7rofwIII4IJ8//wCC2f8AwS0t/jL4R1D4reAtJb/hN9KQTaxaW+P+J3aovzSBO88YAIxy6AjBIWvyc+Gn7RHib4WfDvxp4Rsbzd4d8dWSWeqWUmTGzJIkkcyf3ZFK4z3VmB7EeE6lbJp1MDV1pTTs/Nq1/wBGvmftlPLcn8X8Nl3GeUWpZhgqtL2sG9XGM1KUJPqrXnSlbXWLs+ZR/QP/AINof+Sh/Fv/ALB2nf8Ao6ev2CH+p/Cvx9/4Nnj/AMXB+Ln/AGDtN/8ARs9fsEP9T+FfUcJf8i2n8/zP5a+lNp4k45f3aP8A6Zgfgz/wcC/8pENQ/wCwDp3/AKA1fod/wQP/AOUdfhv/ALCuof8Ao9q/PH/g4F/5SIah/wBgHTv/AEBq/Q7/AIIH/wDKOvw3/wBhXUP/AEe1eNkf/I+xPpL80ftPjB/yYjIv8WH/APTNU+2Jeg+tfywfFP8A5Kz4i/7C11/6Oev6n5eg+tfywfFP/krPiL/sLXX/AKOejjj4aPq/0MfoT/71m/8Aho/nUP6W/h/4ssfAf7Jnh/XNTuFtNN0fwra313MekUUdqju34Kpr+e/VfEd1/wAFAf27JNR1/U7XQ18f+It9zeXk6RQ6XZluhdiFxFboFGSM7AOpr9EP+Cy37T8nws/4J7fDT4f6Vdtb6p8QNKsjeiN9rf2fBbxM4OOQJJTEvP3lWQcjNfIn7A//AARy8Z/t4fCG88aab4i0nw1pcOoPp9uL6CSRrwoiM7rt/hBbb9Vb0rLiKrVxeJpZfh483IuaS2vouvkvzPT8Bcry7hbh7MuNs7xKwrxU50aVRxcuRKUlzKKV5c1RN2tb90ne1z9o/Cnx9+EfgrwLp+g6d4++H1tpul2UdjbW669abIoo0CIg/edAoAr+fX9tf4VaX8Bf2rvGGieGNU0/UtBttRa70a7067S4i+zSYliVZEJG6MMEOD95DX2x/wAQzvjz/opPhX/wCn/xryP9tn/giN42/Yw+A174+u/E2i+JNP0y4hhvILK2ljkt45G2CUluCocopH+3noDUZ/8A2hi6CdTDcihrfmvZdT0fA3/ULhXPJwy3iH61LGctP2cqU4KU3Jcj5nf3ruSV7J82p+s//BNL9r2P9sj9kjw74pkZV1y1VtN1qMc4vIQA7+wkBSQDsJAO1fgB+1Qc/tQ/Ej/sadT/APSuWvtL/g3e/ag/4V1+0PrXw21K4VdN8c2putPR24F/bgthewLw+Zk9zCgr4t/aqbH7UPxI/wCxp1P/ANK5a4s6zD65leHqy+JNp+qS/NWfzPrPBrgP/VLxDz/LaUbUJU6dSl/gm5tL/t180P8At0/pu8Cf8iTo/wD14wf+i1rWrH8CzqvgrSAW5FlCD/37WtX7Qn96v1COyP8AM/Ev97L1YskQl60v3V+lCuH6fypJ93kPt5bacD3qjHTc+Ff+Chv/AAUYvPD3xhuvgv4OvLrwnqGlxQap4w8Z3Ue238OaTtjlle3+VjLO8brGuFx5kiou52+TC/4Iy/DeP4cftS/tS2kN81zaL4gspbFVk3Ry2k7XlzbzgdDvhlQgjsDXxR/wUw/ay+IZ1bx/4C8bfB/wx8O9a8W6rbXmparYRT/adZhtRtgBuWYrcRDbGQyBVyn3Qciv0C/4I+eIfhz8W/BWl+MvC/iSS48b2fgnRvCvjDSR+7xNZR7ILiRGXcz7Q6LIrFCoxyQcdEo2hc8elW9pibN7fLfS36n29XOa/wDCHwv4r8VaTr2qeH9G1DW9BLnTdQubOOW608vw/lSMpaPdjnaRmujrnPiz8QND+GHw91PWvEmvWvhjR7SMLPqlxKkUdkXYRo+5wUB3soG4EZIyDXOevK1tTD/an8ON4q/Zg+IukxBmk1LwxqVogHcyWsiD+dfmr8LfhtoPw5/4IGXHiS18O6T/AMJx45sbjQFv0soxf36XetNBHAZcb2XYQ20nHHTirnjL9ru+1bWpdLv/ANpr4vwaHq0sNhp+rD4ZWlppetabJIIrmSKdguWh8xWkuyIwi/cRyQD7l4w8BaNf/tP/ALP/AOzn4NWWbwf8J4U8aeIWZhIyLaoY9PWVgArSSXDmRxxncrAY6bx93c8urWjUlzx7W+bat+vyPr/xN4ot/gr8EtQ1e+dpbXwrost3OxPLpbQF2OT6hDXwj/wQO/ZtXUfBXij49eJYRdeLviNqV4tpdOOYrYTkzuvoZbgSZ9olweSK+lv+CpmrXGg/8E8/i1NZrI0jeH57c7eojlxFIf8Avh2z7V2n7FPw5h+Ev7JHw38OwxLF/ZnhyxjlAx80xhVpW4/vSM7fjUJ2idMo82Ijf7Kv82eoAYooorM7D8qv+Dmrw3qPiH/hSf8AZ+n3t95P9u+Z9ngaXZn+zcZ2g4zg/ka2f+DavRtQ8N/Db4pR31ldWbTarYbVuImjLDypc4yBX6dPGsn3lVvqKalrFGxZY41Y9SFHNeHHJIrMnmLnr2t5Jb38r7H7hW8aKtTw4h4e/VFyxd/a87v/ABnW+Dl8+X4vPyJKKKK9w/Dz+df/AIKqeDNa1n/goR8U7q30fVLiCbV8pJFau6N+6jHBAwa/Z7/gk3azWH/BO/4W29xDJbzQ6TteORSrIfNfgg8ivoY2sZP+rj/75FOihSBcIqoCc4UY5rwsuyOOExVTFKd+e+lrWu77317H7l4g+NdXinhbL+GJ4RUlhOS0+fm5uSm6fw8kbXvf4nbbzMnxt4I03x94Q1TRdWs4dQ0vVraS0u7aVcpPE6lXRvYgkV/Or+3h+wT4o/Y6/aK1XwxHp+parokzG90W+t4HlFxaM7bAxA4kTBRh6rkcEE/0hUw28ZOfLTPrtq86yWnmMIqT5ZRej39V0/M8/wAHfGTMOAcZWq4ekq1GtFKdNycU2vhkpJOzV2ttU7dFb8BtO/ZX8Z/8FHfg3D4m0O0ubr4ueBbaPTPEGn3+befxLYoNtpexSSYDzxxr5EgY/MIo2zubDeW+BPiV+0B/wTq8SXUemt42+HM00o+0Wt7YOlrdOvGTFMhik4HDAHjocV/SV9liz/q4/wDvkU2WwgnGHhhcejIDXk1OEYtxq06zjUW7S3897p99dT9SwP0qKsIVcuxuU0q+Ak240ZyvyJ6uCk4OLgndwi6d4K0U2krfgDr3/BcL9pTxVpZ02HxhZ2clxhDLZaJarcOT6Hyzgn/ZANeeaX+yH8aP2j9T1Hxt4u0/xHY6SxW41fxZ4pjuI4EQsFDb3UyTtkqqpErsTgAen9HNr4X02xkZodOsYWkOWKW6KW+uBVr7LH/zzj/75FVU4XqV/wDe8RKaWy1t+b/CxeH+k9l+URl/qrw/Qwc5aSkmm2tLr3acde3NzRT1cXs/wR8Pft9eOP2QdOi8H/s+6LqOjeE7VQ99qWreHln1DxFeniS7kDBhEhAVY4lPyqoySxOLOof8Fk/2ttRs2hj1Sa1ZuPMg8K2+9fpuhI/Sv3lFrGP+Wcf/AHyKX7PH/wA80/75rT/V/Fr3YYqUV0STSS8vePK/4j9wxUftsbwxRr1nrKpVqKc5y3cpSlR1b+7okkkl/OZqvwk/ab/b/wDGUN7qmhfEbxpd/dhudQt5ILG13Y4V5AkEQPBwCua/Rf8A4Jhf8ERbT9nbW7Px58UG0/XPGVjIJ9M022bzbLSHHSRyQPNnU8g/cQjI3EKw/RxraN8ZjQ7emVHFKIVXoq/lW2B4Zw9Cr9YrSdSfeX5+vqePxp9JLP8AOMreRZVQp4DCNcrjRum49Y82iUXs1GMbq6bs2j8WP+Di/wAKanrX7YfhM2Gm6heRxeEIELQWzyKD9suzgkAjPI/MV84/sxftqfHz9jzwPeeHfAP9oaTpWoXzajPHJoCXJeZo0jJ3SRsQNsacDjjNf0aG2jZ93lpu9dvNH2eP/nmn/fNZYrhudTGSxlGs4Sl2Xp1TR7XDf0kMJgeFMNwnmmTU8XRoq37yekmpNp8rpySavZas/Bb/AIfHftb/APQWuv8AwlLf/wCM1ynxu/4KRftK/tEfC/VvBviu6vr/AEDXI0jvIE8NxQtIqyLIvzpEGGGRTwa/oU+zx/8APNP++aPs8f8AzzT/AL5qJ8O4ucXCeLk09GnfZ/8AbxthfpBcJ4WvDE4fhPCwqQalGScU4yTummqN001dM/Fr/g3M8LapoP7ZPimS+02/s438IzIHnt2jVm+2WhwCwHPB49q/aimLbxqciNAeuQtPr2spy/6lh1h1Lm1bva25+N+KfiFU404gqZ9UoKi5RjHlUua3KrXvyx39COWASnn+Vfjb/wAFrv8AglS/wz1yb4rfDfSZJND1Sct4g0y0jLf2fcSNxcxoBxC7HDAfdcgj5W+X9lqYbeMnPlpn/dqs0y2jjqDo1fk+z7/5mfhn4kZpwTnUM3y33ltODbUakOsXvZreMrPletmm0/yK/wCDbbw5qPhz4h/Fb+0NPvrFJtO08K08Dx7iJZ843Aeor9dAx+zZ77aDaRM2THGT0ztFSEZFGVZesFho4dO9r6+ruZ+KHHVTjLiOvxDUoqi6qguRS5rckIw3tG9+W+ysfhL/AMF7fCera/8A8FCdSmstL1K6hXRNPQPDbPIvCN3AxX6Ef8EH9JutH/4J7+H7e8t7i0nj1PUGMc0ZjbH2hscHmvs77LFuz5cefXaKckKR/dVV+grjweSLD4+pjVO/PfS212nvfy7H2XF3jTUz3gbA8FSwigsK6b9pz3cvZwlD4eVWvzX+J2t8wmOFH1r+Xf4ofD3X5Pin4ikXQ9YZDqt0QVspDn983tX9RLKHGGAYehFMWzhQfLDGuTk4Uc0Z3kkcxjBOfLyt9L7/ADRPgv4zVPD+ri6tPCLEfWFBaz5OXkcv7sr35vK1j+cr9uDx74q/as/aCspLHRdeudP0XS9P8M6ND9jk5WCFI228fxzmVx7OB2r95/2L/gJB+zD+zJ4N8CwrCr6DpcMV00f3ZbphvuJB/vTNI3/Aq9PNtGR/q0/75p4XaOBijK8lWErVK8p80p+Vrfi/6Rl4leMU+KcnwORYbCLDYfC/ZU3PnlZRUm+WNmlzPbVyk+oVyfxy+F2m/Gz4TeIPCOsR+ZpniKwm0+4GOVWRCu4f7S5yD2IBrrKbJEso+ZVb6jNe44pq0tj8boV6lCpGtRk4yi001umndNeaeqP5jZvh38RP2Wv2gJDa6XrOn+KPAuskRXMFnI6rcW8vDqcYZGK5HZlbuDWR8VNO8Q/Er4n+IvEf/CO6tbtr+qXOpGL7JIREZpmk29O27H4V/UOLaMf8s4/++RS/Z4/+eaf9818PLgtNOCrPlve1r/r2P7Uw/wBMipGpHE1snhKsockpqs1zLRvT2b0vdpXdruz1Z/P1Z/8ABVf9rawtI4IfF2uLDCgRFPhixbaoGAMm2zXbfs5/8FPP2qPGn7QngPR9a8WaxNo+reItPs7+NvDdlEskElzGkilltgVBUkZBBHqK/c/7PH/zzT/vmj7NGf8Almn/AHzXdDh7FKSk8XNrtr/8kfGY76QXC1fD1KMOE8JGUotKVqd02rc1/YJ3T13T8yLTn3IwzuYYzVhvunNNSNY/uqq/QVi/E2XWIPhv4gfw8scmvppty2mK4BVrkRN5QIPGN+2vqj+V9lqfnP8A8HK3ibTV+BHw90c3VsdUk16S8S2EgExhW2kQvtznbudRnGM8U7/gh1+yLqfgf4ueIviha6Pq3hzwXqnhPTtE06DUY3hm1e78m0e8vFjf5hCbiGYoxwGWf5QAMD4C+J/wq174wfDGfxl4y1XxNqvxi1j4jL4S1G11cMrWam23ou09N0jldoAVFiAUAZz/AEQ+G9Gi8P6FZ2MK/u7KFLdDjnaoAH6AV0T92PKePhY/WMQ68tLWsjw39pzxf8Zvgh49tvF3gvQ7f4keBFtBHrPhaMrBrFtIpb/SbGTGJcqRuhfJJQbCNxxg/DP/AIKu/AX40xS6Rqniqy8J6qCYL3RPGEB0q4tnHWKTzv3RYHjCu1fTxUN1FeX/ALQ37Gnwx/ao0trXx34L0XXm2hUunh8q9hA7JcRlZUHsrgVjG3U9KVOpHWm/kz4Z+Pvgf9nP9lrXF+JEXxo1bxPoPhmb+2dA+GVn4tTUNPm1IP5kHkwq7MsKyhXwRtUrksV+Q/SX/BLj4M+IfDnwg1T4mfEG12fE34uXY17WS8RSS1t8FbO0AblEihwQh5QuVPK1R+En/BFT9n/4N/EfT/FGm+E7u81DSpVuLNNS1Ga7t4JVOVfy2baxB5G/cAQCBkZr3748fHPwv+zX8LtS8X+MNTj0nQdJQNcTsrOxLMFVFVQWZmZgAoBJJ+tVKomrI56GHcJe0qJLyW3qfJ9l+3FqH7TX7Zvxc+CPiD4fzal8IdLtJtA1PWYUKLp8nlv58l5OZFWOF1WRU2fOpRTzklfrj4JeJ/CXib4baX/whOt6Xr/h3T4Rp9pdWF8t7CVg/dbfNVm3FduCSScjk1+VviX9orwHqH7D/wATLrxFoviLUNU/ag8fanqPhXRtMcW+oXFrHPBFbtI53KgWaMqcq+5nICsAxH6bfsi/Di4+En7N3g/w7eeH9F8L3Wk6csEumaVO1xbWhyTtErANI/OXcj5nLnJzkk421DCVHKTu79fRN6L7j0iiiisz0AooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKRhuUj1FLRQB5Hqv7Dvw01rxGurXfhuC61BfFSeM2mnmkkMmppCYElbLcqiEbY/uAqpC8V64Biiim5N7kxpxj8KCiiikUFfOf/BRX9ii+/bp0DwB4XfVI9P8ACel+JY9U8SQ+c8U17aJDIvlxFUYFyzgfMVADFs5UA/RlFGxNSCnHllsea3f7Ifw5vdJ8C2UnhHRzB8NbiG58NgRlTpTxKVjKEHJA4OGJBZVYgsoI9KUbRgUUUXbCMUtkFFFFBR//2Q=='
                ,
                rect: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAK4AAACkCAYAAAAOlxWIAAADKElEQVR4Xu3SUQ2AMBAFwVY7Cb4Ivjh+MLFhquB1b/bMzPIUiBXYc12z7js229y/F9hzHM86z/33EP7fKgBu617WfgXARSFZANzk2YwGl4FkAXCTZzMaXAaSBcBNns1ocBlIFgA3eTajwWUgWQDc5NmMBpeBZAFwk2czGlwGkgXATZ7NaHAZSBYAN3k2o8FlIFkA3OTZjAaXgWQBcJNnMxpcBpIFwE2ezWhwGUgWADd5NqPBZSBZANzk2YwGl4FkAXCTZzMaXAaSBcBNns1ocBlIFgA3eTajwWUgWQDc5NmMBpeBZAFwk2czGlwGkgXATZ7NaHAZSBYAN3k2o8FlIFkA3OTZjAaXgWQBcJNnMxpcBpIFwE2ezWhwGUgWADd5NqPBZSBZANzk2YwGl4FkAXCTZzMaXAaSBcBNns1ocBlIFgA3eTajwWUgWQDc5NmMBpeBZAFwk2czGlwGkgXATZ7NaHAZSBYAN3k2o8FlIFkA3OTZjAaXgWQBcJNnMxpcBpIFwE2ezWhwGUgWADd5NqPBZSBZANzk2YwGl4FkAXCTZzMaXAaSBcBNns1ocBlIFgA3eTajwWUgWQDc5NmMBpeBZAFwk2czGlwGkgXATZ7NaHAZSBYAN3k2o8FlIFkA3OTZjAaXgWQBcJNnMxpcBpIFwE2ezWhwGUgWADd5NqPBZSBZANzk2YwGl4FkAXCTZzMaXAaSBcBNns1ocBlIFgA3eTajwWUgWQDc5NmMBpeBZAFwk2czGlwGkgXATZ7NaHAZSBYAN3k2o8FlIFkA3OTZjAaXgWQBcJNnMxpcBpIFwE2ezWhwGUgWADd5NqPBZSBZANzk2YwGl4FkAXCTZzMaXAaSBcBNns1ocBlIFgA3eTajwWUgWQDc5NmMBpeBZAFwk2czGlwGkgXATZ7NaHAZSBYAN3k2o8FlIFkA3OTZjAaXgWQBcJNnMxpcBpIFwE2ezWhwGUgWADd5NqPBZSBZANzk2YwGl4FkAXCTZzMaXAaSBcBNns1ocBlIFgA3eTajwWUgWQDc5NmMBpeBZAFwk2czGlwGkgXATZ7NaHAZSBYAN3k2o1/mNZvlQCVQ3wAAAABJRU5ErkJggg=='
                ,
                circ: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAK4AAACkCAYAAAAOlxWIAAALYUlEQVR4Xu2dgXXUOBCGfy0FXK6Cy1VwoQJCBYQK2N0rAKjgQgWEAtjdq4BQwYUKIBVcUgFQwK3ujZXNbja2V7ZlaWz9fo8XHljW6J8v88YjWTLgRQUGqIAZoM16TJ7ZZ/fGWJxggqNa49b4AYNv9/cszRc9gxmWJQS3zl9TewyD32BwCuAYFsfFT1P8DHdZ3AC4gbn7aXEFi1usjPw7rxIFCO5GFAfpHwWkEj0drOkvgViitIP5mjA7l+QL7tQeweAZDM5gcRo8ivaFvERnU0B8CYsvWJkffXWl+bl5gStRFXgBgykMTjQ7xts2W0TjFYDPOUXj8YMrkRV4NSpYq6jeQvz32CPxeMGdWRdZgTPv6DWuGyWVWGFpPo9rWGPMcSW6TvAatkgFwr75D9X7LideYY0PY4rC44i4krtO8BdQRFhe1QoIwO/GkAsPG1wC2/aXdPAADxNcAtsW2P12gwV4WOC6HFZSgjehPMfnFApc3KUQg6kJDwfcqX0Ng3OYA+sBSGI7BSx+wOIcK/Oh3QPittIP7tTKrNb70UwYxPVv895cLfgtVuaqeeN4LfSCy7QgHgXlPalOH3SC66LskrXYxOxKDdhipjH66gN3bt/z5SsxsI+7v8DCvNVklR5w3bLCT8xlNeGxY4vLfV9qmbzQAe6f9gzrIjWo/4JAqU+zMUsqDxPM8NFcph5zenDnVuqy56mFYP+NFDjHwrxr1CLwzenAdVUDyWe5viCwUyM9TmbdpGyWZNIiDbju64N/mM9GQqyvblze+zwFvPHBnVr5nktewrjssC+gYj7XwSsls+3XyxH6jwuug1YiLV/CIjg3WhduulgibzR444FLaKNxlKSjyPDGAZfQJmEpeqcR4e0fXEIbnZ+kHUaCt19wCW1ShpJ1HgHe/sB1U7hf+SKWDJ+0HTt4n/Y1RdwPuKzTpoVGS+891nn7AXdmJdKOY6cYLRAM1Q6Bd2mehjY/PLhzu+Q0bmg3Df55KyzMLOQowoI7t/IRo6w/4EUF9hV4i4W5CCVLOHClgjDB11CG8TkjVGBdvKwFmV0LA657GZO8lusPRshbsCG5T4EE3s4rysKAO7efMt5cLphfM3nQJRbmZdexdgeXeW1XH+TYvnO+2w1cTjLkCF33MQeYnOgG7szKEkUdZyV0l5NPiKmAnGmxNM/bdtkeXKYIbTVnu60CrVOGduC6KsK/XIdABjsp4FKG39tUGdqBO7MrGLzqZDQbUwFRwOJvLE3jD2abgyvbI03wD1WnAsEUWBef/TTaZK85uHwhC+YvPuhOgRYvas3AlR1nLGSygRcVCKtAw6jbDNyZlRcyTuuGdRmf5nLdGyzN775i+IM7t5JAy5JFXlSgLwVmWBg5JfPg5Q8uo+1BMXlDRwUaRF0/cJnbdvQIm3sr4Jnr+oHLSoK37ryxowKeFYbD4HKBeEdPsHljBTwWnB8Gl7NkjXVng44KeMym1YPr9rD93tEMNqcCzRTwWMNQDy5XgDUTnHeHVKB25Vg9uNwfIaQj+KwmChzYj6EaXHfQ879N+uK9VCCoAutiyeNN2TOrwZ1bOVBEDhbhRQVSKfAOC1N6sE01uJwpS+Us9rtRoCZdKAeXaQLh0aJARbpQDi6rCVrcRjuA0upCObgzewmDF1SNCiRXwOIzluZs346qiGuTG0wDqMBGgYV5xOljcPlNGYHRpkDJirHH4LIMps1ttAd4VBZ7DO7MXsHgGdWiAmoUKMlzy8D9zo0+1LiMhogCsuhmaX7dFeMhuKzfEhStCqzx6+6ON/vgcrMPrY7L3a69F7SH4PLFLHc8NI//wQvaQ3D5tYNmx+Vt295XEfvgsqKQNx56R2/xBUtzvxfzPrisKOh1Xd6W7e25sJ/jcqo3bzx0j35n6ncLLkthup1G64CdJY674LIURjh0K7BTEiO4ul1F63YVKAWXuzESEu0KGLzER3MpZm4jLicftLuN9u2sEiO4xGFICtzPnhHcIbmNthJcMjBIBQjuIN1GowkuGRikAgR3kG6j0QSXDAxSgRJweUDJID2ZldGlExDcTyErBgY5WK5VGKTbaHQFuNzImWjoVqB0WaOYPLdcSK7bdXlbV7qQ3IH7A8AveavD0StV4BYLc38AOj+WVOolmrWnwIGPJVcweEXRqIA6BWo/T+eaXHX+okH3CtRsCMJaLjnRqkDtFkz80ler22jX3iEmZRs7s7JATLQp8BMLc7RrFDd21uYi2vNYAa+NnfmCRnT0KeCxlT5f0PS5LXeLvA4v4dRv7pjoG7/XcVFiNg/o0+e8XC1qeEDfGwDvc9WK41alQIMjUVnPVeW5rI1pdAi1y3O/Afgja9E4+NQKXGNhTsqMKD/L14F7DuCv1Jaz/6wVeFQG26hRDS7ThayJUTH4ijRBbKsGl+mCCt9lbERlmuADLqsLGZOTeOil1YTDqYLcMbVHmOB74gGw+/wU+Ik1jnePQN2XoD5VkLt5aF9+2KQe8d7XDs2qCpu7p/YEE3xNPRb2n5ECazzFykg5tvI6HHFd1OWJkxlxk3Soex9FVtniBy73FUvqy6w6L1kJ1i5V2LSa2xsAv2UlIgcbW4EHeyd0TxXkCTxOKrYTc+xvhoVZ+QzcL1Vg1PXRkvd0U8A72ko3zcBlrtvNNWxdrYBnbrt5QDNwWWEgen0o4FlJ2O26Obj8Jq0P1+X9zIbRtnmqsJGXs2l5gxZy9B6zZN3KYbut3RoGKY9xS9KQTszvWQfXJFRJ0jxV2FYYuHIsP9BCj7h2BViYOm7ZUzgVHNqR+TyvxQtZt5ezhymDnBshiyGYMuSDXIiRSopwgpWRdLPV1T5VYMrQSnA2KhRonSJs9OsOrjyJG4iQR18FKjb48G0eFlxXZZCUgYtwmnogr/tv71IE2cq20xUm4ooJXHDeyRFZNPZYIO6rQzhwpce5ZYnMV/n87vNe+eUjTVhwXb7Lk3t8lM/pnpazY3UShQfXRV5u35QTmPVjrd0foa1M/YDrXtauuPdYW7eMpt011jit+8y87Uj7Ade9rHFyoq1XxtGu8yRD/FRh06OrNEjk5czaOGD0HYVAK5G29hNz34eV3ddfxCW8Xfwy5La9Qyvi9A/utsbLyDtkHP1sjwJtPHAJr5/bh31XNGjjgkt4h41lvfVRoY0P7hbeS65rGA3HUvKa9vkilublrKxX1nnHQm1vddpDAsV5OauC1+ACBq8OGcn/V6iATONavOljcsFntOnA3VjHQ1J8/KTtnspDRWIZmh5cGanbIUf2jOJERSzPt+vnJwym+GjkHSXppQNc99ImU8QiCM9WS4pEZeeSz551+U4s5LD0gLsZ1cxK3vs65CD5rI4KWHzA0shaazWXPnBd9D3FpEgd+ClQWlTkUxspdcmsp6pLJ7gO3iMYnDP6JuJFoqzFeaqqwaFR6wV3Y7mLvhfMfQ+5Mtj/Sy4rZS51UXZ3hPrB3VjrvmeT84VZeQjG6IMH/Sz0XRgJEuqv4YDL9KE/mJSnBWUDHxa42/Th+C7/5axbF5zd7Jfksa23QurSfZe2wwSXAHfxOTBgYDcDHza4BLgZwCMAdlzgbgGWr4vlJW7KGvA907cAVljjQmtpq9lvn7t7HBG3bOSy/kGK5wYv2ggz+DayuZxM4ihYV9CHluMF92EUlggsf8a+DuL6LrquxhRdx1NVaPsr7BbynI0M4g2sl0OsDrR15fgjbpUyMqX8BKfFiieD0wHlxLewuCz2q/gPV2OPrFXuyxfcfUUkGj/BCWzx5xQGz9pGg6Dt5KwEgysYfMN/+JZTVK3TkeDWqSMwA5JenMLC/d3gqIdc+RoWstnxDQxusC52/7khpNXOIbhdwqMsANpckzuw658nUG5nqZQvZOkiTd9tCW7fCvP5vSjwP5QZgtJQ7YOQAAAAAElFTkSuQmCC'
                ,
                tria: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAK4AAACkCAYAAAAOlxWIAAAJJklEQVR4Xu2dT1pbNxTFJXvAlExae2azgrCDsAOygqYraPhqOm0yLfSjXUHTFYQdhB04K8BvhtNJmXaA1c//MfZ7T3+upCvpeMrTveLox0E2R0gKvLwpcPMwGFz0q8pbg4ILy4K/d6/f+s2/g+On/+S4e6ROL15Vj16bFVgc4Hpa9KuHkw9Sil+VEh8v+/cfPLUptizA9bD0K7edCCGPhVCP3SM1hOvSCg1wafVcVLuenvwhhPhpXRquSy8ywCXWdP6G7El2Ji/LdtVsiDdqdGIDXDotl277MPwkpPxhr6xSf4/6k3fE7YotB3AJl77Obdct4Lp0YgNcOi3ne9vPQojz2pJwXTK1AS6RlFcPgzdSdr60lVNqdnbZr+7ansPXmxUAuESEXE+HX4SQb9rLqbtRb3LW/hyeaFIA4BLwoeu224/H4LqusgNcVwUXn9vquu0GXbiuo+4A11HA62+Dc6E68zdlRi/sdY3k2nsY4LrpN3fb+Z92B+ZlVDXqTYbm4zBirgDAdeDg94fBOyU7f9mWkGr248/96pPt+JLHAVyH1bd3281eF65rqT/AtRTO1W3XbeG6dgsAcC10240tWhTYGYLYo42CANdCtXVI3GLowSGIPZorCXANNaN1281eF2Fzw3UAuIaCUbvtBl0c8TFaCYBrINcytijHyyM51C/sdU0UBbgGatWGxA1qND6K2KO2kgBXU6q2kLhmmdbHEDZvlWjxAMDV06n+SI7meO3H4LpaUgFcDZlCue16KnDd9kUBuO0aWcQWNYo2b3YRe2yREOC2CGQaEndFdvvxGMLmTVoC3BbSzEPiZOjCdRukBLgN4sRyW7hu+w8/wG0CdzocSyFft8vo6wkcrKxTFuDWKEMVW3RFGrHHwwoC3Bqy3EPirshuNgwImx+QEuAeEIWL266nBtfdXySAewBcPm4L18UeV/M3t6/Yomb72seUEBeXvfv5/93FC1mFXQb8hMSpOEPs8bmS2Co8U4Or224/18V9Ept9P5UfpF6Ht9tu0MURn5UUcNyVEC/vbeD6g4iDlcuVAbhCiNCxRdcfCsQeAe6CIe9HclxJfTkeYXM4bmpuu2a4dNctfquQnNtuP2Io+hafosGNHVt03UHMOrPTX76rvrrWSXF80eDGC4lToVJu7LFYcFN32+2OocwjPsWCm77bbtAt8ohPkeDa3ttA9Queuk6J90mUCa71vQ3UyFHVK+8+ieLA5RYSp0K3tLB5ceDyC4lToVuW6xYFbq5uu4n6FXSLTzHgphFbdHVfVXWP1OnFq+rRtRL38cWAyz0kTgVKKbHHIsAtw23LCpsXAW4pbrv9a1r+R3yyB7csty3HdbMHN9nYouumN/OwedbgphoSd2W2hLB51uAW67YFhM2zBbd0t83ddbMFN5/YovPG4XbUu3/rXIVZgSzBzSUkTsVKjrHHLMGF2+6dZ88ubJ4duHDbwz6dm+tmBy7ctm6DkdfByqzAzT226LznlbO3o++rW+c6DApkBW6+IXEqUvIJm2cDLtxWD+5cjvhkAy7cVg9cIfJw3SzALS22qIto7du0DO6TSB7cMmOLzugm/5/NkwcXbmsHcepHfJIGF25rB+1yVNq3+CQNLtzWBVwhUnbdZMFFbNEN2o3rKnV60a8qimohayQLbvEhcSpKEj3ikyS4cFsqapd1UrxPIklw4ba04IoEXTc5cBFbJIZ2VS61+ySSAxexRT/gCpFW7DEpcOG2vqBdfcag0rlPIilw4bZ+wU3JdZMBF27rG9q0XDcZcBFbDASuUF8ve5PTMN3suyQBLkLi9gtsMzKFsHkS4MJtbfBzGcM/bM4eXLitC4D2Y7m7LmtwEVu0B899JO/7JFiDi9iiO34uFTjHHtmCC7d1QY5qLN+wOVtw4bZU8LnV4eq6LMGF27rBRjuap+uyBBexRVr0CKr9OerdvyeoQ1aCHbgIiZOtLWkhbmFzduDCbUl5oyvGLGzOCly4LR1nPipxcl1W4F5PTz4LIc59iI6aJAqwuU+CDbiILZKA5b0Il/9szgZchMS9M0fUgMcRHxbgwm2JmApUhoPrsgAXbhuIOLI28V03OriILZLRFLZQ5PskooOLkHhY3ui6xQ2bRwUXbkuHUYxKMcPmUcGF28bAjbJnPNeNBu7V9OS9FOKGUkbUCq9ALNeNAi5ii+EB89cxTuwxCrgIifvDKEblGGHz4ODCbWOg5btneNcNDi7c1jdEceqHdt2g4CK2GAeqMF3VYzfgfRJBwUVIPAxC0boEDJsHAxduGw2noI1Dhc2DgQu3DcpPvGaBXDcIuL/9M3jdmXXG8dRE55AKhHDdIOAithgSGw69/McevYOLkDgHkMLPwXfY3Du4cNvw0PDo6Nd1vYILt+WBUKxZ+HRdr+AithgLGR59lcf7JLyBi5A4D3hiz8JX7NEbuHDb2Mhw6e8nbO4FXLgtF2h4zMOH65KDu4otjoWQAx6yYRbxFaB3XXJwEVuMjwnHGVDHHknBRUicIzJc5kQbNicFF27LBRKe86B0XTJw4bY8YeE1KzrXJQMXsUVeiDCeDcl9EiTgIiTOGBOGU6OIPZKAC7dlSAfnKRGEzZ3BhdtyJoTv3Fxd1xlc3NvAFw7WM3N0XSdwEVtkjQb7ybnEHp3ARUicPRvMJ2gfNrcGF27LnIlEpmfrutbgwm0TIYP9NO1c1wrc62+Dc6E688v08IIC7gpY3CdhB+50OEFs0X29UGGtgHns0RhchMSBmw8FTMPmxuDiSI6PZUNNIcxc1whc3NsAwHwqYOK62uAituhzyVB7qYB+7FEbXITEAVcIBXTD5lrgwm1DLBl6mLiuFrhwW0AVUgEd120FdxlblPPj5schJ49eJSvQvtdtBRch8ZIBivi9t8QeG8FFSDziwqG1aAqbN4ILtwU9URVocN1acHFvQ9QlQ/OVAnWuWwsuYotgh4cCh2OPB8FFSJzHkmEWq0921ezssl/dPdfjILhwWyDDS4F9190DF27La8kwm8Ouuw/udDiWQr6GYFCAlwK7rrsDLkLivJYKs9lV4HnscQdchMSBCm8FtmHzDbhwW95LhtktFVi77gJc3NsALNJRYOm6C3DnfyWTT53zdCaPmZasgOrObv8HgsjGpaG3KSsAAAAASUVORK5CYII='
                ,
                generatepdf: generate(mapOutput)
                ,
                chartpdf: chartpdf(mapOutput)
                ,
                chartpdfAlt : chartpdfAlt(mapOutput)


            },
            styles: {

                header: {fontSize: 14,alignment: 'center'},
                subheader: {fontSize: 8,alignment: 'center'},
                profil: {fontSize: 8,},
                profilBold: {fontSize: 8, bold: true,},
                hal4Table: {fontSize:5, margin: [0, 0, 10, 0]},
                hal3Table: {fontSize:6,},
                hal6Tabel: {fontSize:6, margin: [0, 0, 10, 0]},
                pengecualian: {fontSize:5,},
                lineSpacing: {margin: [0, 0, 0, 6]},
                itemsTableHeader: { bold: true, fontSize: 13, color: 'black'
                },
                totalsTable: {
                    bold: true,
                    margin: [0, 30, 0, 0]
                },
                rightme: {   
                    alignment: 'right',
                    margin: [100, 0, 0, 0]
                },
                tableExample: {
                }

            },
            defaultStyle: {
                fontSize:7,
                color: 'black'
            }
        }

        return dd;
    }

    var getOutputSQS = function(mapOutput) {
        // console.log('mapOutput.docIdStandar == ',mapOutput.docIdStandar);
        // console.log('mapOutput.docIdSubstandar == ',mapOutput.docIdSubstandar);
        // if(mapOutput.docIdSubstandar != ""){
        //        console.log('ada substandard');

        //        mapOutput.docIdStandar = mapOutput.docIdSubstandar;             
        // }else{
        //     console.log('tidak ada substandard'); 
        // }

        ////console.log(getFund(mapOutput));
        var test1 = getCashValueOrDeathBenefit('CLIENT', mapOutput.output.output['FUNDBENEFIT'], mapOutput.dataTopUp, mapOutput.dataPenarikan, mapOutput.dataFund, '', mapOutput.totalPenarikan);
        var test2 = getDeathBenefitForOutput('CLIENT', mapOutput.output.output['DEATHBENEFIT'], mapOutput.dataTopUp, mapOutput.dataPenarikan, mapOutput.dataFund, '', mapOutput.totalPenarikan);
        return [
            {
                columns: [
                    { text: [{text:'PRU', font:'frutiger'}, {text:'link assurance account', font: 'garamount'}], fontSize: 19, width: 260},
                    {
                        width: '*',
                        margin: [0,3,0,0],
                        table: {
                            widths: [ 'auto', 2],
                            body: [
                                    [{text:'RINGKASAN ILUSTRASI INI BUKAN MERUPAKAN SEBUAH KONTRAK ASURANSI', style: 'subheader', alignment:'center',margin:[30,0,30,0]}],
                            ]
                                                
                        },
                    },
                    { image: 'prudent', width: 120 },
                ],
            },

            { text: 'RINGKASAN ILUSTRASI', style: 'header' },

            {
                columns: [
                    { text: 'Nama Tertanggung Utama \nUsia Tahun Berikutnya', width: 100, style: 'profil'},
                    { text: mapOutput.tertanggungName+'\n'+mapOutput.age, width: 100, style: 'profilBold'},
                    { text: 'Jenis Kelamin', width: 80, style: 'profil'},
                    { text: mapOutput.gender, width: 100, style: 'profilBold'},
                ],
            },
            {
                    style: 'noBorders',
                    table: {
                            widths: [ 300, '*'],
                            body: [
                                    [
                                            {
                                                stack: [
                                                    {text: 'A. Rencana Masa Pembayaran Premi yang dikehendaki \nNasabah adalah '+''+mapOutput.rencanaPembayaran+''+ ' tahun*', style: 'profilBold', alignment: 'center', margin: [0,0,0,9]},
                                                ]
                                            },
                                            {
                                                stack: [
                                                    {text: 'D. MANFAAT \n(Hanya untuk ilustrasi, Keterangan lengkap mengenai Manfaat Asuransi, termasuk syarat-syarat dan pengecualian-pengecualian, tercantum pada polis, berlaku dan mengikat)', style: 'profilBold', alignment: 'center'},
                                                ]
                                            }
                                    ],
                                    [
                                            {
                                                stack: [
                                                    {
                                                        table: {
                                                            widths: [30,'*', 20, 55, 65],
                                                            body: [
                                                                    [ '',{text:'Premi Tahunan Pada Awal Tahun'}, '1', mapOutput.currency, {text:''+mapOutput.totalPremiThn.format(formatCurr)+'', alignment:'right', margin:[0,0,50,0]}],
                                                                    [ '','','2', mapOutput.currency, {text:''+mapOutput.totalPremiThn.format(formatCurr)+'', alignment:'right', margin:[0,0,50,0]}],
                                                                    [ '','','3', mapOutput.currency, {text:''+mapOutput.totalPremiThn.format(formatCurr)+'', alignment:'right', margin:[0,0,50,0]}],
                                                                    [ '','','4', mapOutput.currency, {text:''+mapOutput.totalPremiThn.format(formatCurr)+'', alignment:'right', margin:[0,0,50,0]}],
                                                                    [ '','','5', mapOutput.currency, {text:''+mapOutput.totalPremiThn.format(formatCurr)+'', alignment:'right', margin:[0,0,50,0]}],
                                                                    [ '','','6', mapOutput.currency, {text:''+mapOutput.totalPremiThn.format(formatCurr)+'', alignment:'right', margin:[0,0,50,0]}],
                                                                    [ '','','7', mapOutput.currency, {text:''+mapOutput.totalPremiThn.format(formatCurr)+'', alignment:'right', margin:[0,0,50,0]}],
                                                                    [ '','','|', mapOutput.currency, {text:''+mapOutput.totalPremiThn.format(formatCurr)+'', alignment:'right', margin:[0,0,50,0]}],
                                                                    [ '','','|', mapOutput.currency, {text:''+mapOutput.totalPremiThn.format(formatCurr)+'', alignment:'right', margin:[0,0,50,0]}],
                                                                    [ '','',''+mapOutput.rencanaPembayaran+'', mapOutput.currency, {text:''+mapOutput.totalPremiThn.format(formatCurr)+'', alignment:'right', margin:[0,0,50,0]}],
                                                                    [emptycol,emptycol,emptycol,emptycol,emptycol],
                                                                    [ '',{text:'TOTAL PREMI', colSpan:2, alignment:'right', margin: [0,0,36,0]}, '', mapOutput.currency, {text:''+mapOutput.totalPremiAll.format(formatCurr)+'', alignment:'right', margin:[0,0,50,0]} ],
                                                                    [ '',{text:'Total Top-up Tunggal', colSpan:2, alignment:'right', margin: [0,0,15,0]}, '', mapOutput.currency, {text:''+mapOutput.totalTopup.format(formatCurr)+'', alignment:'right', margin:[0,0,50,0]} ],
                                                                    [ { text: 'Informasi mengenai Uraian Biaya terdapat dalam halaman Hal-Hal penting.', style: 'tableHeader', colSpan: 5 },'','','','' ],
                                                                ],
                                                        },layout: whiteNoSpace(),
                                                    },
                                                    {canvas: [{ type: 'line', x1: -5, y1: 5, x2: 303, y2: 5, lineWidth: 1, margin: [0, 15, 0, 15] }]},
                                                    {text:'B. Asumsi Nilai Tunai di masa yang akan datang **', style: 'profilBold', alignment: 'center', margin: [0, 8, 0,12]},
                                                    {
                                                        columns: [
                                                            {
                                                                width: 110,
                                                                style: 'noBorders',
                                                                table: {
                                                                        widths: [60, '*'],
                                                                        body: [
                                                                                ringkasanNilaiTunaiHeader(mapOutput)
                                                                        ],
                                                                },
                                                                layout:{
                                                                    hLineWidth: function(i, node) {
                                                                            return (i === 0 || i === node.table.body.length) ? 0 : 1;
                                                                    },
                                                                    vLineWidth: function(i, node) {
                                                                            return (i === 0 || i === node.table.widths.length) ? 0: 1;
                                                                    },
                                                                    hLineColor: function(i, node) {
                                                                            return (i === 0 || i === node.table.body.length) ? 'black' : 'white';
                                                                    },
                                                                    vLineColor: function(i, node) {
                                                                            return (i === 0 || i === node.table.widths.length) ? 'black' : 'white';
                                                                    },
                                                                } 
                                                            },
                                                            {
                                                                table: {
                                                                        widths: ['*', '*', '*'],
                                                                        body: [
                                                                                ringkasanNilaiTunaiContent(mapOutput)
                                                                        ],
                                                                },
                                                            },
                                                        ]
                                                    },
                                                    {text:'Nilai Tunai dihitung dengan menggunakan asumsi tingkat investasi. Besarnya nilai tunai yang dibayarkan (bisa lebih besar lebih kecil dari yang diilustrasikan), akan bergantung pada perkembangan dari dana investasi. (Lihat Hal-hal Penting pada halaman terakhir)', margin: [0, 12, 0,8]},
                                                    {canvas: [{ type: 'line', x1: -5, y1: 5, x2: 303, y2: 5, lineWidth: 1, margin: [0, 15, 0, 15] }]},
                                                    {text:'C. Rangkuman Manfaat Meninggal', style: 'profilBold', alignment: 'center', margin: [0, 8, 0,12]},
                                                    {
                                                        layout: 'noBorders',
                                                        table: {
                                                            widths: [ '*', 25, 55 ],
                                                            body: [
                                                                    ringkasanManfaatMeninggal(mapOutput)
                                                            ]
                                                        },
                                                    },

                                                ]
                                            },
                                            {
                                                stack:[
                                                    ringkasanManfaat1(mapOutput)
                                                ]
                                            },
                                    ],
                            ]
                    },
            },
            
            {
                pageBreak: 'after',
                absolutePosition : { x :25,y :525 },
                columns: [
                    {
                        table: {
                                body: [
                                        ['Disajikan',mapOutput.agentName, ''],
                                        ['Tanggal',{text: mapOutput.QuotationDate}, ''],
                                        ['Kode Agen/SFC',mapOutput.agentId, ''],
                                        ['','',''],
                                        [mapOutput.docIdRingkasan, mapOutput.versi, {text: mapOutput.substandardValue, fontSize: 5, margin:[0,-3,0,0]}],
                                ]            
                        },layout: whiteNoSpace()
                    },
                    {
                        fontSize: 5,
                        table: {
                                body: [
                                    [mapOutput.pruMedLabel,mapOutput.pruMedLabelDesc],
                                    ['*','Manfaat asuransi di atas dapat diberikan selama biaya asuransi terpenuhi. Apabila Nilai Tunai yang terbentuk tidak mencukupi maka Anda dapat melakukan pembayaran Premi Top-up Tunggal agar polis tetap aktif.'],
                                    ['**','Keterangan lengkap lihat di halaman ILUSTRASI MANFAAT NILAI TUNAI.'],
                                    [mapOutput.valueNilaiTunaiLabel,mapOutput.valueNilaiTunaiLabelDesc],
                                ]
                        },layout: whiteNoSpace()
                    },
                ],
            },

// /////////////////////END HALAMAN 1
            backDated(mapOutput),

////////////////////END PREMI BACKDATE

            subStandard1(mapOutput),

////////////////////END SUBSTANDART 
            subStandard2(mapOutput),

////////////////////END SUBSTANDART 2
            
            {
                columns: [
                    { text: [{text:'PRU', font:'frutiger'}, {text:'link assurance account', font: 'garamount'}], fontSize: 19, width: 260},
                    {
                        width: '*',
                        margin: [0,3,0,0],
                        table: {
                            widths: [ 'auto', 2],
                            body: [
                                    [{text:'RINGKASAN ILUSTRASI INI BUKAN MERUPAKAN SEBUAH KONTRAK ASURANSI', style: 'subheader', alignment:'center',margin:[30,0,30,0]}],
                            ]
                                                
                        },
                    },
                    { image: 'prudent', width: 120 },
                ],
            },
            {
                layout: 'noBorders',
                table: {
                        widths: [ 190, '*','*','*', '*', 240],
                        body: [
                                fundAllocationPage2(mapOutput)
                            ]
                                                
                },
            },
            {
                layout: 'noBorders',
                margin: [0, 12, 0, 0],
                table: {
                    widths: [ 190, '*','*','*', '*', 240],
                    body: [
                        ['Frekuensi Pembayaran',mapOutput.frequency.descriptionInd, emptycol,'Mata Uang',mapOutput.currency, emptycol],
                        [{colSpan: 2, text:'Rencana Masa Pembayaran Premi yang dikehendaki Nasabah*'},'',''+mapOutput.rencanaPembayaran+' tahun','','',''],
                        [{colSpan: 2, text:'Masa Pembebanan Biaya Asuransi & Administrasi (tidak lebih dari)'},'','72 Tahun','','',''],
                        [{colSpan: 3, text:'Jumlah yang harus dibayar dalam 1 tahun (Premi Berkala & Premi Top-up Berkala)'},'','',''+mapOutput.totalPremiThn.format(formatCurr)+'','',''],
                        ['','','','','',{text:'Nomor SPAJ/Polis', alignment:'center', margin:[0,7,0,7]}],
                    ]
                                                
                },
                layout: {
                    hLineWidth: function(i, node) {
                            return (i === 0 || i === node.table.body.length) ? 0 : 0;
                    },
                    vLineWidth: function(i, node) {
                            return (i === 0 || i === node.table.widths.length) ? 0: 0;
                    },
                    paddingLeft: function(i, node) { return 0; },
                    paddingRight: function(i, node) { return 0; },
                    paddingTop: function(i, node) { return 0; },
                    paddingBottom: function(i, node) { return 0 },
                }
            },

            {
                fontSize:9,
                table: {
                    widths: [ 110, 145, 50, 65, 65,65, 210, 10],
                    body: [

                            manfaatAsuransi(mapOutput)
                    ]
                },
                layout: whiteWitSpace()
            },
            {
                margin:[0, 5, 0,2],
                columns: [ 
                    {text:'RINGKASAN MANFAAT', fontSize:9, width:120},  
                    {width:'*', text:'(Hanya untuk ilustrasi. Keterangan lengkap mengenai Manfaat Asuransi tiap produk asuransi, termasuk syarat-syarat dan pengecualian-pengecualian, tercantum pada Polis, berlaku dan mengikat)'},]
            },
            {
                ul: [
                        ringkasanManfaat(mapOutput)
                ]
            },
            {
                pageBreak: 'after',
                absolutePosition : { x :25,y :525 },
                columns: [
                    {
                        table: {
                                body: [
                                        ['Disajikan',mapOutput.agentName,''],
                                        [{text:'Tanggal', margin: [0,0,0,16]},{text: mapOutput.QuotationDate},''],
                                        ['','',''],
                                        ['','',''],
                                        [ mapOutput.docIdStandard, mapOutput.versi, {text: mapOutput.substandardValue, fontSize: 5, margin:[0,-3,0,0]} ],
                                ]            
                        },layout: whiteNoSpace()
                    },
                    {
                        
                        table: {
                                body: [
                                        [{text:'Kode Agen/FSC', margin: [100,0,50,24]},mapOutput.agentId,''],
                                        ['','',''],
                                        ['','',''],
                                        ['','',''],
                                        ['','',mapOutput.uniqueCode],
                                ]            
                        },layout: whiteNoSpace()
                    },
                ],
            },

////////////////// END HALAMAN 2

            pruHSOutput(mapOutput),

///////////////////////END HALAMAN 3 
            pruCCB61Output(mapOutput),

///////////////////////END HALAMAN CCBPlus
            pruMedCoverOutput(mapOutput),

///////////////////////END HALAMAN PengecualianMedikal
            getFund(mapOutput),
            
            {
                columns: [
                    { text: [{text:'PRU', font:'frutiger'}, {text:'link assurance account', font: 'garamount'}], fontSize: 19, width: 260},
                    {
                        width: '*',
                        margin: [0,3,0,0],
                        table: {
                            widths: [ 'auto', 2],
                            body: [
                                    [{text:'RINGKASAN ILUSTRASI INI BUKAN MERUPAKAN SEBUAH KONTRAK ASURANSI', style: 'subheader', alignment:'center',margin:[30,0,30,0]}],
                            ]
                                                
                        },
                    },
                ],
            },
            { 
                text: 'ILUSTRASI MANFAAT NILAI TUNAI', margin: [0, 3, 0, 5], fontSize:10, bold: true
            },
            {
                columns: [
                    {
                        style: 'hal3Table',
                        headerRows: 3,
                        alignment: 'center',
                        margin: [0, -1, 10, 0],
                        table: {
                                widths: [20, 24, 40, 40, 40, '*' ,'*' ,'*'],
                                body: [
                                        [
                                            {rowSpan: 3, text: 'Awal Tahun', margin:[0,12,0,0], alignment: 'center'},
                                            {rowSpan: 3, text: 'Usia (Tahun) \n#', margin:[0,12,0,0], alignment: 'center'},
                                            {colSpan: 3, text: 'RINGKASAN TRANSAKSI SESUAI MASA PEMBAYARAN PREMI YANG DIKEHENDAKI ('+mapOutput.rencanaPembayaran+' tahun)', alignment:'center', bold: true, alignment: 'center'}, '', '',
                                            {colSpan: 3, text: 'ILUSTRASI MANFAAT', alignment: 'center', bold:true, alignment: 'center'},'','',
                                        ],
                                        [
                                            '', '',
                                            {rowSpan: 2, text:'Premi pada awal tahun \n(000)', alignment: 'center'},
                                            {rowSpan: 2, text:'Top-Up premi tunggal \n(000)', alignment: 'center'},
                                            {rowSpan: 2, text:'Penarikan \n(000)', alignment: 'center'},
                                            {colSpan: 3, text: 'Nilai Tunai (000) merupakan nilai pada akhir tahun polis. Sesuai Masa Pembayaran Premi yang dikehendaki ('+mapOutput.rencanaPembayaran+' tahun)', alignment: 'center'},
                                            '','',
                                        ],
                                        ['','','', '', '',{text:'Rendah', alignment: 'center'}, {alignment: 'center',text:'sedang'}, {text:'Tinggi', alignment: 'center'}],
                                ]
                        },
                        layout: {
                                        hLineWidth: function(i, node) {
                                                return (i === 0 || i === node.table.body.length) ? 1 : 1;
                                        },
                                        vLineWidth: function(i, node) {
                                                return (i === 0 || i === node.table.widths.length) ? 1: 1;
                                        },
                                        hLineColor: function(i, node) {
                                                return (i === 0 || i === node.table.body.length) ? 'black' : 'black';
                                        },
                                        vLineColor: function(i, node) {
                                                return (i === 0 || i === node.table.widths.length) ? 'black' : 'black';
                                        },
                            paddingLeft: function(i, node) { return 1; },
                            paddingRight: function(i, node) { return 1; },
                            paddingTop: function(i, node) { return 1; },
                            paddingBottom: function(i, node) { return 1 },
                        }
                    },
                    {
                        style: 'hal3Table',
                        headerRows: 3,
                        alignment: 'center',
                        margin: [0, -1, 10, 0],
                        table: {
                                widths: [20, 24, 40, 40, 40, '*' ,'*' ,'*'],
                                body: [
                                        [
                                            {rowSpan: 3, text: 'Awal Tahun', margin:[0,12,0,0], alignment: 'center'},
                                            {rowSpan: 3, text: 'Usia (Tahun) \n#', margin:[0,12,0,0], alignment: 'center'},
                                            {colSpan: 3, text: 'RINGKASAN TRANSAKSI SESUAI MASA PEMBAYARAN PREMI YANG DIKEHENDAKI (99 tahun)', alignment:'center', bold: true, alignment: 'center'}, '', '',
                                            {colSpan: 3, text: 'ILUSTRASI MANFAAT', alignment: 'center', bold:true, alignment: 'center'},'','',
                                        ],
                                        [
                                            '', '',
                                            {rowSpan: 2, text:'Premi pada awal tahun \n(000)', alignment: 'center'},
                                            {rowSpan: 2, text:'Top-Up premi tunggal \n(000)', alignment: 'center'},
                                            {rowSpan: 2, text:'Penarikan \n(000)', alignment: 'center'},
                                            {colSpan: 3, text: 'Nilai Tunai (000) merupakan nilai pada akhir tahun polis. Sesuai Masa Pembayaran Premi yang dikehendaki (99 tahun)', alignment: 'center'},
                                            '','',
                                        ],
                                        ['','','', '', '',{text:'Rendah', alignment: 'center'}, {alignment: 'center',text:'sedang'}, {text:'Tinggi', alignment: 'center'}],
                                ]
                        },
                        layout: {
                                        hLineWidth: function(i, node) {
                                                return (i === 0 || i === node.table.body.length) ? 1 : 1;
                                        },
                                        vLineWidth: function(i, node) {
                                                return (i === 0 || i === node.table.widths.length) ? 1: 1;
                                        },
                                        hLineColor: function(i, node) {
                                                return (i === 0 || i === node.table.body.length) ? 'black' : 'black';
                                        },
                                        vLineColor: function(i, node) {
                                                return (i === 0 || i === node.table.widths.length) ? 'black' : 'black';
                                        },
                            paddingLeft: function(i, node) { return 1; },
                            paddingRight: function(i, node) { return 1; },
                            paddingTop: function(i, node) { return 1; },
                            paddingBottom: function(i, node) { return 1 },
                        }
                    },
                ]
            },
            {
                columns: [
                        {
                            style: 'hal3Table',
                            margin: [0, -1, 10, 0],
                            table: {
                                    widths: [20, 24, 40, 40, 40, '*' ,'*' ,'*'],
                                    //body: getCashValueOrDeathBenefit('CLIENT', mapOutput.output.output['FUNDBENEFIT'], mapOutput.dataTopUp, mapOutput.dataPenarikan, mapOutput.dataFund, '')
                                    body: test1[0]
                            },
                            layout: {
                                        hLineWidth: function(i, node) {
                                                return (i === 0 || i === node.table.body.length) ? 1 : 1;
                                        },
                                        vLineWidth: function(i, node) {
                                                return (i === 0 || i === node.table.widths.length) ? 1: 1;
                                        },
                                        hLineColor: function(i, node) {
                                                return (i === 0 || i === node.table.body.length) ? 'black' : 'white';
                                        },
                                        vLineColor: function(i, node) {
                                                return (i === 0 || i === node.table.widths.length) ? 'black' : 'black';
                                        },
                                                        paddingLeft: function(i, node) { return 1; },
                                                        paddingRight: function(i, node) { return 1; },
                                                        paddingTop: function(i, node) { return 1; },
                                                        paddingBottom: function(i, node) { return 1 },
                            }
                        },
                        {
                            style: 'hal3Table',
                            margin: [0, -1, 10, 0],
                            table: {
                                    widths: [20, 24, 40, 40, 40, '*' ,'*' ,'*'],
                                    body: test1[1]                   
                            },
                            layout: {
                                        hLineWidth: function(i, node) {
                                                return (i === 0 || i === node.table.body.length) ? 1 : 1;
                                        },
                                        vLineWidth: function(i, node) {
                                                return (i === 0 || i === node.table.widths.length) ? 1: 1;
                                        },
                                        hLineColor: function(i, node) {
                                                return (i === 0 || i === node.table.body.length) ? 'black' : 'white';
                                        },
                                        vLineColor: function(i, node) {
                                                return (i === 0 || i === node.table.widths.length) ? 'black' : 'black';
                                        },
                                                        paddingLeft: function(i, node) { return 1; },
                                                        paddingRight: function(i, node) { return 1; },
                                                        paddingTop: function(i, node) { return 1; },
                                                        paddingBottom: function(i, node) { return 1 },
                            }
                        },
                    ]
            },
            {

                columns: [
                    { 
                        stack: [
                            { text: 'Asumsi tingkat hasil investasi yang digunakan adalah sebagai berikut:', alignment: 'left'},
                            {
                                table: {
                                    widths: [180,30,30,30],
                                    body: getFundAndRate(mapOutput)
                                    
                                }, 
                                layout: {
                                paddingLeft: function(i, node) { return 1; },
                                paddingRight: function(i, node) { return 1; },
                                paddingTop: function(i, node) { return 1; },
                                paddingBottom: function(i, node) { return 1 },
                                } 
                            },
                        ]
                    },
                    {
                        stack: [
                            '*** Menunjukkan bahwa Nilai Tunai pada tahun tersebut tidak mencukupi untuk membayar Biaya Asuransi dan Administrasi, dan oleh karena itu Polis akan batal (lapse). Supaya Manfaat Polis dapat terus berlanjut, maka Anda diminta untuk melanjutkan pembayaran premi tahunan seperti dinyatakan dalam ilustrasi ini.',
                            {text: ['']},
                        ]
                    },
                ],
            },
            {
                stack:[
                    /*{
                        margin:[0,-10,0,-10],
                        table: {
                                widths: ['*'],
                                body: [[' '], [' ']]
                        },
                        layout:lineFullWidth()
                    },*/
                    {
                        pageBreak: 'after',
                        absolutePosition : { x :25,y :525 },
                        columns: [
                            {
                                table: {
                                        body: [
                                                ['Disajikan',mapOutput.agentName,''],
                                                [{text:'Tanggal', margin: [0,0,0,16]},{text: mapOutput.QuotationDate},''],
                                                ['','',''],
                                                ['','',''],
                                                [ mapOutput.docIdStandard, mapOutput.versi, {text: mapOutput.substandardValue, fontSize: 5, margin:[0,-3,0,0]} ],
                                        ]            
                                },layout: whiteNoSpace()
                            },
                            {
                                
                                table: {
                                        body: [
                                                [{text:'Kode Agen/FSC', margin: [100,0,50,24]},mapOutput.agentId,''],
                                                ['','',''],
                                                ['','',''],
                                                ['','',''],
                                                ['','',''],
                                        ]            
                                },layout: whiteNoSpace()
                            },
                        ],
                    }
                ]
            },

            

///////////////////// END HALAMAN 4

            {
                columns: [
                    { text: [{text:'PRU', font:'frutiger'}, {text:'link assurance account', font: 'garamount'}], fontSize: 22, width: 260},
                    { text: 'RINGKASAN ILUSTRASI INI BUKAN SEBUAH KONTRAK ASURANSI', style: 'subheader' },
                ],
            },
            { 
                text: 'ILUSTRASI MANFAAT MENINGGAL', margin: [0, 3, 0, 5], fontSize:10, bold: true
            },
            {
                columns: [
                    {
                        style: 'hal3Table',
                        headerRows: 3,
                        alignment: 'center',
                        margin: [0, -1, 10, 0],
                        table: {
                                widths: [20, 24, 40, 40, 40, '*' ,'*' ,'*'],
                                body: [
                                        [
                                            {rowSpan: 3, text: 'Awal Tahun', margin:[0,12,0,0], alignment: 'center'},
                                            {rowSpan: 3, text: 'Usia (Tahun) \n#', margin:[0,12,0,0], alignment: 'center'},
                                            {colSpan: 3, text: 'RINGKASAN TRANSAKSI SESUAI MASA PEMBAYARAN PREMI YANG DIKEHENDAKI ('+mapOutput.rencanaPembayaran+' tahun)', alignment:'center', bold: true, alignment: 'center'}, '', '',
                                            {colSpan: 3, text: 'ILUSTRASI MANFAAT', alignment: 'center', bold:true, alignment: 'center'},'','',
                                        ],
                                        [
                                            '', '',
                                            {rowSpan: 2, text:'Premi pada awal tahun \n(000)', alignment: 'center'},
                                            {rowSpan: 2, text:'Top-Up premi tunggal \n(000)', alignment: 'center'},
                                            {rowSpan: 2, text:'Penarikan \n(000)', alignment: 'center'},
                                            {colSpan: 3, text: 'Nilai Tunai (000) merupakan nilai pada akhir tahun polis. Sesuai Masa Pembayaran Premi yang dikehendaki ('+mapOutput.rencanaPembayaran+' tahun)', alignment: 'center'},
                                            '','',
                                        ],
                                        ['','','', '', '',{text:'Rendah', alignment: 'center'}, {alignment: 'center',text:'sedang'}, {text:'Tinggi', alignment: 'center'}],
                                ]
                        },
                        layout: {
                                        hLineWidth: function(i, node) {
                                                return (i === 0 || i === node.table.body.length) ? 1 : 1;
                                        },
                                        vLineWidth: function(i, node) {
                                                return (i === 0 || i === node.table.widths.length) ? 1: 1;
                                        },
                                        hLineColor: function(i, node) {
                                                return (i === 0 || i === node.table.body.length) ? 'black' : 'black';
                                        },
                                        vLineColor: function(i, node) {
                                                return (i === 0 || i === node.table.widths.length) ? 'black' : 'black';
                                        },
                            paddingLeft: function(i, node) { return 1; },
                            paddingRight: function(i, node) { return 1; },
                            paddingTop: function(i, node) { return 1; },
                            paddingBottom: function(i, node) { return 1 },
                        }
                    },
                    {
                        style: 'hal3Table',
                        headerRows: 3,
                        alignment: 'center',
                        margin: [0, -1, 10, 0],
                        table: {
                                widths: [20, 24, 40, 40, 40, '*' ,'*' ,'*'],
                                body: [
                                        [
                                            {rowSpan: 3, text: 'Awal Tahun', margin:[0,12,0,0], alignment: 'center'},
                                            {rowSpan: 3, text: 'Usia (Tahun) \n#', margin:[0,12,0,0], alignment: 'center'},
                                            {colSpan: 3, text: 'RINGKASAN TRANSAKSI SESUAI MASA PEMBAYARAN PREMI YANG DIKEHENDAKI (99 tahun)', alignment:'center', bold: true, alignment: 'center'}, '', '',
                                            {colSpan: 3, text: 'ILUSTRASI MANFAAT', alignment: 'center', bold:true, alignment: 'center'},'','',
                                        ],
                                        [
                                            '', '',
                                            {rowSpan: 2, text:'Premi pada awal tahun \n(000)', alignment: 'center'},
                                            {rowSpan: 2, text:'Top-Up premi tunggal \n(000)', alignment: 'center'},
                                            {rowSpan: 2, text:'Penarikan \n(000)', alignment: 'center'},
                                            {colSpan: 3, text: 'Nilai Tunai (000) merupakan nilai pada akhir tahun polis. Sesuai Masa Pembayaran Premi yang dikehendaki (99 tahun)', alignment: 'center'},
                                            '','',
                                        ],
                                        ['','','', '', '',{text:'Rendah', alignment: 'center'}, {alignment: 'center',text:'sedang'}, {text:'Tinggi', alignment: 'center'}],
                                ]
                        },
                        layout: {
                                        hLineWidth: function(i, node) {
                                                return (i === 0 || i === node.table.body.length) ? 1 : 1;
                                        },
                                        vLineWidth: function(i, node) {
                                                return (i === 0 || i === node.table.widths.length) ? 1: 1;
                                        },
                                        hLineColor: function(i, node) {
                                                return (i === 0 || i === node.table.body.length) ? 'black' : 'black';
                                        },
                                        vLineColor: function(i, node) {
                                                return (i === 0 || i === node.table.widths.length) ? 'black' : 'black';
                                        },
                            paddingLeft: function(i, node) { return 1; },
                            paddingRight: function(i, node) { return 1; },
                            paddingTop: function(i, node) { return 1; },
                            paddingBottom: function(i, node) { return 1 },
                        }
                    },
                ]
            },
            {
                columns: [
                        {
                            style: 'hal3Table',
                            margin: [0, -1, 10, 0],
                            table: {
                                    widths: [20, 24, 40, 40, 40, '*' ,'*' ,'*'],
                                    body: test2[0]
                            },
                            layout: {
                                        hLineWidth: function(i, node) {
                                                return (i === 0 || i === node.table.body.length) ? 1 : 1;
                                        },
                                        vLineWidth: function(i, node) {
                                                return (i === 0 || i === node.table.widths.length) ? 1: 1;
                                        },
                                        hLineColor: function(i, node) {
                                                return (i === 0 || i === node.table.body.length) ? 'black' : 'white';
                                        },
                                        vLineColor: function(i, node) {
                                                return (i === 0 || i === node.table.widths.length) ? 'black' : 'black';
                                        },
                                                        paddingLeft: function(i, node) { return 1; },
                                                        paddingRight: function(i, node) { return 1; },
                                                        paddingTop: function(i, node) { return 1; },
                                                        paddingBottom: function(i, node) { return 1 },
                            }
                        },
                        {
                            style: 'hal3Table',
                            margin: [0, -1, 10, 0],
                            table: {
                                    widths: [20, 24, 40, 40, 40, '*' ,'*' ,'*'],
                                    body: test2[1]                   
                            },
                            layout: {
                                        hLineWidth: function(i, node) {
                                                return (i === 0 || i === node.table.body.length) ? 1 : 1;
                                        },
                                        vLineWidth: function(i, node) {
                                                return (i === 0 || i === node.table.widths.length) ? 1: 1;
                                        },
                                        hLineColor: function(i, node) {
                                                return (i === 0 || i === node.table.body.length) ? 'black' : 'white';
                                        },
                                        vLineColor: function(i, node) {
                                                return (i === 0 || i === node.table.widths.length) ? 'black' : 'black';
                                        },
                                                        paddingLeft: function(i, node) { return 1; },
                                                        paddingRight: function(i, node) { return 1; },
                                                        paddingTop: function(i, node) { return 1; },
                                                        paddingBottom: function(i, node) { return 1 },
                            }
                        },
                    ]
            },
            {

                columns: [
                    {
                        stack: [
                            '# Masa Asuransi sampai dengan Peserta Utama Yang Diasuransikan mencapai usia 99 tahun',
                            {text: ['*  Manfaat Meninggal di atas termasuk manfaat meninggal atas ',{text:'PRU', font:'frutiger'}, {text:'link term', font: 'garamount'},' dan ',{text:'PRU', font:'frutiger'}, {text:'crisis cover benefit plus 61', font: 'garamount'},' (jika ada). Manfaat di atas diberikan jika belum ada pembayaran atas manfaat Cacat Tetap dan Total atau ',{text:'PRU', font:'frutiger'}, {text:'crisis cover 34', font: 'garamount'},' atau ',{text:'PRU', font:'frutiger'}, {text:'crisis cover benefit plus 61', font: 'garamount'},' (jika ada).']},
                            '*** Menunjukkan bahwa Nilai Tunai pada tahun tersebut tidak mencukupi untuk membayar Biaya Asuransi dan Ujrah Administrasi, dan oleh karena itu Polis akan batal (lapse). Supaya Manfaat Polis dapat terus berlanjut, maka Anda dapat melakukan pembayaran Kontribusi Top-up Tunggal.',
                        ]
                    },
                    { 
                        stack: [
                            { text: 'Apabila Peserta Utama Yang Diasuransikan meninggal sebelum mencapai usia 5 tahun ulang tahun berikutnya, maka besarnya Santunan Asuransi Dasar PSAA diberikan sesuai tabel berikut dan seluruh nilai tunai yang dihitung berdasarkan harga unit pada tanggal perhitungan terdekat setelah disetujuinya permohonan klaim akan dibayarkan sekaligus/sekurang-kurangnya 5 (lima) kali Kontribusi Berkala PSAA tahunan, mana yang lebih besar:', alignment: 'left'},
                            {
                                alignment:'center',
                                table: {
                                    widths: [180,30,30,30,30,30],
                                    body: [
                                            [{text:'Usia ulang tahun berikut', alignment: 'left'},'1', '2', '3','4','>=5'],
                                            [{text:'% dari Santunan Asuransi', alignment: 'left'}, '20%', '40%', '60%','80%','100%'],
                                    ]
                                }, 
                                layout: {
                                paddingLeft: function(i, node) { return 1; },
                                paddingRight: function(i, node) { return 1; },
                                paddingTop: function(i, node) { return 1; },
                                paddingBottom: function(i, node) { return 1 },
                                } 
                            },
                        ]
                    },
                ],
            },
            {
                stack:[
                    /*{
                        margin:[0,-10,0,-10],
                        table: {
                                widths: ['*'],
                                body: [[' '], [' ']]
                        },
                        layout:lineFullWidth()
                    },*/
                    {
                        pageBreak: 'after',
                        absolutePosition : { x :25,y :525 },
                        columns: [
                            {
                                table: {
                                        body: [
                                                ['Disajikan',mapOutput.agentName,''],
                                                [{text:'Tanggal', margin: [0,0,0,16]},{text: mapOutput.QuotationDate},''],
                                                ['','',''],
                                                ['','',''],
                                                [ mapOutput.docIdStandard, mapOutput.versi, {text: mapOutput.substandardValue, fontSize: 5, margin:[0,-3,0,0]} ],
                                        ]            
                                },layout: whiteNoSpace()
                            },
                            {
                                
                                table: {
                                        body: [
                                                [{text:'Kode Agen/FSC', margin: [100,0,50,24]},mapOutput.agentId,''],
                                                ['','',''],
                                                ['','',''],
                                                ['','',''],
                                                ['','',''],
                                        ]            
                                },layout: whiteNoSpace()
                            },
                        ],
                    }
                ]
            },

            {
                columns: [
                    { text: [{text:'PRU', font:'frutiger'}, {text:'link assurance account', font: 'garamount'}], fontSize: 19, width: 260},
                    {
                        width: '*',
                        margin: [0,3,0,0],
                        table: {
                            widths: [ 'auto', 2],
                            body: [
                                    [{text:'RINGKASAN ILUSTRASI INI BUKAN MERUPAKAN SEBUAH KONTRAK ASURANSI', style: 'subheader', alignment:'center',margin:[30,0,30,0]}],
                            ]
                                                
                        },
                    },
                ],
            },
            {text: 'ILUSTRASI MANFAAT NILAI TUNAI', margin: [0, 3, 0, 5], fontSize:10, bold: true},
            /*{
                margin:[0,-10,0,-10],
                table: {
                        widths: ['*'],
                        body: [[' '], [' ']]
                },
                layout:lineFullWidth()
            },*/
            {
                columns: [
                    { 
                        stack: [
                            {text: 'Grafik Pertumbuhan Nilai Tunai (Rupiah)', },
                            {text: 'Sesuai Masa Pembayaran Premi yang dikehendaki ('+mapOutput.rencanaPembayaran+')', },
                            {text: 'Nilai Tunai (000)/(USD) - 20 tahun pertama', },
                            {
                                table: {
                                        body: [
                                            [ {stack :[
                                                {image: 'chartpdf', width: 350, margin: [0, 0, 10, 0]},
                                                {text: 'Akhir Tahun Polis Ke-..', alignment:'center'},
                                            ]}]
                                        ]
                                },
                            },
                        ],
                    },
                    { 
                        stack: [
                            {text: 'Grafik Pertumbuhan Nilai Tunai (Rupiah)/(USD)', },
                            {text: 'Jika Premi dibayar sampai usia 99 tahun', },
                            {text: 'Nilai Tunai (000)/(USD) - 20 tahun pertama', },
                            {
                                table: {
                                        body: [
                                            [ {stack :[
                                                {image: 'chartpdfAlt', width: 350, margin: [0, 0, 10, 0]},
                                                {text: 'Akhir Tahun Polis Ke-..', alignment:'center'},
                                            ]}]
                                        ]
                                },
                            },
                        ],
                    },
                ],
            },

            'Catatan', // table invenstasi Fund 

            {
                columns: [
                    {   
                        width: 470,
                        stack: [
                            {
                                headerRows:2,
                                table: {
                                    widths: [210,70,'*','*','*','*','*',],
                                     body: [
                                                [{rowSpan: 2, text:'Dana Investasi'}, {colSpan: 6, text: 'Hasil Investasi Bersih Rata-rata (%) per Tahun*', alignment:'center'}, '', '', '', '', '',],
                                                ['', {text:'Sejak diluncurkan', alignment:'center'}, {text:'2012', alignment:'center'}, {text:'2013', alignment:'center'}, {text:'2014', alignment:'center'}, {text:'2015', alignment:'center'}, {text:'2016', alignment:'center'}, ],
                                                getUsingFund(mapOutput),
                                    ]  
                                },
                                layout: {             
                                    paddingLeft: function(i, node) { return 1; },
                                    paddingRight: function(i, node) { return 1; },
                                    paddingTop: function(i, node) { return 1; },
                                    paddingBottom: function(i, node) { return 1 },
                                },
                            },
                            {
                                text: '* Kinerja investasi di atas merupakan hasil pada tahun-tahun sebelumnya. Hasil pada saat mendatang bisa berbeda. \nNilai dan hasilnya dapat menaik ataupun menurun. Lihat keterangan no. 5, 6, 7 dan 15 pada "Hal-Hal Penting" di halaman terakhir.\nBerdasarkan kinerja investasi pada Desember 2016',
                            },
                        ],
                    },
                    {
                        margin: [30,0,0,0],
                        table: {
                            body: [
                                [{image: 'rect', width: 5},{text: 'Nilai Tunai dengan asumsi tingkat investasi Rendah'}],
                                [{image: 'circ', width: 5},{text: 'Nilai Tunai dengan asumsi tingkat investasi Sedang'}],
                                [{image: 'tria', width: 5},{text: 'Nilai Tunai dengan asumsi tingkat investasi Tinggi'}],
                            ]
                        },
                        layout: {
                                    hLineWidth: function(i, node) {
                                            return (i === 0 || i === node.table.body.length) ? 1 : 1;
                                    },
                                    vLineWidth: function(i, node) {
                                            return (i === 0 || i === node.table.widths.length) ? 1 : 1;
                                    },
                                    hLineColor: function(i, node) {
                                            return (i === 0 || i === node.table.body.length) ? 'black' : 'white';
                                    },
                                    vLineColor: function(i, node) {
                                            return (i === 0 || i === node.table.widths.length) ? 'black' : 'white';
                                    },
                        }
                    },
                ]
            },
            {
                stack:[
                    /*{
                        margin:[0,-10,0,-10],
                        table: {
                                widths: ['*'],
                                body: [[' '], [' ']]
                        },
                        layout:lineFullWidth()
                    },*/
                    {
                        pageBreak: 'after',
                        absolutePosition : { x :25,y :525 },
                        columns: [
                            {
                                table: {
                                        body: [
                                                ['Disajikan',mapOutput.agentName,''],
                                                [{text:'Tanggal', margin: [0,0,0,16]},{text: mapOutput.QuotationDate},''],
                                                ['','',''],
                                                ['','',''],
                                                [ mapOutput.docIdStandard, mapOutput.versi, {text: mapOutput.substandardValue, fontSize: 5, margin:[0,-3,0,0]} ],
                                        ]            
                                },layout: whiteNoSpace()
                            },
                            {
                                
                                table: {
                                        body: [
                                                [{text:'Kode Agen/FSC', margin: [100,0,50,24]},mapOutput.agentId,''],
                                                ['','',''],
                                                ['','',''],
                                                ['','',''],
                                                ['','',''],
                                        ]            
                                },layout: whiteNoSpace()
                            },
                        ],
                    }
                ]
            },

///////////////////// End Halaman 5

            {
                columns: [
                    { text: [{text:'PRU', font:'frutiger'}, {text:'link assurance account', font: 'garamount'}], fontSize: 19, width: 260},
                    {
                        width: '*',
                        margin: [0,3,0,0],
                        table: {
                            widths: [ 'auto', 2],
                            body: [
                                    [{text:'RINGKASAN ILUSTRASI INI BUKAN MERUPAKAN SEBUAH KONTRAK ASURANSI', style: 'subheader', alignment:'center',margin:[30,0,30,0]}],
                            ]
                                                
                        },
                    },
                ],
            },
            { text: 'HAL-HAL PENTING', margin: [0, 3, 0, 5], fontSize:10, bold: true},

            {
                
                table: {
                    body: [
                        ['1',
                            {
                                alignment: 'center',
                                style: 'hal6Tabel',
                                tableHeader: 2,
                                table: {
                                        widths: [180,'*',55,'*',55,'*',55,'*',55,'*',55,'*',55],
                                        body: [
                                            [{text:'', rowSpan: 2},{colSpan:2, text: 'Tahun 1'},'',{colSpan:2, text: 'Tahun 2'},'',{colSpan:2, text: 'Tahun 3'},'',{colSpan:2, text: 'Tahun 4'},'',{colSpan:2, text: 'Tahun 5'},'',{colSpan:2, text: 'Tahun 6'},''],
                                            ['','Porsi Investasi','Biaya Akuisisi/ Biaya Top-up','Porsi Investasi','Biaya Akuisisi/ Biaya Top-up','Porsi Investasi','Biaya Akuisisi/ Biaya Top-up','Porsi Investasi','Biaya Akuisisi/ Biaya Top-up','Porsi Investasi','Biaya Akuisisi/ Biaya Top-up','Porsi Investasi','Biaya Akuisisi/ Biaya Top-up'],
                                            [{text:'Premi Berkala', alignment: 'left'},'0%','100%','40%','60%','85%','15%','85%','15%','85%','15%','100%','0%'],
                                            [{text:['Premi (',{text:'PRU', font:'frutiger'}, {text:'saver', font: 'garamount'},') dan Premi', {text: 'Top-up', decoration: 'underline'}, 'Tunggal'], alignment: 'left'},'95%','5%','95%','5%','95%','5%','95%','5%','95%','5%','95%','5%'],
                                        ],
                                },
                            },
                        ],
                        ['2',
                            {
                                stack:[
                                    {text: 'Ilustrasi manfaat di atas sudah diperhitungkan dengan:'},
                                    {ul: [
                                        'Biaya administrasi sebesar Rp 27.500,-/USD 5 per bulan selama berlakunya asuransi.',
                                        'Biaya asuransi, dikenakan setiap bulan selama berlakunya manfaat asuransi.',
                                        'Biaya pengelolaan dana investasi per tahun tergantung dari dana investasi yang dipilih.',
                                    ]}
                                ]
                            }
                        ],
                        ['3',{text: ['Karena tidak adanya unit yang terbentuk dari Premi Berkala Tahun I dan unit yang terbentuk dari Premi Tahun II tidak mencukupi untuk membayar biaya asuransi dan administrasi, maka biaya-biaya tersebut dinyatakan sebagai biaya terhutang yang akan dipotong dari unit yang terbentuk dari Premi Berkala, ',{text:'PRU', font:'frutiger'}, {text:'saver', font: 'garamount'},' (Premi Top-up Berkala) dan Premi Top-up Tunggal (apabila ada) mulai bulan ke-25.']}],
                        ['4','Nilai tunai adalah: Nilai dari Saldo Unit yang dihitung berdasarkan Harga Unit pada saat tertentu.',],
                        ['5','Asumsi tinggi rendahnya tingkat hasil investasi ini hanya bertujuan untuk ilustrasi saja dan bukan merupakan tolok ukur untuk perhitungan rata-rata tingkat hasil investasi yang terendah dan tertinggi.'],
                        ['6','Perubahan harga unit menggambarkan hasil investasi dari dana investasi. Kinerja dari investasi tidak dijamin tergantung dari risiko masing-masing dana investasi. Pemegang Polis diberi keleluasaan untuk menempatkan alokasi dana investasi yang memungkinkan optimalisasi tingkat pengembalian investasi, sesuai dengan kebutuhan dan profil risiko pilihan dana investasi Pemegang Polis.'],
                        ['7',{text: ['Besarnya nilai tunai yang dibayarkan (bisa lebih besar atau lebih kecil dari yang diilustrasikan), akan bergantung pada perkembangan dari dana investasi ',{text:'PRU', font:'frutiger'}, {text:'link', font: 'garamount'},'. Hasil investasi Pemegang Polis tidak dijamin oleh PT Prudential Life Assurance. Semua risiko, kerugian dan manfaat yang dihasilkan dari investasi dalam program asuransi ',{text:'PRU', font:'frutiger'}, {text:'link assurance account', font: 'garamount'},' ini akan sepenuhnya menjadi tanggung jawab Pemegang Polis.']}],
                        ['8','Jumlah minimum Premi Top-up Tunggal Rp 1.000.000,- / USD 250 '],
                        ['9','Minimum Penarikan: Rp 500.000,-/USD 100. Minimum sisa dana setelah penarikan adalah sebesar Rp 1.000.000,-/USD 250'],
                        ['10','Biaya Pengalihan Unit (Switching) sebesar Rp 100.000,-/USD 15 per transaksi. Prudential membebaskan biaya pengalihan Unit sebanyak 5 (lima) kali dalam setiap tahun Polis.'],
                        ['11','Jumlah minimum pengalihan Unit adalah sebesar Rp 2.000.000,-/USD 500. Sisa Nilai Tunai setelah pengalihan Unit tersebut sebesar minimum Rp 2.000.000,-/USD 500. Jika sisa Nilai Tunai setelah pengalihan Unit kurang dari Rp 2.000.000,-/USD 500 maka Pemegang Polis harus mengalihkan seluruh Nilai Tunai pada jenis dana investasi tersebut.'],
                        ['12','Pajak yang dikenakan atas penarikan atau penebusan polis adalah sesuai dengan ketentuan peraturan perundang-undangan pajak yang berlaku, dan/atau setiap perubahannya sebagaimana dapat ditentukan oleh Pemerintah Republik Indonesia dari waktu ke waktu.'],
                        ['13','Penilaian harga unit dilakukan pada setiap hari kerja, Senin sampai dengan Jumat, dengan menggunakan metode harga pasar yang berlaku bagi instrumen investasi yang mendasari masing-masing alokasi dana investasi yang dipilih.'],
                        ['14','Pemegang Polis tidak akan dikenakan biaya apapun apabila Pemegang Polis melakukan penarikan dana.'],
                        ['15','Besarnya Nilai Tunai yang terbentuk pada polis ini (dapat lebih besar atau lebih kecil dari dana yang diinvestasikan oleh Pemegang Polis), akan dipengaruhi oleh fluktuasi dari harga unit atau faktor biaya-biaya sebagaimana disebutkan di atas.'],
                        ['16','Perpanjangan masa pertanggungan asuransi tambahan setelah berakhirnya masa asuransi akan dilakukan underwriting/seleksi risiko ulang sehingga perpanjangan dapat diterima dengan rate standar atau bahkan ditolak.'],
                        ['17','Harga Unit yang digunakan pada Premi Pertama akan terbentuk setelah diterimanya SPAJ dan teridentifikasinya seluruh pembayaran Premi pertama di Kantor Pusat oleh Prudential. Tanggal Perhitungan Harga Unit adalah Tanggal Perhitungan berikutnya setelah diterimanya SPAJ atau teridentifikasinya seluruh pembayaran Premi pertama di Kantor Pusat, mana yang paling akhir.'],
                    ]            
                },
                layout: whiteNoSpacePadBot()
            },
            {
                stack:[
                    /*{
                        margin:[0,-10,0,-10],
                        table: {
                                widths: ['*'],
                                body: [[' '], [' ']]
                        },
                        layout:lineFullWidth()
                    },*/
                    {
                        pageBreak: 'after',
                        absolutePosition : { x :25,y :525 },
                        columns: [
                            {
                                table: {
                                        body: [
                                                ['Disajikan',mapOutput.agentName,''],
                                                [{text:'Tanggal', margin: [0,0,0,16]},{text: mapOutput.QuotationDate},''],
                                                ['','',''],
                                                ['','',''],
                                                [ mapOutput.docIdStandard, mapOutput.versi, {text: mapOutput.substandardValue, fontSize: 5, margin:[0,-3,0,0]} ],
                                        ]            
                                },layout: whiteNoSpace()
                            },
                            {
                                
                                table: {
                                        body: [
                                                [{text:'Kode Agen/FSC', margin: [100,0,50,24]},mapOutput.agentId,''],
                                                ['','',''],
                                                ['','',''],
                                                ['','',''],
                                                ['','',''],
                                        ]            
                                },layout: whiteNoSpace()
                            },
                        ],
                    }
                ]
            },

            ///////////////////////////////////////////////////////////
            {
                columns: [
                    { text: [{text:'PRU', font:'frutiger'}, {text:'link assurance account', font: 'garamount'}], fontSize: 19, width: 260},
                    {
                        width: '*',
                        margin: [0,3,0,0],
                        table: {
                            widths: [ 'auto', 2],
                            body: [
                                    [{text:'RINGKASAN ILUSTRASI INI BUKAN MERUPAKAN SEBUAH KONTRAK ASURANSI', style: 'subheader', alignment:'center',margin:[30,0,30,0]}],
                            ]
                                                
                        },
                    },
                ],
            },

            { text: 'HAL-HAL PENTING', margin: [0, 3, 0, 5], fontSize:10, bold: true},

            {
                
                table: {
                    body: [
                        ['18',{
                            stack:[
                                {text:'Kami menjamin Polis Anda akan tetap berlaku dalam 10 tahun sejak Tanggal Mulai Berlakunya Polis walaupun Nilai Tunai pada Tanggal Perhitungan terdekat sebelum tanggal pembebanan Biaya Asuransi dan Biaya Administrasi tidak cukup untuk melunasi Biaya Asuransi dan Biaya Administrasi, selama:'},
                                {ul: [
                                'Premi berkala dan Premi Top-up Berkala selalu dibayar lunas paling lambat dalam masa leluasa pembayaran Premi;',
                                'Fasilitas Cuti Premi atau Premium Holiday tidak pernah dimanfaatkan oleh Pemegang Polis;',
                                'Pemegang Polis tidak pernah melakukan Penarikan (Withdrawal);',
                                'Polis tidak pernah berakhir karena lewat waktu atau lapsed; dan ',
                                'Pemegang Polis tidak melakukan Perubahan Mayor;',
                                'Pemegang Polis menyetujui untuk menaikan Premi Berkala dan Premi Top-up Berkala (jika diadakan) sebagaimana diminta oleh Penanggung dalam hal terjadi kenaikan terhadap Biaya Asuransi. Detail ketentuan mengacu pada Polis.',
                                ],}
                            ]
                        }],
                        ['19','Selisih negatif Biaya Asuransi dan Biaya Administrasi dikurangi dengan Nilai Tunai yang terbentuk pada Tanggal Perhitungan yang bersangkutan merupakan kewajiban yang tertunggak terhadap Penanggung dan Manfaat Asuransi akan dibayarkan setelah dikurangi dengan kewajiban yang tertunggak dari Pemegang Polis kepada Penanggung, kecuali apabila ditentukan lain berdasarkan Polis.'], 
                        ['20','Dalam Hal terdapat kewajiban yang tertunggak, dan Pemegang Polis melakukan hal-hal yang menyebabkan tidak terpenuhinya salah satu ketentuan yang tertera dalam no.18 di atas, maka Polis akan berakhir karena lewat waktu atau lapsed.'], 
                        ['21','Penanggung dapat menurunkan atau menaikkan Biaya Asuransi setiap saat dengan memberitahukan kepada Pemegang Polis paling lambat 30 (tiga puluh) hari kerja sebelum penurunan atau kenaikan Biaya Asuransi diberlakukan. '], 
                        ['22','Pemegang Polis diberikan waktu untuk mempelajari Polis selama 14 (empat belas) hari kalender terhitung  sejak Polis diterima oleh Pemegang Polis atau selambat-lambatnya 45 (empat puluh lima hari) kalender sejak Tanggal Mulai berlakunya Polis mana yang lebih cepat. Apabila Pemegang Polis tidak setuju dengan ketentuan Polis, maka Pemegang Polis dapat segera memberitahukan hal tersebut kepada Penanggung dengan mengembalikan dokumen Polis atau dalam hal Polis dibuat dalam bentuk Polis elektronik, maka Pemegang Polis wajib menyerahkan Ringkasan Polis asli (apabila diterbitkan secara cetak oleh Penanggung), dan Penanggung akan mengembalikan Premi yang telah dibayarkan oleh Pemegang Polis setelah dikurangi biaya-biaya yang timbul sehubungan dengan penerbitan Polis termasuk biaya pemeriksaan kesehatan yang ditetapkan oleh Penanggung, jika ada (ketentuan ini ini tidak berlaku dalam hal Pemegang Polis telah mengajukan/melakukan Transaksi Keuangan, Perubahan Mayor, Perubahan Minor; dan/atau mengajukan klaim Manfaat Asuransi).'], 
                        ['23',{text: ['Memiliki polis asuransi jiwa merupakan komitmen jangka panjang. ',{text:'PRU', font:'frutiger'}, {text:'link', font: 'garamount'},' assurance account adalah suatu produk asuransi jiwa yang dikaitkan dengan investasi. Untuk dapat menikmati manfaat polis ini, Kami  sarankan Anda untuk melakukan pembayaran Premi selama Masa Asuransi']}], 
                        ['24','PT Prudential Life Assurance terdaftar dan diawasi oleh Otoritas Jasa Keuangan.'], 
                    ]            
                },
                layout: whiteNoSpacePadBot()
            },
            {
                stack:[
                    /*{
                        margin:[0,-10,0,-10],
                        table: {
                                widths: ['*'],
                                body: [[' '], [' ']]
                        },
                        layout:lineFullWidth()
                    },*/
                    {
                        pageBreak: 'after',
                        absolutePosition : { x :25,y :525 },
                        columns: [
                            {
                                table: {
                                        body: [
                                                ['Disajikan',mapOutput.agentName,''],
                                                [{text:'Tanggal', margin: [0,0,0,16]},{text: mapOutput.QuotationDate},''],
                                                ['','',''],
                                                ['','',''],
                                                [ mapOutput.docIdStandard, mapOutput.versi, {text: mapOutput.substandardValue, fontSize: 5, margin:[0,-3,0,0]} ],
                                        ]            
                                },layout: whiteNoSpace()
                            },
                            {
                                
                                table: {
                                        body: [
                                                [{text:'Kode Agen/FSC', margin: [100,0,50,24]},mapOutput.agentId,''],
                                                ['','',''],
                                                ['','',''],
                                                ['','',''],
                                                ['','',''],
                                        ]            
                                },layout: whiteNoSpace()
                            },
                        ],
                    }
                ]
            },
            

//////////////////////  END HALAMAN 6
// ----- ian coding disini

            {
                columns: [
                    { text: [{text:'PRU', font:'frutiger'}, {text:'link assurance account', font: 'garamount'}], fontSize: 19, width: 260},
                    {
                        width: '*',
                        margin: [0,3,0,0],
                        table: {
                            widths: [ 'auto', 2],
                            body: [
                                    [{text:'RINGKASAN ILUSTRASI INI BUKAN MERUPAKAN SEBUAH KONTRAK ASURANSI', style: 'subheader', alignment:'center',margin:[30,0,30,0]}],
                            ]
                                                
                        },
                    },
                ],
            },

            {
                style: 'hal6Tabel',
                table: {
                    body: [
                        [
                            [
                                {
                                    table: {
                                        widths: [170, 300],
                                        body: 
                                            fundAllocationPage7(mapOutput)
                                    },layout: whiteNoSpace(),
                                }
                            ],
                            [
                                {
                                    table: {
                                        widths: [190, 190],
                                        /*
                                        body: [
                                            ['Nomor SPAJ / Polis',mapOutput.SPAJNo,],
                                        ]
                                        */
                                        body:
                                            fundAllocationPage7Section2(mapOutput)
                                    },layout: whiteNoSpace(),
                                }
                            ],
                        ],
                        // [
                        //      [
                        //          {
                        //              table:{
                        //                  widths: [100, 100, 100, 100],
                        //                  body: 
                        //                      fundAllocationPage7Section3(mapOutput)
                        //              },layout: whiteNoSpace(),       
                                    
                        //          }
                        //      ]
                        // ]
                    ]
                },
                layout: {
                            hLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ? 1 : 0;
                            },
                            vLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ? 1: 1;
                            },
                            hLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ? 'black' : 'white';
                            },
                            vLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ? 'black' : 'white';
                            },
                                            paddingLeft: function(i, node) { return 1; },
                                            paddingRight: function(i, node) { return 1; },
                                            paddingTop: function(i, node) { return 1; },
                                            paddingBottom: function(i, node) { return 1 },
                }
            },

            {
                pageBreak: 'after',
                absolutePosition : { x :25,y :515 },
                stack:[
                    {
                        table: {

                                body: [
                                        [
                                            {text:'Disajikan', margin:[0,0,24,0]},{text:mapOutput.agentName, width: 100},'',
                                            {text:'Kode Agen/FSC', margin: [24,0,0,0], alignment:'right'},
                                            {text:mapOutput.agentId, alignment:'center'},''                      
                                        ],
                                        [{text:'Tanggal'},{text: mapOutput.QuotationDate},'','','',''],
                                        [
                                            '','',
                                            {text:'Tanda Tangan Agen/SFC', margin: [12,0,0,0]},
                                            '________________________________________________________________',
                                            'Tanda Tangan Calon Pemegang Polis',
                                            '________________________________________________________________',
                                        ],
                                        [   
                                            '','','',
                                            {margin: [0,0,0,8], fontSize: 6, italics: true, text:'Saya telah menjelaskan isi ilustrasi ini kepada Calon Pemegang Polis'},
                                            '',{fontSize: 6, italics: true, text:'Saya telah memahami isi ilustrasi ini'}
                                        ],
                                        [ 
                                            mapOutput.docIdStandard, 
                                            {
                                                columns:[
                                                {text: mapOutput.versi, italics: true},
                                                {text: '[10-Feb-2017', italics: true},
                                                {text: 'Agency]', italics: true},
                                                ],
                                            },
                                            {text: mapOutput.substandardValue, fontSize: 5, margin:[-12,-3,0,0]},
                                            '','',''  
                                        ],
                                ]            
                        },layout: whiteNoSpace()
                        
                    },
                ],
            },
//////////////////////  END HALAMAN 7

            {
                columns: [
                    { text: [{text:'PRU', font:'frutiger'}, {text:'link assurance account', font: 'garamount'}], fontSize: 19, width: 260},
                    {
                        width: '*',
                        margin: [0,3,0,0],
                        table: {
                            widths: [ 'auto', 2],
                            body: [
                                    [{text:'RINGKASAN ILUSTRASI INI BUKAN MERUPAKAN SEBUAH KONTRAK ASURANSI', style: 'subheader', alignment:'center',margin:[30,0,30,0]}],
                            ]
                                                
                        },
                    },
                ],
            },

            '* Ketentuan jenis pemeriksaan dan Fakultatif di atas hanya berdasarkan pada informasi yang ada dalam ilustrasi ini saja. Dalam hal terdapat informasi lain yang ditemukan ketika dilakukan proses underwriting, maka underwriter berhak mengubah ketentuan tersebut.',
            '** Merupakan bagian dari dasar penilaian underwriter dalam menerbitkan kontrak asuransi. Perbedaan informasi pada penghasilan di ilustrasi dengan SPAJ atau risk profile jika ada, akan menggunakan data yang tertinggi.',
             
            { image: 'generatepdf', width: 780, height: 70, },
            {text: 'DESKRIPSI PEKERJAAN', fontSize:10, bold: true},
            {
                table: {
                    widths: [170, 300],
                    body: 
                        deskripsiPekerjaan(mapOutput)
                        
                },layout: whiteNoSpace(),
            },
            {
                table: {
                    widths: [500, 300],
                    body: 
                        informasiTambahan(mapOutput)
                        
                },layout: whiteNoSpace(),
            },                                    
            {
                pageBreak: 'after',
                absolutePosition : { x :25,y :515 },
                stack:[
                    {
                        table: {

                                body: [
                                        [
                                            {text:'Disajikan', margin:[0,0,24,0]},{text:mapOutput.agentName, width: 100},'',
                                            {text:'Kode Agen/FSC', margin: [24,0,0,0], alignment:'right'},
                                            {text:mapOutput.agentId, alignment:'center'},''                      
                                        ],
                                        [{text:'Tanggal'},{text: mapOutput.QuotationDate},'','','',''],
                                        [
                                            '','',
                                            {text:'Tanda Tangan Agen/SFC', margin: [12,0,0,0]},
                                            '________________________________________________________________',
                                            'Tanda Tangan Calon Pemegang Polis',
                                            '________________________________________________________________',
                                        ],
                                        [   
                                            '','','',
                                            {margin: [0,0,0,8], fontSize: 6, italics: true, text:'Saya telah menjelaskan isi ilustrasi ini kepada Calon Pemegang Polis'},
                                            '',{fontSize: 6, italics: true, text:'Saya telah memahami isi ilustrasi ini'}
                                        ],
                                        [ 
                                            mapOutput.docIdStandard, 
                                            {
                                                columns:[
                                                {text: mapOutput.versi, italics: true},
                                                {text: '[10-Feb-2017', italics: true},
                                                {text: 'Agency]', italics: true},
                                                ],
                                            },
                                            {text: mapOutput.substandardValue, fontSize: 5, margin:[-12,-3,0,0]},
                                            '','','' 
                                        ],
                                ]            
                        },layout: whiteNoSpace()
                        
                    },
                ],
            },
           
        ];

    };


    //------------------------------------------------------------------------------------------ start Scope for output death benefit ---------------------------------------------------------------------------------

    // --------------------------------------------------------------------------------------------- added by Efrat -----------------------------------------------------------------------------------------------

    function getDeathBenefitForOutput(type,tmpClientBenefit, dataTopUp, dataPenarikan, dataFund, fundCode, totalPenarikan){
        var body1 = [];
        var body2 = [];
        var allbody = [];

        //console.log('getDeathBenefitForOutput dataTopUp == ', dataTopUp);
        //console.log('getDeathBenefitForOutput dataPenarikan == ', dataPenarikan);
        //console.log('getDeathBenefitForOutput dataFund == ', dataFund);
        //console.log('getDeathBenefitForOutput fundCode == ', fundCode);

        var nilaiTopup;
        var nilaiTarik;
        var percentage = 1;

        if(fundCode != ''){
            for (fund = 0; fund < dataFund.length; fund++){
                var data = dataFund[fund].split('|');
                if(fundCode == data[0]){
                    percentage = parseInt(data[1])/100;
                }
            }
        }

        for(var i = 0; i < tmpClientBenefit.length; i++){
            if((i >= 0 && i <= 29) || (parseInt(tmpClientBenefit[i].year) % 5 == 0)){
                var tmp = tmpClientBenefit[i];
                var tmpBenefit1 = {};
                var tmpBenefit2 = {};

                //implement topup

                if(dataTopUp != undefined){
                    for(topup = 0; topup < dataTopUp.length; topup++){
                        var data = dataTopUp[topup].split('|');
                        //console.log('data topup == ',data);
                        if(data[0] == tmp.year){
                            nilaiTopup = (parseFloat(data[1])*percentage)/1000;
                            break;
                        }else{
                            nilaiTopup = '';
                        }
                    }    
                }

                //console.log('nilai topup '+i + ' == ',nilaiTopup);

                //implement penarikan

                if(dataPenarikan != undefined){
                    for(tarik = 0; tarik < dataPenarikan.length; tarik++){
                        var data = dataPenarikan[tarik].split('|');
                        //console.log('data tarik == ',data);
                        if(data[0] == tmp.year){
                            nilaiTarik = (parseFloat(data[1])*percentage)/1000;
                            break;
                        }else{
                            nilaiTarik = '';
                        }
                    }    
                }

                ////console.log('nilai tarik '+i + ' == ',nilaiTarik);

                tmpBenefit1 = {
                    year : tmp.year,
                    customerAge : tmp.customerAge,
                    premi : tmp.premiClient,
                    low : tmp.lowClient,
                    med : tmp.medClient,
                    high : tmp.highClient,
                    topup : nilaiTopup==undefined?'':nilaiTopup,
                    tarik : nilaiTarik==undefined?'':nilaiTarik
                };

                tmpBenefit2 = {
                    year : tmp.year,
                    customerAge : tmp.customerAge,
                    premi : tmp.premiAlt,
                    low : tmp.lowAlt,
                    med : tmp.medAlt,
                    high : tmp.highAlt,
                    topup : nilaiTopup==undefined?'':nilaiTopup,
                    tarik : nilaiTarik==undefined?'':nilaiTarik
                };

                /*if(type == 'CLIENT'){
                    tmpBenefit = {
                        year : tmp.year,
                        customerAge : tmp.customerAge,
                        premi : tmp.premiClient,
                        low : tmp.lowClient,
                        med : tmp.medClient,
                        high : tmp.highClient,
                        topup : nilaiTopup==undefined?'':nilaiTopup,
                        tarik : nilaiTarik==undefined?'':nilaiTarik
                    };
                }else{
                    tmpBenefit = {
                        year : tmp.year,
                        customerAge : tmp.customerAge,
                        premi : tmp.premiAlt,
                        low : tmp.lowAlt,
                        med : tmp.medAlt,
                        high : tmp.highAlt,
                        topup : nilaiTopup==undefined?'':nilaiTopup,
                        tarik : nilaiTarik==undefined?'':nilaiTarik
                    };
                }*/

                if(parseInt(tmpBenefit1.year) <= 10 && parseFloat(totalPenarikan) == 0){
                    body1.push([
                        {
                            text : tmpBenefit1.year, alignment : 'center'
                        },
                        {
                            text : tmpBenefit1.customerAge, alignment : 'center'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit1.premi))==true?'':parseFloat(tmpBenefit1.premi).format(), alignment : 'right'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit1.topup))==true?'':parseFloat(tmpBenefit1.topup).format(), alignment : 'right'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit1.tarik))==true?'':parseFloat(tmpBenefit1.tarik).format(), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit1.low).format(), alignment:'right'
                            text : (tmpBenefit1.low <= 0) ? '0' : parseFloat(tmpBenefit1.low).format(formatCurr), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit1.med).format(), alignment : 'right'
                            text : (tmpBenefit1.med <= 0) ? '0' : parseFloat(tmpBenefit1.med).format(formatCurr), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit1.high).format(), alignment : 'right'
                            text : (tmpBenefit1.high <= 0) ? '0' : parseFloat(tmpBenefit1.high).format(formatCurr), alignment : 'right'
                    }
                    ]);    
                }else if(parseInt(tmpBenefit1.year) <= 10 && parseFloat(totalPenarikan) > 0){
                    body1.push([
                        {
                            text : tmpBenefit1.year, alignment : 'center'
                        },
                        {
                            text : tmpBenefit1.customerAge, alignment : 'center'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit1.premi))==true?'':parseFloat(tmpBenefit1.premi).format(), alignment : 'right'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit1.topup))==true?'':parseFloat(tmpBenefit1.topup).format(), alignment : 'right'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit1.tarik))==true?'':parseFloat(tmpBenefit1.tarik).format(), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit1.low).format(), alignment:'right'
                            text : (tmpBenefit1.low <= 0) ? '0' : parseFloat(tmpBenefit1.low).format(formatCurr), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit1.med).format(), alignment : 'right'
                            text : (tmpBenefit1.med <= 0) ? '0' : parseFloat(tmpBenefit1.med).format(formatCurr), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit1.high).format(), alignment : 'right'
                            text : (tmpBenefit1.high <= 0) ? '0' : parseFloat(tmpBenefit1.high).format(formatCurr), alignment : 'right'
                    }
                    ]);
                }else{
                    body1.push([
                        {
                            text : tmpBenefit1.year, alignment : 'center'
                        },
                        {
                            text : tmpBenefit1.customerAge, alignment : 'center'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit1.premi))==true?'':parseFloat(tmpBenefit1.premi).format(), alignment : 'right'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit1.topup))==true?'':parseFloat(tmpBenefit1.topup).format(), alignment : 'right'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit1.tarik))==true?'':parseFloat(tmpBenefit1.tarik).format(), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit1.low).format(), alignment:'right'
                            text : (tmpBenefit1.low <= 0) ? '***' : parseFloat(tmpBenefit1.low).format(formatCurr), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit1.med).format(), alignment : 'right'
                            text : (tmpBenefit1.med <= 0) ? '***' : parseFloat(tmpBenefit1.med).format(formatCurr), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit1.high).format(), alignment : 'right'
                            text : (tmpBenefit1.high <= 0) ? '***' : parseFloat(tmpBenefit1.high).format(formatCurr), alignment : 'right'
                    }
                    ]);
                }    

                if(parseInt(tmpBenefit2.year) <= 10 && parseFloat(totalPenarikan) == 0){
                    body2.push([
                        {
                            text : tmpBenefit2.year, alignment : 'center'
                        },
                        {
                            text : tmpBenefit2.customerAge, alignment : 'center'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit2.premi))==true?'':parseFloat(tmpBenefit2.premi).format(), alignment : 'right'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit2.topup))==true?'':parseFloat(tmpBenefit2.topup).format(), alignment : 'right'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit2.tarik))==true?'':parseFloat(tmpBenefit2.tarik).format(), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit2.low).format(), alignment:'right'
                            text : (tmpBenefit2.low <= 0) ? '0' : parseFloat(tmpBenefit2.low).format(formatCurr), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit2.med).format(), alignment : 'right'
                            text : (tmpBenefit2.med <= 0) ? '0' : parseFloat(tmpBenefit2.med).format(formatCurr), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit2.high).format(), alignment : 'right'
                            text : (tmpBenefit2.high <= 0) ? '0' : parseFloat(tmpBenefit2.high).format(formatCurr), alignment : 'right'
                        }
                    ]);    
                }else if(parseInt(tmpBenefit1.year) <= 10 && parseFloat(totalPenarikan) > 0){
                    body2.push([
                        {
                            text : tmpBenefit2.year, alignment : 'center'
                        },
                        {
                            text : tmpBenefit2.customerAge, alignment : 'center'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit2.premi))==true?'':parseFloat(tmpBenefit2.premi).format(), alignment : 'right'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit2.topup))==true?'':parseFloat(tmpBenefit2.topup).format(), alignment : 'right'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit2.tarik))==true?'':parseFloat(tmpBenefit2.tarik).format(), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit2.low).format(), alignment:'right'
                            text : (tmpBenefit2.low <= 0) ? '0' : parseFloat(tmpBenefit2.low).format(formatCurr), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit2.med).format(), alignment : 'right'
                            text : (tmpBenefit2.med <= 0) ? '0' : parseFloat(tmpBenefit2.med).format(formatCurr), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit2.high).format(), alignment : 'right'
                            text : (tmpBenefit2.high <= 0) ? '0' : parseFloat(tmpBenefit2.high).format(formatCurr), alignment : 'right'
                        }
                    ]);
                }else{
                    body2.push([
                        {
                            text : tmpBenefit2.year, alignment : 'center'
                        },
                        {
                            text : tmpBenefit2.customerAge, alignment : 'center'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit2.premi))==true?'':parseFloat(tmpBenefit2.premi).format(), alignment : 'right'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit2.topup))==true?'':parseFloat(tmpBenefit2.topup).format(), alignment : 'right'
                        },
                        {   
                            text : isNaN(parseFloat(tmpBenefit2.tarik))==true?'':parseFloat(tmpBenefit2.tarik).format(), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit2.low).format(), alignment:'right'
                            text : (tmpBenefit2.low <= 0) ? '***' : parseFloat(tmpBenefit2.low).format(formatCurr), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit2.med).format(), alignment : 'right'
                            text : (tmpBenefit2.med <= 0) ? '***' : parseFloat(tmpBenefit2.med).format(formatCurr), alignment : 'right'
                        },                    
                        {   
                            // text : parseFloat(tmpBenefit2.high).format(), alignment : 'right'
                            text : (tmpBenefit2.high <= 0) ? '***' : parseFloat(tmpBenefit2.high).format(formatCurr), alignment : 'right'
                        }
                    ]);
                }    

                
            }
            if(body1.length == 32){
                break;
            }
        }
        allbody.push(body1);
        allbody.push(body2);
        return allbody;
    }


    //------------------------------------------------------------------------------------------ end Scope for output death benefit ---------------------------------------------------------------------------------


    // ------------------------------------------------------------------------------------------ Scope For Output Chart -------------------------------------------------------------------------------------- 

    // ---------------------------------------------------------------------------- added by Efrat ---------------------------------------------------------------------------------------------


    function loopCashValueLowCln(mapOutput){
        var CashValueCln  = [];
        var setTotalCvLow = new Array();
        var getCashValueLow = 0;
        var cashValue = {}
        CashValueCln = mapOutput.output.output["FUNDBENEFIT"];
        for(var i = 0; i<=19; i++){
            getCashValueLow = parseInt(CashValueCln[i].lowClient);
            setTotalCvLow.push(getCashValueLow);
        }
        return setTotalCvLow;
    }

    function loopCashValueMedCln(mapOutput){
        var CashValueCln  = [];
        var setTotalCvMed = new Array();
        var getCashValueMed = 0;
        CashValueCln = mapOutput.output.output["FUNDBENEFIT"];
        for(var i = 0; i<=19; i++){
            getCashValueMed = parseInt(CashValueCln[i].medClient);
            setTotalCvMed.push(getCashValueMed);
        }
        return setTotalCvMed;
    }

    function loopCashValueHighCln(mapOutput){
        var CashValueCln  = [];
        var setTotalCvHigh = new Array();
        var getCashValueHigh = 0;
        CashValueCln = mapOutput.output.output["FUNDBENEFIT"];
        for(var i = 0; i<=19; i++){
            getCashValueHigh = parseInt(CashValueCln[i].highClient);
            setTotalCvHigh.push(getCashValueHigh);  
        }
        return setTotalCvHigh;
    }

    // start for alternative 
     function loopCashValueLowAlt(mapOutput){
        var CashValueAlt = [];
        var setTotalCvLow = new Array();
        var getCashValueLow = 0;
        CashValueAlt = mapOutput.output.output["FUNDBENEFIT"];
        for(var i = 0; i<=19; i++){
            getCashValueLow = parseInt(CashValueAlt[i].lowAlt);
            setTotalCvLow.push(getCashValueLow);
        }
        return setTotalCvLow;
    }

    function loopCashValueMedAlt(mapOutput){
        var CashValueAlt = [];
        var setTotalCvMed = new Array();
        var getCashValueMed = 0;
        CashValueAlt = mapOutput.output.output["FUNDBENEFIT"];
        for(var i = 0; i<=19; i++){
            getCashValueMed = parseInt(CashValueAlt[i].medAlt);
            setTotalCvMed.push(getCashValueMed);
        }
        return setTotalCvMed;
    }

    function loopCashValueHighAlt(mapOutput){
        var CashValueAlt = [];
        var setTotalCvHigh = new Array();
        var getCashValueHigh = 0;
        CashValueAlt = mapOutput.output.output["FUNDBENEFIT"];
        for(var i = 0; i<=19; i++){
            getCashValueHigh = parseInt(CashValueAlt[i].highAlt);
            setTotalCvHigh.push(getCashValueHigh);  
        }
        return setTotalCvHigh;
    }

//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    //function for table catatan Fund

   var mapFund={
    'PRMF':'12.52|10.70|8.82|-8.82|14.51|-4.37|9.39',
    'PREF':'17.00|1.14|10.39|-2.54|26.96|-19.4|8.10',
    'PRFF':'10.02|17.71|10.25|-13.51|10.43|0.98|11.11',
    'PRCF':'7.73|5.16|4.43|5.09|7.36|6.82|6.12',
    'PRMP':'12.18|6.33|9.26|-4.28|19.24|-10.05|8.79',
    'PDFF':'6.46|6.61|12.00|-10.74|12.74|-2.07|10.15',
    'PRGC':'4.35|-|-|-|24.81|-12.05|6.70',
    'PDGC':'-4.20|-|-|-|22.29|-20.69|9.56',
    'PREP':'3.36|-|-|-|-|-13.3|8.66',
    'PRIE':'2.59|-|-|-|-|-|10.52',
    'PRVE':'-|-|-|-|-|-|-',
    };

    function getUsingFund(mapOutput){
        var body = [];
        var fundName = '';
        var code = '';
        var getMapFund = [];
        var srtMapFund = '';
        var alloc;
        for(var i = 0; i < mapOutput.fundListOutput.length; i++){

            fundName1 = mapOutput.fundListOutput[i].name.substring(0,3);
            fundName2 = mapOutput.fundListOutput[i].name.substring(3,7);
            fundName3 = mapOutput.fundListOutput[i].name.substring(7);
            code = mapOutput.fundListOutput[i].code;
            alloc = mapOutput.fundListOutput[i].itemInput[0].inputValue;

            if(alloc != '0' || alloc != 0){
                //Tampilkan fund yang hanya ada alokasinya    

                srtMapFund = mapFund[code];
                if(srtMapFund == null || srtMapFund === ''){
                    body.push([
                        {text:[{ text:fundName1, font: 'frutiger' },{text:fundName2, font: 'garamount'},fundName3], alignment:'left'}, '-', '-', '-', '-', '-', '-'
                    ]);
                }else{
                    getMapFund = srtMapFund.split('|');
                    body.push([
                        {text:[{ text:fundName1, font: 'frutiger' },{text:fundName2, font: 'garamount'},fundName3], alignment:'left'},
                        {
                            text : getMapFund[0], alignment : 'right'
                        },
                        // {   
                        //     text : getMapFund[1], alignment : 'right'
                        // },
                        {   
                            text : getMapFund[2], alignment : 'right'
                        },
                        {   
                            text : getMapFund[3], alignment : 'right'
                        },                    
                        {   
                            text : getMapFund[4], alignment:'right'
                        },                    
                        {   
                            text : getMapFund[5], alignment : 'right'
                        },
                        {   
                            text : getMapFund[6], alignment : 'right'
                        }
                    ]);
                }
            }            
            
        }
        return body.transpose();
    }


//---------------------------------------------------------------------------- end edded code----------------------------------------------------------------------------------

    function chartpdf(mapOutput) {
        var chart_data = {
            
            labels : [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20],
            datasets : [
              {
                  label: "tinggi",
                    fill: false,
                    strokeColor: "#fff",
                    pointDot: true,
                    radius: 3,
                    pointStyle: 'triangle',
                    spanGaps: false,
                    backgroundColor : '#000',
                    pointBackgroundColor: '#8CE822',
                    pointBorderColor: '#8CE822',
                    data : loopCashValueHighCln(mapOutput)
              },
              {
                  label: "sedang",
                    fill: false,
                    strokeColor: "#fff",
                    pointDot: true,
                    radius: 3,
                    pointStyle: 'circle',
                    spanGaps: false,
                    backgroundColor : '#0062ff',
                    pointBackgroundColor: '#0062ff',
                    pointBorderColor: '#0062ff',
                    data : loopCashValueMedCln(mapOutput)
              },
              {
                  label: "rendah",
                    fill: false,
                    strokeColor: "#fff",
                    pointDot: true,
                    radius: 5,
                    pointStyle: 'rect',
                    spanGaps: false,
                    backgroundColor : '#ff0909',
                    pointBackgroundColor: '#ff0909',
                    pointBorderColor: '#ff0909',
                    data : loopCashValueLowCln(mapOutput)
              },
            ],    
        };

        var canvasid = document.createElement('canvas');
        canvasid.id = 'myChart';
        document.body.appendChild(canvasid);

        canvasid.width = 410;
        canvasid.height = 204;

        var context = document.getElementById("myChart");

        var myChart = new ChartSQS(context, {
            type: 'line',
            data: chart_data,
            options : {
                bezierCurve : false,
                animation: false,
                responsive: false,  
                onAnimationComplete: 'done',                                                                      
                scales: {
                    yAxes: [{
                    display: true,
                        ticks: {
                            beginAtZero: true,
                            callback: function(value, index, values) {
                                return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                            }
                        }
                    }],
                    xAxes: [{
                        gridLines: {
                          drawOnChartArea: false
                        },
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                },
                legend: {
                    display: false,
                },
            }
        });

        document.body.removeChild(canvasid);

        var canvasImg = canvasid.toDataURL();

        return canvasImg

    }

    function chartpdfAlt(mapOutput) {
        var chart_data = {
            
            labels : [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20],
            datasets : [
              {
                  label: "tinggi",
                    fill: false,
                    strokeColor: "#fff",
                    pointDot: true,
                    radius: 3,
                    pointStyle: 'triangle',
                    spanGaps: false,
                    backgroundColor : '#000',
                    pointBackgroundColor: '#8CE822',
                    pointBorderColor: '#8CE822',
                    data : loopCashValueHighAlt(mapOutput) 
              },
              {
                  label: "sedang",
                    fill: false,
                    strokeColor: "#fff",
                    pointDot: true,
                    radius: 3,
                    pointStyle: 'circle',
                    spanGaps: false,
                    backgroundColor : '#0062ff',
                    pointBackgroundColor: '#0062ff',
                    pointBorderColor: '#0062ff',
                    data : loopCashValueMedAlt(mapOutput) 
              },
              {
                  label: "rendah",
                    fill: false,
                    strokeColor: "#fff",
                    pointDot: true,
                    radius: 5,
                    pointStyle: 'rect',
                    spanGaps: false,
                    backgroundColor : '#ff0909',
                    pointBackgroundColor: '#ff0909',
                    pointBorderColor: '#ff0909',
                    data : loopCashValueLowAlt(mapOutput) 
              },
            ],    
        };

        var canvasid = document.createElement('canvas');
        canvasid.id = 'myChart';
        document.body.appendChild(canvasid);

        canvasid.width = 410;
        canvasid.height = 204;

        var context = document.getElementById("myChart");

        var myChart = new ChartSQS(context, {
            type: 'line',
            data: chart_data,
            options : {
                bezierCurve : false,
                animation: false,
                responsive: false,  
                onAnimationComplete: 'done',                                                                      
                scales: {
                    yAxes: [{
                    display: true,
                        ticks: {
                            beginAtZero: true,
                            callback: function(value, index, values) {
                                return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                            }
                        }
                    }],
                    xAxes: [{
                        gridLines: {
                          drawOnChartArea: false
                        },
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                },
                legend: {
                    display: false,
                }
            }
        });

        document.body.removeChild(canvasid);

        var canvasImg = canvasid.toDataURL();

        return canvasImg

    }

    function generate(mapOutput) {
        //var textToEncode = "Mba Nat..., Pembayaran Kedua (satu tahun setelah Pembayaran Pertama) sebesar 80% dari Uang Pertanggungan PRUlink investor account yang akan mengurangi Uang Pertanggungan PRUlink investor account.";
        var textToEncode = mapOutput.barcode;
        //console.log(mapOutput);
        PDF417.init(textToEncode);             

        var barcode = PDF417.getBarcodeArray();

        // block sizes (width and height) in pixels
        var bw = 2;
        var bh = 2;

        // create canvas element based on number of columns and rows in barcode
        /*var container = dikpdf;
        container.removeChild(container.firstChild);*/

        var canvas = document.createElement('canvas');
        canvas.width = bw * barcode['num_cols'];
        canvas.height = bh * barcode['num_rows'];
        //container.appendChild(canvas);

        var ctx = canvas.getContext('2d');                    

        // graph barcode elements
        var y = 0;
        // for each row
        for (var r = 0; r < barcode['num_rows']; ++r) {
            var x = 0;
            // for each column
            for (var c = 0; c < barcode['num_cols']; ++c) {
                if (barcode['bcode'][r][c] == 1) {                        
                    ctx.fillRect(x, y, bw, bh);
                }
                x += bw;
            }
            y += bh;
        };       
        var dataURL = canvas.toDataURL("image/png"); 
        return dataURL;

    }


    /*function datatexted(page, pages) { 
        return { 
            text: [
                { text: page.toString()},
                ' - ',
                { text: pages.toString()},

                { text: mapOutput.docIdStandard()}
                ' - ',
            ]
        };
    },*/

    function textToBase64Barcode(texted){
        var canvas = document.createElement("canvas");
        JsBarcode(canvas, texted, {format: "CODE39",displayValue: false});
        return canvas.toDataURL("image/png");
    }

    function base64ToUint8Array(base64) {
        var raw = atob(base64);
        var uint8Array = new Uint8Array(raw.length);
        for (var i = 0; i < raw.length; i++) {
            uint8Array[i] = raw.charCodeAt(i);
        }
        return uint8Array;
        // return raw;
    }


    return {
            createPdf: createPdf,
            outputPdf: outputPdf
        };


});


