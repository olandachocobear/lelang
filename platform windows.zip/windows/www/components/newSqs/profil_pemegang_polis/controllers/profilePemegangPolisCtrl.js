﻿var pruforce = angular.module('PruForce');

pruforce.controller('profilePemegangPolisCtrl', function($q, $scope, $ionicScrollDelegate, $ionicPopup,$ionicLoading, $rootScope, $state, $localStorage, PublishGlobalService, CustomerStorageService, QuotationStorageService, $timeout) {

console.log('Quotation ID :' + $rootScope.QuotationId);
    
    console.log('Level        :' + $rootScope.Level);
    $scope.polis = {};
   /* $scope.valOccList =  [{code : '--- Pilih ---' , nameInd : '--- Pilih ---'}];
    $scope.valOccList = $scope.valOccList.concat($rootScope.occupationList);    */
    $scope.valOccList = $rootScope.occupationList;  
    $scope.tmp_input = {};  
    //---------------------------

    $scope.searchPemegangPolis;


    var today = new Date();
    var custListStorage;

    var workCode;
    var pemegangKe;
    var maritalStatus;
    $scope.maxDateornDatePP = new Date(
    today.getFullYear(),
    today.getMonth(),
    today.getDate());

    var QuotationStorage = {};
    var tempCustList = {};    
    if ($rootScope.QuotationId != undefined) {
        QuotationStorageService.getQuotationStorageByKey($q, $rootScope.QuotationId).then(function(result){
            console.log('ISI QUOTATION STORAGE ', result);
            QuotationStorage = result;
            custListStorage = result.CustomerList;

            tempCustList = custListStorage ? custListStorage : {};
            console.log(custListStorage);
            CustomerStorageService.getCustomerStorageByCustMap($q, custListStorage).then(function(res){
                var quotStorage = res;
                console.log(quotStorage);

                var policyHolder = getDataTertanggung('01', custListStorage, quotStorage);
                console.log('policyHolder ',policyHolder);
                if(policyHolder && policyHolder.Dob){
                    policyHolder.Dob = new Date(policyHolder.Dob);
                }

                $scope.polis = policyHolder;
                console.log("$scope.polis ", $scope.polis);
                  var resprof = $rootScope.positionList.filter(function(obj){
                    return obj.code == $scope.polis.Position;
                  })
                  if(resprof.length > 0){
                      $scope.tmp_input.inp_pos = resprof[0];
                  }
                  resprof = $rootScope.businessList.filter(function(obj){
                    return obj.code == $scope.polis.Business;
                  })
                  if(resprof.length > 0){
                      $scope.tmp_input.inp_bss = resprof[0];
                  }
                  $scope.tmp_input.inp_prem = $scope.polis.workPremi;
                $ionicLoading.hide();
            });
        });      
    } 

$scope.settext_combo = function(val, type){
      if(!val){
        if(type == "pekerjaan")
          return "Pekerjaan";
        else if(type == "usaha")
          return "Bidang Usaha";
        else if(type == "jabatan")
          return "Jabatan/Pangkat/Golongan";
        else if(type == "pekerjaan2")
          return "Pekerjaan";
      }else{
        if(val.nameInd)
          return val.nameInd;
        else
          return val.descriptionInd;
      }
    }

    function getDataTertanggung(key, map, list){
        var tertanggungUtama;

        var tmpCustId = map[key];
        for(var j = 0; j < list.length; j++){
            if(list[j].customerId == tmpCustId){
                tertanggungUtama = list[j];
                break;
            }
        }
        return tertanggungUtama;
    }

    function genCustId(){
        return 'PLCHLDR' + new Date().getTime();
    }

    function genQuotId(){
        var reDate = moment(today).format('YYYYMMDDHHMMSS'); 
        return $rootScope.agent.code + reDate;
    } 


    var key = 0;
    $scope.tmp_required = {};
    $scope.bool_tidakbekerja = false;
    $scope.keyPress = function(title, value){
      
        var flag = false;

        $scope.polis.flagAccordion = false;
        $scope.polis.flagField = false;

        if($scope.polis.customerId == undefined){
            $scope.polis.customerId = genCustId();
            console.log($scope.polis.customerId);
        }

        if (title === 'name') {
            $scope.polis.name = value.name;
        }

        //INCOME
        if (title === 'tipe') {
            $scope.polis.tipe = value.tipe;
            $scope.totalIncomess = $rootScope.incomeList[value.tipe];
            console.log('------ $scope.totalIncomes : ',$scope.totalIncomes);
        }
        
        if (title === 'pemegang') {
            $scope.polis.pemegang = value.pemegang;
            console.log('----- polis.pemegang : ',$scope.polis.pemegang); 
            pemegangKe = $scope.polis.pemegang;
            $scope.premiCondition = (pemegangKe === value.pembayaran) && (pemegangKe === 1);
            
            $rootScope.tertanggung = false;
            flag = true;

            $rootScope.myDateToday = new Date();
            if($scope.polis.pemegang == 1){
                $rootScope.minDateVal = new Date(
                    $rootScope.myDateToday.getFullYear() - 100,
                    $rootScope.myDateToday.getMonth(),
                    $rootScope.myDateToday.getDate());
                $rootScope.maxDateVal = new Date(
                   $rootScope.myDateToday.getFullYear()+100,
                   $rootScope.myDateToday.getMonth(),
                   $rootScope.myDateToday.getDate());
            }else{
                $rootScope.minDateVal = new Date(
                    $rootScope.myDateToday.getFullYear() - 70,
                    $rootScope.myDateToday.getMonth(),
                    $rootScope.myDateToday.getDate());
                $rootScope.maxDateVal = new Date(
                   $rootScope.myDateToday.getFullYear()+70,
                   $rootScope.myDateToday.getMonth(),
                   $rootScope.myDateToday.getDate());
            }
        } 

        if (title === 'status') {
            $scope.polis.MaritalStatus = value.MaritalStatus;
            maritalStatus = $scope.polis.MaritalStatus;
        }   
        
        if (title === 'dob') {
            // $timeout(function(){              
                console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>"+value.Dob);
                var birthDate = new Date(value.Dob);
                var age = today.getFullYear() - birthDate.getFullYear();
                var m = today.getMonth() - birthDate.getMonth();
                if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
                    age--;
                }
                
                $scope.polis.Dob = value.Dob;
                $scope.polis.age = age;
                $scope.polis.anb = parseInt(age)+1;
                $scope.polis.custAge = $scope.polis.age;
                console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>"+age);
                $scope.polis.custAgeDay = Math.abs(today - birthDate);
                $scope.polis.custAgeMonth = (((today.getFullYear() - birthDate.getFullYear())*12) + parseInt(m));
              
            // },500);
        }
        
        //OCCUPATION
        if (title === 'occupation'){
            //$scope.polis.Occupation = value.Occupation;
            $scope.polis.pekerjaanCode = value.Occupation.code;
            $scope.tmp_required.bss = 'required';
            $scope.tmp_required.dep = 'required';
            $scope.tmp_required.pos = 'required';
                if(value.Occupation.code == 'HSWF' || value.Occupation.code == 'UNEM' || value.Occupation.code == 'RETI' || value.Occupation.code == 'NSTN'){
                    for(var od=0; od< $rootScope.businessList.length; od++){
                        if($rootScope.businessList[od].code == 'X'){
                            $scope.polis.Business = $rootScope.businessList[od].code;
                        $scope.tmp_input.inp_bss = $rootScope.businessList[od];
                            break;
                        }
                    }
                    for(var jab=0; jab < $rootScope.positionList.length; jab++){
                        if($rootScope.positionList[jab].code == 'UNP'){
                            $scope.polis.Position = $rootScope.positionList[jab].code;
                        $scope.tmp_input.inp_pos = $rootScope.positionList[jab];
                        break;
                        }
                    }
                    for(var ic =0; ic < $rootScope.totalIncomes.length; ic++){
                        if($rootScope.totalIncomes[ic].code == 'O'){
                            $scope.polis.Income = $rootScope.totalIncomes[ic].code;
                        }
                    }
                    $scope.polis.Department = 'Tidak Bekerja';
                $scope.tmp_required.bss = '';
                $scope.tmp_required.dep = '';
                $scope.tmp_required.pos = '';
                $scope.bool_tidakbekerja = true;
            }else if(value.Occupation.code == 'STDN'){
                    for(var od=0; od< $rootScope.businessList.length; od++){
                        if($rootScope.businessList[od].code == 'S'){
                            $scope.polis.Business = $rootScope.businessList[od].code;
                        $scope.tmp_input.inp_bss = $rootScope.businessList[od];
                            break;
                        }
                    }
                    for(var jab=0; jab < $rootScope.positionList.length; jab++){
                        if($rootScope.positionList[jab].code == 'UNP'){
                            $scope.polis.Position = $rootScope.positionList[jab].code;
                        $scope.tmp_input.inp_pos = $rootScope.positionList[jab];
                        break;
                        }
                    }
                    for(var ic =0; ic < $rootScope.totalIncomes.length; ic++){
                        if($rootScope.totalIncomes[ic].code == 'O'){
                            $scope.polis.Income = $rootScope.totalIncomes[ic].code;
                        }
                    }
                    $scope.polis.Department = 'Tidak Bekerja';
                $scope.tmp_required.bss = '';
                $scope.tmp_required.dep = '';
                $scope.tmp_required.pos = '';
                $scope.bool_tidakbekerja = true;
            }else{
                $scope.tmp_required.bss = 'required';
                $scope.tmp_required.dep = 'required';
                $scope.tmp_required.pos = 'required';
                //clear jika sebelumnya adalah "tidak bekerja"
                if($scope.bool_tidakbekerja){
                    $scope.tmp_input = {};
                    $scope.polis.Department = '';
                    $scope.polis.Business = '';
                    $scope.polis.Position = '';
                }
                $scope.bool_tidakbekerja = false;
            }
        }          
        if (title === 'instansi') {
            $scope.polis.Department = value.Department;
        }

        //BUSINESS
        if (title === 'bidang') {
            console.log("inp_bss ", $scope.tmp_input.inp_bss);
            if($scope.tmp_input.inp_bss)
              $scope.polis.Business = $scope.tmp_input.inp_bss.code;
        }
        
        //POSITION  
        if (title === 'instansi2') {
            $scope.polis.Position = $scope.tmp_input.inp_pos.code;        
        }

        if (title === 'pembayaran') {
            $scope.polis.PembayaranPremi = value.PembayaranPremi;
            $scope.premiCondition = (pemegangKe === value.PembayaranPremi) && (pemegangKe === 1);
            $scope.premiCondition2 = (value.PembayaranPremi === 7);
        }

        if (title === 'namePremi') {
            $scope.polis.namePremi = value.namePremi;
        }

        if (title === 'occupationPremi') {
          //console.log("tmp_input.inp_prem ", $scope.tmp_input.inp_prem);
            $scope.polis.workPremi = $scope.tmp_input.inp_prem;
            $scope.polis.OccupationPremi = $scope.tmp_input.inp_prem.code;
            $scope.polis.workClassPremi = $scope.tmp_input.inp_prem.clazz; 
            $scope.polis.descriptionWorkPremi = $scope.tmp_input.inp_prem.descriptionInd;
        }

        //INCOME
        $scope.totalNoIncome = [ 
            {individualInd: "Tidak Berpenghasilan", individualEng:"No Income", value: "O"}
        ]

        if (title === 'tp') {
            $scope.polis.IncomePremi = value.IncomePremi;
            $scope.polis.NoIncomePremi = value.totalPenghasilan;
        }

              
        if ($rootScope.QuotationId == undefined){            
            setCustomerList();
            
            $rootScope.QuotationId = genQuotId();
            QuotationStorage.QuotationId = $rootScope.QuotationId;
            QuotationStorage.CustomerList = tempCustList;        
            QuotationStorage.QuotationDate = today;
            QuotationStorage.Level = 1;
        }          
              
        if($rootScope.flagOpenTertanggung == false){
            tempCustList['01'] = $scope.polis.customerId;
        }

        if (flag){
            console.log('F L A G');
            if($rootScope.flagOpenTertanggung == false){
                console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> sini ");
                resetQuotCustList($scope.polis)
               
            }else{
                $scope.polis.customerId = genCustId();
                console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> sana ");
                resultPolicyHolder($scope.polis);
               /* $timeout(function(){
                    CustomerStorageService.addCustomerStorage($q, $scope.polis.customerId, $scope.polis).then(function(){
                        QuotationStorage.CustomerList = tempCustList;
                        QuotationStorageService.addQuotationStorage($q, $rootScope.QuotationId, QuotationStorage);                
                    })
                },1000);*/

            }
            
            if($scope.polis.pemegang){
                key = parseInt($scope.polis.pemegang);
                console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>",key);
                sortingBackwards();

            }

            
            flag = false;
        } else {
            // $scope.polis.customerId = genCustId();
            resultPolicyHolder($scope.polis);
        }
        
            $timeout(function(){
                CustomerStorageService.addCustomerStorage($q, $scope.polis.customerId, $scope.polis).then(function(){
                    QuotationStorage.CustomerList = tempCustList;
                    QuotationStorageService.addQuotationStorage($q, $rootScope.QuotationId, QuotationStorage);                
                })
            },1000);    
        
        
        // $timeout(function(){
            // CustomerStorageService.addCustomerStorage($q, $scope.polis.customerId, $scope.polis);

        /*sortingBackwards($scope.polis.pemegang).then(function(r){
            QuotationStorage.CustomerList = tempCustList;
            QuotationStorageService.addQuotationStorage($q, $rootScope.QuotationId, QuotationStorage);            
        })*/
/*        console.log('MASUUKKKKKKKKKKKKKKKKKKKKKKKKKK');
        if($scope.polis.pemegang){
            key = parseInt($scope.polis.pemegang);
            sortingBackwards($scope.polis.pemegang);
        }*/

          // QuotationStorage.CustomerList = tempCustList;
          // QuotationStorageService.addQuotationStorage($q, $rootScope.QuotationId, QuotationStorage);
        // },500);
    }

      
     
    function resultPolicyHolder(result) {
        console.log(result);
        // var newCustId = genCustId();
        tempCustList['01'] = result.customerId;
        if(result.pemegang){
            if(result.pemegang > 1){
                var keyCust = '0' + result.pemegang;
                tempCustList[keyCust] = result.customerId;
            }            
        }
       /* CustomerStorageService.addCustomerStorage($q, $scope.polis.customerId, $scope.polis).then(function(){
            QuotationStorage.CustomerList = tempCustList;
            QuotationStorageService.addQuotationStorage($q, $rootScope.QuotationId, QuotationStorage);                
        })*/
    }

    function resetQuotCustList(result) {
        console.log(result);       
        tempCustList['01'] = result.customerId;
        for(var i = 2; i < 7; i++){
            if(result.pemegang && i != result.pemegang){
                tempCustList['0' + i] = null;              
            }else{
                tempCustList['0' + i] = result.customerId;
            }
        }
        /*CustomerStorageService.addCustomerStorage($q, $scope.polis.customerId, $scope.polis).then(function(){
            QuotationStorage.CustomerList = tempCustList;
            QuotationStorageService.addQuotationStorage($q, $rootScope.QuotationId, QuotationStorage);                
        })*/
    }


    function sortingBackwards(){
        //var deffer = $q.defer();
        //var key = parseInt(result);
        var promisesss = [];
        // $timeout(function(){ 
        console.log("key ", key);
        // console.log("Pemegang polis :  ", pp);
        // var i = 0;
        if(key <= 2){
           /* $timeout(function(){
                    CustomerStorageService.addCustomerStorage($q, $scope.polis.customerId, $scope.polis).then(function(){
                        QuotationStorage.CustomerList = tempCustList;
                        QuotationStorageService.addQuotationStorage($q, $rootScope.QuotationId, QuotationStorage);                
                    })
                },1000);*/

            console.log("selesai");
        }else {
            if(tempCustList['0' + (key-1)] == null){
                var tempCode = genCustId()+key;
                console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>================== ",tempCode);
                tempCustList['0' + (key-1)] = tempCode;

                var tempPolis = {};
                tempPolis.customerId = tempCode;

                var data = {};
                data.agentId = $rootScope.agent.code;
                data.retrieveDate = new Date();
                data.customerId = tempCode;
                console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>================== ",key+" || "+$scope.polis.pemegang);
                console.log("scope polis ", $scope.polis);
                console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>tempPolis>>>>>>>>>================== ",tempPolis);
                // if(key == $scope.polis.pemegang){
                //     var newPP = $scope.polis;
                //     newPP.customerId = tempCode;
                //     data.invocationResult = newPP;
                // }else{
                    data.invocationResult = tempPolis;
                // }
                //data.invocationResult = key == $scope.polis.pemegang ? $scope.polis : tempPolis;

                WL.JSONStore.get('CustomerStorage').add(data).then(function () {
                    console.log("Success adding data to jsonstore CustomerStorage", data);
                    key--;
                    sortingBackwards();
                }).fail(function (error) {
                    console.log("Failed adding data to jsonstore CustomerStorage");
                });
            }
        }

       
        /*for(var i = (key-1); i > 1; i--){
            var zzz = tempCustList['0' + i];
            //if(zzz == null){
                function setPromises(){
                    var deferred1 = $q.defer();
                    var tempCode = genCustId()+i;
                    console.log('KEY --------------------------' + i);
                    console.log('tempCode : '  + tempCode);

                    var tempPolis = {};
                    tempPolis.customerId = tempCode;
                    console.log('temp tertanggung : ', tempPolis);
                    // $timeout(function(){
                    //     $timeout(function(){
                    //       $timeout(function(){
                    //         $timeout(function(){
                    //           $timeout(function(){
                               /*CustomerStorageService.addCustomerStorage($q, tempPolis.customerId, tempPolis).then(function(res){
                                    console.log('RES : ', res);
                                    tempCustList['0'+i] = tempCode;
                                    deferred1.resolve(res);        
                               })*/
                    //            },300);
                    //           },300);
                    //        },300);
                    //     },300);
                    // },300);
                    /*CustomerStorageService.addCustomerStorage($q, tempPolis.customerId, tempPolis).then(function(res){
                        deferred1.resolve(res);
                    });*/
                    // break;

                    /*tempCustList['0'+i] = tempCode;

                    var data = {};
                    data.agentId = $rootScope.agent.code;
                    data.retrieveDate = new Date();
                    data.invocationResult = tempPolis;
                    data.customerId = tempCode;

                    WL.JSONStore.get('CustomerStorage').add(data).then(function () {
                        console.log("Success adding data to jsonstore CustomerStorage", data);
                        deferred1.resolve(tempCustList);
                    }).fail(function (error) {
                        console.log("Failed adding data to jsonstore CustomerStorage");
                        deferred1.reject(error);
                    });

                console.log(tempCustList);
                return deferred1.promise; 
                }
                
                promisesss.push(setPromises());*/
            //}


       // }
        // },300);
        //return $q.all(promisesss);
        // deffer.resolve($q.all(promisesss));
        // console.log($q);
        // return deferred1.promise;
    }

    function setCustomerList(){        
        tempCustList['01'] = null;
        tempCustList['02'] = null;
        tempCustList['03'] = null;
        tempCustList['04'] = null;
        tempCustList['05'] = null;
        tempCustList['06'] = null;
    }

/**    $scope.mainMenu = function() {
        if (!$rootScope.QuotationId || $rootScope.QuotationId === undefined) {
            console.log('back /n QuotationId undefined');
            $rootScope.check = false;
            $rootScope.dataset = [];
            $rootScope.datasetTertanggung = [];
            $rootScope.datasetMandatory = [];
        }
    }    **/

    $scope.searchPekerjaan;
    $scope.clearPekerjaan = function() {
      $scope.searchPekerjaan = '';
    };

    $scope.searchBidang;
    $scope.clearBidang = function() {
      $scope.searchBidang = '';
    };

    $scope.searchPosition;
    $scope.clearPosition = function() {
      $scope.searchPosition = '';
    };
  
})


pruforce.config(function($mdDateLocaleProvider) {
  $mdDateLocaleProvider.formatDate = function(date) {
    return date ? moment(date).format('DD MMMM YYYY') : '';
  };
});