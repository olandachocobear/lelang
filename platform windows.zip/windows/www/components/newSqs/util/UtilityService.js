﻿angular.module('PruForce.services')

	.factory('UtilityService', function () {

	});