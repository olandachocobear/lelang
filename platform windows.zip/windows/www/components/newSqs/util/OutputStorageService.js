﻿angular.module('PruForce.services')

	.factory('OutputStorageService', function ($rootScope) {

		var collection = JsonStoreConfig.OutputStorage;

		function getOutputStorageByKey($q, outputId){
			var deferredAllOut = $q.defer();
			//console.log("Retrieve data from json store " + collection.JSONSTORE_NAME);
			try{
				
				var query = {agentId: $rootScope.agent.code, outputId : outputId};
				var options = {exact: false
					    	   //limit: 100 //returns a maximum of 10 documents
				   	  };
				
				WL.JSONStore.get(collection.JSONSTORE_NAME).find(query, options).then(function(res){
				 	try{
						if(res.length > 0){
							var result =  res[0].json;
							deferredAllOut.resolve(result.invocationResult);
						}		
					} catch(error){
						deferredAllOut.reject(error);
					}						
				}).fail(function(error){
				 	deferredAllOut.reject(error);
				});
			} catch (error) {
				deferredAllOut.reject(error);
			}
			return deferredAllOut.promise;
		}


		function addOutputStorage($q, outputId, param){
			var deferredOneOut = $q.defer();
			var result = {};
			result.retrieveDate = new Date();
			result.agentId = $rootScope.agent.code;
			//clearCollection(collection.JSONSTORE_NAME);
			var data = {};
			data.invocationResult = param;
			data.agentId = result.agentId;
			data.outputId = outputId;
			data.retrieveDate = result.retrieveDate;
			
			var query = {agentId: $rootScope.agent.code, outputId : outputId};
			var options = {exact: false
				    	   //limit: 100 //returns a maximum of 10 documents
			   	  };

			WL.JSONStore.get(collection.JSONSTORE_NAME).find(query, options).then(function(res){
			 	try{
					if(res.length > 0){
						res[0].json.invocationResult = param;

						WL.JSONStore.get(collection.JSONSTORE_NAME).replace(res).then(function () {
							AppsLog.log("Success adding data to jsonstore " + collection.JSONSTORE_NAME);
							deferredOneOut.resolve(data);
						}).fail(function (error) {
							AppsLog.log("Failed adding data to jsonstore " + collection.JSONSTORE_NAME);
							deferredOneOut.reject(error);
						});

					}else{
						WL.JSONStore.get(collection.JSONSTORE_NAME).add(data).then(function () {
							AppsLog.log("Success adding data to jsonstore " + collection.JSONSTORE_NAME);
							deferredOneOut.resolve(data);
						}).fail(function (error) {
							AppsLog.log("Failed adding data to jsonstore " + collection.JSONSTORE_NAME);
							deferredOneOut.reject(error);
						});

					}
					deferredOneOut.resolve(true);
				} catch(error){
					deferredOneOut.reject(error);
				}						
			}).fail(function(error){
			 	deferredOneOut.reject(error);
			});
                        return deferredOneOut.promise;
		}


		function deleteOutputStorageByKey($q, outputId){
			var deferredAllOut = $q.defer();
			//console.log("Retrieve data from json store " + collection.JSONSTORE_NAME);
			try{
				
				var query = {agentId: $rootScope.agent.code, outputId : outputId};
				var options = {exact: false
					    	   //limit: 100 //returns a maximum of 10 documents
				   	  };
				
				WL.JSONStore.get(collection.JSONSTORE_NAME).remove(query, options).then(function(res){
				 	try{
						if(res.length > 0){
							var result =  res[0].json;
							deferredAllOut.resolve(result.invocationResult);
						}		
					} catch(error){
						deferredAllOut.reject(error);
					}						
				}).fail(function(error){
				 	deferredAllOut.reject(error);
				});
			} catch (error) {
				deferredAllOut.reject(error);
			}
			return deferredAllOut.promise;
		}


		return {
			getOutputStorageByKey : getOutputStorageByKey,
			addOutputStorage : addOutputStorage,
			deleteOutputStorageByKey : deleteOutputStorageByKey
		};
	});