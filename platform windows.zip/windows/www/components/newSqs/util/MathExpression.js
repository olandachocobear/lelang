﻿angular.module('PruForce.services')

	.factory('MathExpressionService', function ($rootScope, $filter) {

		function isValidExpression(expression) {
			var result = parseFloat(expression);
			if(result === 'Nan'){
				return false;
			}else{
				return true;
			}
		}

		function getResultExpression(expression, maxunit) {
			var result = eval(expression);
			return result;
		}

		var mymanfaatlist = [];
		var manfaatList;
		function processIlustration(param){
			var response = {};
 			var mapOutputFundList = {};
 			var mapOutputFund = {};
 			var mapOutputFundAlt = {};

 			var start = new Date();
            start = start.getHours() + ":" + start.getMinutes() + ":" + start.getSeconds();
            var end = null;

			
 			var year = 1;
 			var ageCustomer = param.age;
 			mymanfaatlist = sortingRiderTopupMain(param.manfaatList);
 			for(var i = 0; i < param.fundList.length; i++){
	    		param.fundList[i].flagDB = false;
	    		mymanfaatlist.push(param.fundList[i]);
	    	}
	    	for(var i = 0; i < param.fundList.length; i++){
	    		var bantu = {
	    			code : param.fundList[i].code,
	    			name : param.fundList[i].name,
	    			checked : param.fundList[i].checked,
	    			taken : param.fundList[i].taken,
	    			flagSearch : param.fundList[i].flagSearch,
	    			itemInput : param.fundList[i].itemInput,
	    			type : param.fundList[i].type,
	    			flagDB : true
	    		}
	    		mymanfaatlist.push(bantu);
	    	}
 			
 			if(param.manfaat.rencanaPembayaran==0){
 				param.manfaat.rencanaPembayaran = param.alternatifRencanaPembayaran;
 			}

 			while(ageCustomer <= param.alternatifRencanaPembayaran){
 				param.year = year;
 				param.age = ageCustomer;
 				//console.log('---------------------------------');
 				//console.log('Year  = ' + year);
 				//console.log('Umur  = ' + param.age);
 				var result = preparedParameter('proses', param, mapOutputFund, mapOutputFundAlt);
 				//if(year == 17){
 					//console.log(result); 					
 				//}
 				

 				//BLOK JIKA SISA (PREMI - WITHDRAWAL) < (1000000/250)
 				for(var d = 0; d < param.withdrawalList.length; d++){
 					var tmpWithdrawal = param.withdrawalList[d];
 					if(tmpWithdrawal.year == year){
 						var tmpValue;
 						if(param.currCd == 'IDR'){
 							tmpValue = 1000000;
 						}else if(param.currCd == 'USD'){
 							tmpValue = 250;
 						}
 						if(result.MAPCOV2.TOTALCVLOWDISPLAY < tmpValue){
		 					response.status = '2';
							response.content = null;
				 			return response;
		 				}
		 				break;
 					}
 				}

 				//JIKA TERJADI ERROR DALAM PROSES PERHITUNGNGAN
 				if(result.MAPCOVALT2.TOTALCVLOWDISPLAY < 0 && year <= 20){
 					response.status = '1';
					response.content = null;
		 			return response;
 				}

 				mapOutputFund = result.MAPOUTPUTFUND;
 				mapOutputFundAlt = result.MAPOUTPUTFUNDALT;
				var mapFundNLG = result.MAPCOV2;
				var mapFundNLGAlt = result.MAPCOVALT2;
 				var mapOutput = result.MAPOUTPUTFUNDPERTAHUN;
 				mapOutputFundList[year] = {year : year, ageCustomer : ageCustomer, mapOutput : mapOutput, mapFundNLG : mapFundNLG, mapFundNLGAlt : mapFundNLGAlt};

 				year++;
 				ageCustomer++;
 			}
 			end = new Date();
	        end = end.getHours() + ":" + end.getMinutes() + ":" + end.getSeconds();
	        
	        response.status = '0';
			response.content = generateOutput(param, mapOutputFundList);
 			return response;
 		}


 		function getUnappliedPremium(param, flagProcess){
 			param.year = 1;
 			mymanfaatlist = sortingRiderTopupMain(param.manfaatList);
 			var map = preparedParameter('hitung', param, {}, {}, flagProcess);

 			return map;
 		}


		function preparedParameter(type, param, paramMapOutputFund, paramMapOutputFundAlt, flagProcess){
			var mapResult = {};
		    var mapProperties = {};

		    //CLIENT_PLANNING
		    var mapOutputCoverage = {};
		    var mapOutputFund = paramMapOutputFund;
		    //ALTERNATIVE
		    var mapOutputCoverageAlt = {};
		    var mapOutputFundAlt = paramMapOutputFundAlt;

		    //COVERAGE_GROUP
		    var coverageList = [];
		    var coverageGroupList = [];
		    var tmpCoverageGroupList = [];

		    var mapResultCalculateCoverage = {};
		    var mapOutpunFunPerYear = {};
		    
		    var mapFundPerYear = {};

		    var xTerm;
		    

		    var manfaatListCodeSelected = [];		    

		    for(var i = 0; i < mymanfaatlist.length; i++){
		      var itemSelected = mymanfaatlist[i];
		      var ITEM;
		      var fundAllocationValue;

		      
		      if(type != 'proses'){
		      	manfaatListCodeSelected.push(itemSelected.code);
		   	  }

		      //GET FULL DATA FROM JSONStore PUBLISH
		      if(itemSelected.type === 'COVERAGE'){
		      	ITEM = $rootScope.COVERAGE[itemSelected.code];
		      }else if(itemSelected.type === 'FUND'){
		      	ITEM = $rootScope.FUND[itemSelected.code];
		      	ITEM.flagDB = itemSelected.flagDB;
		      }

		      mapProperties = {};	

		      //FOR VALIDASI RULE; TIDAK BISA MEMILIH BEBERAPA COVERAGE DALAM 1 GROUP 
		      mapProperties['PDSELECTEDML'] = 0;
		      mapProperties['PDSELECTEDAL2'] = 0;
			  mapProperties['PDSELECTEDAL3'] = 0;
			  mapProperties['PDSELECTEDAL4'] = 0;
			  mapProperties['PDSELECTEDAL5'] = 0;
			 
			  var pdselectedKey = "";

			  if(itemSelected.tertanggungKey == 2){
				  pdselectedKey = "ML";
			  }else if(itemSelected.tertanggungKey == 3){
				  pdselectedKey = "AL2";
			  }else if(itemSelected.tertanggungKey == 4){
				  pdselectedKey = "AL3";
			  }else if(itemSelected.tertanggungKey == 5){
				  pdselectedKey = "AL4";
			  }else if(itemSelected.tertanggungKey == 6){
				  pdselectedKey = "AL5";
			  }
			  mapProperties['PDSELECTED'+pdselectedKey] = 1;

		      //CUST PREMI PER TAHUN
		      mapProperties['CUSTPREMI'] = param.manfaat.premi;
		      
		      
		   	  //CUST TOPUP PER TAHUN
		   	  for(var d = 0; d < param.topupList.length; d++){
				var tmpTopup = param.topupList[d];
				if(tmpTopup.year == param.year){
					mapProperties['CUSTTOPUP'] = tmpTopup.amount;
					break;
				}
			  }
			  //CUST WITHDRAWAL PER TAHUN
	   	   	  for(var d = 0; d < param.withdrawalList.length; d++){
				var tmpWithdrawal = param.withdrawalList[d];
				if(tmpWithdrawal.year == param.year){
					mapProperties['CUSTWITHDRAW'] = tmpWithdrawal.amount;
					break;
				}
			  }		   	  	
		   	  

		      //CUSTSA
		      mapProperties['CUSTSA'] = param.custSA;


		      //CUSTSAVER
		      mapProperties['CUSTSAVER'] = param.custSaver;	
		      
		      
		      //FROM ITEM INPUT
		      var itemInputList = itemSelected.itemInput;
		      for(var j = 0; j < itemInputList.length; j++){
		        mapProperties[itemInputList[j].key] = itemInputList[j].inputValue;
		        if(itemInputList[j].key === 'PDALLO'){
		        	fundAllocationValue = itemInputList[j].inputValue;
		        	break;
		        }
		      }

			  //AGE
		      mapProperties['CUSTAGE'] = param.age;
		      mapProperties['CUSTAGEML'] = param.age;

		      //MONTH AGE 
		      mapProperties['CUSTAGEMONTH'] = param.custAgeMonth;

		      //DAY AGE
		      mapProperties['CUSTAGEDAY'] = param.custAgeDay;
		      
		      //ADMIN FEE
		      mapProperties['CHARGE'] = param.adminFee;
		      
		      mapProperties['CUSTOCCUPATIONCLASS'] = param.clazz;

		      //CUST INCOME
			  mapProperties['CUSTINCOME'] = param.custIncome;

			  //CUSTPREMIPLAN -- Ian PJ Coding		      
			  mapProperties['CUSTPREMIPLAN'] = param.manfaat.rencanaPembayaran;		      
		      
		      //ALLOCATION AND RATE JUST FOR COVERAGE NOT FUND
		      if(itemSelected.type === 'COVERAGE'){
				    //ALLOCATION VALUE
				    var allocationValue = ITEM.ALLOCATION_VALUE[param.year];
				    mapProperties['ALLOVALUE'] = allocationValue == null ? 0 : allocationValue;
				  
				    //TOPUP_ALLOCATION VALUE
				    var topupAllocationValue = ITEM.TOPUPALLOCATION_VALUE[param.year];
				    mapProperties['TOPUPALLOVALUE'] = topupAllocationValue == null ? 0 : topupAllocationValue;
				  
				    //FROM RATE
				    var tempListRateCd = ITEM.CHANNEL[param.channelCode];
				    mapProperties['CUSTAGE'+'0'+(itemSelected.tertanggungKey-1)] = itemSelected.tertanggungAge;
				    ITEM.keyTertanggungAge = 'CUSTAGE'+'0'+(itemSelected.tertanggungKey-1);
				    
				    if(tempListRateCd){
				      	for(var j = 0; j < tempListRateCd.length; j++){
				          	var tertanggungAge = (itemSelected.tertanggungAge + (param.year - 1));

				          	//ADD BENEFIT TERM
				          	var mainLifeAge;
				          	if(param.year != undefined){
				          		mainLifeAge = (param.age + (param.year-1)); 
				          	}else{
				          		mainLifeAge = param.age;
				          	}

				          	var benefitTerm;
				          	if(mapProperties['PDTERM'] > 0){
								benefitTerm = (mapProperties['PDTERM'] - mainLifeAge);
							}

							var tmpRate = getRateVal(tempListRateCd[j], param.age, tertanggungAge, param.gender, param.smokerStatus, param.clazz, mapProperties['PDTERM'], mapProperties['PDPLAN'], benefitTerm)
				          	if(tmpRate){
					          	mapProperties[tmpRate.rate_type_cd] = tmpRate.value;
				          	}
				    	}
			      	}
		  	  }
		  	  

		  	  //PROPERTIES FOR FUND
		  	  if(itemSelected.type === 'FUND'){
		  	  	  var lowRate = ITEM.lowRate/100;
		  	  	  var mediumRate = ITEM.mediumRate/100;
		  	  	  var highRate = ITEM.highRate/100;

				  mapProperties['LOWRATE'] = lowRate;
			      mapProperties['MEDRATE'] = mediumRate;
			      mapProperties['HIGHRATE'] = highRate;
			  }

			  
			  //BATAS TERM, IF ANY
			  var flag = param.year <= param.manfaat.rencanaPembayaran ? true : false;
			  
			  //GET RESULT FORMULA
			  var term = getTerm(itemSelected);

			  if(flagProcess == 'flagHitung'){
			  	mapFundPerYear = mapOutpunFunPerYear[itemSelected.code];
		      	mapResult = getResultFormula(itemSelected, ITEM, mapProperties, mapResult, mapFundPerYear, mapOutputCoverage, mapOutputCoverageAlt, mapOutputFund, mapOutputFundAlt, param.year, flag, type);
	      		mapOutputCoverage = mapResult.MAPOUTPUTCOVERAGE;
	      		mapOutputFund = mapResult.MAPOUTPUTFUND;
	      		mapOutputCoverageAlt = mapResult.MAPOUTPUTCOVERAGEALT;
	      		mapOutputFundAlt = mapResult.MAPOUTPUTFUNDALT;
	      	  }else{
	      	  	if(term){
				    if(param.age <= term){
				      	mapFundPerYear = mapOutpunFunPerYear[itemSelected.code];
			      		mapResult = getResultFormula(itemSelected, ITEM, mapProperties, mapResult, mapFundPerYear, mapOutputCoverage, mapOutputCoverageAlt, mapOutputFund, mapOutputFundAlt, param.year, flag, type);
			      		mapOutputCoverage = mapResult.MAPOUTPUTCOVERAGE;
			      		mapOutputFund = mapResult.MAPOUTPUTFUND;
			      		mapOutputCoverageAlt = mapResult.MAPOUTPUTCOVERAGEALT;
			      		mapOutputFundAlt = mapResult.MAPOUTPUTFUNDALT;
			        }
		      	}else{
					mapFundPerYear = mapOutpunFunPerYear[itemSelected.code];
		      		mapResult = getResultFormula(itemSelected, ITEM, mapProperties, mapResult, mapFundPerYear, mapOutputCoverage, mapOutputCoverageAlt, mapOutputFund, mapOutputFundAlt, param.year, flag, type);
	      			mapOutputCoverage = mapResult.MAPOUTPUTCOVERAGE;
	      			mapOutputFund = mapResult.MAPOUTPUTFUND;
	      			mapOutputCoverageAlt = mapResult.MAPOUTPUTCOVERAGEALT;
	      			mapOutputFundAlt = mapResult.MAPOUTPUTFUNDALT;
		        }
	      	  }		  


		      mapResultCalculateCoverage[itemSelected.code + '|' + itemSelected.tertanggungCustomerId] = {};
		      mapResultCalculateCoverage[itemSelected.code + '|' + itemSelected.tertanggungCustomerId].riderPremium = 0;
		      mapResultCalculateCoverage[itemSelected.code + '|' + itemSelected.tertanggungCustomerId].chargeRider = 0;
		      mapResultCalculateCoverage[itemSelected.code + '|' + itemSelected.tertanggungCustomerId].chargeInsurance = 0;
		      if(mapResult.riderPremium){
		      		mapResultCalculateCoverage[itemSelected.code + '|' + itemSelected.tertanggungCustomerId].riderPremium = mapResult.riderPremium;
		      }
		      if(mapResult['CHARGERIDER']){
		      		mapResultCalculateCoverage[itemSelected.code + '|' + itemSelected.tertanggungCustomerId].chargeRider = mapResult['CHARGERIDER'];	      				
		      }
		      if(mapResult['CHARGEINSURANCE']){
		      		mapResultCalculateCoverage[itemSelected.code + '|' + itemSelected.tertanggungCustomerId].chargeInsurance = mapResult['CHARGEINSURANCE'];
		      }


		      if(itemSelected.type === 'FUND'){
				mapOutpunFunPerYear[itemSelected.code] = mapResult.MAPOUTPUTFUNDPERTAHUN;
				mapOutpunFunPerYear[itemSelected.code].ALLOCATION = fundAllocationValue;
			  }

		      //GENERATE NEW FORMAT COVERAGE
		      coverageList.push({
		      		itemCd : ITEM.coverageCode,
		      		keyTertanggungAge : ITEM.keyTertanggungAge,
		      		itemType : 'COVERAGE',
		      		properties : mapProperties,
		      		mapOutputCoverage : mapOutputCoverage,
		      		mapOutputFund : mapOutputFund 
		      	});

		      //GENERATE TEMP BEFORE CHANGE FORMAT COVERAGE_GROUP
		      var tmpCoverageGroup = {
		      		coverageCd : ITEM.coverageCode,
		      		keyTertanggungAge : ITEM.keyTertanggungAge,
		      		coverageGroupCdList : ITEM.COVERAGE_GROUP,
		      		properties : mapProperties,
		      		mapOutputCoverage : mapOutputCoverage,
		      		mapOutputFund : mapOutputFund
		      	};
		      tmpCoverageGroupList.push(tmpCoverageGroup);
			  
			  mapFundPerYear = {};
		    }

		    mapResult.MAPRESULTCALCULATE = mapResultCalculateCoverage;
		    mapResult.MAPOUTPUTFUNDPERTAHUN = mapOutpunFunPerYear;
			mapResult.MAPCOV2 = mapOutputCoverage;
			mapResult.MAPCOVALT2 = mapOutputCoverageAlt;
		    if(type === 'hitung'){
			    //GENERATE MAP COVERAGE -> COVERAGE_GROUP
			    coverageGroupList = generateCoverageGroup(tmpCoverageGroupList);
			    
			    //GET RULE VALIDATION COVERAGE_GROUP
			    mapResult.rule = getRuleValidation(mapOutputCoverage, coverageList.concat(coverageGroupList), mymanfaatlist);
		    }

		    if(type != 'proses'){
		    	mapResult.manfaatList = manfaatListCodeSelected;
		    }
		    
		    return mapResult;
		}

		function getTerm(itemSelected){
			var t;
			for(var h = 0; h < itemSelected.itemInput.length; h++){
				var is = itemSelected.itemInput[h];
				if(is.key){
					if(is.key == 'PDTERM'){
						t = is.inputValue;
						break;
					}
				}
			}
			return t;
		}

		function getRateVal(rate_cd, age_life_1, age_life_2, gender, smoker_status, clazz, term, plan, benefitTerm){
			var obj;

			var rate = $rootScope.RATE;
			for(var i = 0; i < rate.length; i++){
				if((!rate_cd || rate[i].rate_cd == ' ' || rate[i].rate_cd == rate_cd) &&
						(!age_life_1 || rate[i].age_life_1 == ' ' || rate[i].age_life_1 == age_life_1) &&
							(!age_life_2 || rate[i].age_life_2 == ' ' || rate[i].age_life_2 == age_life_2 ) &&
								(!gender || rate[i].gender == ' ' || rate[i].gender == gender) &&
									(!smoker_status || rate[i].smoker_status == ' ' || rate[i].smoker_status == smoker_status) &&
										(!clazz || rate[i].clazz == ' ' || rate[i].clazz == clazz) &&
											(!term || rate[i].term == ' ' || rate[i].term == term ) &&
												(!plan || rate[i].plan == ' ' || rate[i].plan == plan) &&
													(!benefitTerm || rate[i].benefitTerm == ' ' || rate[i].benefitTerm == benefitTerm )){
					obj = rate[i];
					break;
				}
			}
			/*if(rate_cd == 'RTH1TR' || rate_cd == 'CHH1TR'){
				////console.log(rate_cd);
				////console.log(age_life_1);
				////console.log(age_life_2);
				////console.log(gender);
				////console.log(smoker_status);
				////console.log(clazz);
				////console.log(term);
				////console.log(plan);
			}*/
			return obj;
		}

		function getFactorFromAnuityByMonth(month, annuityList){
			for(var v = 0; v < annuityList.length; v++){
				if(annuityList[v].month == month){
					return annuityList[v].factor;
					break;
				}
			}
		}

		function getResultFormula(itemSelected, ITEM, map, mapResult, mapFundPerYear, mapOutputCoverage, mapOutputCoverageAlt, mapOutputFund, mapOutputFundAlt, year, flag, buttonType){
			var mapResultFormula = mapResult;
		    var tempMapFormulaList = ITEM.FORMULA;
		    var mapResultPerYear = {};
		    if(ITEM.flagDB == true){
				mapResultPerYear = mapFundPerYear;
			}
		    
		    for(var j = 0; j < tempMapFormulaList.length; j++){
		      	var tmpFormula = tempMapFormulaList[j];
		      	var stringFormula = '';
		      	var stringFormulaAlt = '';
		      	var stringFormulaOri = '';
		      	var result = 0;
		      	var resultAlternativeAsumtion = 0;
		      	var value;

			    var formula = $rootScope.FORMULA[tmpFormula.formulaCd];
			    
			    if(formula){
		      	  	var isProcess = false;
		          	if(ITEM.flagDB == true && (formula.formulaTypeCd.indexOf('TOTALCVDB') !== -1 || formula.formulaTypeCd.indexOf('TOTALCVLOWDISPLAY') !== -1 || formula.formulaTypeCd.indexOf('TOTALCVMEDDISPLAY') !== -1 || formula.formulaTypeCd.indexOf('TOTALCVHIGHDISPLAY') !== -1)){
			          	isProcess = true;
			      	}else if(ITEM.flagDB == false && (formula.formulaTypeCd.indexOf('TOTALCVDB') === -1 && formula.formulaTypeCd.indexOf('TOTALCVLOWDISPLAY') === -1 && formula.formulaTypeCd.indexOf('TOTALCVMEDDISPLAY') === -1 && formula.formulaTypeCd.indexOf('TOTALCVHIGHDISPLAY') === -1)){
				      	isProcess = true;
				    }else if(itemSelected.type === 'COVERAGE'){
				      	isProcess = true;
				    }

				    if(isProcess){
				      	var tempFormulaElementList = formula.FORMULA_ELEMENT;

					    for(var k = 0; k < tempFormulaElementList.length; k++){
					        var fe = tempFormulaElementList[k];

					        stringFormulaOri += fe.value;

					        if(fe.type.toLowerCase().trim() === "coverage" 
					        	|| fe.type.toLowerCase().trim() === "customer" 
					        	|| fe.type.toLowerCase().trim() === "rate" 
					        	|| fe.type.toLowerCase().trim() === "fund"
					        	|| fe.type.toLowerCase().trim() === "product"
					        	|| fe.type.toLowerCase().trim() === "allocation"){

						        if(fe.value.toUpperCase() === 'CUSTINCOME'){
						          	stringFormula += "\'" + map[fe.value] +"\'";  
						          	stringFormulaAlt += "\'" + map[fe.value] +"\'";
						        }else if(fe.value.toUpperCase() === 'PDPLAN'){
						          	stringFormula += map[fe.value] ? "\'" + map[fe.value] +"\'" : '0.0';
						          	stringFormulaAlt += map[fe.value] ? "\'" + map[fe.value] +"\'" : '0.0';
						        }else if(fe.value.toUpperCase() === 'PDALLO'){
						          	stringFormula += map[fe.value] ? map[fe.value]/100 : '0.0';
						          	stringFormulaAlt += map[fe.value] ? map[fe.value]/100 : '0.0';       
						        }else if(fe.value.toUpperCase() === 'YEAR'){
						          	stringFormula += year;
						          	stringFormulaAlt += year;
						        }else if(fe.value.toUpperCase() === 'RTSARANNUITY'){
						        	var factor = getFactorFromAnuityByMonth(map['CUSTAGEMONTH'], ITEM.ANNUITY);
						          	stringFormula += factor;
						          	stringFormulaAlt += factor;
						        }else if(ITEM.flagDB == true && fe.value.indexOf('TOTALCV') !== -1){
						          	stringFormula += mapOutputCoverage[fe.value] ? mapOutputCoverage[fe.value] : '0.0';
						          	stringFormulaAlt += mapOutputCoverageAlt[fe.value] ? mapOutputCoverageAlt[fe.value] : '0.0';
						        }else{
						          	stringFormula += map[fe.value] ? map[fe.value] : '0.0';
						          	stringFormulaAlt += map[fe.value] ? map[fe.value] : '0.0';
						        }

					        }else if(fe.type.toLowerCase().trim() === "load"){
					          stringFormula += itemSelected.loadMap[fe.value] ? itemSelected.loadMap[fe.value] : '0.0';
					          stringFormulaAlt += itemSelected.loadMap[fe.value] ? itemSelected.loadMap[fe.value] : '0.0';
					        }else if(fe.type.toLowerCase().trim() === "formula"){
					          stringFormula += mapOutputCoverage[fe.value] ? mapOutputCoverage[fe.value] : '0.0';
					          stringFormulaAlt += mapOutputCoverageAlt[fe.value] ? mapOutputCoverageAlt[fe.value] : '0.0';
					        }else if(fe.type.toLowerCase().trim() === "formulafund"){
					          stringFormula += getValueFund(ITEM.code, fe.value, mapOutputFund);
					          stringFormulaAlt += getValueFund(ITEM.code, fe.value, mapOutputFundAlt);
					        }else if(fe.type.toLowerCase().trim() === "string"){
					          stringFormula += "\'"+fe.value+"\'";
					          stringFormulaAlt += "\'"+fe.value+"\'";
					        }else{
					          stringFormula += fe.value;
					          stringFormulaAlt += fe.value;
					        }
					    }


				      //  	if(tmpFormula.output == 'TOTALCVLOW' || tmpFormula.output == 'TOTALCVLOWDISPLAY' || tmpFormula.output == 'TOTALCVLOWFUNDDSPLY' ||
					  			// tmpFormula.formulaTypeCd == 'TOTALCVLOW' || tmpFormula.formulaTypeCd == 'TOTALCVLOWDISPLAY' || tmpFormula.formulaTypeCd == 'TOTALCVLOWFUNDDSPLY'){
					  		//console.log('----------------------------------------------------');
					  		//console.log('Item Code  		: ' + 'FUND' == tmpFormula.itemType.toUpperCase() ? ITEM.code : ITEM.code);
				        	//console.log('Formula Codenya    : ' + tmpFormula.formulaCd);
				        	//console.log('Formula Aslinyanya : ' + stringFormulaOri);
				      		//console.log('Formulanya			: ' + stringFormula);			      		
					  	// }					  	
				       	 
					   	var maxunit;

					    if(isValidExpression(stringFormula)){
					    	if(formula.formulaTypeCd == 'MAXUNIT'){
					    		maxunit = 'MAXUNIT';
					    	}
					      	result = getResultExpression(stringFormula, maxunit);
					      	resultAlternativeAsumtion = getResultExpression(stringFormulaAlt, maxunit);

					      	if(!flag && 'ALLOCATEDPREMIUM' == formula.formulaTypeCd){
					        	result = 0;
					      	}
					    
					    	// if(tmpFormula.output == 'TOTALCVLOW' || tmpFormula.output == 'TOTALCVLOWDISPLAY' || tmpFormula.output == 'TOTALCVLOWFUNDDSPLY' ||
					  			// tmpFormula.formulaTypeCd == 'TOTALCVLOW' || tmpFormula.formulaTypeCd == 'TOTALCVLOWDISPLAY' || tmpFormula.formulaTypeCd == 'TOTALCVLOWFUNDDSPLY'){
				       			//console.log('Hasilnya			:' + result);
					      		//console.log('Formula Type		:' + formula.formulaTypeCd);
					      		//console.log('Outputnya			:' + tmpFormula.output);	
				       		// }	 
					        
					        if(tmpFormula.output){
					        	if('COVERAGE' === tmpFormula.itemType.toUpperCase()){
					        		//CLIENT_PLANNING
					        	    value = mapOutputCoverage[tmpFormula.output];
							        if(value){
							            if("ADMINCHARGE" === mapOutputCoverage[tmpFormula.output]){
							              mapOutputCoverage[tmpFormula.output] = value;
							            }else{
							              value = (value + result) ;
							              mapOutputCoverage[tmpFormula.output] = value;
							            }
						            }else{
						            	mapOutputCoverage[tmpFormula.output] = result;
						        	}

						        	//ALTERNATIVE
						        	value = mapOutputCoverageAlt[tmpFormula.output];
							        if(value){
							            if("ADMINCHARGE" === mapOutputCoverageAlt[tmpFormula.output]){
							              mapOutputCoverageAlt[tmpFormula.output] = value;
							            }else{
							              value = (value + resultAlternativeAsumtion) ;
							              mapOutputCoverageAlt[tmpFormula.output] = value;
							            }
						            }else{
						            	mapOutputCoverageAlt[tmpFormula.output] = resultAlternativeAsumtion;
						        	}


					      			//SET NEW KEY PDPREMI IF FORMULATYPE = 'RIDERPREMIUM' / BIAYA ASURANSI PERTAHUN
							        if('RIDERPREMIUM' == formula.formulaTypeCd){
								        map["PDPREMI"] = result;
								        mapResultFormula.riderPremium = result;
							        }

							        //CHARGE / BIAYA ANGSURAN BULANAN
							        if('CHARGERIDER' == formula.formulaTypeCd || 'CHARGEINSURANCE' == formula.formulaTypeCd){
							          	mapResultFormula[formula.formulaTypeCd] = (result/12);
							        }


					        	}else if('FUND' === tmpFormula.itemType.toUpperCase()){
					        		var itemCd = ITEM.code;

					        		value = mapOutputCoverage[formula.formulaTypeCd];
							        if(value){
							            value = (value + result) ;
							            mapOutputCoverage[formula.formulaTypeCd] = value;						            
						            }else{
						            	mapOutputCoverage[formula.formulaTypeCd] = result;
						        	}

						        	value = mapOutputCoverageAlt[formula.formulaTypeCd];
							        if(value){
							            value = (value + resultAlternativeAsumtion) ;
							            mapOutputCoverageAlt[formula.formulaTypeCd] = value;						            
						            }else{
						            	mapOutputCoverageAlt[formula.formulaTypeCd] = resultAlternativeAsumtion;
						        	}			        				
				        			

					        		//CLIENT PLANNING
					        		value = getValueFund(itemCd, output, mapOutputFund);
						            var output =  mapOutputFund[itemCd];
					        		
					        		if(value === '0.0'){
					        			var  tmp = {};
					        			tmp[tmpFormula.output] = result;

						            	if(output){
							                output[tmpFormula.output] = result;
							                mapOutputFund[itemCd] = output;
						            	}else{
						            		mapOutputFund[itemCd] = tmp;
						            	}
						            }else{
						                output[tmpFormula.output] = result;				        		
						                mapOutputFund[itemCd] = output;
						        	}

						        	//ALTERNATIVE
						        	value = getValueFund(itemCd, output, mapOutputFundAlt);
						            var output =  mapOutputFundAlt[itemCd];
					        		
					        		if(value === '0.0'){
					        			var  tmp = {};
					        			tmp[tmpFormula.output] = resultAlternativeAsumtion;

						            	if(output){
							                output[tmpFormula.output] = resultAlternativeAsumtion;
							                mapOutputFundAlt[itemCd] = output;
						            	}else{
						            		mapOutputFundAlt[itemCd] = tmp;
						            	}
						            }else{
						                output[tmpFormula.output] = resultAlternativeAsumtion;				        		
						                mapOutputFundAlt[itemCd] = output;
						        	}
					       
					        		//ASUMSTION FUND 
					        		if(tmpFormula.output == 'CVTOTALHIGHDISPLAY' || tmpFormula.output == 'CVTOTALMEDDISPLAY' || tmpFormula.output == 'CVTOTALLOWDISPLAY'){
					      				mapResultPerYear[tmpFormula.output] = result;
										mapResultPerYear['ALT'+tmpFormula.output] = resultAlternativeAsumtion;
					      			}
						   		}
						    }
				    	}
				    }
				    if('hitung' === buttonType){
				    	if('SA_BASIC' === tmpFormula.output.toUpperCase()){
					  	  	mapResultFormula['SA_BASIC'] = result;
				  	    }
					    if('SABASIC' === tmpFormula.output.toUpperCase()){
					  	  	mapResultFormula['SABASIC'] = result;
				  	    }
					    if('OUT_SA_U1ZR' === tmpFormula.output.toUpperCase()){
					  	  	mapResultFormula['OUT_SA_U1ZR'] = result;
				  	    }
					    if('OUT_DETERMINED_FACULTATIVE_U1ZR' === tmpFormula.output.toUpperCase()){
					  	  	mapResultFormula['OUT_DETERMINED_FACULTATIVE_U1ZR'] = result;
				  	    }
					    if('OUT_TOT_ACC_U1ZR' === tmpFormula.output.toUpperCase()){
					  	  	mapResultFormula['OUT_TOT_ACC_U1ZR'] = result;
				  	    }
						if('OUT_SA_I1DR' === tmpFormula.output.toUpperCase()){
					  	  	mapResultFormula['OUT_SA_I1DR'] = result;
				  	    } 
						if('OUT_FACULTATIVE_U1ZR' === tmpFormula.output.toUpperCase()){
					  	  	mapResultFormula['OUT_FACULTATIVE_U1ZR'] = result;
				  	    } 
						if('OUT_MED_U1ZR' === tmpFormula.output.toUpperCase()){
					  	  	mapResultFormula['OUT_MED_U1ZR'] = result;
				  	    }
						if("TOTALDEATHBENEFIT" === tmpFormula.output.toUpperCase()){
					  	  	mapResultFormula['TOTALDEATHBENEFIT'] = result;
				  	    }
				      	if('MINSA' === formula.formulaTypeCd.toUpperCase()){
				      		mapResultFormula['MINSA'] = result;
				      	}
				      	if('MAXSA' === formula.formulaTypeCd.toUpperCase()){
				      		mapResultFormula['MAXSA'] = result;
				      	}
				      	if('UNAPPLIED' === formula.formulaTypeCd.toUpperCase()){
				      		mapResultFormula['UNAPPLIED'] = result;
				      	}
				      	if('HSPLAN' === formula.formulaTypeCd.toUpperCase()){
				      		mapResultFormula['HSPLAN'] = result;
				      	}
				    }
				   	
			      	mapResultFormula['MAPOUTPUTCOVERAGE'] = mapOutputCoverage;
			      	mapResultFormula['MAPOUTPUTFUND'] = mapOutputFund;
			      	mapResultFormula['MAPOUTPUTCOVERAGEALT'] = mapOutputCoverageAlt;
			      	mapResultFormula['MAPOUTPUTFUNDALT'] = mapOutputFundAlt;
				}   
		    }
		    
			mapResultFormula['MAPOUTPUTFUNDPERTAHUN'] = mapResultPerYear;
			
		    return mapResultFormula;
		}

		function generateOutput(param, mapOutput){
 			var newOutput = {};
 			newOutput.FUNDMAP = {};

 			var divider = 1000;

 			if(param.currCd == 'USD'){
 				divider = 1; 				
 			}

 			var tmpLowClient;
			var tmpMedClient;
			var tmpHighClient;
			var tmpLowAlt;
			var tmpMedAlt;
			var tmpHighAlt;

 			for(var year in mapOutput){
 				var mapItemCd = mapOutput[year];
 				//console.log('mapItemCd == ',mapItemCd);
 				var tmpListOutput = [];

 				for(var itemCd in mapItemCd.mapOutput){
 					var mapOut = mapItemCd.mapOutput[itemCd];
 					////console.log('fund nya :',mapOut);
		            //---------------------------------------------------------------------------------------------------------

		            if(mapOut.ALLOCATION != '0'){
		            	//fund dihitung hanya yang ada alokasinya
						var tmpPremi = (((parseInt(mapOut.ALLOCATION) * param.manfaat.totalPremi)/100)/divider);

						//console.log("mapOut[CVTOTALLOWDISPLAY] ==== ", mapOut['CVTOTALLOWDISPLAY']);

			            tmpLowClient = mapOut['CVTOTALLOWDISPLAY'] ?  (mapOut['CVTOTALLOWDISPLAY']/divider) : 0;
						tmpMedClient = mapOut['CVTOTALMEDDISPLAY'] ? (mapOut['CVTOTALMEDDISPLAY']/divider)  : 0;
						tmpHighClient = mapOut['CVTOTALHIGHDISPLAY'] ? (mapOut['CVTOTALHIGHDISPLAY']/divider) : 0;
						tmpLowAlt = mapOut['ALTCVTOTALLOWDISPLAY'] ? (mapOut['ALTCVTOTALLOWDISPLAY']/divider) : 0;
						tmpMedAlt = mapOut['ALTCVTOTALMEDDISPLAY'] ? (mapOut['ALTCVTOTALMEDDISPLAY']/divider) : 0;
						tmpHighAlt = mapOut['ALTCVTOTALHIGHDISPLAY'] ? (mapOut['ALTCVTOTALHIGHDISPLAY']/divider) : 0;

						//console.log('tmpLowClient atas == ',tmpLowClient);

						if(param.currCd == 'IDR'){
							tmpLowClient = Math.round(tmpLowClient);
							tmpMedClient = Math.round(tmpMedClient);
							tmpHighClient = Math.round(tmpHighClient);
							tmpLowAlt = Math.round(tmpLowAlt);
							tmpMedAlt = Math.round(tmpMedAlt);
							tmpHighAlt = Math.round(tmpHighAlt);

							//console.log('tmpLowClient IDR == ',tmpLowClient);
						}

			            var objList = {
	 							year : (year).toString(),
	 							customerAge : (mapItemCd.ageCustomer).toString(),
	 							premiClient : parseInt(year) <= parseInt(param.rencanaPembayaran) ? (tmpPremi).toString() : '',
	 							lowClient : tmpLowClient,
	 							medClient : tmpMedClient,
	 							highClient : tmpHighClient,
	 							premiAlt : (tmpPremi),
	 							lowAlt : tmpLowAlt,
	 							medAlt : tmpMedAlt,
	 							highAlt : tmpHighAlt
	 						};
						
	 					//console.log('lowClient ',objList.lowClient);
			            tmpListOutput = [];
			            tmpListOutput = newOutput.FUNDMAP[itemCd];
			            if(tmpListOutput){
			            	tmpListOutput.push(objList);
	 						newOutput.FUNDMAP[itemCd] = tmpListOutput;
			            }else{
			            	tmpListOutput = [];
			            	tmpListOutput.push(objList);
			            	newOutput.FUNDMAP[itemCd] = tmpListOutput;
			            }		            	
		            }


 				}

				var mapFundNLG = mapItemCd.mapFundNLG;
				var mapFundNLGAlt = mapItemCd.mapFundNLGAlt;
 				//ASUMTION CLIENT TOTAL FUND
 				tmpLowClient = mapFundNLG['TOTALCVLOWDISPLAY']/divider;
				tmpMedClient = mapFundNLG['TOTALCVMEDDISPLAY']/divider;
				tmpHighClient = mapFundNLG['TOTALCVHIGHDISPLAY']/divider
				tmpLowAlt = mapFundNLGAlt['TOTALCVLOWDISPLAY']/divider;
				tmpMedAlt = mapFundNLGAlt['TOTALCVMEDDISPLAY']/divider;
				tmpHighAlt = mapFundNLGAlt['TOTALCVHIGHDISPLAY']/divider;
 				/*tmpLowClient = mapFundNLG['TOTALCVLOWFUNDDSPLY']/divider;
				tmpMedClient = mapFundNLG['TOTALCVMEDFUNDDSPLY']/divider;
				tmpHighClient = mapFundNLG['TOTALCVHIGHFUNDDSPLY']/divider
				tmpLowAlt = mapFundNLGAlt['TOTALCVLOWFUNDDSPLY']/divider;
				tmpMedAlt = mapFundNLGAlt['TOTALCVMEDFUNDDSPLY']/divider;
				tmpHighAlt = mapFundNLGAlt['TOTALCVHIGHFUNDDSPLY']/divider;*/

				if(param.currCd == 'IDR'){
					tmpLowClient = Math.round(tmpLowClient);
					tmpMedClient = Math.round(tmpMedClient);
					tmpHighClient = Math.round(tmpHighClient);
					tmpLowAlt = Math.round(tmpLowAlt);
					tmpMedAlt = Math.round(tmpMedAlt);
					tmpHighAlt = Math.round(tmpHighAlt);
				}

 				var objGabFund = {
	 					year : (year).toString(),
						customerAge : (mapItemCd.ageCustomer).toString(),
						premiClient : parseInt(year) <= parseInt(param.rencanaPembayaran) ? ((param.manfaat.totalPremi)/divider).toString() : '',
						lowClient : tmpLowClient.toString(),
						medClient : tmpMedClient.toString(),
						highClient : tmpHighClient.toString(),
						premiAlt : ((param.manfaat.totalPremi)/divider).toString(),
						lowAlt : tmpLowAlt.toString(),
						medAlt : tmpMedAlt.toString(),
						highAlt : tmpHighAlt.toString()
	 				};

	 			tmpListOutput = [];
	 			tmpListOutput = newOutput['FUNDBENEFIT'];
 				if(tmpListOutput){
 					tmpListOutput.push(objGabFund);
					newOutput['FUNDBENEFIT'] = tmpListOutput;
 				}else{
 					tmpListOutput = [];
 					tmpListOutput.push(objGabFund);
	 				newOutput['FUNDBENEFIT'] = tmpListOutput;
 				}

 				//ASUMTION CLIENT TOTAL DEATH BENEFIT
 				tmpLowClient = mapFundNLG['TOTALCVDBLOWDISPLAY']/divider;
				tmpMedClient = mapFundNLG['TOTALCVDBMEDDISPLAY']/divider;
				tmpHighClient = mapFundNLG['TOTALCVDBHIGHDISPLAY']/divider;
				tmpLowAlt = mapFundNLGAlt['TOTALCVDBLOWDISPLAY']/divider;
				tmpMedAlt = mapFundNLGAlt['TOTALCVDBMEDDISPLAY']/divider;
				tmpHighAlt = mapFundNLGAlt['TOTALCVDBHIGHDISPLAY']/divider;

				if(param.currCd == 'IDR'){
					tmpLowClient = Math.round(tmpLowClient);
					tmpMedClient = Math.round(tmpMedClient);
					tmpHighClient = Math.round(tmpHighClient);
					tmpLowAlt = Math.round(tmpLowAlt);
					tmpMedAlt = Math.round(tmpMedAlt);
					tmpHighAlt = Math.round(tmpHighAlt);
				}
 				var objGabDeath = {
	 					year : (year).toString(),
						customerAge : (mapItemCd.ageCustomer).toString(),
						premiClient : parseInt(year) <= parseInt(param.rencanaPembayaran) ? ((param.manfaat.totalPremi)/divider).toString() : '',
						lowClient : tmpLowClient.toString(),
						medClient : tmpMedClient.toString(),
						highClient : tmpHighClient.toString(),
						premiAlt : ((param.manfaat.totalPremi)/divider).toString(),
						lowAlt : tmpLowAlt.toString(),
						medAlt : tmpMedAlt.toString(),
						highAlt : tmpHighAlt.toString()
	 				};
	 			tmpListOutput = [];
	 			tmpListOutput = newOutput['DEATHBENEFIT'];
 				if(tmpListOutput){
 					tmpListOutput.push(objGabDeath);
					newOutput['DEATHBENEFIT'] = tmpListOutput;
 				}else{
 					tmpListOutput = [];
 					tmpListOutput.push(objGabDeath);
	 				newOutput['DEATHBENEFIT'] = tmpListOutput;
 				}
 			}

 			return newOutput;
 		}

		function getRuleValidation(mapOutputCoverage,itemList, manfaatList){
		  	var ruleList = [];		 	
		  	var keyTertanggungAge;
		  	for(var i = 0; i < itemList.length; i++){
		  		//console.log('aaa',itemList[i])
		  		var itemRuleList = [];
		  		if(itemList[i].itemType === 'COVERAGE_GROUP' || itemList[i].itemType === 'Coverage Group'){
		  			itemRuleList = $rootScope.COVERAGE_GROUP[itemList[i].itemCd].RULE;
		  			//console.log('item code 					: ' + itemList[i].itemCd);
		  			//console.log('RUle 						: ',itemRuleList);
		  		}else{
		  			itemRuleList = $rootScope.COVERAGE[itemList[i].itemCd].RULE;
		  		}
		  		//console.log('isi dari ItemRule list =============== ',itemRuleList);
  				for(var j = 0; j < itemRuleList.length; j++){
  					var itemRule = itemRuleList[j];
  					keyTertanggungAge = itemList[i].keyTertanggungAge;
  					//console.log('-----------------------------------------------------------------------');
  					//console.log(itemRule);
		  			var tmpRule = $rootScope.RULE[itemRule.ruleCd];
  					//if (tmpRule.code != 'MINWITHDRAWAL') {
  					if(tmpRule){
  						
  						tmpRule.keyTertanggungAge = keyTertanggungAge;
  						// console.log('loop count ===================== ');
  						// console.log('isi DARI tmpRule ===================== ',tmpRule);
  						// tmpRule.keyType
  						// tmpRule.key
  						var mapProperties = itemList[i].properties;
  						//console.log('-------------------- mapProperties isine : ',mapProperties)
  						//console.log('-------------------- manfaatList isine : ',manfaatList)
			  			var keyValue = tmpRule.keyType.toLowerCase().trim();
			  			//console.log('value dari keyValue ======================== ',keyValue);
			  			var key = tmpRule.key;//+'0'+keyTertanggung;
			  			var inputValue = 0;
			  			var custKey;
						if(keyValue === "customer" || keyValue === "coverage"){
							//console.log('Isi dari Key nya adalah : ===================== ',key);
							if(key == 'CUSTAGE'){
								//console.log('masuk sini jika CUSTAGE === ');
								inputValue = mapProperties[keyTertanggungAge] ? mapProperties[keyTertanggungAge] : 0;
							}else{
								//console.log('masuk sini kecuali CUSTAGE === ', key);
								inputValue = mapProperties[key] ? mapProperties[key] : 0; 
								//console.log('dan value nya dari input value = ',inputValue);
							}
					                       
				        }else if(keyValue === "formula"){
				        	//console.log('map output coverage , ======== ',mapOutputCoverage);
				          	inputValue= mapOutputCoverage[key] ? mapOutputCoverage[key] : 0;
				        }

			  			var value2 = itemRule.type.toLowerCase() === 'logic' ? formulaRule(itemList[i].itemCd, itemRule.value, mapProperties, mapOutputCoverage) : itemRule.value;
			  			//console.log('hasil dari mapOutputCoverage adalah = ',mapOutputCoverage);
			  			var ruleValue;
			  			if(itemRule.itemCd == 'H1VR'){
			  				ruleValue =Math.floor(value2);
			  			}else{
			  				ruleValue = value2;
			  			}
			  			var roundFixInput = Number(inputValue).toFixed(2);
			  			var inputValue2 = Math.round(roundFixInput);
						//console.log('input value 		: ' +inputValue2);
					  	//console.log('operator 			: ' + tmpRule.operator);
					  	//console.log('value result 		: ' + ruleValue);
					  	//console.log('item code nya adalah ======= ',itemRule.itemCd);
			  			var comparisson = getComparissonValue(inputValue2, tmpRule.operator, ruleValue);
			  			//console.log('comparisson 		: ' + comparisson);
			  			// console.log('______________________________________________________________________________');
			  			if(comparisson == true){
				  			var resultMap = {
				  					ruleCd : tmpRule.code,
				  					ruleTypeCd : tmpRule.ruleTypeCd,
				  					key : tmpRule.key,
				  					keyType : tmpRule.keyType,
				  					operator : tmpRule.operator,
				  					type : itemRule.type,
				  					value : ruleValue,
				  					errorType : itemRule.errorType,
				  					errorMessageInd : itemRule.errorMessageInd,
				  					errorMessageEng : itemRule.errorMessageEng,
				  					sumAssured : itemList[i].properties['PDSA'],
				  					comparisson : comparisson
				  				};

			  				ruleList.push(resultMap);
			  			}
  					// }else{

  					// }
		  			////console.log(ruleList);
  					}
  				}
		  	}
		  	return ruleList;
		  
		}

		function formulaRule(itemCd, formulaCd, map, mapOutputCoverage, mapOutputFund){
			var frml = $rootScope.FORMULA[formulaCd];
		 	var stringFormula = '';
	     	var stringFormulaOri = '';
			var itemType = '';
	     	var result = 0;

			if(frml){
			 	var forElmList = frml.FORMULA_ELEMENT;

			 	for(var i= 0; i < forElmList.length; i++){
			 		var fe = forElmList[i];
			        stringFormulaOri += fe.value;

			        if(fe.type.toLowerCase().trim() === "customer" 
			        	|| fe.type.toLowerCase().trim() === "coverage"
			        	|| fe.type.toLowerCase().trim() === "rate" 
			        	|| fe.type.toLowerCase().trim() === "load" 
			        	|| fe.type.toLowerCase().trim() === "fund"
			        	|| fe.type.toLowerCase().trim() === "product"
			        	|| fe.type.toLowerCase().trim() === "allocation"){

			          if(fe.value.toUpperCase() === 'CUSTINCOME'){
						stringFormula += "\'" + map[fe.value] +"\'";						
					  }else if(fe.value.toUpperCase() === 'PDPLAN'){
			          	stringFormula += map[fe.value] ? "\'" + map[fe.value] +"\'" : '0.0';                
			          }else if(fe.value.toUpperCase() === 'PDALLO'){
			          	stringFormula += map[fe.value] ? map[fe.value]/100 : '0.0';                
			          }else{
			          	stringFormula += map[fe.value] ? map[fe.value] : '0.0';                
			          }

			        }else if(fe.type.toLowerCase().trim() === "formula"){
			          stringFormula += mapOutputCoverage[fe.value] ? mapOutputCoverage[fe.value] : '0.0';
			        }else if(fe.type.toLowerCase().trim() === "string"){
			          stringFormula += "\'"+fe.value+"\'";			         
			        }else{
			          stringFormula += fe.value;
			        }
			 	}


			 	if(isValidExpression(stringFormula)){
			        result = getResultExpression(stringFormula, '');
			    }
			}
			
		    return result;

		}

		

		function getRateValue(rateCd, age, gender, smokerStatus, clazz, term, plan){
		    var listRate = getRate(rateCd);
		    if(listRate){
		      // var tempListRateValue = [];
		      for(var i = 0; i < listRate.length; i++){
		        var r = listRate[i];
		        
		          if((r.ageLife1 == null || r.ageLife1.trim() == '' || age == null || r.ageLife1 == age ) 
			          	&&(r.gender == null || r.gender.trim() == '' || gender == null || r.gender == gender ) 
				          	&&(r.smokerStatus == null || r.smokerStatus.trim() == '' || smokerStatus == null || r.smokerStatus == smokerStatus ) 
					          	&&(r.term == null || r.term.trim() == '' || term == null || r.term == term ) 
					          		&& (r.plan == null || r.plan.trim() == '' || plan == null || r.plan == plan)  
					          			&& (r.clazz == null || r.clazz.trim() == '' || clazz == null || r.clazz == clazz)){

		            return r.value ? r.value : 0;  
		           	break;
		          }
		        
		      }

		      return 0;		     
		    }
		}


		function generateCoverageGroup(coverageList){
		  	var coverageGroupList = [];
		  	var coverageCount = 0;
		  	////console.log('Isi dari coverageList di MathExpression === ',coverageList);
		  	for(var i = 0; i < coverageList.length; i++){
		  		

		  		for(var j = 0; j < coverageList[i].coverageGroupCdList.length; j++){
		  			var tmpCovGroup = coverageList[i].coverageGroupCdList[j];
		  			var idx = -1;
					for(var k = 0; k < coverageGroupList.length; k++){
						if(tmpCovGroup === coverageGroupList[k].itemCd){
							idx = k;
							coverageCount++;
							break;
						}
					}

					var newProp = {};
					for(var k in coverageList[i].properties){
						newProp[k] = coverageList[i].properties[k];
					}
					
					if(idx < 0){
		  				var map = {
		  						itemCd : tmpCovGroup,
		  						itemType : 'COVERAGE_GROUP',
		  						properties : newProp,
		  						mapOutputCoverage : coverageList[i].mapOutputCoverage,
		  						mapOutputFund : coverageList[i].mapOutputFund
			  				};
		  				coverageGroupList.push(map);
		  				
		  			}else{
		  				var maps = coverageGroupList[idx];
		  				maps.properties['PDSA'] =  parseInt(maps.properties['PDSA']) + parseInt(newProp['PDSA']);
		  				if(coverageCount > 0){
		  					maps.properties['PDSELECTEDML'] = parseInt(maps.properties['PDSELECTEDML']) + parseInt(newProp['PDSELECTEDML']);
							maps.properties['PDSELECTEDAL2'] = parseInt(maps.properties['PDSELECTEDAL2']) + parseInt(newProp['PDSELECTEDAL2']);
							maps.properties['PDSELECTEDAL3'] = parseInt(maps.properties['PDSELECTEDAL3']) + parseInt(newProp['PDSELECTEDAL3']);
							maps.properties['PDSELECTEDAL4'] = parseInt(maps.properties['PDSELECTEDAL4']) + parseInt(newProp['PDSELECTEDAL4']);
							maps.properties['PDSELECTEDAL5'] = parseInt(maps.properties['PDSELECTEDAL5']) + parseInt(newProp['PDSELECTEDAL5']);
		  				}else{
		  					maps.properties['PDSELECTEDML'] = parseInt(newProp['PDSELECTEDML']);
							maps.properties['PDSELECTEDAL2'] = parseInt(newProp['PDSELECTEDAL2']);
							maps.properties['PDSELECTEDAL3'] = parseInt(newProp['PDSELECTEDAL3']);
							maps.properties['PDSELECTEDAL4'] = parseInt(newProp['PDSELECTEDAL4']);
							maps.properties['PDSELECTEDAL5'] = parseInt(newProp['PDSELECTEDAL5']);
		  				}
		  				maps.properties['PDPREMI'] = parseInt(maps.properties['PDPREMI']) + parseInt(newProp['PDPREMI']);
		  			}
		  		}
		  		coverageCount++;
		  	}
		  	//console.log('ini update dari Efrat');
		  	return coverageGroupList;
		}

		function getValueFund(code, output, mapOutputFund){
			var res = '0.0';

			if(mapOutputFund[code]){
				var fundCd = mapOutputFund[code];
				if(fundCd[output]){
					res = fundCd[output];
				}
			}
			return res;
		}
		
		function sortingRiderTopupMain(tempManfaatList){
		  	var manfaatList = [];
		  	for(var i = 0; i < tempManfaatList.length; i++){
		  		var tmpManfaat = tempManfaatList[i];
		  		for(var j = 0; j < tmpManfaat.custList.length; j++){
		  			var tmpCustList = tmpManfaat.custList[j];
		  			var manfaat = {};
		  			var isInsert = true;

		  			manfaat.code = tmpManfaat.code;
                  	manfaat.name = tmpManfaat.name;
                  	manfaat.disabled = tmpManfaat.disabled;
                  	manfaat.coverageType = tmpManfaat.coverageType;
                  	manfaat.type = tmpManfaat.type;
                  	manfaat.lifeAssureCd = tmpManfaat.lifeAssureCd;

		  			manfaat.tertanggungName = tmpCustList.name;
                  	manfaat.tertanggungAge = tmpCustList.anb;
                 	manfaat.tertanggungKey = tmpCustList.key;
                 	manfaat.tertanggungCustomerId = tmpCustList.customerId;
		  			manfaat.itemInput = tmpCustList.itemInput;
		  			manfaat.loadMap = getLoadMapFromCustomer(tmpCustList.loadList);

		  			for(var k = 0; k < manfaat.itemInput.length; k++){
		  				console.log(manfaat.itemInput);
		  				if(manfaat.itemInput[k].key == 'PDPLAN' && (manfaat.itemInput[k].inputValue == 'N' || !manfaat.itemInput[k].inputValue || manfaat.itemInput[k].inputValue == '')){
		  					isInsert = false;	
		  				} else if(manfaat.itemInput[k].key == 'PDTERM' && (manfaat.itemInput[k].inputValue == 'N' || !manfaat.itemInput[k].inputValue || manfaat.itemInput[k].inputValue == '')){
		  					isInsert = false;	
		  				} 
		  			}
		  			
		  			if(isInsert){
		  				manfaatList.push(manfaat);	
		  			}
	  				
		  		}		  		
		  	}


		  	var tmpList = [];
		  	var tempList_topup = [];
		  	var tempList_main = [];
		  	var tempList_h1tr = [];
		  	var tempList_no_h1tr = [];

		    for(var i = 0; i < manfaatList.length; i++){
		      var coverage = $rootScope.COVERAGE[manfaatList[i].code];
		      if(coverage.type.toLowerCase().trim() === 'rider'){
				if(manfaatList[i].code.toUpperCase().trim() == 'H1TR'){
			        tempList_h1tr.push(manfaatList[i]);
			    }else{
			    	tempList_no_h1tr.push(manfaatList[i]);
			    }
		      }

		      if(coverage.type.toLowerCase().trim() === 'topup'){
		        tempList_topup.push(manfaatList[i]);
		      }

		      if(coverage.type.toLowerCase().trim() === 'main'){
		        tempList_main.push(manfaatList[i]);
		      }
		    }

		    tmpList = tempList_h1tr.concat(tempList_no_h1tr).concat(tempList_topup).concat(tempList_main);
		    //tempList_h1tr.concat(tempList_topup);
		    //tempList_h1tr.concat(tempList_main);

		    /*for(var i = 0; i < manfaatList.length; i++){
		      var coverage = $rootScope.COVERAGE[manfaatList[i].code];
		      if(coverage.type.toLowerCase().trim() === 'rider'){
		        tmpList.push(manfaatList[i]);
		      }
		    }

		    var tempList = [];
		    for(var i = 0; i < tmpList.length; i++){
			    var cov = tmpList[i];
				if(cov.code.toUpperCase().trim() == 'H1TR'){
			        tempList.push(cov);
			    }
		    }
		    
		    for(var i = 0; i < tmpList.length; i++){
			    var cov = tmpList[i];
				if(cov.code.toUpperCase().trim() != 'H1TR'){
			        tempList.push(cov);
			    }
		    }
		    
		    /*for(var i = 0; i < manfaatList.length; i++){
		      var coverage = $rootScope.COVERAGE[manfaatList[i].code];
		      if(coverage.type.toLowerCase().trim() === 'rider'){
		        tempList.push(manfaatList[i]);
		      }
		    }*/

		    /*for(var i = 0; i < manfaatList.length; i++){
		      var coverage = $rootScope.COVERAGE[manfaatList[i].code];
		      if(coverage.type.toLowerCase().trim() === 'topup'){
		        tempList.push(manfaatList[i]);
		      }
		    }

		    for(var i = 0; i < manfaatList.length; i++){
		      var coverage = $rootScope.COVERAGE[manfaatList[i].code];
		      if(coverage.type.toLowerCase().trim() === 'main'){
		        tempList.push(manfaatList[i]);
		      }
		    }*/
		    //return tempList;
			return tmpList;
		}


		function getLoadMapFromCustomer(loadList){
		    var tmpLoadList = {};
		    if(loadList){
		        for(var v = 0; v < loadList.length; v++){
		            var tmpLod = loadList[v];
		            if(tmpLod.selectedValue){
		                tmpLoadList[tmpLod.code] = tmpLod.selectedValue;
		            }
		        }
		    }
		    return tmpLoadList;
	    }

		function getRate(rateCd){
		    var tmpListRateDate = $rootScope.RATE[rateCd].RATE_VALUE;
		    if(tmpListRateDate){
		      for(var j = 0; j < tmpListRateDate.length; j++){
		        var rateByDate = tmpListRateDate[j];
		        //if((new Date() >= toDate(rateByDate.effectiveDate)) && (new Date() < toDate(rateByDate.expiryDate))){
		          return tmpListRateDate[j].rateValue;
		          break;
		        //}          
		      }
		    } 
		}

		function getFundListByFundMap(fundMap){
			var tempFund = [];
			for(x in fundMap){

				var tmp = {
                    code : x,
					key : fundMap[x].key ,
                    value : fundMap[x].value,
                    type : fundMap[x].type
				};
				tempFund.push(tmp);
			}
			return tempFund;
		}

		function toDate(strDate){
		    var from = strDate.split("/");
		    var f = new Date(from[2], from[1] - 1, from[0]);
		    return f;
		}

		function getComparissonValue(value1, operator, value2){
			var isValidation = false;

			switch(operator){

				case "<" :
				isValidation = value1 < value2;
				break;

				case ">" :
				isValidation = value1 > value2;
				break;

				case "==" :
				isValidation = value1 == value2;
				break;

				case "!=" :
				isValidation = value1 != value2;
				break;

				case "<=" : 
				isValidation : value1 <= value2;
				break;

				case ">=" :
				isValidation = value1 >= value2;
				break;

				case "=" :
				isValidation = value1 == value2;
				break;

				default : 
				isValidation = false;
				break;

			}

			return isValidation;
		}

		function getPremi(freq, premi){
		   if(freq === '00'){
		     return premi*1;
		   }else if(freq === '01'){
		     return premi*1;
		   }else if(freq === '03'){
		     return premi*4;
		   }else if(freq === '06'){
		     return premi*2;
		   }else if(freq === '12'){
		     return premi*12;
		   }
		}

	

		return {
	        getUnappliedPremium : getUnappliedPremium,
	        processIlustration : processIlustration
	    };
	});
