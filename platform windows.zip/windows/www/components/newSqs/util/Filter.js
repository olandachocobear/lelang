﻿/**
 * 
 */
angular.module('PruForce.controllers')

	.filter('optionspliter', function() {
	    return function(input) {
	        return input.split('|');
	        } 
	});