﻿angular.module('PruForce.services')

	.factory('CustomerStorageService', function ($rootScope) {

		
		var collection = JsonStoreConfig.CustomerStorage;

		function getCustomerStorage($q){
			var deferredAllCust = $q.defer();
			//console.log("Retrieve data from json store " + collection.JSONSTORE_NAME);
			try{
				
				var query = {agentId: $rootScope.agent.code};
				var options = {exact: false
					    	   //limit: 100 //returns a maximum of 10 documents
				   	  };
				
				WL.JSONStore.get(collection.JSONSTORE_NAME).find(query, options).then(function(res){
				 	try{
						if(res.length > 0){
							var result =  res;
							deferredAllCust.resolve(result);
						}		
					} catch(error){
						deferredAllCust.reject(error);
					}						
				}).fail(function(error){
				 	deferredAllCust.reject(error);
				});
			} catch (error) {
				deferredAllCust.reject(error);
			}
			return deferredAllCust.promise;
		}


		function getCustomerStorageByKey($q, customerId){
			//console.log("Retrieve data from json store " + collection.JSONSTORE_NAME);
			var deferredOneCust = $q.defer();
			try{
				
				var query = {agentId: $rootScope.agent.code, customerId : customerId};

				var options = {exact: false
					    	   //limit: 100 //returns a maximum of 10 documents
				   	  };
				
				WL.JSONStore.get(collection.JSONSTORE_NAME).find(query, options).then(function(res){
				 	try{
						if(res.length > 0){
							var result =  res[0].json;
							deferredOneCust.resolve(result.invocationResult);
						}		
					} catch(error){
						deferredOneCust.reject(error);
					}						
				}).fail(function(error){
				 	deferredOneCust.reject(error);
				});
			} catch (error) {
				deferredOneCust.reject(error);
			}
			return deferredOneCust.promise;
		}

		function deleteCustomerStorageByKey($q, customerId){
			//console.log("Retrieve data from json store " + collection.JSONSTORE_NAME);
			console.log('deleting ' + customerId);
			var deferredOneCust = $q.defer();
			try{
				
				var query = {agentId: $rootScope.agent.code, customerId : customerId};

				var options = {exact: false
					    	   //limit: 100 //returns a maximum of 10 documents
				   	  };
				
				WL.JSONStore.get(collection.JSONSTORE_NAME).remove(query, options).then(function(res){
				 	try{
						if(res.length > 0){
							var result =  res[0].json;
							deferredOneCust.resolve(result.invocationResult);
						}		
					} catch(error){
						deferredOneCust.reject(error);
					}						
				}).fail(function(error){
				 	deferredOneCust.reject(error);
				});
			} catch (error) {
				deferredOneCust.reject(error);
			}
			return deferredOneCust.promise;
		}

		function getCustomerStorageByCustMap($q, customerIdMap){
	      var deferredCustByMapCust = $q.defer();
	      var custList = [];
	    
	      for(var key in customerIdMap){
	      	if(customerIdMap[key] != null){
		      	console.log("cek ini "+key+" >>>>>>>>>>>>>>>>>> "+customerIdMap[key]);
		        var query = {agentId: $rootScope.agent.code, customerId : customerIdMap[key]};
		        var options = {exact: false
		                   //limit: 100 //returns a maximum of 10 documents
		              };
		        WL.JSONStore.get(collection.JSONSTORE_NAME).find(query, options).then(function(res){

		        	console.log("cek res ini ", res);
		          if(res.length > 0){
		            var result =  res[0].json;
		            custList.push(result.invocationResult);
		            deferredCustByMapCust.resolve(custList);     
		          }
		        });
	    	}
	      } 
	      return deferredCustByMapCust.promise;
	    }

		function addCustomerStorage($q, customerId, param){
			var deferredAddCust = $q.defer();
			var result = {};
			result.retrieveDate = new Date();
			result.agentId = $rootScope.agent.code;
			//clearCollection(collection.JSONSTORE_NAME);
			var data = {};
			data.invocationResult = param;
			data.agentId = result.agentId;
			data.customerId = customerId;
			data.retrieveDate = result.retrieveDate;
			
			var query = {agentId: $rootScope.agent.code, customerId : customerId};
			var options = {exact: false
				    	   //limit: 100 //returns a maximum of 10 documents
			   	  };

			WL.JSONStore.get(collection.JSONSTORE_NAME).find(query, options).then(function(res){
			 	try{
					if(res.length > 0){
						res[0].json.invocationResult = param;

						WL.JSONStore.get(collection.JSONSTORE_NAME).replace(res).then(function () {
							AppsLog.log("Success adding data to jsonstore " + collection.JSONSTORE_NAME);
							deferredAddCust.resolve(data);
						}).fail(function (error) {
							AppsLog.log("Failed adding data to jsonstore " + collection.JSONSTORE_NAME);
							deferredAddCust.reject(error);
						});

					}else{
						WL.JSONStore.get(collection.JSONSTORE_NAME).add(data).then(function () {
							AppsLog.log("Success adding data to jsonstore " + collection.JSONSTORE_NAME);
							deferredAddCust.resolve(data);
						}).fail(function (error) {
							AppsLog.log("Failed adding data to jsonstore " + collection.JSONSTORE_NAME);
							deferredAddCust.reject(error);
						});

					}
					// deferredAddCust.resolve(true);	
				} catch(error){
					deferredAddCust.reject(error);
				}						
			}).fail(function(error){
			 	deferredAddCust.reject(error);
			});
                        return deferredAddCust.promise;
		}

		function addOriginalCustomerStorage($q, customerId, param){
			var deferredAddCust = $q.defer();
			var result = {};
			result.retrieveDate = new Date();
			result.agentId = $rootScope.agent.code;
			//clearCollection(collection.JSONSTORE_NAME);
			var data = {};
			data.invocationResult = param;
			data.agentId = result.agentId;
			data.customerId = customerId;
			data.retrieveDate = result.retrieveDate;
			
			var query = {agentId: $rootScope.agent.code, customerId : customerId};
			var options = {exact: false
				    	   //limit: 100 //returns a maximum of 10 documents
			   	  };
			   	  
			WL.JSONStore.get(collection.JSONSTORE_NAME).add(data).then(function () {
				AppsLog.log("Success adding data to jsonstore " + collection.JSONSTORE_NAME);
				deferredAddCust.resolve(data);
			}).fail(function (error) {
				AppsLog.log("Failed adding data to jsonstore " + collection.JSONSTORE_NAME);
				deferredAddCust.reject(error);
			});
			
                        return deferredAddCust.promise;
		}


		return {
			getCustomerStorage : getCustomerStorage,
			getCustomerStorageByKey : getCustomerStorageByKey,
			getCustomerStorageByCustMap : getCustomerStorageByCustMap,
			addCustomerStorage : addCustomerStorage,
			addOriginalCustomerStorage : addOriginalCustomerStorage,
			deleteCustomerStorageByKey : deleteCustomerStorageByKey
		};
	});