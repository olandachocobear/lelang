﻿angular.module('PruForce.services')

	.factory('PublishGlobalService', function ($rootScope) {

		var collection = JsonStoreConfig.findPublish;

		function getPublishExisting($q){
			var deferredAllPublish = $q.defer();
			//console.log("Retrieve data from json store " + collection.JSONSTORE_NAME);
			try{
				
				var query = {agentId: $rootScope.agent.code};
				var options = {exact: false
					    	   //limit: 100 //returns a maximum of 10 documents
				   	  };
				
				WL.JSONStore.get(collection.JSONSTORE_NAME).find(query, options).then(function(res){
				 	try{
				 		console.log('Hasil res : ', res);
						if(res.length > 0){
							var result =  res[0].json;
							deferredAllPublish.resolve(result);
						}else{
							deferredAllPublish.resolve();
						}
					} catch(error){
						deferredAllPublish.reject(error);
					}						
				}).fail(function(error){
				 	deferredAllPublish.reject(error);
				});
			} catch (error) {
				deferredAllPublish.reject(error);
			}
			return deferredAllPublish.promise;
		}

		function getPublish($q, publishVersion){
			var deferredAllPublish = $q.defer();
			//console.log("Retrieve data from json store " + collection.JSONSTORE_NAME);
			try{
				var query = {agentId: $rootScope.agent.code, publishVersion : publishVersion};
				console.log("query getpublish : " + JSON.stringify(query));
				var options = {exact: false
					    	   //limit: 100 //returns a maximum of 10 documents
				   	  };
				
				WL.JSONStore.get(collection.JSONSTORE_NAME).find(query, options).then(function(res){
				 	try{
				 		console.log('getPublish : Hasil res : ', res);
						if(res.length > 0){
							var result =  res[0].json;
							deferredAllPublish.resolve(result);
						}else{
							deferredAllPublish.resolve();
						}
					} catch(error){
						console.log("getPublish : error");
						deferredAllPublish.reject(error);
					}						
				}).fail(function(error){
					console.log("getPublish : fail - ", error);
				 	deferredAllPublish.reject(error);
				});
			} catch (error) {
				console.log("getPublish : error 2 : " + error)
				deferredAllPublish.reject(error);
			}
			return deferredAllPublish.promise;
		}

		function getPublishVersion($q, publishVersion){
			var deferredAllPublish = $q.defer();
			//console.log("Retrieve data from json store " + collection.JSONSTORE_NAME);
			try{
				var query = {agentId: $rootScope.agent.code, publishVersion : publishVersion};
				console.log("query versionVld : " + JSON.stringify(query));
				var options = {exact: false
					    	   //limit: 100 //returns a maximum of 10 documents
				   	  };
				
				WL.JSONStore.get("versionvld").find(query, options).then(function(res){
				 	try{
				 		console.log('versionVld : Hasil res : ', res);
						if(res.length > 0){
							var result =  res[0].json;
							deferredAllPublish.resolve(result);
						}else{
							deferredAllPublish.resolve();
						}
					} catch(error){
						console.log("versionVld : error");
						deferredAllPublish.reject(error);
					}						
				}).fail(function(error){
					console.log("versionVld : fail - ", error);
				 	deferredAllPublish.reject(error);
				});
			} catch (error) {
				console.log("versionVld : error 2 : " + error)
				deferredAllPublish.reject(error);
			}
			return deferredAllPublish.promise;
		}

		function dropPublish($q, publishVersion){
			var deferredAllPublish = $q.defer();
			//console.log("Retrieve data from json store " + collection.JSONSTORE_NAME);
			try{
				
				var query = {agentId: $rootScope.agent.code, publishVersion : publishVersion};
				var options = {exact: false
					    	   //limit: 100 //returns a maximum of 10 documents
				   	  };
				
				WL.JSONStore.get(collection.JSONSTORE_NAME).remove(query, options).then(function(res){
				 	try{
						if(res.length > 0){
							var result =  res[0].json;
							deferredAllPublish.resolve(result.invocationResult.content);
						}		
					} catch(error){
						deferredAllPublish.reject(error);
					}						
				}).fail(function(error){
				 	deferredAllPublish.reject(error);
				});
			} catch (error) {
				deferredAllPublish.reject(error);
			}
			return deferredAllPublish.promise;
		}

		/*function getFormula($q){
			var deferredAllQuotation = $q.defer();
			//console.log("Retrieve data from json store " + collection.JSONSTORE_NAME);
			try{
				
				WL.JSONStore.get("formulaTbl").findAll().then(function(res){
				 	try{
						if(res.length > 0){
							var result =  res;
							deferredAllQuotation.resolve(result);
						}		
					} catch(error){
						deferredAllQuotation.reject(error);
					}						
				}).fail(function(error){
				 	deferredAllQuotation.reject(error);
				});
			} catch (error) {
				deferredAllQuotation.reject(error);
			}
			return deferredAllQuotation.promise;
		}

		function getRule($q){
			var deferredAllQuotation = $q.defer();
			//console.log("Retrieve data from json store " + collection.JSONSTORE_NAME);
			try{
				
				WL.JSONStore.get("ruleTbl").findAll().then(function(res){
				 	try{
						if(res.length > 0){
							var result =  res;
							deferredAllQuotation.resolve(result);
						}		
					} catch(error){
						deferredAllQuotation.reject(error);
					}						
				}).fail(function(error){
				 	deferredAllQuotation.reject(error);
				});
			} catch (error) {
				deferredAllQuotation.reject(error);
			}
			return deferredAllQuotation.promise;
		}*/

		function getFormula($q){
			var deferredAllRate = $q.defer();
			console.log("Retrieve data from sqlite Formula");
			try{

				$rootScope.db.transaction(function (tx) {
					var query = "SELECT * FROM formula";
					tx.executeSql(query, [], function (tx, rs) {
						deferredAllRate.resolve(rs);
					}, function (tx, error) {
						console.log('SELECT error: ' + error.message);
					});
				});
			} catch (error) {
				deferredAllRate.reject(error);
			}
			return deferredAllRate.promise;

		}

		function getpdf($q, sqsid){
			var deferredAllRate = $q.defer();
			console.log("Retrieve data from sqlite pdfstore");
			try{

				$rootScope.db.transaction(function (tx) {
					var query = "SELECT * FROM pdfstore where sqsid = '"+sqsid+"'";
					tx.executeSql(query, [], function (tx, rs) {
						deferredAllRate.resolve(rs);
					}, function (tx, error) {
						console.log('SELECT error: ' + error.message);
					});
				});
			} catch (error) {
				deferredAllRate.reject(error);
			}
			return deferredAllRate.promise;

		}

		function removepdf($q, sqsid){
			var deferredAllRate = $q.defer();
			console.log("Delete data from sqlite pdfstore");
			try{

				$rootScope.db.transaction(function (tx) {
					var query = "DELETE FROM pdfstore where sqsid = '"+sqsid+"'";
					tx.executeSql(query, [], function (tx, rs) {
						deferredAllRate.resolve(rs);
					}, function (tx, error) {
						console.log('DELETE error: ' + error.message);
					});
				});
			} catch (error) {
				deferredAllRate.reject(error);
			}
			return deferredAllRate.promise;
		}

		function getRule($q){
			var deferredAllRate = $q.defer();
			console.log("Retrieve data from sqlite Rule");
			try{

				$rootScope.db.transaction(function (tx) {
					var query = "SELECT * FROM rule";
					tx.executeSql(query, [], function (tx, rs) {
						deferredAllRate.resolve(rs);
					}, function (tx, error) {
						console.log('SELECT error: ' + error.message);
					});
				});
			} catch (error) {
				deferredAllRate.reject(error);
			}
			return deferredAllRate.promise;

		}

		function getPosition($q){
			var deferredAllQuotation = $q.defer();
			//console.log("Retrieve data from json store " + collection.JSONSTORE_NAME);
			try{
				
				WL.JSONStore.get("POSITION").findAll().then(function(res){
				 	try{
						if(res.length > 0){
							var result =  res;
							deferredAllQuotation.resolve(result);
						}		
					} catch(error){
						deferredAllQuotation.reject(error);
					}						
				}).fail(function(error){
				 	deferredAllQuotation.reject(error);
				});
			} catch (error) {
				deferredAllQuotation.reject(error);
			}
			return deferredAllQuotation.promise;
		}

		function getChannel($q){
			var deferredAllQuotation = $q.defer();
			//console.log("Retrieve data from json store " + collection.JSONSTORE_NAME);
			try{
				
				WL.JSONStore.get("CHANNEL").findAll().then(function(res){
				 	try{
						if(res.length > 0){
							var result =  res;
							deferredAllQuotation.resolve(result);
						}		
					} catch(error){
						deferredAllQuotation.reject(error);
					}						
				}).fail(function(error){
				 	deferredAllQuotation.reject(error);
				});
			} catch (error) {
				deferredAllQuotation.reject(error);
			}
			return deferredAllQuotation.promise;
		}

		function getOccupation($q){
			var deferredAllQuotation = $q.defer();
			//console.log("Retrieve data from json store " + collection.JSONSTORE_NAME);
			try{
				
				WL.JSONStore.get("OCCUPATION").findAll().then(function(res){
				 	try{
						if(res.length > 0){
							var result =  res;
							deferredAllQuotation.resolve(result);
						}		
					} catch(error){
						deferredAllQuotation.reject(error);
					}						
				}).fail(function(error){
				 	deferredAllQuotation.reject(error);
				});
			} catch (error) {
				deferredAllQuotation.reject(error);
			}
			return deferredAllQuotation.promise;
		}

		function getLoad($q){
			var deferredAllQuotation = $q.defer();
			//console.log("Retrieve data from json store " + collection.JSONSTORE_NAME);
			try{
				
				WL.JSONStore.get("LOAD").findAll().then(function(res){
				 	try{
						if(res.length > 0){
							var result =  res;
							deferredAllQuotation.resolve(result);
						}		
					} catch(error){
						deferredAllQuotation.reject(error);
					}						
				}).fail(function(error){
				 	deferredAllQuotation.reject(error);
				});
			} catch (error) {
				deferredAllQuotation.reject(error);
			}
			return deferredAllQuotation.promise;
		}

		function getBusiness($q){
			var deferredAllQuotation = $q.defer();
			//console.log("Retrieve data from json store " + collection.JSONSTORE_NAME);
			try{
				
				WL.JSONStore.get("BUSINESS").findAll().then(function(res){
				 	try{
						if(res.length > 0){
							var result =  res;
							deferredAllQuotation.resolve(result);
						}		
					} catch(error){
						deferredAllQuotation.reject(error);
					}						
				}).fail(function(error){
				 	deferredAllQuotation.reject(error);
				});
			} catch (error) {
				deferredAllQuotation.reject(error);
			}
			return deferredAllQuotation.promise;
		}

		function getPosition($q){
			var deferredAllQuotation = $q.defer();
			//console.log("Retrieve data from json store " + collection.JSONSTORE_NAME);
			try{
				
				WL.JSONStore.get("POSITION").findAll().then(function(res){
				 	try{
						if(res.length > 0){
							var result =  res;
							deferredAllQuotation.resolve(result);
						}		
					} catch(error){
						deferredAllQuotation.reject(error);
					}						
				}).fail(function(error){
				 	deferredAllQuotation.reject(error);
				});
			} catch (error) {
				deferredAllQuotation.reject(error);
			}
			return deferredAllQuotation.promise;
		}

		function getIncome($q){
			var deferredAllQuotation = $q.defer();
			//console.log("Retrieve data from json store " + collection.JSONSTORE_NAME);
			try{
				
				WL.JSONStore.get("INCOME").findAll().then(function(res){
				 	try{
						if(res.length > 0){
							var result =  res;
							deferredAllQuotation.resolve(result);
						}		
					} catch(error){
						deferredAllQuotation.reject(error);
					}						
				}).fail(function(error){
				 	deferredAllQuotation.reject(error);
				});
			} catch (error) {
				deferredAllQuotation.reject(error);
			}
			return deferredAllQuotation.promise;
		}

		function getFund($q){
			var deferredAllQuotation = $q.defer();
			//console.log("Retrieve data from json store " + collection.JSONSTORE_NAME);
			try{
				
				WL.JSONStore.get("FUND").findAll().then(function(res){
				 	try{
						if(res.length > 0){
							var result =  res;
							deferredAllQuotation.resolve(result);
						}		
					} catch(error){
						deferredAllQuotation.reject(error);
					}						
				}).fail(function(error){
				 	deferredAllQuotation.reject(error);
				});
			} catch (error) {
				deferredAllQuotation.reject(error);
			}
			return deferredAllQuotation.promise;
		}

		function getCoverage($q){
			var deferredAllQuotation = $q.defer();
			//console.log("Retrieve data from json store " + collection.JSONSTORE_NAME);
			try{
				
				WL.JSONStore.get("COVERAGE").findAll().then(function(res){
				 	try{
						if(res.length > 0){
							var result =  res;
							deferredAllQuotation.resolve(result);
						}		
					} catch(error){
						deferredAllQuotation.reject(error);
					}						
				}).fail(function(error){
				 	deferredAllQuotation.reject(error);
				});
			} catch (error) {
				deferredAllQuotation.reject(error);
			}
			return deferredAllQuotation.promise;
		}

		function getCoverageGroup($q){
			var deferredAllQuotation = $q.defer();
			//console.log("Retrieve data from json store " + collection.JSONSTORE_NAME);
			try{
				
				WL.JSONStore.get("COVERAGEGROUP").findAll().then(function(res){
				 	try{
						if(res.length > 0){
							var result =  res;
							deferredAllQuotation.resolve(result);
						}		
					} catch(error){
						deferredAllQuotation.reject(error);
					}						
				}).fail(function(error){
				 	deferredAllQuotation.reject(error);
				});
			} catch (error) {
				deferredAllQuotation.reject(error);
			}
			return deferredAllQuotation.promise;
		}

		function getPaymentFreq($q){
			var deferredAllQuotation = $q.defer();
			//console.log("Retrieve data from json store " + collection.JSONSTORE_NAME);
			try{
				
				WL.JSONStore.get("PAYMENTFREQUENSI").findAll().then(function(res){
				 	try{
						if(res.length > 0){
							var result =  res;
							deferredAllQuotation.resolve(result);
						}		
					} catch(error){
						deferredAllQuotation.reject(error);
					}						
				}).fail(function(error){
				 	deferredAllQuotation.reject(error);
				});
			} catch (error) {
				deferredAllQuotation.reject(error);
			}
			return deferredAllQuotation.promise;
		}

		function getFundGroup($q){
			var deferredAllQuotation = $q.defer();
			//console.log("Retrieve data from json store " + collection.JSONSTORE_NAME);
			try{
				
				WL.JSONStore.get("FUNDGROUP").findAll().then(function(res){
				 	try{
						if(res.length > 0){
							var result =  res;
							deferredAllQuotation.resolve(result);
						}		
					} catch(error){
						deferredAllQuotation.reject(error);
					}						
				}).fail(function(error){
				 	deferredAllQuotation.reject(error);
				});
			} catch (error) {
				deferredAllQuotation.reject(error);
			}
			return deferredAllQuotation.promise;
		}

		function getInput($q){
			var deferredAllQuotation = $q.defer();
			//console.log("Retrieve data from json store " + collection.JSONSTORE_NAME);
			try{
				
				WL.JSONStore.get("INPUT").findAll().then(function(res){
				 	try{
						if(res.length > 0){
							var result =  res;
							deferredAllQuotation.resolve(result);
						}		
					} catch(error){
						deferredAllQuotation.reject(error);
					}						
				}).fail(function(error){
				 	deferredAllQuotation.reject(error);
				});
			} catch (error) {
				deferredAllQuotation.reject(error);
			}
			return deferredAllQuotation.promise;
		}

		return {
			getPublishExisting : getPublishExisting,
			getPublish : getPublish,
			dropPublish : dropPublish,
			getPublishVersion : getPublishVersion,
			getFormula : getFormula,
			getRule : getRule,
			getPosition : getPosition,
			getChannel : getChannel,
			getOccupation : getOccupation,
			getLoad : getLoad,
			getBusiness : getBusiness,
			getIncome : getIncome,
			getFund : getFund,
			getCoverage : getCoverage,
			getPaymentFreq : getPaymentFreq,
			getCoverageGroup : getCoverageGroup,
			getFundGroup : getFundGroup,
			getInput : getInput,
			getpdf : getpdf,
			removepdf : removepdf
		};
	});