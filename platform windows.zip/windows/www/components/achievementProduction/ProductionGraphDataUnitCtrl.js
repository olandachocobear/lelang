﻿angular.module('PruForce.controllers')

	.controller('ProductionGraphDataUnitCtrl', function ($scope, $rootScope, $http, $filter, GraphPeriodProdHistoryService) {

		$scope.init = function (DataProductionGraphUnit, LastUpdateInit) {
			getDataProductionGraphUnitListSuccess(DataProductionGraphUnit);
			getLastUpdateSuccess(LastUpdateInit);
		};

		GraphPeriodProdHistoryService.invoke($rootScope.username, $rootScope.agent.code, "unit").then(function (res) {
			getGraphPeriodProdHistoryUnitListSuccess(res);
		});

		$scope.statusHistory = false;
		function getDataProductionGraphUnitListSuccess(result) {
			if (result.invocationResult.isSuccessful && result.invocationResult.statusCode == 200) {
				$scope.statusHistory = true;
				ListProdUnitData = [];
				if (result.invocationResult != null || result.invocationResult.array.length != 0) {
					$scope.flagShow = true;
					var periodMonthYearUnit = [];
					var apeNetUnit = [];
					ListDataUnit = [];
					for (var i = 0; i < result.invocationResult.array.length; i++) {

						var dt = {};

						apeNetShow = result.invocationResult.array[i].apeNet;
						dt.apeNetShow = Number(apeNetShow).formatMoney(2, '.', ',');
						var month = result.invocationResult.array[i].periodMonth;
						(month.length < 2) ? month = "0" + month : month;
						var inputDate = result.invocationResult.array[i].periodYear + "-" + month + "-01";
						dt.periodMonthYear = moment(inputDate).format('MMM YY');
						ListDataUnit[i] = dt;

						periodMonthYearUnit.push(moment(inputDate).format('MMM YY'));

						apeNetUnit.push(Number(result.invocationResult.array[i].apeNet / 1000000).formatMoney(2, '.', ','));
					}
				}

				$scope.dataProductionUnit = {
					labels: periodMonthYearUnit,
					datasets: [
						{
							label: "My First dataset",
							fillColor: "rgba(0,0,0,0)",
							strokeColor: "#f00",
							highlightFill: "rgba(220,220,220,0.75)",
							highlightStroke: "rgba(220,220,220,1)",
							data: apeNetUnit
						}
					]
				};
				$scope.ListDataUnit = ListDataUnit;

			} else {
				$scope.statusHistory = false;
				AppsLog.log("No data found. Please try again later!");
			}
		}

		function getGraphPeriodProdHistoryUnitListSuccess(result) {
			if (result.invocationResult.statusCode == 200) {
				AppsLog.log("maxUnit " + JSON.stringify(result));
				$scope.maxUnit = moment("01 " + result.invocationResult.max).format('MMMM YYYY');
				$scope.minUnit = moment("01 " + result.invocationResult.min).format('MMMM YYYY');
			} else {
				AppsLog.log("No data found. Please try again later!");
				$scope.successResult = false;
			}
		}

		$scope.optionsProductionUnit = {
			scaleFontStyle: "normal",
			scaleFontColor: "#4b79bc",
			responsive: true,
			scaleBeginAtZero: false,
			scaleShowGridLines: false,
			scaleGridLineColor: "rgba(0,0,0,.05)",
			scaleGridLineWidth: 2,
			scaleShowHorizontalLines: true,
			scaleShowVerticalLines: true,
			barShowStroke: true,
			barStrokeWidth: 1,
			barValueSpacing: 2,
			barDatasetSpacing: 1,
			legendTemplate: false,
			showTooltips: false
		};


		function getLastUpdateSuccess(result) {
			if (result.invocationResult.statusCode == 200) {
				var lastUpdate = result.invocationResult.latest;
				var lastUpdateConv = moment(lastUpdate).format('LLLL');
				$scope.lastUpdateConv = lastUpdateConv;
			} else {
				$scope.successResult = false;
			}
		}

	})