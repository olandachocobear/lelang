﻿angular.module('PruForce.services')

	.service('LastUpdateProdHistoryService', function (DataFactory, $q) {
		function invoke(pruforceId, agentCode) {

			var req = {
				adapter: "HTTPAdapter3",
				procedure: "findLastUpdateProdHistory",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + pruforceId + "','" + agentCode + "']" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, false)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invoke: invoke
		}

	});

