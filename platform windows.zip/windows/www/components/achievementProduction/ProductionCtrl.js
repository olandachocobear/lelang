﻿/**
 * 
 */
angular.module('PruForce.controllers')
    .controller("ProductionCtrl", function ($scope, $rootScope, $http, $interval, AchievementProductionUnit, AchievementProductionIndividu, ProdHistoryIndividu, ProdHistoryUnit, getLastUpdate) {
        AppsLog.log("START >> ProductionCtrl " + new Date());

        $scope.AchievementProductionUnit = AchievementProductionUnit;
        $scope.AchievementProductionIndividu = AchievementProductionIndividu;
        $scope.ProdHistoryIndividu = ProdHistoryIndividu;
        $scope.ProdHistoryUnit = ProdHistoryUnit;
        $scope.getLastUpdate = getLastUpdate;

        AppsLog.log("DATA UPDATE");
        AppsLog.log(getLastUpdate);
        AppsLog.log(ProdHistoryIndividu);
        AppsLog.log(ProdHistoryUnit);

        $scope.achievementTabs = [{
            title: 'mtd',
            url: 'mtd1'
        }, {
                title: 'ytd',
                url: 'ytd1'
            }, {
                title: 'riwayat',
                url: 'history'
            }];
        $scope.currentachievementTab = localStorage.getItem('currentTabProduction');
        $scope.onClickTab = function (achievementTab) {
            $scope.currentachievementTab = achievementTab.url;
            localStorage.setItem('currentTabProduction', $scope.currentachievementTab);
        }

        $scope.isActiveTab = function (achievementTabUrl) {
            return achievementTabUrl == $scope.currentachievementTab;
        }


        // Chart.js Options
        $scope.options = {
            //Boolean - Whether the scale should start at zero, or an order of magnitude down from the lowest value
            scaleBeginAtZero: true,

            //Boolean - Whether grid lines are shown across the chart
            scaleShowGridLines: true,

            //String - Colour of the grid lines
            scaleGridLineColor: "rgba(0,0,0,.05)",

            //Number - Width of the grid lines
            scaleGridLineWidth: 1,

            //Boolean - Whether to show horizontal lines (except X axis)
            scaleShowHorizontalLines: true,

            //Boolean - Whether to show vertical lines (except Y axis)
            scaleShowVerticalLines: true,

            //Boolean - If there is a stroke on each bar
            barShowStroke: true,

            //Number - Pixel width of the bar stroke
            barStrokeWidth: 1,

            //Number - Spacing between each of the X value sets
            barValueSpacing: 2,

            //Number - Spacing between data sets within X values
            barDatasetSpacing: 1,

            //String - A legend template
            legendTemplate: false

        };
        AppsLog.log("END >> ProductionCtrl " + new Date());
    })