﻿angular.module('PruForce.services')

	.service('UnitProductionYearlyService', function (DataFactory, $q) {

		function invoke(agentNumberUnit, pageUnit, sizeUnit, searchByUnit, searchValUnit, orderByUnit, directionUnit, pruforceId) {

			var req = {
				adapter: "HTTPAdapter3",
				procedure: "findUnitProductionYearly",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + agentNumberUnit + "'," + pageUnit + "," + sizeUnit + ",'" + searchByUnit + "','" + searchValUnit + "','" + orderByUnit + "','" + directionUnit + "','" + pruforceId + "']" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invoke: invoke
		}
	});

