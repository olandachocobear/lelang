﻿/**
 * 
 */

angular.module('PruForce.controllers')
	.controller('GroupProductionTranCtrl', function ($scope, $rootScope, $ionicLoading, $interval, $state, $http, $filter, $stateParams, ProductionData, UnitProductionMonthlyService, UnitProductionYearlyService, ListAgentType) {
		AnalyticsLog.logPage("prudential.production.list.unit");
		$scope.changePage = function (id) {
			$state.go('detail_individu_transaction_by_unit', { type: $state.params.type, agentNumber: id });
			$rootScope.agentNumberClickByUser = id;
		}
		var sizeUnit = 30;
		var pageUnit = 1;
		var pageLocalunit = 1;
		var searchByUnit = '';
		var searchValUnit = '';
		var orderByUnit = '';
		var directionUnit = 'asc';
		var listUnitAll = [];
		var listUnitAfterAdd = [];
		$scope.noMoreItemsAvailable = false;
		$scope.numberOfItemsToDisplay = 30;
		$scope.sortOptions = {
			st: [
				{
					id: 0,
					name: $filter('translate')('DEFAULT_SORT')

				},
				{ id: 1, name: $filter('translate')('HIGHEST_APE_PROD') },
				{ id: 2, name: $filter('translate')('LOWEST_APE_PROD') }
			]
		};

		$scope.sortItem = {
			onRequest: $scope.sortOptions.st[0]
		};

		getListAgentTypeSuccess(ListAgentType);
		$scope.getListAgentTypeSuccess = getListAgentTypeSuccess;
		function getListAgentTypeSuccess(result) {
			if (result.invocationResult.isSuccessful) {
				if (result.invocationResult.array != null) {
					$scope.agentTypeList = [];
					$scope.agentTypeList.push($filter('translate')('SHOW_ALL'));
					for (var i = 0; i < result.invocationResult.array.length; i++) {
						$scope.agentTypeList.push(result.invocationResult.array[i].key);
					}
					$scope.filterItem = {
						onRequest: $scope.agentTypeList[0]
					}
				}
			} else if (result.invocationResult.statusCode == 500) {
				$ionicLoading.hide();
				AppsLog.log("No data found2. Please try again later!");
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}
		function getListAgentTypeFailed(result) {
			$ionicLoading.hide();
			AppsLog.log("Data Individu Failed, Please Check Your Connection");
		}

		$scope.loadMore = function () {
			pageUnit += 1;
			$scope.showSpinner = true;
			getDataFromService();
			noMoreItemsAvailable = false;
			$scope.$broadcast('scroll.infiniteScrollComplete');
		};

		$scope.GoFiltering = function () {
			$ionicLoading.show();
			listUnitAll = [];
			pageUnit = 1;
			sizeUnit = 30;

			if ($scope.filterItem.onRequest == $filter('translate')('SHOW_ALL')) {
				searchByUnit = '';
				searchValUnit = '';
			} else {
				searchByUnit = 'agentType';
				searchValUnit = $scope.filterItem.onRequest;
				if ($scope.$root.$$phase != '$apply' && $scope.$root.$$phase != '$digest') {
					$scope.$apply();
				}
			}

			if ($scope.sortItem.onRequest.id === 0) {
				$scope.descSorted = false;
				orderByUnit = 'totalNetAPI';
				directionUnit = 'desc';
			} else if ($scope.sortItem.onRequest.id === 1) {
				orderByUnit = 'totalNetAPI';
				directionUnit = 'desc';
			} else {
				orderByUnit = 'totalNetAPI';
				directionUnit = 'asc';
			}

			if (searchValUnit == undefined) {
				searchValUnit = '';
			}
			getDataFromService();
		}

		function getDataFromService() {
			if ($stateParams.type == 'mtd') {
				UnitProductionMonthlyService.invoke(
					$rootScope.agent.code, pageUnit, sizeUnit,
					searchByUnit, searchValUnit, orderByUnit, directionUnit, $rootScope.username)
					.then(function (res) {
						getDataUnitListSuccess(res);
					});
			} else {
				UnitProductionYearlyService
					.invoke($rootScope.agent.code, pageUnit, sizeUnit,
					searchByUnit, searchValUnit, orderByUnit,
					directionUnit, $rootScope.username)
					.then(
					function (res) {
						getDataUnitListSuccess(res);
					});
			}
		}
		getDataUnitListSuccess(ProductionData);

		$scope.getDataUnitListSuccess = getDataUnitListSuccess;

		function getDataUnitListSuccess(result) {
			if (result.invocationResult.isSuccessful) {
				var agentType2;
				if (result.invocationResult.array != null) {
					if (listUnitAll.length == 0) {
						listUnitAll = [];
						for (var i = 0; i < result.invocationResult.array.length; i++) {
							var dt = {};
							dt.agentNumber = result.invocationResult.array[i].agentNumber;
							dt.clientNumber = result.invocationResult.array[i].clientNumber;
							dt.clientName = result.invocationResult.array[i].clientName;
							dt.agentType = result.invocationResult.array[i].agentType;
							totalNetAPI = result.invocationResult.array[i].totalNetAPI;
							dt.totalNetAPI = Number(totalNetAPI).formatMoney(2, '.', ',');
							listUnitAll[i] = dt;
							pageUnit = 1;

							var responseTimestamp = new Date(result.invocationResult.array[i].responseTimestamp);
							responseTimestamp = moment(responseTimestamp).format('LLLL');
							$scope.lastUpdate = responseTimestamp;

							if (totalNetAPI = "") {
								totalNetAPI = "N/A";
							}
						}
					} else {
						for (var i = 0; i < result.invocationResult.array.length; i++) {
							var dt = {};
							dt.agentNumber = result.invocationResult.array[i].agentNumber;
							dt.clientNumber = result.invocationResult.array[i].clientNumber;
							dt.clientName = result.invocationResult.array[i].clientName;
							dt.agentType = result.invocationResult.array[i].agentType;
							totalNetAPI = result.invocationResult.array[i].totalNetAPI;
							dt.totalNetAPI = Number(totalNetAPI).formatMoney(2, '.', ',');
							listUnitAfterAdd[i] = dt;
							listUnitAll.push(listUnitAfterAdd[i]);
							$scope.numberOfItemsToDisplay += 5;

							var responseTimestamp = new Date(result.invocationResult.array[i].responseTimestamp);
							responseTimestamp = moment(responseTimestamp).format('LLLL');
							$scope.lastUpdate = responseTimestamp;

							if (totalNetAPI = "") {
								totalNetAPI = "N/A";
							}
						}
					}
				}

				$scope.agentList = listUnitAll;

				Array.prototype.removeValue = function (name, value) {
					var array = $.map(this, function (v, i) {
						return v[name] === value ? null : v;
					});
					this.length = 0;
					this.push.apply(this, array);
				}

				function groupBy(items, propertyName) {
					var result = [];
					result.push($filter('translate')('SHOW_ALL'));
					$.each(items, function (index, item) {
						if ($.inArray(item[propertyName], result) == -1) {
							if (item[propertyName] != null) {
								result.push(item[propertyName]);
							}
						}
					});
					return result;
				}
				$scope.showSpinner = false;
				$ionicLoading.hide();
				$scope.noMoreItemsAvailable = false;
				if (result.invocationResult.statusCode == 500) {
					$scope.showLoading = false;
					$ionicLoading.hide();
					$scope.noMoreItemsAvailable = true;
					AppsLog.log("No data found1. Please try again later!");
				}
			} else if (result.invocationResult.statusCode == 500) {
				$scope.showLoading = false;
				$ionicLoading.hide();
				$scope.noMoreItemsAvailable = true;
				AppsLog.log("No data found2. Please try again later!");
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}

		function getDataUnitListFailed(result) {
			$ionicLoading.hide();
			AppsLog.log("Load Data Failed, Please Check Your Connection");
		}
	})