﻿angular.module('PruForce.services')


.service('DetailUnitIndividuTransactionMonthlyService', function(DataFactory, $q){
	function invoke(agentNumberIndividuUnit,pageIndividuUnit,sizeIndividuUnit,searchByIndividuUnit,searchValIndividuUnit,searchBy2IndividuUnit,searchVal2IndividuUnit,orderByIndividuUnit,directionIndividuUnit,pruforceId,agentCode){

		var req = {
				adapter : "HTTPAdapter3",
				procedure : "findAllProductionIndividuMonthly",
                //headers: headers
                method: WLResourceRequest.POST,
     			parameters : {"params":"['"+agentNumberIndividuUnit+"',"+pageIndividuUnit+","+sizeIndividuUnit+",'"+searchByIndividuUnit+"','"+searchValIndividuUnit+"','"+searchBy2IndividuUnit+"','"+searchVal2IndividuUnit+"','"+orderByIndividuUnit+"','"+directionIndividuUnit+"','"+pruforceId+"','"+agentCode+"']"}
        	};

		AppsLog.log("Request Filtering" + agentNumberIndividuUnit);
		AppsLog.log("Request 1 :" + searchByIndividuUnit);
		AppsLog.log("Request 2 :" + searchValIndividuUnit);
		AppsLog.log("Request 3 :" + pageIndividuUnit);
		AppsLog.log("Request 4 :" + sizeIndividuUnit);
		AppsLog.log("Request 5 :" + orderByIndividuUnit);
		AppsLog.log("Request 6 :" + directionIndividuUnit);
		AppsLog.log("Request 7 :" + searchBy2IndividuUnit);
		AppsLog.log("Request 8 :" + searchVal2IndividuUnit);
		
		var deferred = $q.defer();
		
		DataFactory.invoke(req,true)
	    .then(function (res) {
        	deferred.resolve(res);
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
	}
	
	return {
		invoke: invoke
	}
});

