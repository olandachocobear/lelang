﻿angular.module('PruForce.services')
.service('AllPersistencyIndividuFromUnitService', function(DataFactory2, $q,$rootScope){
	function invoke(agentNumberIndividuUnit,pageIndividuUnit,sizeIndividuUnit,searchByIndividuUnit,searchValIndividuUnit,searchBy2IndividuUnit,searchVal2IndividuUnit,orderByIndividuUnit,directionIndividuUnit,pruforceId,agentCode){

		$rootScope.flagingForJsonWithParams = true;
		var req = {
				adapter : "HTTPAdapter3",
				procedure : "findAllPersistencyIndividuDetailByAgentNumber",
				method: WLResourceRequest.POST,
     		  	parameters : {"params":"['"+agentNumberIndividuUnit+"',"+pageIndividuUnit+","+sizeIndividuUnit+",'"+searchByIndividuUnit+"','"+searchValIndividuUnit+"','"+searchBy2IndividuUnit+"','"+searchVal2IndividuUnit+"','"+orderByIndividuUnit+"','"+directionIndividuUnit+"','"+pruforceId+"','"+agentCode+"']"}
			};
		
	    var deferred = $q.defer();
	    
	    AppsLog.log("searchByIndividuUnit : "+searchByIndividuUnit);
		
		DataFactory2.invoke(req)
	    .then(function (res) {
        	deferred.resolve(res);
	    }, function(error){
	    	deferred.reject(error);
	    });
		
		return deferred.promise;
	}
	
	return {
		invoke: invoke
	}
});

