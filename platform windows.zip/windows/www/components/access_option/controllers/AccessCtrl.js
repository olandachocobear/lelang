﻿angular.module('PruForce.controllers')

    .controller('AccessCtrl', function ($scope, $state, $ionicPopup, $stateParams, $rootScope) {

        $scope.Agent = function () {

            $rootScope.userType = 'agent';
            switch ($stateParams.access_type) {
                case "daftar_pruforceId":
                    $state.go("daftar-pruforceId-with-sfa");
                    break;
                case "lupa_pruforceId":
                    $state.go("lupa-pruforceId-agen");
                    break;
                case "lupa_pertanyaan_rahasia":
                    $state.go("lupa-pertanyaan-rahasia-agen");
                    break;
            }
        }

        $scope.CalonAgent = function () {

            $rootScope.userType = 'candidate';
            switch ($stateParams.access_type) {
                case "daftar_pruforceId":
                    $state.go("daftar-pruforceId-calon-agen");
                    break;
                case "lupa_pruforceId":
                    $state.go("lupa-pruforceId-calon-agen");
                    break;
                case "lupa_pertanyaan_rahasia":
                    $state.go("lupa-pertanyaan-rahasia-calon-agen");
                    break;
            }
        }

        $scope.goBackState = function () {
            if ($rootScope.previousState == 'public-home') {
                $state.go('public-home');
            } else {
                $rootScope.goBack();
            }
        }

    })