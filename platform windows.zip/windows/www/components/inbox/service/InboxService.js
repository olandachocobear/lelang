﻿angular.module('PruForce.services')

    .service('InboxService', function (AOBResources, $q) {

        function invoke(agentCode, filterBy, size, page) {
            var req = {
                adapter: "HTTPAdapterAuth",
                procedure: "getUnreadPushNotification",
                method: WLResourceRequest.POST,
                parameters: { "params": "['" + agentCode + "','" + filterBy + "'," + size + "," + page + "]" }
            };

            var deferred = $q.defer();

            AOBResources.invoke(req, false)
                .then(function (res) {
                    deferred.resolve(res);
                }, function (error) {
                    deferred.reject(error);
                });

            return deferred.promise;
        }

        return {
            invoke: invoke
        }
    });

