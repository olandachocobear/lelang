﻿angular.module('PruForce.services')

    .service('UpdateInboxService', function (CandidateFactory, InboxService, $q) {

        function invoke(idInbox) {
            var req = {
                adapter: "HTTPAdapterAuth",
                procedure: "UpdateStatusPushNotification",
                method: WLResourceRequest.POST,
                parameters: { "params": "['" + idInbox + "']" }
            };

            var deferred = $q.defer();

            CandidateFactory.invoke(req, true)
                .then(function (res) {
                    deferred.resolve(res);
                }, function (error) {
                    deferred.reject(error);
                });

            return deferred.promise;
        }

        return {
            invoke: invoke
        }
    });

