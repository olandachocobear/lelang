﻿angular.module('PruForce.services')

    .service('GetListPendingDocService', function (CandidateFactory, $q) {

        function invoke(statusapp) {
            var req = {
                adapter: "HTTPAdapterAuth",
                procedure: "GetListPendingDoc",
                method: WLResourceRequest.POST,
                parameters: { "params": "['" + statusapp + "']" }
            };

            var deferred = $q.defer();

            CandidateFactory.invoke(req, true)
                .then(function (res) {
                    deferred.resolve(res);
                }, function (error) {
                    deferred.reject(error);
                });

            return deferred.promise;
        }

        return {
            invoke: invoke
        }
    });

