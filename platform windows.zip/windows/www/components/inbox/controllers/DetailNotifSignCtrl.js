﻿/**
 * 
 */
angular.module('PruForce.controllers')
	.controller('DetailNotifSignCtrl', function ($scope, $filter, $jrCrop, $translate, $rootScope, $state, $stateParams, $ionicModal, $ionicPopup, $ionicLoading, getCreateDate, GetAplicationPackService, SignatureService,
		SubmitNotifByUserService, CheckAAJIService, SupportDocService, BPMResumeService, CheckAAJICountLocalService, UploadDocumentReadyService, UploadSignatureService, UpdateInboxService, InboxService, CandidateDetail) {

		var listDetailInbox = [];

		if ($rootScope.inbox.changemanager) {
			$scope.buttonLabel = $filter('translate')('AGREE');
		} else {
			$scope.buttonLabel = $filter('translate')('SAVE_N_SEND');
		}

		getCreateDateSuccess(getCreateDate);
		function getCreateDateSuccess(res) {
			try {
				if (res.result != undefined) {
					$scope.DateSubmit = moment(res.result.createdate).format('LL');
				} else {
					$scope.DateSubmit = moment(new Date()).format('LL');
				}
			} catch (error) {

			}
		}
		$scope.gotoApplicationPack = function () {
			$ionicLoading.show();
			$rootScope.flagReadOnly = true;
			$rootScope.candidate.npa = $stateParams.npa;
			$state.go("data-kandidat-pack");
		}

		$scope.gotoAMLTraining = function () {
			$rootScope.AlertDialog($filter('translate')('PRU_94'));
		}

		$scope.gotoAAJI = function () {
			$state.go("aaji_agent", { flagReadOnly: true });
		}

		$scope.gotoPRUFastStart = function () {
			$state.go("prufaststart-agent");
		}

		getDataAplicationPackSuccess(CandidateDetail);
		function getDataAplicationPackSuccess(res) {
			$ionicLoading.hide();
			var result = res.json;
			$scope.candidateName = result.dataPribadi.name;
			$scope.recruiterCode = result.dataKeagenan.recruitersCode;
			$scope.recruiterName = result.dataKeagenan.recruitersName;
			$scope.recruiterOfficeMarketing = result.dataKeagenan.recruitersOffice;
			$scope.mobilePhone1 = result.dataPribadi.candidateCellularNo1;

			// aaji

			var timeStart = new Date(result.dataUjian.aajiexamstarttime);
			var timeEnd = new Date(result.dataUjian.aajiexamendtime);
			var DataAAJI = [];
			var training = {};
			training.date = moment(result.dataUjian.choosedDate).format("dddd, D MMMM YYYY");
			training.sch = [];
			var childAAJI = {};
			childAAJI.number = 1;
			childAAJI.id = result.dataUjian.choosedId;
			childAAJI.time = timeStart.getFormattedTime() + " - " + timeEnd.getFormattedTime();
			childAAJI.loc = result.dataUjian.choosedLocation;
			childAAJI.endReg = moment(result.dataUjian.choosedDate).format("DD MMMM YYYY");
			training.sch.push(childAAJI);
			DataAAJI.push(training);
			$rootScope.candidate.aajiSchedule = [];
			$rootScope.candidate.aajiSchedule = DataAAJI;

			// fastart
			try {
				$rootScope.trainingTypeFastStart = result.dataFastStart.trainingType;
				if (result.dataFastStart.trainingType == 1) {

					$scope.DataFastStartSchedule = [];
					$rootScope.fastStartSchedule = {};

					$rootScope.fastStartSchedule.trainingType = result.dataFastStart.trainingType;
					$rootScope.fastStartSchedule.faststartlocation = result.dataFastStart.faststartlocation;
					$rootScope.fastStartSchedule.time = result.dataFastStart.time;
					$rootScope.fastStartSchedule.part = result.dataFastStart.part;
					$rootScope.fastStartSchedule.loc = result.dataFastStart.faststartlocation;
					$rootScope.fastStartSchedule.id = result.dataFastStart.faststartscheduleid;
					$rootScope.fastStartSchedule.icon = result.dataFastStart.icon;
					$rootScope.fastStartSchedule.days = result.dataFastStart.days;
					$rootScope.fastStartSchedule.date = result.dataFastStart.date;
					$rootScope.fastStartSchedule.month = result.dataFastStart.month;
					$scope.DataFastStartSchedule.push($rootScope.fastStartSchedule);
					$rootScope.candidate.fastStartSchedule = [];
					$rootScope.candidate.fastStartSchedule = $scope.DataFastStartSchedule;

				}


			} catch (error) {
				AppsLog.log(error);
			}
		}

		// this is start using image sign and image upload and crop
		$scope.notifsign = {};
		$scope.notifsign.all_image = {};
		$scope.signature = SignatureService.signature().getSignatureData();
		$scope.goToSign = function () {
			$state.go("tanda-tangan", { signParams: "recruiter" });
		}
		var signResult;
		$scope.showCropper = function (image, uploadTo, widthCropper, heightCropper) {
			var dataModel = uploadTo.split(".");
			$jrCrop.crop({
				url: image,
				width: widthCropper,
				height: heightCropper,
				cancelText: $filter('translate')('CANCEL'),
				chooseText: $filter('translate')('CROP'),
				allowRotation: true,
				buttonLocation: 'footer',
			}).then(function (canvas) {
				$scope[dataModel[0]][dataModel[1]][dataModel[2]] = canvas.toDataURL();
			});
		};

		function getSubstringImage(base64Image) {
			var subStringImage;
			subStringImage = base64Image.substring(22, base64Image.length);
			return subStringImage;
		}

		// this is used for submit detail notif 

		$scope.SubmitNotification = function () {
			signResult = $filter('limitTo')($scope.signature[1], $scope.signature[1].length, 22);
			if ($rootScope.inbox.changemanager) {
				if ($scope.signature[1].length == 0) {
					$rootScope.AlertDialog($filter('translate')('PRU_96'));
				} else {
					$ionicLoading.show();
					SubmitSignatureLeader();
				}
			} else {
				if ($scope.notifsign.all_image.pas_foto == undefined || $scope.notifsign.all_image.pas_foto == "") {
					$rootScope.AlertDialog($filter('translate')('PRU_46'));
				} else if ($scope.signature[1].length == 0) {
					$rootScope.AlertDialog($filter('translate')('PRU_96'));
				} else {
					$ionicLoading.show();
					//checking aaji quota..
					CheckAAJIService.invoke($stateParams.npa).then(function (res) {
						CheckQuotaAAJISuccess(res);
					});
				}
			}

		}

		function CheckQuotaAAJISuccess(res) {
			if (res.invocationResult.statusCode == 200) {
				if ($rootScope.flagPending) {
					UploadImagePasFoto();
				} else {
					CheckAAJICountLocalService.invoke(new Date(res.invocationResult.aajiexamdate)).then(function (resultLocal) {
						var count = resultLocal;
						var date = new Date();
						var currentHour = date.getHours();
						var aajiexamquota = res.invocationResult.aajiexamquota;
						var reserved = res.invocationResult.reserved;
						var isvalidexpireddate = res.invocationResult.isvalidexpireddate;
						var isvalidexamdate = res.invocationResult.isvalidexamdate;
						var minCount = 6;
						var maxCount = 15;

						if (currentHour >= 11) {
							minCount = 6;
						} else {
							minCount = 5;
						}

						if (count >= minCount && count <= maxCount) {
							if (reserved == null) {
								reserved = 0;
							}
							if (isvalidexpireddate == null) {
								isvalidexpireddate = true;
							}
							if (isvalidexamdate == null) {
								isvalidexamdate = true;
							}

							if (!isvalidexpireddate) {
								$ionicLoading.hide();
								$rootScope.AlertDialog($filter('translate')('PRU_91'), 'SubmitNotifToCandidate');
							} else if ($rootScope.agent.userType == 'candidate' && reserved >= aajiexamquota) {
								$ionicLoading.hide();
								$rootScope.AlertDialog($filter('translate')('PRU_92'), 'SubmitNotifToCandidate');
							} else {
								UploadImagePasFoto();
							}
						} else {
							$ionicLoading.hide();
							$rootScope.AlertDialog($filter('translate')('PRU_93'), 'SubmitNotifToCandidate');
						}
					});

				}

			} else {
				$ionicLoading.hide();
				$rootScope.AlertDialog($filter('translate')('PRU_83'));
			}
		}

		function UploadImagePasFoto() {
			var typeKTP;
			if ($rootScope.agent_isLeader) {
				typeKTP = 'KTP Manajer Keagenan';
			} else {
				typeKTP = 'KTP Perekrut';
			}
			var imageBase64 = getSubstringImage($scope.notifsign.all_image.pas_foto);

			SupportDocService.invoke($stateParams.npa, 'JPG', typeKTP, imageBase64, 'true').then(function (res) {
				SupportDocAgentSuccess(res);
			});
		}

		$rootScope.SubmitNotificationToCandidate = function () {
			$ionicLoading.show();
			/*eventId for sign is 99584 (this based on back office) */
            var eventId = 99584;
			var userId = $stateParams.npa;
			var payload = {};
			payload.reqId = 'AAJI';
			payload.agentcode = $rootScope.agent.code;
			payload.docList = 'invalid schedule AAJI';

			SubmitNotifByUserService.invoke(userId, eventId, pushNotifToken, payload).then(function (res) {
				SubmitNotifToCandidateSuccess(res);
			});
		}

		function SubmitNotifToCandidateSuccess(res) {
			if (res.invocationResult.isSuccessful) {
				updateInbox($rootScope.agent.code, 'PRU_81');
			} else {
				$ionicLoading.hide();
				$rootScope.DialogEvents($filter('translate')('PRU_82'), "home-menu.agent");
			}
		}


		function SupportDocAgentSuccess(res) {
			if (res.invocationResult.respCode == 200) {
				if ($rootScope.agent_isLeader) {
					SubmitSignatureLeader();
				} else {
					SubmitSignatureRecruiter();
				}
			} else {
				$ionicLoading.hide();
				$rootScope.AlertDialog($filter('translate')('PRU_45'));
			}
		}

		function SubmitSignatureLeader() {
			var typeSignature = 'leader';
			var changes = 'false';
			if ($rootScope.inbox.changemanager) {
				changes = 'true';
			}
			UploadSignatureService.invoke($stateParams.npa, 'JPG', typeSignature, signResult, changes).then(function (res) {
				SubmitSignatureLeaderSuccess(res);
			});

		}

		function SubmitSignatureLeaderSuccess(res) {
			if (res.invocationResult.respCode == 200) {
				if ($rootScope.inbox.changemanager) {
					SubmitBpmResume();
				} else {
					isExistSignatureRecruiter();
				}
			} else {
				AppsLog.log('Not Success Save Signature Recruiter 2 ' + res.invocationResult.respDesc);
				$ionicLoading.hide();
				$rootScope.AlertDialog($filter('translate')('PRU_44'));
			}
		}

		function isExistSignatureRecruiter(npa) {

			if ($rootScope.agent_isLeader) {
				if ($rootScope.inbox.reqId == "doc_ag") {
					SubmitBpmResume();
				} else {
					SubmitDocumentReady();
				}
			} else {
				UploadSignatureRecruiter();
			}

		}

		function SubmitBpmResume() {
			BPMResumeService.invoke($stateParams.npa).then(function (res) {
				SubmitBpmResumeSuccess(res);
			});
		}

		function SubmitBpmResumeSuccess(res) {
			if (res.invocationResult.respCode == 200) {
				var messageLabel = 'PRU_42';
				if ($rootScope.inbox.changemanager) {
					messageLabel = 'PRU_100';
				}
				updateInbox($rootScope.agent.code, messageLabel);
			} else {
				$ionicLoading.hide();
				$rootScope.AlertDialog($filter('translate')('PRU_44'));
			}
		}


		function SubmitSignatureRecruiter() {
			var typeSignature = 'recruiter';
			UploadSignatureService.invoke($stateParams.npa, 'JPG', typeSignature, signResult, 'false').then(function (res) {
				SubmitSignatureRecruiterSuccess(res);
			});

		}

		function SubmitSignatureRecruiterSuccess(res) {
			if ($rootScope.inbox.reqId == "doc_ag") {
				SubmitBpmResume();
			} else {
				SubmitNotificationToLeader();
			}
		}


		function SubmitNotificationToLeader() {
			/*eventId for sign is 99583 (this based on back office) */
            var eventId = 99583;
			var userId = $rootScope.agent.leaderagentcode;
			var payload = {};
			obj.reqId = "sign";
			obj.npa = $stateParams.npa;
			obj.docList = 'From Recruiter';
			obj.candidatename = $scope.candidateName;

			SubmitNotifByUserService.invoke(userId, eventId, pushNotifToken, payload).then(function (res) {
				SubmitNotificationToLeaderSuccess(res);
			});
		}


		function SubmitNotificationToLeaderSuccess(res) {
			if (res.invocationResult.isSuccessful) {
				updateInbox($rootScope.agent.code, 'PRU_42');
			} else {
				$ionicLoading.hide();
				$rootScope.AlertDialog($filter('translate')('PRU_44'));
			}
		}


		function UploadSignatureRecruiter() {
			var typeSignature = 'recruiter';
			UploadSignatureService.invoke($stateParams.npa, 'JPG', typeSignature, signResult, 'false').then(function (res) {
				SubmitSignatureRecruiterSuccess(res);
			});
		}

		function SuccessuploadSignatureRecruiter(res) {
			if (res.invocationResult.respCode == 200) {
				SubmitDocumentReady();
			} else {
				$ionicLoading.hide();
				$rootScope.AlertDialog($filter('translate')('PRU_44'));
				AppsLog.log('Not Success Save Signature Recruiter ' + res.invocationResult.respDesc);
			}

		}

		function SubmitDocumentReady() {
			UploadDocumentReadyService.invoke($stateParams.npa).then(function (res) {
				UploadDocumentReadySuccess(res);
			});
		}

		function UploadDocumentReadySuccess(res) {
			if (res.invocationResult.respCode == 200) {
				updateInbox($rootScope.agent.code, 'PRU_42');
			} else {
				$ionicLoading.hide();
				$rootScope.AlertDialog($filter('translate')('PRU_44'));
			}
		}

		$scope.toSign = function () {
			var element = document.getElementById("signBottom");
			element.scrollTop = element.scrollHeight;
		}


		function updateInbox(userId, messageLabel) {
			UpdateInboxService.invoke($rootScope.inbox.idInbox).then(function (res) {
				$rootScope.DialogEvents($filter('translate')(messageLabel), "home-menu.agent");
			});
		}
	});

