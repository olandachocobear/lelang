﻿/**
 * 
 */
angular.module('PruForce.controllers')

    .controller('AgentCodeReceivedCtrl', function ($scope, $state, $ionicLoading, $rootScope, UpdateInboxService, InboxService) {
        $scope.selesai = function () {
            AnalyticsLog.logPage("Update.Inbox");
            $ionicLoading.show();
            UpdateInboxService.invoke($rootScope.inbox.idInbox).then(function (res) {
                if (res.invocationResult.statusCode == 200) {
                    $ionicLoading.hide();
                    $state.go('home-menu.agent');
                } else {
                    $ionicLoading.hide();
                    $rootScope.DialogEvents($filter('translate')('PRU_97'), "home-menu.agent");
                }
            });
        }

    })


