﻿angular.module('PruForce.services')

	.service('CheckAAJICountLocalService', function (CandidateFactory, $q) {

		function invoke(AAJIDate) {
			var deferred = $q.defer();
			var currentDate = new moment().format("YYYY-MM-DD");
			var aajidate = new moment(AAJIDate).format("YYYY-MM-DD");
			var count = checkingValidAAJI(currentDate, aajidate);
			deferred.resolve(count);
			return deferred.promise;
		}

		function checkingValidAAJI(dt1, dt2) {
			var count = 0;
			var date1 = moment(dt1).dayOfYear();
			var date2 = moment(dt2).dayOfYear();

			var getDay1 = moment(date1).day();
			var getDay2 = moment(date2).day();
			count = date2 - date1;
			return count;
		}

		return {
			invoke: invoke
		}
	});

