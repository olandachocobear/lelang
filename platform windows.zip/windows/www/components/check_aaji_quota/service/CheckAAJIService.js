﻿angular.module('PruForce.services')

	.service('CheckAAJIService', function (AOBResources, $q) {

		function invoke(npa) {

			var req = {
				adapter: "HTTPAdapterAuth",
				procedure: "checkAAJIQuotaByNPA",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + npa + "']" }
			};

			var deferred = $q.defer();

			AOBResources.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		function invokeByCandidate(scheduleId) {

			var req = {
				adapter: "HTTPAdapterAuth",
				procedure: "CheckAAJIQuotaCandidate",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + scheduleId + "']" }
			};

			var deferred = $q.defer();

			AOBResources.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		function changeAAJIRegistration(aajischeduleid, npa, agentcode, aajidate) {

			var req = {
				adapter: "HTTPAdapterAuth",
				procedure: "changeAAJIRegistration",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + aajischeduleid + "','" + npa + "','" + agentcode + "','" + aajidate + "']" }
			};

			var deferred = $q.defer();

			AOBResources.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		function submitAAJIRegistration(aajischeduleid, npa, agentcode, aajiexamdate, statusagent) {

			var req = {
				adapter: "HTTPAdapterAuth",
				procedure: "inputAAJIRegistration",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + aajischeduleid + "','" + npa + "','" + agentcode + "','" + aajiexamdate + "','" + statusagent + "']" }
			};

			var deferred = $q.defer();

			AOBResources.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}


		return {
			invoke: invoke,
			invokeByCandidate: invokeByCandidate,
			changeAAJIRegistration: changeAAJIRegistration,
			submitAAJIRegistration: submitAAJIRegistration
		}
	});

