﻿angular.module('PruForce.services')

    .service('CheckFastStartService', function (CandidateFactory, $q) {


        function invokeSubmit(fstscheduleid, npa, agentcode, couseCode, faststarttype, faststartdate, description) {

            var req = {
                adapter: "HTTPAdapterAuth",
                procedure: "inputFastStartRegistration",
                method: WLResourceRequest.POST,
                parameters: { "params": "['" + fstscheduleid + "','" + npa + "','" + agentcode + "','" + couseCode + "','" + faststarttype + "','" + faststartdate + "','" + description + "']" }
            };

            var deferred = $q.defer();

            CandidateFactory.invoke(req, true)
                .then(function (res) {
                    deferred.resolve(res);
                }, function (error) {
                    deferred.reject(error);
                });

            return deferred.promise;
        }

        function invokeUpdate(fstscheduleid, npa, agentcode, couseCode, faststarttype, faststartdate, description) {

            var req = {
                adapter: "HTTPAdapterAuth",
                procedure: "changeFastStartRegistration",
                method: WLResourceRequest.POST,
                parameters: { "params": "['" + fstscheduleid + "','" + npa + "','" + agentcode + "','" + couseCode + "','" + faststarttype + "','" + faststartdate + "','" + description + "']" }
            };

            var deferred = $q.defer();

            CandidateFactory.invoke(req, true)
                .then(function (res) {
                    deferred.resolve(res);
                }, function (error) {
                    deferred.reject(error);
                });

            return deferred.promise;
        }
        return {
            invokeSubmit: invokeSubmit,
            invokeUpdate: invokeUpdate

        }

    });

