﻿angular.module('PruForce.controllers')
.controller("InquiryProposalPolicyCtrl", function ($scope,$ionicLoading, $ionicScrollDelegate, $location, $filter, $stateParams, ProposalPolicyUnit, ProposalPolicyUnitStatus, ProposalPolicyIndividu, ProposalPolicyStatus, $rootScope, $localStorage) {
	AnalyticsLog.logPage("prudential.inquiry.proposalpolicy.landing");
	var PolicyStatusTab = [];
	//var title = ($stateParams.Type == "1") ? "My Proposal" : "My Policy";
	
	  $scope.inquiriesProposalTabs = [
	  {title: 'Individu', url: 'components/inquiries_proposal_policy/inquiries_proposal_policy_individu.html'},
	  {title: 'Unit', url: 'components/inquiries_proposal_policy/inquiries_proposal_policy_unit_list.html'}
	  ];

	  //Init
	  $scope.currentInquiryTab = $scope.inquiriesProposalTabs[0].url;
	  $scope.ProposalPolicyUnit = ProposalPolicyUnit;
	  getPolicyStatusSuccess(ProposalPolicyUnitStatus);
	  $scope.PolicyStatusTab = PolicyStatusTab;
	  $scope.Type = $stateParams.Type;
	  $scope.ProposalPolicyIndividu = ProposalPolicyIndividu;
	  $scope.ProposalPolicyStatus = ProposalPolicyStatus;
	  $scope.HeadTitle = ($stateParams.Type == "1") ? $filter('translate')('PROPOSAL2') : $filter('translate')('POLICY2');
	  
	  $scope.onClickTab = function (InquiryWidgetTab) {
	    $scope.currentInquiryTab = InquiryWidgetTab;
	  }
	
	  $scope.isActiveTab = function(InquiryWidgetTabUrl) {
	      return InquiryWidgetTabUrl == $scope.currentInquiryTab;
	  }
	
	  $scope.go = function(path){
	    //$location.path(path);
	    $scope.currentInquiryTab = path;
    	localStorage.setItem('currentTabPP',$scope.currentInquiryTab); 
	    $scope.ProposalPolicyUnit = ProposalPolicyUnit;
	    getPolicyStatusSuccess(ProposalPolicyUnitStatus);
	    $scope.PolicyStatusTab = PolicyStatusTab;
	    $scope.Type = $stateParams.Type;
	    $scope.ProposalPolicyIndividu = ProposalPolicyIndividu;
		$scope.ProposalPolicyStatus = ProposalPolicyStatus;
		$ionicScrollDelegate.scrollTop();
	  }
	  
  	$scope.currentInquiryTab = localStorage.getItem('currentTabPP'); 
	  
	  $scope.accordionInit = function(){
		    var accordions = $(".list-info-accordion");
	
		    $.each(accordions, function( index, value ) {
		      var accordionBody = $(value).find(".accordion-body");
	
		      if(!$(value).hasClass("collapsed")){
		        accordionBody.attr("style", "margin-top: -" + accordionBody.height()  + "px;")
		      }
		    });
		  }
	
	  $scope.collapseAccordion = function(e){
	    var self = $(e.toElement);
	    var accordion = self.parents(".list-info-accordion");
	    var accordionBody = accordion.find(".accordion-body");
	
	    if(accordion.hasClass("collapsed")){
	      accordion.removeClass("collapsed");
	      accordionBody.attr("style", "margin-top: -" + accordionBody.height() + "px;");
	    }else{
	      accordion.addClass("collapsed");
	      accordionBody.css("margin-top", 0);
	    }
	  }
	  
	  function getPolicyStatusSuccess(result){
		   	AppsLog.log(" hasil json :"+JSON.stringify(result));
		   	if (result.invocationResult.isSuccessful) {
		   		if (result.invocationResult.array != null) {	
		   			PolicyStatusTab = [];
		   			for(var i = 0 ; i < result.invocationResult.array.length; i++){
		   				PolicyStatusTab.push({"desc" :result.invocationResult.array[i].name.replace("Show All",$filter('translate')('SHOW_ALL')), "key" :result.invocationResult.array[i].value});
		   			}
		   		}
		   	} else if(result.invocationResult.statusCode==500) {
						$ionicLoading.hide();
						AppsLog.log("No data found2. Please try again later!");
				    }else {
		   	   AppsLog.log("No data found. Please try again later!");
		       }
		   	
		   }
  
	  if(!$rootScope.UnitByAgentType){
		  angular.element("#inquiriesProposalPolicyView").removeClass("tabs-non-scroll");
		  angular.element("#inquiriesProposalPolicyContent").removeClass("mtop-header-space");
		  angular.element("#inquiriesProposalPolicyNavTitle").show("false");
		  angular.element("#inquiriesProposalPolicyMenu").show("false");
		  angular.element(".header").removeClass("bar-positive");
		  angular.element(".header").addClass("bar-assertive");
	  }
});

