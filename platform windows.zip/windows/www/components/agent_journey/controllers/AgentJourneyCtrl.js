﻿angular.module('PruForce.controllers')

    .controller('AgentJourneyCtrl', function ($scope, $translate, $filter, $rootScope, $state, $ionicPopup, $ionicLoading, $stateParams, $ionicHistory, CollectStatus, getCreateDate, CandidateDetail, getAMLSCore) {

        $scope.candidateName = $stateParams.candidatename;
        getCreateDateSuccess(getCreateDate);
        function getCreateDateSuccess(res) {
            try {
                if (res[0].result != undefined) {
                    $scope.dateDone = moment(res[0].result.createdate).format('LL');
                }
            } catch (error) {
                AppsLog.log(error);
            }
        }

        getAMLSCoreSuccess(getAMLSCore);
        function getAMLSCoreSuccess(res) {
            if (res.invocationResult.respCode == 200) {
                $rootScope.candidate.amlScore = res.invocationResult.result.score;
            } else {
                $rootScope.candidate.amlScore = 0;
            }
        }

        getCollectStatusSuccess(CollectStatus);
        function getCollectStatusSuccess(res) {
        }

        getCandidateDetailSuccess(CandidateDetail);
        function getCandidateDetailSuccess(res) {
            try {
                $ionicLoading.hide();
                var result = res.json;
                $scope.recruiterCode = result.dataKeagenan.recruitersCode;
                $scope.recruiterName = result.dataKeagenan.recruitersName;
                $scope.recruiterOfficeMarketing = result.dataKeagenan.recruitersOffice;
                $scope.mobilePhone1 = result.dataPribadi.candidateCellularNo1;

                var timeStart = new Date(result.dataUjian.aajiexamstarttime);
                var timeEnd = new Date(result.dataUjian.aajiexamendtime);
                var DataAAJI = [];
                var training = {};
                training.date = moment(result.dataUjian.choosedDate).format("dddd, D MMMM YYYY");
                training.sch = [];
                var childAAJI = {};
                childAAJI.number = 1;
                childAAJI.id = result.dataUjian.choosedId;
                childAAJI.time = timeStart.getFormattedTime() + " - " + timeEnd.getFormattedTime();
                childAAJI.loc = result.dataUjian.choosedLocation;
                childAAJI.endReg = moment(result.dataUjian.choosedDate).format("DD MMMM YYYY");
                training.sch.push(childAAJI);
                DataAAJI.push(training);
                $rootScope.candidate.aajiSchedule = [];
                $rootScope.candidate.aajiSchedule = DataAAJI;

                try {
                    $rootScope.trainingTypeFastStart = result.dataFastStart.trainingType;
                    if (result.dataFastStart.trainingType == 1) {
                        $scope.DataFastStartSchedule = [];
                        $rootScope.fastStartSchedule = {};
                        $rootScope.fastStartSchedule.trainingType = result.dataFastStart.trainingType;
                        $rootScope.fastStartSchedule.faststartlocation = result.dataFastStart.faststartlocation;
                        $rootScope.fastStartSchedule.time = result.dataFastStart.time;
                        $rootScope.fastStartSchedule.part = result.dataFastStart.part;
                        $rootScope.fastStartSchedule.loc = result.dataFastStart.faststartlocation;
                        $rootScope.fastStartSchedule.id = result.dataFastStart.faststartscheduleid;
                        $rootScope.fastStartSchedule.icon = result.dataFastStart.icon;
                        $rootScope.fastStartSchedule.days = result.dataFastStart.days;
                        $rootScope.fastStartSchedule.date = result.dataFastStart.date;
                        $rootScope.fastStartSchedule.month = result.dataFastStart.month;
                        $scope.DataFastStartSchedule.push($rootScope.fastStartSchedule);
                        $rootScope.candidate.fastStartSchedule = [];
                        $rootScope.candidate.fastStartSchedule = $scope.DataFastStartSchedule;
                    }
                } catch (error) {
                    AppsLog.log('error AgentJourneyCtrl :' + error);
                }
            } catch (error) {
                AppsLog.log('error AgentJourneyCtrl :' + error);
            }
        }

        if ($rootScope.candidate.statusAgentJourney == 'complete') {
            $scope.iconStatus = "ion-ios-checkmark balanced";
            $scope.iconStatusKodeEtik = "ion-ios-checkmark balanced";
            $scope.statusDoneAplicationPack = $filter('translate')('THREE');
            $scope.DataKandidatDate = $scope.dateDone;
            $scope.DokumenPendukungDate = $scope.dateDone;
            $scope.SyaratdanKetentuanDate = $scope.dateDone;

            $scope.statusDonePeraturanKodeEtik = $filter('translate')('TWO');
            $scope.statusDoneTrainingMaterial = $filter('translate')('FINISH');
            $scope.statusDoneUjianKodeEtik = $filter('translate')('FINISH');

            $scope.statusDonePruFastStart = $filter('translate')('ONE_DONE');
            $scope.statusDoneTrainingUjian = $filter('translate')('FINISH');

            $scope.statusDonePeraturanKodeEtik = $filter('translate')('TWO');
            $scope.statusDoneTrainingMaterial = $filter('translate')('FINISH');
            $scope.statusDoneUjianKodeEtik = $filter('translate')('FINISH');

            $scope.statusDoneAAJI =$filter('translate')('THREE');
            $scope.statusDonePendaftaranJadwalUjian = $filter('translate')('FINISH');
            $scope.statusDoneSuratInformasiUjian = $filter('translate')('FINISH');
            $scope.statusDoneUjianAAJI = $filter('translate')('TWO');
        } else {
            $scope.iconStatus = "ion-ios-close assertive";
            if ($rootScope.candidate.amlScore != 0) {

                $scope.statusDonePeraturanKodeEtik = $filter('translate')('TWO');
                $scope.statusDoneTrainingMaterial = $filter('translate')('FINISHON') + moment().format('LL');
                $scope.statusDoneUjianKodeEtik = $filter('translate')('FINISHON') + moment().format('LL');
                $scope.iconStatusKodeEtik = "ion-ios-checkmark balanced";
            } else {
                $scope.iconStatusKodeEtik = "ion-ios-close assertive";
                $scope.statusDonePeraturanKodeEtik = $filter('translate')('UNSTARTED');
                $scope.statusDoneTrainingMaterial = $filter('translate')('UNSTARTED');
                $scope.statusDoneUjianKodeEtik = $filter('translate')('UNSTARTED');
            }
            $scope.statusDoneAplicationPack = $filter('translate')('UNSTARTED');
            $scope.DataKandidatDate = $filter('translate')('UNSTARTED');
            $scope.DokumenPendukungDate = $filter('translate')('UNSTARTED');
            $scope.SyaratdanKetentuanDate = $filter('translate')('UNSTARTED');

        }

        $scope.gotoApplicationPack = function () {
            $rootScope.candidate.npa = $stateParams.npanumber;
            if ($rootScope.candidate.statusAgentJourney == 'complete') {
                $rootScope.flagReadOnly = true;

                if ($rootScope.trainingTypeFastStart == undefined) {
                    $rootScope.trainingTypeFastStart = 2;
                } else {
                    $rootScope.trainingTypeFastStart = $rootScope.trainingTypeFastStart;
                }
            } else {
                $rootScope.flagReadOnly = false;
            }
            $state.go("data-kandidat-pack");
        }

        $scope.gotoAMLTraining = function () {
            $rootScope.AlertDialog($filter('translate')('PRU_94'));
        }

        $scope.gotoAAJI = function () {
            $state.go("aaji_agent", { flagReadOnly: true });
        }

        $scope.gotoPRUFastStart = function () {
            $state.go("prufaststart-agent");
        }

        $scope.goBackState = function () {
            $rootScope.reqNewList = false;
            $ionicLoading.show();
            $ionicHistory.nextViewOptions({
                disableAnimate: true,
                disableBack: true
            });
            $state.go('daftar-rekrutment');
        }

    })