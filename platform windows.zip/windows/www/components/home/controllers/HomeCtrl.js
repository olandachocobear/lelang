﻿/**
 * 
 */
angular.module('PruForce.controllers')
	.controller('HomeCtrl', function ($filter, $translate, $scope, $rootScope, $http, $state, $ionicPopup, $ionicSideMenuDelegate, $ionicLoading, findUserWidgetToggle, GetPhotoAgentProfile, getDisclaimerConfig, $localStorage, getUserBonus, AgentProfileData, ListImage) {

		$ionicLoading.hide();
		$scope.userLogin = $rootScope.userLoginName;

		$scope.openpdf = function () {
			var urlusermanual = $filter('translate')('URL_USER_MANUAL');
			$rootScope.openPDF(urlusermanual);
		}

		CheckBonusSuccessListener(getUserBonus);
		function CheckBonusSuccessListener(result) {
			if (result.invocationResult.isSuccessful) {
				localStorage.setItem("flagBonus", result.invocationResult.eligible);
				$scope.statusBonusWidget = result.invocationResult.eligible;
			} else {
				localStorage.setItem("flagBonus", false);
				result.invocationResult.eligible = false;
			}
		}


		//Get user agent profile from NewOds
		getDataAgentProfileSuccess(AgentProfileData);


		function getDataAgentProfileSuccess(result) {
			if (result.invocationResult.isSuccessful) {

				$scope.agentNumber = result.invocationResult.agentNumber;
				$scope.clientName = result.invocationResult.clientName;
				var agentTypeLogin = result.invocationResult.agentType;
				localStorage.setItem("agentTypeLogin", agentTypeLogin);
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}

		function getDataAgentProfileFailed(result) {
			AppsLog.log("Load Data Failed, Please Check Your Connection");
		}
		getImageAgentProfileSuccess(GetPhotoAgentProfile);
		function getImageAgentProfileSuccess(result) {
			if (result.invocationResult.isSuccessful) {
				$("#imageAgentProfile").empty();
				$("#imageAgentProfile").css('background-image', 'url(' + result.invocationResult.text + ')');
			}
		}

		AppsLog.log("START >> HomeCtrl " + new Date());

		$rootScope.ListImage = ListImage;

		$ionicSideMenuDelegate.canDragContent(true);

		//================================== get disclaimer status ==========================//

		GetDisclaimerSuccessListSuccess(getDisclaimerConfig);

		function GetDisclaimerSuccessListSuccess(result) {
			AppsLog.log("START >> GetDisclaimerSuccessListSuccess " + new Date() + " result abi : " + result);
			AppsLog.log(result);

			if (result.isSuccessful) {
				AppsLog.log(result);
				var disclaimerStatus = result.status;
				if (disclaimerStatus == false) {
					$rootScope.alertPopup = $ionicPopup.show({
						title: 'Disclaimer',
						cssClass: 'pop-up-disclaimer',
						templateUrl: 'components/disclaimer/disclaimer.html'
					});
				}
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
			AppsLog.log("END >> GetDisclaimerSuccessListSuccess " + new Date());
		}

		function getDisclaimerFailed(result) {
			AppsLog.log("Load Data Failed, Please Check Your Connection home");
		}
		//================================== end of get disclaimer status ==========================//

		FindUserWidgetToggleListSuccess(findUserWidgetToggle);
		function FindUserWidgetToggleListSuccess(result) {
			AppsLog.log("START >> FindUserWidgetToggleListSuccess " + new Date());
			AppsLog.log(result);
			if (result.invocationResult.isSuccessful) {
				ListUserWidgetToggle = [];
				for (var i = 0; i < result.invocationResult.array.length; i++) {
					var dt = {};
					dt.userId = result.invocationResult.array[i].id_user;
					dt.widgetId = result.invocationResult.array[i].id_widget;
					dt.toggleValue = result.invocationResult.array[i].value_toggle;
					dt.sortValue = result.invocationResult.array[i].value_sort;
					dt.collapseValue = result.invocationResult.array[i].value_collapse;
					ListUserWidgetToggle[i] = dt;
				}
				$scope.ListUserWidgetToggle = ListUserWidgetToggle;
			}

			function UpdateWidgetToggleConfigListFailed(result) {
				AppsLog.log("Data Bank Failed, Please Check Your Connection123");
			}
			AppsLog.log("END >> FindUserWidgetToggleListSuccess " + new Date());
		}

		if ($ionicLoading.show()) {
			$ionicLoading.hide();
		}
		AppsLog.log("END >> HomeCtrl " + new Date());



		$scope.showLeftNav = function () {
			if ($ionicSideMenuDelegate.isOpenLeft()) {
				$ionicSideMenuDelegate.toggleLeft(false);
			}
			else {
				$ionicSideMenuDelegate.toggleLeft(true);
			}
		}

		//this is used when go to achievement landing2 page because this controller used in achievement landing2
		$scope.statusBonusWidget = localStorage.getItem("flagBonus");

		$scope.logout = function () {
			$ionicSideMenuDelegate.toggleLeft(false);
			$rootScope.DialogWithCancel($filter('translate')('PRU_78'), ['logout']);
		}

		$scope.setting = function () {
			$ionicSideMenuDelegate.toggleLeft(false);
			$state.go("setting");
		}
		$scope.listnotif = function () {
			$ionicLoading.show();
			$state.go("notifikasi-user", { 'userId': $rootScope.agent.code });
		}
		$scope.rekrutment = function () {
			if ($rootScope.agent.licenseType == null || $rootScope.agent.licenseType == undefined || $rootScope.agent.licenseType == '') {
				$rootScope.AlertDialog($filter('translate')('PRU_57'));
			} else {
				$ionicLoading.show();
				$ionicSideMenuDelegate.toggleLeft(false);
				$state.go("daftar-rekrutment");
			}
		}

		$scope.aajiAgent = function () {
			$ionicSideMenuDelegate.toggleLeft(false);
			$state.go("aaji_agent", { flagReadOnly: false });
		}

		$ionicLoading.show();
	})