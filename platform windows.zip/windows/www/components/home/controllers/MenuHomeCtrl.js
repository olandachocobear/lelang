﻿
angular.module('PruForce.controllers')

    .controller('MenuHomeCtrl', function ($scope, $translate, $rootScope, $ionicSideMenuDelegate, $state, $ionicLoading, $ionicPopup, $localStorage, $filter, GetPhotoAgentProfile, getUserPermitted, GetListInbox) {

        var bodyHeight = $('body').height();
        var rowHeight = parseInt(bodyHeight) - $('.bottom-menu-container').height() - $('.bar.bar-header.bar-assertive').height() - 20;
        $('#menu-home').css('height', rowHeight + "px");
        $(window).resize(function () {
            bodyHeight = $('body').height();
            rowHeight = parseInt(bodyHeight) - $('.bottom-menu-container').height() - $('.bar.bar-header.bar-assertive').height() - 20;
            $('#menu-home').css('height', rowHeight + "px");
        });

        if ($rootScope.agent.userType == 'candidate' || $rootScope.agent.userType == 'CANDIDATE') {
            $scope.MenuList = {
                'CONTACTSUPPORT': true,
                'LIST_RECRUITMENT': false
            };
        }

        getListInboxSuccess(GetListInbox);
        function getListInboxSuccess(res) {
            if (res.invocationResult.statusCode == 200) {
                if (res.invocationResult.array != null) {
                    $rootScope.inbox.Length = res.invocationResult.array.length;
                }
            } else {
                $rootScope.inbox.Length = 0;
            }

        }
        $scope.homeAction = function () {
            $ionicLoading.show();
            $state.go('home-menu.agent', null, { reload: true });
            $ionicSideMenuDelegate.toggleLeft(false);
        }

        $scope.logout = function () {
            $ionicSideMenuDelegate.toggleLeft(false);
            $rootScope.DialogWithCancel($filter('translate')('PRU_78'), ['logout']);
        }

        $scope.setting = function () {
            $ionicSideMenuDelegate.toggleLeft(false);
            $state.go("setting");
        }

        $scope.listnotif = function () {
            $ionicLoading.show();
            if ($rootScope.agent.userType == 'candidate' || $rootScope.agent.userType == 'CANDIDATE') {
                $state.go("notifikasi-user", { 'userId': $rootScope.candidate.npa });
            } else {
                $state.go("notifikasi-user", { 'userId': $rootScope.agent.code });
            }
        }
        $scope.rekrutment = function () {
            $rootScope.reqNewList = true;
            $ionicSideMenuDelegate.toggleLeft(false);
            $ionicLoading.show();
            $state.go("daftar-rekrutment");
        }

        $scope.aajiAgent = function () {
            $rootScope.mandatoryBuktiBayar = true;
            $scope.flagReadOnly = false;
            $ionicSideMenuDelegate.toggleLeft(false);
            $state.go("aaji_agent");
        }

        $scope.GoAMLTraining = function () {
            if ($rootScope.candidate.amlScore > 59) {
                $rootScope.AlertDialog($filter('translate')('PRU_71'));
            } else {
                $state.go("intro-training-material");
            }
        }

        $scope.GoUjianKodeEtik = function () {
            if ($rootScope.candidate.amlScore > 59) {
                $rootScope.AlertDialog($filter('translate')('PRU_71'));
            } else if (localStorage['AML' + $rootScope.candidate.npa]) {
                $state.go("ujian-peraturan-dan-kode-etik");
            } else {
                $rootScope.AlertDialog($filter('translate')('PRU_70'));
            }
        }

        $scope.achievement = function () {
            $('#rightNotif').removeClass('hide');
            $state.go("achievement_landing");
            $ionicSideMenuDelegate.toggleLeft();
        }

        $scope.newsUpdates = function () {
            $('#rightNotif').removeClass('hide');
            $state.go("news_updates");
            $ionicSideMenuDelegate.toggleLeft();
        }

        $scope.faq = function () {
            $state.go("faq");
            $ionicSideMenuDelegate.toggleLeft();
        }

        $scope.inquiry = function () {
            AppsLog.log("masuk inquiry");
            $state.go("inquiry");
            $ionicSideMenuDelegate.toggleLeft();
        }

        $scope.agenProfile = function () {
            $state.go("agent_profile");
            $ionicSideMenuDelegate.toggleLeft();
        }

        $scope.userManual = function () {
            $state.go("public_page_daftar_informasi");
            $ionicSideMenuDelegate.toggleLeft();
        }

        $scope.contest = function () {
            $state.go("contest-tab");
            $ionicSideMenuDelegate.toggleLeft();
        }

        getImageAgentProfileSuccess(GetPhotoAgentProfile);
        function getImageAgentProfileSuccess(result) {
            if (result.invocationResult.statusCode == 200) {
                $scope.imageAgentProfile = result.invocationResult.text;
                $rootScope.getPhotoProfile = result.invocationResult.text;
            } else {
                $scope.imageAgentProfile = './img/ionic/agent-profile.png';
                $rootScope.getPhotoProfile = undefined;
            }
        }

        $scope.newsqs = function () {
            $ionicLoading.show();
            $state.go("daftar-newsqs");
            $ionicSideMenuDelegate.toggleLeft(false);
        }

        $scope.gotoApplicationPack = function () {
            var data = $rootScope.candidate.agentjourney;
            var agCount = $rootScope.candidate.countagentjourney;
            if (data.length != 0 && agCount != 0) {
                $rootScope.AlertDialog($filter('translate')('PRU_42'));
            } else if (localStorage['CandidateSubmit' + $rootScope.candidate.npa]) {
                $rootScope.AlertDialog($filter('translate')('PRU_42'));
            } else {
                $ionicLoading.show();
                $scope.flagReadOnly = false;
                $state.go("data-kandidat-pack");
            }

        }
        $scope.isRolePD = function () {
            return $rootScope.pd
        }

    })