﻿/**
 * 
 */

angular.module('PruForce.controllers')

	.controller('InquiriesProductionUnitCtrl', function ($scope, $http) {

		AppsLog.log("START >> InquiriesProductionUnitCtrl " + new Date());

		$scope.getMTDProductionUnitListSuccess = getMTDProductionUnitListSuccess;

		$scope.init = function (result) {
			AppsLog.log("START >> InitInquiriesProductionUnitCtrl " + new Date());
			getMTDProductionUnitListSuccess(result);
			AppsLog.log("END >> InquiriesProductionUnitCtrl " + new Date());
		}

		function getMTDProductionUnitListSuccess(result) {
			if (result.invocationResult.isSuccessful) {

				var MTDUnitProduction = result.invocationResult.APENET;
				var YTDUnitProduction = result.invocationResult.TOTALAPE;

				var MTDUnit = MTDUnitProduction.substring(0, 18)
				var YTDUnit = YTDUnitProduction.substring(0, 18)

				var PodMTDUnit = Number(MTDUnit);
				var ProdYTDUnit = Number(YTDUnit);

				$scope.MTDProductionUnit = PodMTDUnit.formatMoney(2, '.', ',');
				$scope.$apply();
				$scope.YTDProductionUnit = ProdYTDUnit.formatMoney(2, '.', ',');

				$scope.$apply();
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}

		function getMTDProductionUnitListFailed(result) {
			AppsLog.log("Data Bank Failed, Please Check Your Connection");
		}

		AppsLog.log("END >> InquiriesProductionUnitCtrl " + new Date());
	})  