﻿angular.module('PruForce.controllers')

	.controller('InquiriesProductionCtrl', function ($scope, $http) {
		AppsLog.log("START >> InquiriesProductionCtrl " + new Date());

		$scope.init = function (result) {
			var retrieveDate2 = new Date(result.retrieveDate);
			var momentDate = moment(retrieveDate2).format('LLLL');
			$scope.lastUpdate = momentDate;
		}

		AppsLog.log("END >> InquiriesProductionCtrl " + new Date());
	})