﻿/**
 * 
 */


angular.module('PruForce.controllers')

	.controller('AchievementLandingCtrl', function ($translate, $scope, $rootScope, $ionicLoading, $http, $ionicPopup, $ionicSideMenuDelegate) {

		AppsLog.log("START >> AchievementLandingCtrl " + new Date());

		$ionicSideMenuDelegate.canDragContent(true);

		if (g_agentdetail.isretaker) {
			checkingIsRetaker($rootScope.agent.code);
		}
		$scope.showLeftNav = function () {
			if ($ionicSideMenuDelegate.isOpenLeft()) {
				$ionicSideMenuDelegate.toggleLeft(false);
			}
			else {
				$ionicSideMenuDelegate.toggleLeft(true);
			}
		}

		$scope.statusBonus = localStorage.getItem("flagBonus");
		AppsLog.log("END >> AchievementLandingCtrl " + new Date());
	})