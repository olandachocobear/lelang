﻿angular.module('PruForce.controllers')

	.controller('InquiriesProductionIndividuCtrl', function ($scope, $http) {

		AppsLog.log("START >> InquiriesProductionIndividuCtrl " + new Date());

		$scope.getMTDProductionIndividuListSuccess = getMTDProductionIndividuListSuccess;

		$scope.init = function (result) {
			AppsLog.log("START >> InitInquiriesProductionIndividuCtrl " + new Date());
			getMTDProductionIndividuListSuccess(result);
			AppsLog.log("END >> InitInquiriesProductionIndividuCtrl " + new Date());
		}


		function getMTDProductionIndividuListSuccess(result) {
			if (result.invocationResult.isSuccessful) {
				//get current month and year

				var MTDIndividuProduction = result.invocationResult.APENET;
				var YTDIndividuProduction = result.invocationResult.TOTALAPE;

				var MTDInd = MTDIndividuProduction.substring(0, 18)
				var YTDInd = YTDIndividuProduction.substring(0, 18)

				var PodMTDIndv = Number(MTDInd);
				var ProdYTDIndv = Number(YTDInd);

				$scope.MTDProductionIndividu = PodMTDIndv.formatMoney(2, '.', ',');
				$scope.YTDProductionIndividu = ProdYTDIndv.formatMoney(2, '.', ',');

				var retrieveDate2 = new Date(result.retrieveDate);
				var retrieveDate3 = retrieveDate2.toString();
				var retrieveDate4 = retrieveDate3.substring(0, 25);
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}

		function getMTDProductionIndividuListFailed(result) {
			AppsLog.log("Data Bank Failed, Please Check Your Connection");
		}

		AppsLog.log("END >> InquiriesProductionIndividuCtrl " + new Date());
	})