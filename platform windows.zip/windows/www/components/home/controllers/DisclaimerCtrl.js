﻿/**
 * 
 */

angular.module('PruForce.controllers')


	.controller('DisclaimerCtrl', function ($scope, $interval, $state, $http, getDisclaimerConfig) {

		AppsLog.log("START >> DisclaimerCtrl " + new Date());

		$('#rightNotif').removeClass('hide');


		getDisclaimerSuccess(getDisclaimerConfig);

		function getDisclaimerSuccess(result) {

			AppsLog.log("START >> getDisclaimerSuccess " + new Date());
			if (result.invocationResult.isSuccessful) {
	               AppsLog.log("berhasil invoke disclaimer");
	               AppsLog.log(result);
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
			AppsLog.log("END >> getDisclaimerSuccess " + new Date());
		}

		function getDisclaimerFailed(result) {
			AppsLog.log("Load Data Failed, Please Check Your Connection disclaimer");
		}

		AppsLog.log("END >> DisclaimerCtrl " + new Date());

	})
