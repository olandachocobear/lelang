﻿angular.module('PruForce.controllers')
	.controller("ProposalHomeCtrl", function ($scope, $rootScope, $state, findProposalHomeGraphService, PDfindProposalHomeGraphService, findLastUpdateService, $q, $filter) {
		$scope.loading = true;
		$scope.loadingSmall = true;
		$scope.successCall = true;
		$scope.successResult = true;

		$scope.findProposalHomeGraphService = findProposalHomeGraphService;
		$scope.findLastUpdateService = findLastUpdateService;

		$scope.initProposalHome = function (result) {
			getDataHomeProposalGraphSuccess(result);
		};

		$scope.init = function () {
			$scope.loading = true;
			$scope.loadingSmall = true;
			$scope.successCall = true;
			$scope.successResult = true;
			if($rootScope.pd){
				initPD();
			} else {
				initAgency();
			}
			var qfindLastUpdateService = findLastUpdateService.invoke($rootScope.agent.code, $rootScope.username, true).then(function (res) {
				getMyProposalLastUpdateSuccess(res);
				$scope.loading = false;
			});
		}

		function initAgency(){
			var qfindProposalHomeGraphService = findProposalHomeGraphService.invoke($rootScope.agent.code, $rootScope.username, true).then(function (res) {
				getDataHomeProposalGraphSuccess(res)
				$scope.loading = false;
			});
		}

		function prepareAgencyData(){
			collection = JsonStoreConfig['findProposalHomeGraph'];
			$scope.$on(collection.JSONSTORE_NAME, function (event, args) {
				$scope.successCall = (args.status == "success") ? true : false;

				var qfindProposalHomeGraphService = findProposalHomeGraphService.invoke($rootScope.agent.code, $rootScope.username, false).then(function (res) {
					getDataHomeProposalGraphSuccess(res)
				});

				$q.all([qfindProposalHomeGraphService]).then(function () {
					$scope.loadingSmall = false;
					$scope.loading = false;
				});
			});
		}

		function initPD(){
			var qfindProposalHomeGraphService = PDfindProposalHomeGraphService.invoke($rootScope.agent.code, $rootScope.username, true).then(function (res) {
				getDataHomeProposalGraphSuccess(res)
				$scope.loading = false;
			});
		}

		function preparePDData(){
			collection = JsonStoreConfig['findProposalHomeGraphPD'];
			$scope.$on(collection.JSONSTORE_NAME, function (event, args) {
				$scope.successCall = (args.status == "success") ? true : false;

				var qfindProposalHomeGraphService = PDfindProposalHomeGraphService.invoke($rootScope.agent.code, $rootScope.username, false).then(function (res) {
					getDataHomeProposalGraphSuccess(res)
				});

				$q.all([qfindProposalHomeGraphService]).then(function () {
					$scope.loadingSmall = false;
					$scope.loading = false;
				});
			});
		}

		$scope.headerTitle = 'PROPOSAL';

		if($rootScope.pd){
			preparePDData();
			if($rootScope.UnitByAgentType == true){
				$scope.headerTitle = 'PROPOSAL_UNIT';
			}
		} else {
			prepareAgencyData();
		}

		collection = JsonStoreConfig['findLastUpdateProposalPolicy'];
		$scope.$on(collection.JSONSTORE_NAME, function (event, args) {
			$scope.successCall = (args.status == "success") ? true : false;

			var qfindLastUpdateService = findLastUpdateService.invoke($rootScope.agent.code, $rootScope.username, false).then(function (res) {
				getMyProposalLastUpdateSuccess(res);
			});

			$q.all([qfindLastUpdateService]).then(function () {
				$scope.loadingSmall = false;
				$scope.loading = false;
			});
		});

		$scope.init();

		$scope.proposalWidgetTabs = [{
			title: 'individu',
			url: 'individu.proposal'
		},
			{
				title: 'unit',
				url: 'unit.proposal'
			}];
		$scope.currentproposalWidgetTab = 'individu.proposal';

		$scope.onClickTab = function (proposalWidgetTab) {
			$scope.currentproposalWidgetTab = proposalWidgetTab.url;
		}

		$scope.isActiveTab = function (proposalWidgetTabUrl) {
			return proposalWidgetTabUrl == $scope.currentproposalWidgetTab;
		}

		function getDataHomeProposalGraphSuccess(result) {

			if (result.invocationResult.statusCode == 200) {
				$scope.proposal = result.invocationResult.P;
				$scope.UA = result.invocationResult.UA;

				$scope.decline = result.invocationResult.DC;
				$scope.postpone = result.invocationResult.PO;
				$scope.withdrawn = result.invocationResult.WD;
				$scope.total = result.invocationResult.total;

				// request pru for group 3 status
				$scope.total3group = ($scope.decline + $scope.postpone + $scope.withdrawn);

				$scope.dataIndividu = [
					{
						value: $scope.proposal,
						color: '#696a6c',
						highlight: '#aeacac',
						label: $filter('translate')('PROPOSAL2')
					},
					{
						value: $scope.UA,
						color: '#48752a',
						highlight: '#538532',
						label: $filter('translate')('UW-APPROVAL')
					},
					{
						value: $scope.decline,
						color: '#ec1b2c',
						highlight: '#f5404f',
						label: $filter('translate')('DECLINE')
					},
					{
						value: $scope.postpone,
						color: '#fdc056',
						highlight: '#edc370',
						label: $filter('translate')('POSTPONE')
					},
					{
						value: $scope.withdrawn,
						color: '#592989',
						highlight: '#ce93d8',
						label: $filter('translate')('WITHDRAWN')
					}
				];

				$scope.dataUnit = [
					{
						value: 78,
						color: '#ee1b2c',
						highlight: '#f5404f',
						label: 'Inforced'
					},
					{
						value: 25,
						color: '#4b79bc',
						highlight: '#6493d9',
						label: 'Lapsed'
					},
					{
						value: 15,
						color: '#eabc5f',
						highlight: '#edc370',
						label: 'Surrendered'
					},
					{
						value: 12,
						color: '#9c9c9c',
						highlight: '#aeacac',
						label: 'Void from inception'
					},
					{
						value: 15,
						color: '#48752a',
						highlight: '#538532',
						label: 'Canceled'
					}
				];

				// Chart.js Options
				$scope.options = {

					// Sets the chart to be responsive

					//Boolean - Whether we should show a stroke on each segment
					segmentShowStroke: false,

					//String - The colour of each segment stroke
					segmentStrokeColor: '#fff',

					//Number - The width of each segment stroke
					segmentStrokeWidth: 2,

					//Number - The percentage of the chart that we cut out of the middle
					percentageInnerCutout: 0, // This is 0 for Pie charts

					//Number - Amount of animation steps
					animationSteps: 100,

					//String - Animation easing effect
					animationEasing: 'easeOutBounce',

					//Boolean - Whether we animate the rotation of the Doughnut
					animateRotate: true,

					//Boolean - Whether we animate scaling the Doughnut from the centre
					animateScale: false,

					//String - A legend template
					legendTemplate: '<ul class="tc-chart-js-legend"><% for (var i=0; i<segments.length; i++){%><li><span style="background-color:<%=segments[i].fillColor%>"></span><%if(segments[i].label){%><%=segments[i].value%> <%=segments[i].label%><%}%></li><%}%></ul>'

				};
			} else {
				AppsLog.log("No data found. Please try again later!");
				$scope.successResult = false;
			}
		}

		function getDataHomeProposalGraphFailed(result) {
			AppsLog.log("Load Data Failed, Please Check Your Connection");
		}

		function getMyProposalLastUpdateSuccess(result) {
			if (result.invocationResult.statusCode == 200) {
				var lastUpdateProp = result.invocationResult.latest;
				var lastUpdate = moment(lastUpdateProp).format('LLLL');
				$scope.lastUpdateProp = lastUpdate;
			} else {
				$scope.successResult = false;
			}
		}

		$scope.goToProposalList = function(){
			if($rootScope.pd){
				$state.go("pd_inquiries_list_proposal_policy", {"Flag": "1"});
			} else {
				$state.go("inquiries_proposal", {"Type": "1"});
			}
		}
	})