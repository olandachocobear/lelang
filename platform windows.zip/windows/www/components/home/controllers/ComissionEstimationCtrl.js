﻿angular.module('PruForce.controllers')
	.controller('ComissionEstimationCtrl', function ($scope, $rootScope, $http, ComissionEstimationByAgentNumberService, $q, $interval) {
		AppsLog.log("START >> ComissionEstimationCtrl " + new Date());
		AnalyticsLog.logPage("prudential.comission.est.inq");

		var objid = "MSINQCOMM";
		var agentNumber = $rootScope.agent.code;

		$scope.ComissionEstimationByAgentNumberService = ComissionEstimationByAgentNumberService;
		$scope.loading = true;
		$scope.loadingSmall = true;
		$scope.successResult = true;
		$scope.successCall = true;

		$scope.init = function () {
			$scope.loading = true;
			$scope.loadingSmall = true;
			$scope.successResult = true;
			$scope.successCall = true;

			ComissionEstimationByAgentNumberService.invoke($rootScope.agent.code, $rootScope.username, true)
				.then(function (res) {
					getDataComissionEstimationListSuccess(res);
					$scope.loading = false;
				});
		}

		collection = JsonStoreConfig['findAllComissionEstimationByAgentNumber'];
		$scope.$on(collection.JSONSTORE_NAME, function (event, args) {
			$scope.successCall = (args.status == "success") ? true : false;

			ComissionEstimationByAgentNumberService.invoke($rootScope.agent.code, $rootScope.username, false)
				.then(function (res) {
					getDataComissionEstimationListSuccess(res);
					$scope.loading = false;
					$scope.loadingSmall = false;
				}, function () {
					$scope.loading = false;
					$scope.loadingSmall = false;
				});
		});

		$scope.init();

		function getDataComissionEstimationListSuccess(result) {
			if (result.invocationResult.statusCode == 200) {
				//retrieve last update date
				var d = new Date();
				var n = d.getMonth();
				var currentMonth;

				var retrieveDate2 = new Date(result.retrieveDate);
				var momentDate = moment(retrieveDate2).format('LLLL');
				var retrieveDate4 = momentDate.toString();
				$scope.lastUpdate = momentDate;

				$scope.currentFullYear = d.getFullYear();

				var momentMonth = moment(d).format('MMMM');
				var momentMonth2 = momentMonth.toString();
				$scope.currentMonth = momentMonth2;

				//get current month and year
				clearCollection($rootScope.COLLECTION_COMISSIONESTIMATION);

				var GROSSCOMM = result.invocationResult.GROSSCOMM;
				var TOTCOMM = result.invocationResult.TOTCOMM;
				var comissionDot = ".";
				var insertPosition = 15;

				var GROSSCOMM2 = [GROSSCOMM.slice(0, insertPosition), comissionDot, GROSSCOMM.slice(insertPosition)].join('');
				var GROSSCOMM3 = GROSSCOMM2.substring(0, 18);
				var TOTCOMM2 = [TOTCOMM.slice(0, insertPosition), comissionDot, TOTCOMM.slice(insertPosition)].join('');
				var TOTCOMM3 = TOTCOMM2.substring(0, 18);

				var GROSSCOMM4 = Number(GROSSCOMM3);
				var TOTCOMM4 = Number(TOTCOMM3);
				$scope.comissionIDR = TOTCOMM4.formatMoney(2, '.', ',');
				$scope.comissionUSD = GROSSCOMM4.formatMoney(2, '.', ',');

				var comissionArray = {};
				comissionArray.objid = objid;
				comissionArray.agntsel = agentNumber;
				comissionArray.GROSSCOMM = GROSSCOMM4.formatMoney(2, '.', ',');
				comissionArray.TOTCOMM = TOTCOMM4.formatMoney(2, '.', ',');
				comissionArray.lastUpdate = retrieveDate4;
				var ListcomissionArray = [];
				ListcomissionArray = comissionArray;
				addDataComissionEstimate($rootScope.COLLECTION_COMISSIONESTIMATION, ListcomissionArray);
			} else {
				AppsLog.log("No data found. Please try again later!");
				$scope.successResult = false;
			}
		}

		function getDataComissionEstimationListFailed(result) {
			AppsLog.log("Data Bank Failed, Please Check Your Connection");
		}

		AppsLog.log("END >> ComissionEstimationCtrl " + new Date());
	})
