﻿/**
 * 
 */


angular.module('PruForce.controllers')

	.controller('Ctrl', function ($scope, $rootScope, $ionicLoading, $filter, $state, $stateParams, $translate, $localStorage, UpdateWidgetSortingConfigService, UpdateWidgetCollapseConfigService, findUserWidgetToggleService, $ionicScrollDelegate) {
		var toggleWidget;
		var networkState = navigator.connection.type;

        localStorage.setItem('currentTabProduction', 'mtd1');
		localStorage.setItem('currentTabToDo', 'components/toDo/to_do_my_tasks.html');
		localStorage.setItem('currentTabPP', 'components/inquiries_proposal_policy/inquiries_proposal_policy_individu.html');
        localStorage.setItem('currentTabPersistency', 'persistency-mtd');
        localStorage.setItem('currentTabContest', 'components/contest/my_contest.html');

		$scope.init = function (ListUserWidgetToggle, ListUserAppConfigFinal) {
			toggleWidget = ListUserWidgetToggle;
			userAppConfig = ListUserAppConfigFinal;

			ListUserWidgetForToggle = toggleWidget;
			$scope.toggleWidgetContent = function () {
				angular.element(event.target).parent().parent().children().toggleClass('collapse');
			};


			$scope.widgetProductionTabs = [{
				title: 'mtd',
				url: 'mtd'
			}, {
					title: 'ytd',
					url: 'ytd'
				}];


			$scope.dataAchiever = [
				{
					value: 50,
					color: '#48752a',
					highlight: '#538532',
					label: 'Postpone'
				},
				{
					value: 38,
					color: '#fff',
					highlight: '#538532',
					label: 'Postpone'
				}
			];
			// Chart.js Options
			$scope.options = {

				// Sets the chart to be responsive
				responsive: false,

				//Boolean - Whether we should show a stroke on each segment
				segmentShowStroke: false,

				//String - The colour of each segment stroke
				segmentStrokeColor: '#000',

				//Number - The width of each segment stroke
				segmentStrokeWidth: 20,

				//Number - The percentage of the chart that we cut out of the middle
				percentageInnerCutout: 0, // This is 0 for Pie charts

				//Number - Amount of animation steps
				animationSteps: 100,

				//String - Animation easing effect
				animationEasing: 'easeOutBounce',

				//Boolean - Whether we animate the rotation of the Doughnut
				animateRotate: true,

				//Boolean - Whether we animate scaling the Doughnut from the centre
				animateScale: false,

				//String - A legend template
				legendTemplate: '<ul class="tc-chart-js-legend"><li><%=segments[0].value%>%</li></ul>'

			};

			$scope.currentwidgetProductionTab = 'mtd';

			$scope.onClickTab = function (widgetProductionTab) {
				$scope.currentwidgetProductionTab = widgetProductionTab.url;
			}

			$scope.isActiveTab = function (widgetProductionTabUrl) {
				return widgetProductionTabUrl == $scope.currentwidgetProductionTab;
			}

			$scope.buttonSettingText = $filter('translate')('BUTTON_SETTING_WIDGET');
			var orderBy = $filter('orderBy');

			//change sort order by sortValue ascending
			$scope.ListUserWidgetForToggle = orderBy(ListUserWidgetForToggle, 'sortValue', false);

			//get list widget from server or JSONStore
			ListWidgetSort = [];
			var countToggle = 0;
			var statusToggle = true;
			if ($scope.ListUserWidgetForToggle != null) {
				for (var i = 0; i < $scope.ListUserWidgetForToggle.length; i++) {
					ListWidgetSort[i] = [];
					ListWidgetSort[i]["widgetId"] = ($scope.ListUserWidgetForToggle[i].widgetId).toString();;
					ListWidgetSort[i]["sortValue"] = $scope.ListUserWidgetForToggle[i].sortValue;
					ListWidgetSort[i]["toggleValue"] = $scope.ListUserWidgetForToggle[i].toggleValue;
					ListWidgetSort[i]["collapseValue"] = $scope.ListUserWidgetForToggle[i].collapseValue;
					if (!ListWidgetSort[i]["toggleValue"]) {
						countToggle++;
					}
					if ($scope.ListUserWidgetForToggle.length == countToggle) {
						statusToggle = false
					}
				}
			}

			var listWidgetSortFinal = ListWidgetSort;

			$scope.widgetItems = listWidgetSortFinal;

			console.info("widget Ctrl");
			console.info($scope.widgetItems);
			var count = 0;
			$scope.updateWidgetOrder = function () {
				UpdateWidgetSortingConfigService.update(count, $rootScope.agent.code, parseInt($scope.widgetItems[count].widgetId)).then(function (res) {
					count++;
					if (count < $scope.widgetItems.length) {
						$scope.updateWidgetOrder();
					}
				}, function (error) {
					count++;
					if (count < $scope.widgetItems.length) {
						$scope.updateWidgetOrder();
					}
				});
			}

			$scope.changeCollapse = function (collapsevalue, widgetid, index) {

				$scope.widgetItems[index].collapseValue = collapsevalue;

				UpdateWidgetCollapseConfigService.update(collapsevalue, $rootScope.agent.code, parseInt(widgetid));
				setTimeout(function(){
					$ionicScrollDelegate.$getByHandle('homeContent').resize();
				}, 510);
			}

			$scope.onReorder = function (fromIndex, toIndex) {
				var moved = $scope.widgetItems.splice(fromIndex, 1);

				$scope.widgetItems.splice(toIndex, 0, moved[0]);
				count = 0;
				$scope.updateWidgetOrder();

			};

			/*Please fill value after widgetId == with widgetId for the correspondent widget as in table widget on server. 
			for example contest have widgetId 5 so the result will be widgetId == 5
			Thank you
			*/
			if (ListUserWidgetForToggle != null) {
				for (var i = 0; i < ListUserWidgetForToggle.length; i++) {
					if (ListUserWidgetForToggle[i].widgetId == 3) {
						$scope.statusViewComission = ListUserWidgetForToggle[i].toggleValue;
					}
					else if (ListUserWidgetForToggle[i].widgetId == 4) {
						$scope.statusViewProduction = ListUserWidgetForToggle[i].toggleValue;
					}
					else if (ListUserWidgetForToggle[i].widgetId == 5) {
						$scope.statusViewPersistency = ListUserWidgetForToggle[i].toggleValue;
					}
					else if (ListUserWidgetForToggle[i].widgetId == 7) {
						$scope.statusViewProposal = ListUserWidgetForToggle[i].toggleValue;
					}
					else if (ListUserWidgetForToggle[i].widgetId == 11) {
						$scope.statusViewPolicy = ListUserWidgetForToggle[i].toggleValue;
					}
					else if (ListUserWidgetForToggle[i].widgetId == 16) {
						var statusWidgetBonus = ListUserWidgetForToggle[i].toggleValue;
						var flagBonus = localStorage.getItem("flagBonus");
						if (flagBonus == "true" && statusWidgetBonus == true) {
							$scope.statusBonus = true;
						} else {
							$scope.statusBonus = false;
						}
					}
					else if (ListUserWidgetForToggle[i].widgetId == 2) {
						$scope.statusNewsUpdate = ListUserWidgetForToggle[i].toggleValue;
					}
					else if (ListUserWidgetForToggle[i].widgetId == 10) {
						$scope.statusViewContest = ListUserWidgetForToggle[i].toggleValue;
					}


					AppsLog.log("ListUserWidget >>> " + ListUserWidgetForToggle[i].widgetId);
				}
			}



			//************************************** update widget toggle to server**************************************//
			WL.JSONStore.get('findingUserWidgetToggleNew1').findAll().then(function (res) {
				try {
					if (res.length > 0) {
						result = res[0].json;
						AppsLog.log("test update toggle when online on home");
						AppsLog.log("JsonStore before update");
						AppsLog.log(result);
						for (i = 0; i < result.invocationResult.array.length; i++) {
							AppsLog.log("test loop");
							resultSet = result.invocationResult.array[i];
							if (resultSet.id_user == $rootScope.agent.code) {
								AppsLog.log(resultSet);

								var request = {
									adapter: "HTTPAdapterGeneral",
									procedure: "updateWidgetToggleConfig",
									method: WLResourceRequest.POST,
									parameters: { "params": "['" + resultSet.value_toggle + "','" + resultSet.id_user + "','" + resultSet.id_widget + "']" }
								};


								var resourceRequest = new WLResourceRequest(
									"adapters/" + request.adapter + "/" + request.procedure,
									request.method
								);

								resourceRequest.setHeader("X-CSRF-Token", "Bearer " + $localStorage.access_token);
								resourceRequest.sendFormParameters(request.parameters).then(onSuccess, onFailure)

							}
						}

						AppsLog.log("Jsonstore after update");
						AppsLog.log(result);
					} else {
						throw new Error("Local data is empty : findingUserWidgetToggleNew1");
					}
				} catch (error) {
					AppsLog.log("failed to retrieve jsonstore findingUserWidgetToggleNew1");
				}
			}).fail(function (error) {
				AppsLog.log("failed to retrieve jsonstore findingUserWidgetToggleNew1");
			});
			//***********************************end of update to server*************************//

			if (!statusToggle) {
				$scope.buttonSettingText = $filter('translate')('BUTTON_ADD_WIDGET');
			}

			if ($ionicLoading.show()) {
				$ionicLoading.hide();
			}

		};

		function onApiSuccess(result) {
			AppsLog.log("success update to server " + JSON.stringify(result));
		}

		function onApiFailure(error) {
			AppsLog.log("failed update to server");
			AppsLog.log(error);
		}



	})
