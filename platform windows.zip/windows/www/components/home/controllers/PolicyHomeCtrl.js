﻿angular.module('PruForce.controllers')
	.controller("PolicyHomeCtrl", function ($scope, $rootScope, $state, TotalPolicyGraphService, PDTotalPolicyGraphService, findLastUpdateService,  $q, $filter) {
		$scope.loading = true;
		$scope.loadingSmall = true;
		$scope.successCall = true;
		$scope.successResult = true;

		$scope.findLastUpdateService = findLastUpdateService;
		$scope.TotalPolicyGraphService = TotalPolicyGraphService;
		$scope.initPolicyHome = function (result) {
			getDataHomePolicyGraphSuccess(result);
		};

		$scope.init = function () {
			$scope.loading = true;
			$scope.loadingSmall = true;
			$scope.successCall = true;
			$scope.successResult = true;
			if($rootScope.pd){
				initPD();
			} else {
				initAgency();
			}
			var qfindLastUpdateService = findLastUpdateService.invoke($rootScope.agent.code, $rootScope.username, true).then(function (res) {
				getMyProposalLastUpdateSuccess(res);
				$scope.loading = false;
			});
		}

		function initAgency(){
			var qTotalPolicyGraphService = TotalPolicyGraphService.invoke($rootScope.agent.code, $rootScope.username, true).then(function (res) {
				getDataHomePolicyGraphSuccess(res);
				$scope.loading = false;
			});
		}

		function prepareAgencyData(){
			collection = JsonStoreConfig['findTotalPolicyGraph'];
			$scope.$on(collection.JSONSTORE_NAME, function (event, args) {
				$scope.successCall = (args.status == "success") ? true : false;

				var qTotalPolicyGraphService = TotalPolicyGraphService.invoke($rootScope.agent.code, $rootScope.username, false)
					.then(function (res) {
						getDataHomePolicyGraphSuccess(res);
					});

				$q.all([qTotalPolicyGraphService]).then(function () {
					$scope.loadingSmall = false;
					$scope.loading = false;
				});
			});
		}

		function initPD(){
			var qTotalPolicyGraphService = PDTotalPolicyGraphService.invoke($rootScope.agent.code, $rootScope.username, true).then(function (res) {
				getDataHomePolicyGraphSuccess(res);
				$scope.loading = false;
			});
		}

		function preparePDData(){
			collection = JsonStoreConfig['findTotalPolicyGraphPD'];
			$scope.$on(collection.JSONSTORE_NAME, function (event, args) {
				$scope.successCall = (args.status == "success") ? true : false;

				var qTotalPolicyGraphService = PDTotalPolicyGraphService.invoke($rootScope.agent.code, $rootScope.username, false)
					.then(function (res) {
						getDataHomePolicyGraphSuccess(res);
					});

				$q.all([qTotalPolicyGraphService]).then(function () {
					$scope.loadingSmall = false;
					$scope.loading = false;
				});
			});
		}

		$scope.headerTitle = 'POLICY';

		if($rootScope.pd){
			preparePDData();
			if($rootScope.UnitByAgentType == true){
				$scope.headerTitle = 'POLICY_UNIT';
			}
		} else {
			prepareAgencyData();
		}

		collection = JsonStoreConfig['findLastUpdateProposalPolicy'];
		$scope.$on(collection.JSONSTORE_NAME, function (event, args) {
			$scope.successCall = (args.status == "success") ? true : false;

			var qfindLastUpdateService = findLastUpdateService.invoke($rootScope.agent.code, $rootScope.username, false)
				.then(function (res) {
					getMyProposalLastUpdateSuccess(res);
				});

			$q.all([qfindLastUpdateService]).then(function () {
				$scope.loadingSmall = false;
				$scope.loading = false;
			});
		});

		$scope.init();

		$scope.policyWidgetTabs = [{
			title: 'individu',
			url: 'individu.policy'
		},
			{
				title: 'unit',
				url: 'unit.policy'
			}
		];
		$scope.currentPolicyWidgetTab = 'individu.policy';

		$scope.onClickTab = function (policyWidgetTab) {
			$scope.currentPolicyWidgetTab = policyWidgetTab.url;
		}

		$scope.isActiveTab = function (policyWidgetTabUrl) {
			return policyWidgetTabUrl == $scope.currentPolicyWidgetTab;
		}

		function getDataHomePolicyGraphSuccess(result) {
			if (result.invocationResult.statusCode == 200) {
				$scope.inForce = result.invocationResult.inForce;
				$scope.lapsed = result.invocationResult.lapsed;
				$scope.surrender = result.invocationResult.surrender;
				$scope.cancelled = result.invocationResult.cancelled;
				$scope.others = result.invocationResult.others;
				$scope.totalText = (result.invocationResult.total).formatMoney(0, '.', ',');
				$scope.total = result.invocationResult.total;

				$scope.dataIndividu = [
					{
						value: $scope.inForce,
						color: '#48752a',
						highlight: '#538532',
						label: $filter('translate')('INFORCE')
					},
					{
						value: $scope.lapsed,
						color: '#fdc056',
						highlight: '#edc370',
						label: $filter('translate')('LAPSED')
					},
					{
						value: $scope.surrender,
						color: '#ec1b2c',
						highlight: '#f5404f',
						label: $filter('translate')('SURRENDER')
					},
					{
						value: $scope.cancelled,
						color: '#696a6c',
						highlight: '#aeacac',
						label: $filter('translate')('CANCELED')
					},
					{
						value: $scope.others,
						color: '#592989',
						highlight: '#ce93d8',
						label: $filter('translate')('OTHERS')
					}
				];

				$scope.dataUnit = [
					{
						value: 78,
						color: '#ee1b2c',
						highlight: '#f5404f',
						label: 'Inforced'
					},
					{
						value: 25,
						color: '#4b79bc',
						highlight: '#6493d9',
						label: 'Lapsed'
					},
					{
						value: 15,
						color: '#eabc5f',
						highlight: '#edc370',
						label: 'Surrendered'
					},
					{
						value: 12,
						color: '#9c9c9c',
						highlight: '#aeacac',
						label: 'Void from inception'
					},
					{
						value: 15,
						color: '#48752a',
						highlight: '#538532',
						label: 'Canceled'
					}
				];

				// Chart.js Options
				$scope.options = {

					// Sets the chart to be responsive

					//Boolean - Whether we should show a stroke on each segment
					segmentShowStroke: false,

					//String - The colour of each segment stroke
					segmentStrokeColor: '#fff',

					//Number - The width of each segment stroke
					segmentStrokeWidth: 2,

					//Number - The percentage of the chart that we cut out of the middle
					percentageInnerCutout: 0, // This is 0 for Pie charts

					//Number - Amount of animation steps
					animationSteps: 100,

					//String - Animation easing effect
					animationEasing: 'easeOutBounce',

					//Boolean - Whether we animate the rotation of the Doughnut
					animateRotate: true,

					//Boolean - Whether we animate scaling the Doughnut from the centre
					animateScale: false,

					//String - A legend template
					legendTemplate: '<ul class="tc-chart-js-legend"><% for (var i=0; i<segments.length; i++){%><li><span style="background-color:<%=segments[i].fillColor%>"></span><%if(segments[i].label){%><%=segments[i].value%> <%=segments[i].label%><%}%></li><%}%></ul>'

				};
			} else {
				AppsLog.log("No data found. Please try again later!");
				$scope.successResult = false;
			}
		}

		function getDataHomePolicyGraphFailed(result) {
			AppsLog.log("Load Data Failed, Please Check Your Connection");
		}

		function getMyProposalLastUpdateSuccess(result) {
			if (result.invocationResult.statusCode == 200) {
				var lastUpdateProp = result.invocationResult.latest;
				var lastUpdate = moment(lastUpdateProp).format('LLLL');
				$scope.lastUpdateProp = lastUpdate;
			} else {
				AppsLog.log("getMyProposalLastUpdate != 200");
				$scope.successResult = false;
			}
		}

		$scope.goToPolicyList = function(){
			if($rootScope.pd){
				$state.go("pd_inquiries_list_proposal_policy", {"Flag": "2"});
			} else {
				$state.go("inquiries_proposal", {"Type": "2"});
			}
		}
	})