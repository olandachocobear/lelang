﻿/**
 * 
 */
angular.module('PruForce.services')
	.service('UpdateDisclaimerConfigService', function ($q, $rootScope) {

		var collection = [];
		var deferred = $q.defer();

		var APIEvent = {
			onSuccess: onApiSuccess,
			onFailure: onApiFailure
		};

		var request = {
			adapter: "HTTPAdapterAuth",
			procedure: "updateDisclaimerConfig",
			parameters: [],
			compressResponse: true
		};

		function update(username) {

			request.parameters = [username];

			collection = JsonStoreConfig[request.procedure];

			var networkState = navigator.connection.type;

			if (networkState == Connection.NONE) {
				updateToJsonStore();
			} else {
				updateToJsonStore();
				updateToServer();
			}

			return deferred.promise;
		}

		function updateToJsonStore() {
			var result;

			var query = { agentId: $rootScope.agent.code };
			var options = {
				exact: false,
				limit: 100 //returns a maximum of 10 documents
			};

			WL.JSONStore.get(collection.JSONSTORE_NAME).find(query, options).then(function (res) {
				try {

					if (res.length > 0) {
						result = res[0].json;
						AppsLog.log("JsonStore before update disclaimer config");
						AppsLog.log(result);
						result.invocationResult.status = true;

						AppsLog.log("Jsonstore after update disclaimer config");
						AppsLog.log(result);

						clearCollection(collection.JSONSTORE_NAME);

						WL.JSONStore.get(collection.JSONSTORE_NAME).add(result).then(function () {
							AppsLog.log("Success adding data to jsonstore " + collection.JSONSTORE_NAME);
							deferred.resolve(result);
						}).fail(function (error) {
							AppsLog.log("Failed adding data to jsonstore " + collection.JSONSTORE_NAME);
							deferred.reject(error);
						});

						deferred.resolve(result);
					} else {
						throw new Error("Local data is empty : " + collection.JSONSTORE_NAME);
					}
				} catch (error) {
					AppsLog.log("failed to retrieve jsonstore " + collection.JSONSTORE_NAME);
					deferred.reject(error);
				}
			}).fail(function (error) {
				AppsLog.log("failed to retrieve jsonstore " + collection.JSONSTORE_NAME);
				deferred.reject(error);
			});
		}

		function updateToServer() {
			AppsLog.log("update to server");
			WL.Client.invokeProcedure(request, APIEvent);
		}

		function onApiSuccess(result) {
			AppsLog.log("success update to server");
			AppsLog.log(result);
		}

		function onApiFailure(error) {
			AppsLog.log("failed update to server");
			AppsLog.log(error);
			deferred.reject(error);
		}


		return {
			update: update
		}
	});

