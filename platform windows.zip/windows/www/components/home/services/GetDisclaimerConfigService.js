﻿/**
 * 
 */
angular.module('PruForce.services')
	.service('getDisclaimerConfigService', function (DataFactoryOffline, $q) {
		function invoke(username) {
			var req = {
				adapter: "HTTPAdapterAuth",
				procedure: "getDisclaimerConfig",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + username + "']" }
			};

			var deferred = $q.defer();

			DataFactoryOffline.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invoke: invoke
		}
	});

