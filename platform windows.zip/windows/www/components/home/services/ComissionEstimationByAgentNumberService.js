﻿angular.module('PruForce.services')
	.service('ComissionEstimationByAgentNumberService', function (DataFactoryOffline, $q) {
		function invoke(agentNumber, pruforceId, callservice) {
			AppsLog.log("ComissionEstimationByAgentNumberService");
			var req = {
				adapter: "HTTPAdapter3",
				procedure: "findAllComissionEstimationByAgentNumber",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + agentNumber + "','" + pruforceId + "']" }
			};

			var deferred = $q.defer();

			DataFactoryOffline.invoke(req, callservice)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invoke: invoke
		}
	});

