﻿angular.module('PruForce.services')

	.service('MasterDataService', function ($q, $filter, AOBResources) {

		var getDataGender = function () {
			var deferred = $q.defer();

			var req = {
				adapter: "HTTPAdapterAuth",
				method: WLResourceRequest.GET,
				procedure: "getDataGender",
				parameters: []

			};

			var deferred = $q.defer();

			AOBResources.invoke(req, false)
				.then(function (res) {
					var masterDataGender = [];

					res.invocationResult.array.forEach(function (element) {
						var dataGender = {};
						dataGender.value = element.aobitem;
						dataGender.label = element.aoblongdescription;

						masterDataGender.push(dataGender);
					}, this);



					deferred.resolve(masterDataGender);

				}, function (error) {
					deferred.reject(error);
				});



			return deferred.promise;
		}

		var getDataReligion = function () {
			var deferred = $q.defer();

			var req = {
				adapter: "HTTPAdapterAuth",
				method: WLResourceRequest.GET,
				procedure: "getDataReligion",
				parameters: []

			};

			var deferred = $q.defer();

			AOBResources.invoke(req, false)
				.then(function (res) {
					var masterDataReligion = [];

					res.invocationResult.array.forEach(function (element) {
						var dataReligion = {};
						dataReligion.value = element.aobitem;
						dataReligion.label = element.aoblongdescription;

						masterDataReligion.push(dataReligion);
					}, this);



					deferred.resolve(masterDataReligion);

				}, function (error) {
					deferred.reject(error);
				});



			return deferred.promise;
		}

		var getDataProvince = function () {
			var deferred = $q.defer();

			var req = {
				adapter: "HTTPAdapterAuth",
				method: WLResourceRequest.GET,
				procedure: "getDataProvince",
				parameters: []

			};

			var deferred = $q.defer();


			AOBResources.invoke(req, false)
				.then(function (res) {
					var masterDataProvince = [];

					res.invocationResult.forEach(function (element) {
						var dataProvince = {};
						dataProvince.aobItem = element.aobItem;
						dataProvince.value = element.aobItem;
						dataProvince.label = element.aobLongDescription;

						masterDataProvince.push(dataProvince);
					}, this);



					deferred.resolve(masterDataProvince);

				}, function (error) {
					AppsLog.log(error);
					deferred.reject(error);
				});



			return deferred.promise;
		}

		var getDataEducation = function () {
			var deferred = $q.defer();

			var req = {
				adapter: "HTTPAdapterAuth",
				method: WLResourceRequest.GET,
				procedure: "getDataEducation",
				parameters: []

			};

			var deferred = $q.defer();

			AOBResources.invoke(req, false)
				.then(function (res) {
					var masterDataEducation = [];

					res.invocationResult.forEach(function (element) {
						var dataEducation = {};
						dataEducation.value = element.aobItem;
						dataEducation.label = element.aobLongDescription;

						masterDataEducation.push(dataEducation);
					}, this);



					deferred.resolve(masterDataEducation);

				}, function (error) {
					deferred.reject(error);
				});



			return deferred.promise;
		}

		var getDataMaritalStatus = function () {
			var deferred = $q.defer();

			var req = {
				adapter: "HTTPAdapterAuth",
				method: WLResourceRequest.GET,
				procedure: "getDataMaritalStatus",
				parameters: []

			};

			var deferred = $q.defer();

			AOBResources.invoke(req, false)
				.then(function (res) {
					var masterDataMaritalStatus = [];

					res.invocationResult.array.forEach(function (element) {
						var dataMaritalStatus = {};
						dataMaritalStatus.value = element.aobitem;
						dataMaritalStatus.label = element.aoblongdescription;

						masterDataMaritalStatus.push(dataMaritalStatus);
					}, this);



					deferred.resolve(masterDataMaritalStatus);

				}, function (error) {
					deferred.reject(error);
				});



			return deferred.promise;
		}

		var getDataNPWPStatus = function () {
			var deferred = $q.defer();

			var req = {
				adapter: "HTTPAdapterAuth",
				method: WLResourceRequest.GET,
				procedure: "getDataNPWPStatus",
				parameters: []

			};

			var deferred = $q.defer();

			AOBResources.invoke(req, false)
				.then(function (res) {
					var masterDataNPWPStatus = [];

					masterDataNPWPStatus.push({ value: 'no', 'label': 'Tidak Ada' });

					res.invocationResult.array.forEach(function (element) {
						var dataNPWPStatus = {};
						dataNPWPStatus.value = element.aobitem;
						dataNPWPStatus.label = element.aoblongdescription;

						masterDataNPWPStatus.push(dataNPWPStatus);
					}, this);



					deferred.resolve(masterDataNPWPStatus);

				}, function (error) {
					deferred.reject(error);
				});



			return deferred.promise;
		}

		var getDataOffice = function () {
			var deferred = $q.defer();

			var req = {
				adapter: "HTTPAdapterAuth",
				method: WLResourceRequest.GET,
				procedure: "getDataOffice",
				parameters: []

			};

			var deferred = $q.defer();

			AOBResources.invoke(req, false)
				.then(function (res) {
					var masterDataOffice = [];
					res.invocationResult.array.forEach(function (element) {
						var dataOffice = {};
						dataOffice.value = element.officecode;
						dataOffice.label = element.gafullname;
						masterDataOffice.push(dataOffice);
					}, this);

					masterDataOffice = masterDataOffice.filter(function (element) {
						return element.label !== '';
					});
					deferred.resolve(masterDataOffice);

				}, function (error) {
					deferred.reject(error);
				});



			return deferred.promise;
		}

		var getBankAccount = function () {

			var deferred = $q.defer();
			var paramRequest = "MSTBABRPF";
			var req = {
				adapter: "HTTPAdapterAuth",
				procedure: "getBankAccount",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + paramRequest + "']" }

			};

			var deferred = $q.defer();

			AOBResources.invoke(req, false)
				.then(function (res) {
					var masterBankAccount = [];

					res.invocationResult.forEach(function (element) {
						var bankAccount = {};
						bankAccount.value = element.aobItem;
						bankAccount.label = element.aobLongDescription;
						masterBankAccount.push(bankAccount);
					}, this);

					deferred.resolve(masterBankAccount);

				}, function (error) {
					deferred.reject(error);
				});



			return deferred.promise;
		}

		return {
			getDataGender: getDataGender,
			getDataReligion: getDataReligion,
			getDataProvince: getDataProvince,
			getDataEducation: getDataEducation,
			getDataMaritalStatus: getDataMaritalStatus,
			getDataNPWPStatus: getDataNPWPStatus,
			getDataOffice: getDataOffice,
			getBankAccount: getBankAccount

		}
	});