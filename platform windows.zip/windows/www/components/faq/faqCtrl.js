﻿angular.module('PruForce.controllers')

	.controller('faqCtrl', function ($scope) {

		AppsLog.log("START >> faqCtrl " + new Date());
		AppsLog.log("END >> faqCtrl " + new Date());
	})