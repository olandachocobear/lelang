﻿angular.module('PruForce.controllers')
    .controller('PDAchievementProdIndividuCtrl', function ($scope, $state, $rootScope, $http, $interval, PDAchievementProductionIndividuService) {
        AppsLog.log("START >> PDAchievementProdIndividuCtrl " + new Date());
        AnalyticsLog.logPage("prudential.production.inq.indv");

        PDAchievementProductionIndividuService.invoke($rootScope.agent.code, $rootScope.username)
            .then(function (res) {
                getDataAchievementIndividuListSuccess(res);
            });
        
        //start pd
		$scope.goToDetailIndividu = function (params) {
			if(params == 'mtd'){
				if ($rootScope.pd){
					$state.go("detail_individu_transaction_pd", {"type": "mtd"});
				} else {
					$state.go("detail_individu_transaction", {"type": "mtd"});
				}	
			} else {
				if ($rootScope.pd){
					$state.go("detail_individu_transaction_pd", {"type": "ytd"});
				} else {
					$state.go("detail_individu_transaction", {"type": "ytd"});
				}
			}
		}//end pd

        function getDataAchievementIndividuListSuccess(result) {
            if (result.invocationResult.isSuccessful) {
                var Dot = ".";
                var insertPosition = 15;

                var TOTALAPI = result.invocationResult.TOTALAPI;
                var TOTTOPUP = result.invocationResult.TOTTOPUP;
                var TUAV = result.invocationResult.TUAV;
                var ZAMOUNT = result.invocationResult.ZAMOUNT;
                var APENET = result.invocationResult.APENET;

                var YTDAPI = result.invocationResult.YTDAPI;
                var TOPUPAMNT = result.invocationResult.TOPUPAMNT;
                var TOTALSAVER = result.invocationResult.TOTALSAVER;
                var ZNETAMT = result.invocationResult.ZNETAMT;
                var TOTALAPE = result.invocationResult.TOTALAPE;

                var TOTALAPIdot = [TOTALAPI.slice(0, insertPosition), Dot, TOTALAPI.slice(insertPosition)].join('');
                var TOTTOPUPdot = [TOTTOPUP.slice(0, insertPosition), Dot, TOTTOPUP.slice(insertPosition)].join('');
                var TUAVdot = [TUAV.slice(0, insertPosition), Dot, TUAV.slice(insertPosition)].join('');
                var ZAMOUNTdot = [ZAMOUNT.slice(0, insertPosition), Dot, ZAMOUNT.slice(insertPosition)].join('');
                var APENETdot = [APENET.slice(0, insertPosition), Dot, APENET.slice(insertPosition)].join('');

                var YTDAPIdot = [YTDAPI.slice(0, insertPosition), Dot, YTDAPI.slice(insertPosition)].join('');
                var TOPUPAMNTdot = [TOPUPAMNT.slice(0, insertPosition), Dot, TOPUPAMNT.slice(insertPosition)].join('');
                var TOTALSAVERdot = [TOTALSAVER.slice(0, insertPosition), Dot, TOTALSAVER.slice(insertPosition)].join('');
                var ZNETAMTdot = [ZNETAMT.slice(0, insertPosition), Dot, ZNETAMT.slice(insertPosition)].join('');
                var TOTALAPEdot = [TOTALAPE.slice(0, insertPosition), Dot, TOTALAPE.slice(insertPosition)].join('');

                var mAPI = TOTALAPIdot.substring(0, 18);
                $scope.mAPI = (TOTALAPIdot.substring(18, 19) == "+") ? "" : "-";
                var mTOPUP = TOTTOPUPdot.substring(0, 18);
                $scope.mTOPUP = (TOTTOPUPdot.substring(18, 19) == "+") ? "" : "-";
                var mTUAV = TUAVdot.substring(0, 18);
                $scope.mTUAV = (TUAVdot.substring(18, 19) == "+") ? "" : "-";
                var mAMOUNT = ZAMOUNTdot.substring(0, 18);
                $scope.mAMOUNT = (ZAMOUNTdot.substring(18, 19) == "+") ? "" : "-";
                var mAPENET = APENETdot.substring(0, 18);
                $scope.mAPENET = (APENETdot.substring(18, 19) == "+") ? "" : "-";

                var yAPI = YTDAPIdot.substring(0, 18);
                $scope.yAPI = (YTDAPIdot.substring(18, 19) == "+") ? "" : "-";
                var yTOPUP = TOPUPAMNTdot.substring(0, 18);
                $scope.yTOPUP = (TOPUPAMNTdot.substring(18, 19) == "+") ? "" : "-";
                var yTUAV = TOTALSAVERdot.substring(0, 18);
                $scope.yTUAV = (TOTALSAVERdot.substring(18, 19) == "+") ? "" : "-";
                var yAMOUNT = ZNETAMTdot.substring(0, 18);
                $scope.yAMOUNT = (ZNETAMTdot.substring(18, 19) == "+") ? "" : "-";
                var yAPENET = TOTALAPEdot.substring(0, 18);
                $scope.yAPENET = (TOTALAPEdot.substring(18, 19) == "+") ? "" : "-";

                var mtdAPI = Number(mAPI);
                var mtdTOPUP = Number(mTOPUP);
                var mtdTUAV = Number(mTUAV);
                var mtdAMOUNT = Number(mAMOUNT);
                var mtdAPENET = Number(mAPENET);

                var ytdAPI = Number(yAPI);
                var ytdTOPUP = Number(yTOPUP);
                var ytdTUAV = Number(yTUAV);
                var ytdAMOUNT = Number(yAMOUNT);
                var ytdAPENET = Number(yAPENET);

                var retrieveDate2 = new Date(result.retrieveDate);
                var momentDate = moment(retrieveDate2).format('LLLL');
                $scope.lastUpdate = momentDate;

                $scope.APIMTD = mtdAPI.formatMoney(2, '.', ',');
                $scope.TOPUPMTD = mtdTOPUP.formatMoney(2, '.', ',');
                $scope.SAVERMTD = mtdTUAV.formatMoney(2, '.', ',');
                $scope.AMOUNTMTD = mtdAMOUNT.formatMoney(2, '.', ',');
                $scope.APENETMTD = mtdAPENET.formatMoney(2, '.', ',');

                $scope.APIYTD = ytdAPI.formatMoney(2, '.', ',');
                $scope.TOPUPYTD = ytdTOPUP.formatMoney(2, '.', ',');
                $scope.SAVERYTD = ytdTUAV.formatMoney(2, '.', ',');
                $scope.AMOUNTYTD = ytdAMOUNT.formatMoney(2, '.', ',');
                $scope.APENETYTD = ytdAPENET.formatMoney(2, '.', ',');

                $scope.$apply();
            } else {
                AppsLog.log("No data found. Please try again later!");
            }
        }

        function getDataAchievementIndividuListFailed(result) {
            AppsLog.log("Load Data Failed, Please Check Your Connection");
        }
        AppsLog.log("END >> PDAchievementProdIndividuCtrl " + new Date());
    })