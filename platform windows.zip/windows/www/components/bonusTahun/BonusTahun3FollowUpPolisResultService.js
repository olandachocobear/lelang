﻿angular.module('PruForce.services')
	.service('BonusTahun3FollowUpPolisResultService', function (DataFactory, $q) {
		function invoke(salesforceId, agentCode, agentNumber, filterBy, searchWords, periodFrom, periodTo, sortBy, sortDir, size, page) {
			AppsLog.log("BonusTahun3FollowUpPolisResultService invoke:" + salesforceId + "-" + agentCode + "-" + agentNumber + "-" + filterBy + "-" + searchWords + "-" + periodFrom + "-" + periodTo + "-" + sortBy + "-" + sortDir + "-" + size + "-" + page);

			var req = {
				adapter: "HTTPAdapter3",
				procedure: "findPolicyList",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + salesforceId + "','" + agentCode + "','" + agentNumber + "','" + filterBy + "','" + searchWords + "','" + periodFrom + "','" + periodTo + "','" + sortBy + "','" + sortDir + "'," + size + "," + page + "]" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invoke: invoke
		}
	});

