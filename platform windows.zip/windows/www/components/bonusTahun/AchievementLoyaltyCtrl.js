﻿angular.module('PruForce.controllers')
    .controller('AchievementLoyaltyCtrl', function ($scope, $rootScope, $ionicLoading, $filter, DataBonusTahun, DataListMonth, AchievementLoyaltyService) {
        AnalyticsLog.logPage("prudential.Bonus3+.AchievementLoyalty");

        $scope.bonus = "";
        $scope.bonusRate = "";
        $scope.targetCollectionRate = "";
        $scope.actualCollectionRate = "";
        $scope.renewalPremiumDue = "";
        $scope.renewalPremiumCollected = "";
        $scope.lastUpdatedTime = "";
        $scope.bonusType = "";
        $scope.month = "";
        $scope.year = "";
        $scope.listMonth = [];
        $scope.statusCode = 500;
        var lastUpdatedTimeTemp = "";


        getDataAchievementLoyaltyCtrlSuccess(DataBonusTahun);

        function getDataAchievementLoyaltyCtrlSuccess(result) {
            if (result.invocationResult.isSuccessful) {
                $scope.statusCode = result.invocationResult.statusCode;
                var vBonus = Number(result.invocationResult.bonus);
                var vRenewalPremiumDue = Number(result.invocationResult.renewalPremiumDue);
                var vRenewalPremiumCollected = Number(result.invocationResult.renewalPremiumCollected);
                $scope.bonus = vBonus.formatMoney(2, '.', ',');
                $scope.bonusRate = result.invocationResult.bonusRate;
                $scope.targetCollectionRate = result.invocationResult.targetCollectionRate;
                $scope.actualCollectionRate = result.invocationResult.actualCollectionRate;
                $scope.renewalPremiumDue = vRenewalPremiumDue.formatMoney(2, '.', ',');
                $scope.renewalPremiumCollected = vRenewalPremiumCollected.formatMoney(2, '.', ',');
                lastUpdatedTimeTemp = new Date(result.invocationResult.lastUpdatedTime);
                if (lastUpdatedTimeTemp != undefined) {
                    var lastUpdatedTimeTemp = moment(lastUpdatedTimeTemp).format('LLLL');
                    $scope.lastUpdatedTime = lastUpdatedTimeTemp;
                }
                $scope.bonusType = result.invocationResult.bonusType;
                $scope.month = result.invocationResult.month;
                $scope.year = result.invocationResult.year;

                if (result.invocationResult.statusCode == 500) {
                    $scope.bonus = "";
                }
            }
            $ionicLoading.hide();
        }

        getDataListMonth(DataListMonth);

        function getDataListMonth(result) {
            if (result.invocationResult.isSuccessful) {
                var tempHighest = result.invocationResult.array.length;
                $scope.listMonth = [];
                for (var i = 0; i < tempHighest; i++) {
                    var temp = new Date(result.invocationResult.array[i].listMonth);
                    if (lastUpdatedTimeTemp != undefined) {
                        temp = moment(temp).format('LLLL');
                        var temp2 = temp.split(" ");
                        if (temp2[2].indexOf(",") > -1) {
                            $scope.listMonth.push({ value: result.invocationResult.array[i].listMonth, name: temp2[1] + " " + temp2[3] });
                        } else {
                            $scope.listMonth.push({ value: result.invocationResult.array[i].listMonth, name: temp2[2] + " " + temp2[3] });
                        }
                    }
                }
                $scope.dateMonth = {
                    onRequest: $scope.listMonth[tempHighest - 1]
                };
            } else if (result.invocationResult.statusCode == 500) {
                $ionicLoading.hide();
                AppsLog.log("No data found. StatusCode 500 Please try again later!");
            } else {
                $ionicLoading.hide();
                AppsLog.log("No data found. Please try again later!");
            }
        }

        $scope.changePeriodTime = function () {
            var tempMonth = $scope.dateMonth.onRequest.value;
            tempMonth = tempMonth.split("-");
            var monthSelected = tempMonth[1];
            var yearSelected = tempMonth[0];
            $ionicLoading.show();
            AchievementLoyaltyService.invoke($rootScope.username, $rootScope.agent.code, $rootScope.agent.code, monthSelected, yearSelected).then(function (res) {
                getDataAchievementLoyaltyCtrlSuccess(res);
            });
        }

        $scope.openpdf = function () {
            var urlusermanual = '';
            if ($rootScope.agent_isLeader) {
                urlusermanual = $filter('translate')('URL_USER_MANUAL_BONUS_AGENT');
                $rootScope.openPDF(urlusermanual);
            } else {
                urlusermanual = $filter('translate')('URL_USER_MANUAL_BONUS_NOT_AGENT');
                $rootScope.openPDF(urlusermanual);
            }
        }
    })