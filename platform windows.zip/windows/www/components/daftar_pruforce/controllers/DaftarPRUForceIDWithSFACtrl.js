﻿angular.module('PruForce.controllers')

    .controller('DaftarPRUForceIDWithSFACtrl', function ($scope, $translate, $filter, $rootScope, $ionicLoading, $state, $ionicPopup, VerifyAgentSFAService, GetPRUForceIDService) {


        $scope.initModel = {};

        $scope.LoginSFA = function () {
            if ($scope.initModel.agentCode_sfaId == undefined || $scope.initModel.password == undefined || $scope.initModel.agentCode_sfaId == '' || $scope.initModel.password == '') {
                $rootScope.AlertDialog($filter('translate')('PRU_05'));
            } else {
                AnalyticsLog.logPage("Login.SFA");
                $ionicLoading.show();
                $rootScope.agent.code = $scope.initModel.agentCode_sfaId;
                VerifyAgentSFAService.invoke($scope.initModel.agentCode_sfaId, $scope.initModel.password).then(function (res) {
                    VerifyAgentSFASuccess(res);
                    clearFormData();
                });
            }

        }

        function clearFormData() {
            $scope.initModel.agentCode_sfaId = "";
            $scope.initModel.password = "";
        }
        $scope.RegisterSFA = function () {
            $state.go("daftar-pruforceId-no-sfa");
        }

        function VerifyAgentSFASuccess(res) {
            if (res.invocationResult.statusCode == 200) {
                var successStatus = res.invocationResult.succes;
                var errorCode = res.invocationResult.errorCode;
                if (successStatus) {
                    $rootScope.agent.code = res.invocationResult.agentId;
                    CekSalesForceID();
                } else {
                    $ionicLoading.hide();
                    clearFormData();
                    if (errorCode == '02') {
                        $rootScope.AlertDialog($filter('translate')('PRU_87'));
                    } else {
                        $rootScope.AlertDialog($filter('translate')('PRU_86'));
                    }
                }
            } else {
                clearFormData();
                $ionicLoading.hide();
                $rootScope.AlertDialog($filter('translate')('PRU_86'));
            }

        }

        function CekSalesForceID() {
            var npa = "";
            GetPRUForceIDService.invoke($rootScope.agent.code, npa).then(function (res) {
                GetPRUForceIDSuccess(res);
            });
        }
        function GetPRUForceIDSuccess(res) {
            $ionicLoading.hide();
            if (res.invocationResult.errorCode == 000000) {
                $rootScope.AlertDialog($filter('translate')('PRU_19'));
                clearFormData();
            } else {
                $state.go("create-pruforce-id", { 'type': 'createPRUForceIDWithSFA' });
            }
        }


    });