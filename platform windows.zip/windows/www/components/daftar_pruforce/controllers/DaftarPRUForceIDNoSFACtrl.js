﻿angular.module('PruForce.controllers')

    .controller('DaftarPRUForceIDNoSFACtrl', function ($scope, $translate, $filter, $rootScope, $state, $ionicLoading, $localStorage, $ionicPopup, AgentVerifyingDataService, CheckIDEmailService, GetPRUForceIDService) {

        $scope.flagShowPlaceHolder = true;
        $scope.removeClass = function ($event) {
            $scope.flagShowPlaceHolder = false;
        }
        $scope.checkDate = function ($event) {
            if ($scope.initModel.dob == undefined || $scope.initModel.dob == '') {
                $scope.flagShowPlaceHolder = true;
            }
        }
        $scope.initModel = {};

        $scope.VerifyAgent = function () {
            if ($scope.initModel.agentCode == undefined || $scope.initModel.dob == undefined || $scope.initModel.idcardno == undefined || $scope.initModel.phonenumber == undefined || $scope.initModel.agentCode == '' || $scope.initModel.dob == '' || $scope.initModel.idcardno == '' || $scope.initModel.phonenumber == '') {
                $rootScope.AlertDialog($filter('translate')('PRU_05'));
            } else {
                AnalyticsLog.logPage("Daftar.PruforceID.NoSFA");
                $ionicLoading.show();
                $rootScope.agent.code = $scope.initModel.agentCode;
                $rootScope.agent.dob = $scope.initModel.dob;
                $rootScope.agent.idcardno = $scope.initModel.idcardno;
                $rootScope.agent.phonenumber = $scope.initModel.phonenumber;
                var dateOfBirth = $filter('date')($scope.initModel.dob, 'yyyy-MM-dd');
                AgentVerifyingDataService.invoke($scope.initModel.agentCode, $scope.initModel.idcardno, dateOfBirth, $scope.initModel.phonenumber).then(function (res) {
                    VerifyAgentNoSFASuccess(res);
                });
            }

        }


        function VerifyAgentNoSFASuccess(res) {
            if (res.invocationResult.respCode == 200) {
                CheckEmailDataAgentNoSFA();
            } else {
                $ionicLoading.hide();
                $rootScope.AlertDialog($filter('translate')('PRU_25'));
            }

        }

        function CheckEmailDataAgentNoSFA() {
            CheckIDEmailService.invoke($rootScope.agent.code, $rootScope.userType).then(function (res) {
                CheckIDEmailAgentDataSuccess(res);
            });
        }

        function CheckIDEmailAgentDataSuccess(res) {
            if (res.invocationResult.statusCode == 200) {
                $rootScope.agent.email = res.invocationResult.email;
                CekSalesForceIDNoSFA();
            } else {
                $ionicLoading.hide();
                $rootScope.AlertDialog($filter('translate')('PRU_39'));
            }
        }


        function CekSalesForceIDNoSFA() {
            var npa = "";
            GetPRUForceIDService.invoke($rootScope.agent.code, npa).then(function (res) {
                GetPRUForceIDSuccess(res);
            });
        }
        function GetPRUForceIDSuccess(res) {
            $ionicLoading.hide();
            if (res.invocationResult.errorCode == 000000) {
                $rootScope.AlertDialog($filter('translate')('PRU_19'));
            } else {
                $state.go("verifikasi-sms", { 'smsType': 'DaftarPRUForceID', 'userType': 'agent' });
            }
        }

    });