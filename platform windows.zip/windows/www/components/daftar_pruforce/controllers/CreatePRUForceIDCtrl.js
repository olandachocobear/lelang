﻿angular.module('PruForce.controllers')

	.controller('CreatePRUForceIDCtrl', function ($scope, $translate, $filter, $state, $rootScope, $stateParams, $localStorage, $ionicPopup, $ionicLoading, GetPRUForceIDService, CreatePRUForceIDService) {


		$scope.initModel = {};

		$scope.CreatePRUForceID = function () {
			if ($scope.initModel.pruforceID == undefined || $scope.initModel.cpassword == undefined || $scope.initModel.password == undefined || $scope.initModel.pruforceID == '' || $scope.initModel.cpassword == '' || $scope.initModel.password == '') {
				$rootScope.AlertDialog($filter('translate')('PRU_05'));
			} else if ($scope.initModel.cpassword != $scope.initModel.password) {
				$rootScope.AlertDialog($filter('translate')('PRU_37'));
			} else {
				AnalyticsLog.logPage("Create.PruforceID");
				$ionicLoading.show();
				switch ($stateParams.type) {
					case "createPRUForceIDWithSFA":
						AnalyticsLog.logPage("Create.PruforceID.WithSFA");
						var flagNpa = "0";
						CreatePRUForceIDService.invoke($scope.initModel.pruforceID, $scope.initModel.password, flagNpa, $rootScope.agent.code).then(function (res) {
							DaftarPRUForceIDSuccess(res);
						});
						break;
					case "createPRUForceIDNoSFA":
						AnalyticsLog.logPage("Create.PruforceID.NoSFA");
						var flagNpa = "0";
						CreatePRUForceIDService.invoke($scope.initModel.pruforceID, $scope.initModel.password, flagNpa, $rootScope.agent.code).then(function (res) {
							DaftarPRUForceIDSuccess(res);
						});
						break;
					case "createPRUForceIDCandidate":
						AnalyticsLog.logPage("Create.PruforceID.Candidate");
						var flagAgentCode = "0";
						CreatePRUForceIDService.invoke($scope.initModel.pruforceID, $scope.initModel.password, $rootScope.candidate.npa, flagAgentCode).then(function (res) {
							DaftarPRUForceIDSuccess(res);
						});
						break;

				}
			}

		}
		function DaftarPRUForceIDSuccess(res) {
			$ionicLoading.hide();
			if (res.invocationResult.errorCode == 000000) {
				$rootScope.temp.pruforceId = res.invocationResult.agent.salesforceId;
				$state.go("security-question");
			} else {
				$rootScope.AlertDialog(res.invocationResult.errorMessage);
			}
		}


	})