﻿angular.module('PruForce.services')

    .service('CreatePRUForceIDService', function (AOBResources, $q) {

        function invoke(username, password, npa, agentCode) {
            var req = {
                adapter: "HTTPAdapterAuth",
                procedure: "createpruforceid",
                method: WLResourceRequest.POST,
                parameters: { "params": "['" + username + "','" + password + "','" + npa + "','" + agentCode + "']" }
            };

            var deferred = $q.defer();

            AOBResources.invoke(req, true)
                .then(function (res) {
                    deferred.resolve(res);
                }, function (error) {
                    deferred.reject(error);
                });

            return deferred.promise;
        }

        return {
            invoke: invoke
        }
    });

