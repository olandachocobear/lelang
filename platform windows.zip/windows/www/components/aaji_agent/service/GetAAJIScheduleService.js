﻿angular.module('PruForce.services')

	.service('GetAAJIScheduleService', function (AOBResources, $q, $filter) {

		function invoke(city) {

			var masterDataAAJI = [];
			var req = {
				adapter: "HTTPAdapterAuth",
				procedure: "getAAJIScheduleList",
				method: WLResourceRequest.POST,
				parameters: { "params": "" }
			};

			var deferred = $q.defer();
			AOBResources.invoke(req, false)
				.then(function (res) {

					var tempAAJI = $filter('filter')(res.invocationResult, { aajiexamlocation: city });
					var unique = {};
					var distinctDate = [];
					for (var i in tempAAJI) {
						if (typeof (unique[tempAAJI[i].aajiexamdate]) == "undefined") {
							distinctDate.push(tempAAJI[i].aajiexamdate);
						}
						unique[tempAAJI[i].aajiexamdate] = 0;
					}

					distinctDate.forEach(function (trainingDate) {
						var count = 1;
						var training = {};
						training.dateDefault = moment(trainingDate).format("YYYY-MM-DD");
						training.date = moment(trainingDate).format("dddd, D MMMM YYYY");
						training.sch = [];


						var tempAAJIChild = $filter('filter')(tempAAJI, { aajiexamdate: trainingDate });

						tempAAJIChild.forEach(function (element) {
							var childAAJI = {};
							var timeStart = new Date(element.aajiexamstarttime);
							var timeEnd = new Date(element.aajiexamendtime);
							childAAJI.id = element.aajiexamscheduleid;
							childAAJI.number = count++;
							childAAJI.time = moment(element.aajiexamstarttime).format("hh:mm") + " - " + moment(element.aajiexamendtime).format("hh:mm");
							childAAJI.loc = element.aajiexamlocation;
							childAAJI.endReg = moment(element.aajiexamexpireddate).format("DD MMMM YYYY");


							training.sch.push(childAAJI);
						}, this);



						masterDataAAJI.push(training);
					}, this);


					deferred.resolve(masterDataAAJI);

				}, function (error) {
					deferred.reject(error);
				});
			return deferred.promise;
		}

		return {
			invoke: invoke
		}
	});

