﻿
angular.module('PruForce.controllers')
	.controller('AllAfterDueDateTotalCtrl', function ($scope, $rootScope, $http, AllAfterDueDateTotalService, $q, findAllAfterDueDateTotalUnitService, $stateParams) {
		$scope.loading = true;
		$scope.successCall = true;
		$scope.AllAfterDueDateTotalService = AllAfterDueDateTotalService;
		$scope.agentNumber = $stateParams.agentNumber;
		$scope.init = function () {
			$scope.loading = true;
			$scope.successCall = true;
			if (localStorage.getItem('currentTabToDo') == 'components/toDo/to_do_my_tasks.html') {
				AllAfterDueDateTotalService.invoke($rootScope.agent.code, $rootScope.username, $rootScope.agent.code, true).then(function (result) {
					getAllTotalAfterDueDateSuccess(result);
					$scope.loading = false;
				});
			}
			else {
				findAllAfterDueDateTotalUnitService.invoke($stateParams.agentNumber, $rootScope.agent.code, $rootScope.username, "unit").then(function (result) {
					getAllTotalAfterDueDateSuccess(result);
					$scope.loading = false;
				});
			}
		}

		if (localStorage.getItem('currentTabToDo') == 'components/toDo/to_do_my_tasks.html') {
			collection = JsonStoreConfig['findTotalAfterDueDate'];
		}
		else {
			collection = JsonStoreConfig['findTotalAfterDueDateUnit'];
		}

		$scope.$on(collection.JSONSTORE_NAME, function (event, args) {
			$scope.successCall = (args.status == "success") ? true : false;

			if (localStorage.getItem('currentTabToDo') == 'components/toDo/to_do_my_tasks.html') {
				var qAllAfterDueDateTotalService = AllAfterDueDateTotalService.invoke($rootScope.agent.code, $rootScope.username, $rootScope.agent.code, false).then(function (result) {
					getAllTotalAfterDueDateSuccess(result);
				});

				$q.all([qAllAfterDueDateTotalService]).then(function () {
					$scope.loading = false;
					$scope.loadingSmall = false;
				});
			}
			else {
				var qfindAllAfterDueDateTotalUnitService = findAllAfterDueDateTotalUnitService.invoke($stateParams.agentNumber, $rootScope.agent.code, $rootScope.username, "unit", false).then(function (result) {
					getAllTotalAfterDueDateSuccess(result);
				});

				$q.all([qfindAllAfterDueDateTotalUnitService]).then(function () {
					$scope.loading = false;
					$scope.loadingSmall = false;
				});
			}
		});

		$scope.init();

		function getAllTotalAfterDueDateSuccess(result) {
			if (result.invocationResult.isSuccessful) {
				$scope.totalAllAfterDueDate = result.invocationResult.array[0].total;
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}

		function getTotalClaimPendingRequirementFailed(result) {
			AppsLog.log("Load Data Failed, Please Check Your Connection");
		}
	})