﻿angular.module('PruForce.services')
	.service('AfterDueDatePolicyListService', function (DataFactory, $q) {
		function invoke(salesforceId, agentNumber, type, startDay, endDay, searchBy, orderBy, sortDir, size, page) {
			var req = {
				adapter: "HTTPAdapterInquiry",
				procedure: "findAfterDueDateData",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + salesforceId + "','" + agentNumber + "','" + type + "','" + startDay + "','" + endDay + "','" + searchBy + "','" + orderBy + "','" + sortDir + "'," + size + "," + page + "]" }
			};
			AppsLog.log("1. page " + page);
			AppsLog.log("2. size " + size);
			AppsLog.log("3. salesforceId " + salesforceId);
			AppsLog.log("4. agentNumber " + agentNumber);
			AppsLog.log("5. searchBy " + searchBy);
			AppsLog.log("6. orderBy " + orderBy);

			var deferred = $q.defer();

			DataFactory.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invoke: invoke
		}
	});

