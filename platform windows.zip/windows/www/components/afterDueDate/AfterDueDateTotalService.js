﻿angular.module('PruForce.services')
	.service('AfterDueDateTotalService', function (DataFactory, $q) {
		function invoke(agentNumber, salesforceId, agentCode) {
			var req = {
				adapter: "HTTPAdapterInquiry",
				procedure: "findTotalInforceLapsedPoliciesByAgentNumber",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + agentNumber + "','" + salesforceId + "','" + agentCode + "']" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, false)
				.then(function (res) {
					AppsLog.log("masuk " + JSON.stringify(res));
					deferred.resolve(res);
				}, function (error) {
					AppsLog.log("error");
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invoke: invoke
		}
	});

