﻿angular.module('PruForce.controllers')
	.controller('AfterDueDateTotalCtrl', function ($scope, $rootScope, $ionicLoading, $http, $state, $filter, $location, AfterDueDateTotal, $stateParams) {

		AppsLog.log("START >> AfterDueDateTotalCtrl " + new Date());
		$scope.agentNumber = $stateParams.agentNumber;
		getAfterDueDateTotalCtrltSuccess(AfterDueDateTotal);

		function getAfterDueDateTotalCtrltSuccess(result) {
			AppsLog.log("START >> getAfterDueDateTotalCtrltSuccess " + new Date());

			$scope.totalInforce15 = result.invocationResult.totalInforce15;
			$scope.totalInforce45 = result.invocationResult.totalInforce45;
			$scope.totalInforce30 = result.invocationResult.totalInforce30;
			$scope.totalInforce63 = result.invocationResult.totalInforce63;
			$scope.totalLessThan2Years = result.invocationResult.totalLessThan2Years;
			AppsLog.log("END >> getAfterDueDateTotalCtrltSuccess " + new Date());


			function getAfterDueDateTotalCtrlFailed(result) {
				$ionicLoading.hide();
				AppsLog.log("Data getAfterDueDateTotalCtrlFailed Failed, Please Check Your Connection");
			}

			AppsLog.log("END >> AfterDueDateTotalCtrl " + new Date());
		}

		$scope.go = function (state) {
			$rootScope.flagScrollToTop = 'false';
			$state.go(state, { agentNumber: $scope.agentNumber });
		}

		$scope.pdUnitRole = false;
		if($rootScope.pd && $rootScope.UnitByAgentType){
			$scope.pdUnitRole = true;
		}

		$scope.goToBeforeDueDatePolicies = function(){
			$state.go("pd_before_due_date_policy_list", { agentNumber: $scope.agentNumber });
		}
	});