﻿angular.module('PruForce.services')
	.service('AllAfterDueDateTotalService', function (DataFactoryOffline, $q) {
		function invoke(agentNumber, salesforceId, agentCode, callservice) {
			var req = {
				adapter: "HTTPAdapterInquiry",
				procedure: "findTotalAfterDueDate",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + agentNumber + "','" + salesforceId + "','" + agentCode + "']" }
			};

			var deferred = $q.defer();

			DataFactoryOffline.invoke(req, callservice)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invoke: invoke
		}
	});


