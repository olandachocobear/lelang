﻿angular.module('PruForce.services')
	.service('AfterDueDatePolicyDetailsService', function (DataFactory, $q) {
		function invoke(policyNumber, salesforceId, agentCode, agentNumber, pageType) {
			var req = {
				adapter: "HTTPAdapterInquiry",
				procedure: "findDetailByPolicyNumber",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + policyNumber + "','" + salesforceId + "','" + agentCode + "','" + agentNumber + "','" + pageType + "']" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invoke: invoke
		}
	});

