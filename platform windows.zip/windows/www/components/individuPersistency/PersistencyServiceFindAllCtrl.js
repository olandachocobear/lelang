﻿/**
 * 
 */
angular.module('PruForce.controllers')
	//update persistency
	.controller('PersistencyServiceFindAllCtrl', function ($scope, $rootScope,$ionicLoading, $http, $state, $filter, AllPersistencyIndividu, AllPersistencyIndividuService, IndividuPolisStatusPersistency) {
		AnalyticsLog.logPage("prudential.persistency.indv.dtl");
		var sizeIndividu = 30;
		var pageIndividu = 1;
		var searchByIndividu = '';
		var searchValIndividu = '';
		var searchBy2Individu = '';
		var searchVal2Individu = '';
		var orderByIndividu = '';
		var directionIndividu = 'asc';
		$scope.transaction = [];
		var listIndividuAll = [];
		var listIndividuAfterAdd = [];
		$scope.noMoreItemsAvailable = false;
		$scope.numberOfItemsToDisplay = 30;
		$scope.policyHolderNames = {
			data: [{
				id: 0,
				name: $filter('translate')('DEFAULT_SORT')
			},
			{
				id: 1,
				name: $filter('translate')('POLICY_NAME')
			},
			{
				id: 2,
				name: $filter('translate')('POLICY_NUMBER')
			},]
		};

		$scope.sortItem = {
			onRequest: $scope.policyHolderNames.data[0]
		};

		$scope.loadMore = function () {

			pageIndividu += 1;
			$scope.showSpinner = true;
			getDataFromService();
			$scope.noMoreItemsAvailable = false;
			$scope.$broadcast('scroll.infiniteScrollComplete');

		};

		$scope.GoSearching_GoFiltering = function () {
			$ionicLoading.show();
			listIndividuAll = [];
			sizeIndividu = 30;
			pageIndividu = 1;
			searchValIndividu = ($scope.transaction.searchString==undefined)?"":$scope.transaction.searchString.replace(/['|"|\\]/g, "\\$&");
			searchByIndividu = '';
			if ($scope.filterItem.onRequest == $filter('translate')('SHOW_ALL')) {
				searchByIndividu = '';
				searchVal2Individu = '';
			} else {
				searchVal2Individu = $scope.filterItem.onRequest;
				searchBy2Individu = 'policyStatus';
			}
			if ($scope.sortItem.onRequest.id === 0) {
				$scope.descSorted = false;
				orderByIndividu = 'policyHolderName';
			} else if ($scope.sortItem.onRequest.id === 1) {
				$scope.descSorted = false;
				$scope.policyOption = 'policyHolderName';
				orderByIndividu = 'policyHolderName';
			} else {
				$scope.descSorted = false;
				$scope.policyOption = 'policyNumber';
				orderByIndividu = 'policyNumber';
			}
			if (searchValIndividu == undefined) {
				searchValIndividu = '';
			}
			$scope.noMoreItemsAvailable = false;
			getDataFromService();
		}

		function getDataFromService() {
			AllPersistencyIndividuService.invoke($rootScope.agent.code, pageIndividu, sizeIndividu,
				searchByIndividu, searchValIndividu, searchBy2Individu, searchVal2Individu, orderByIndividu,
				directionIndividu, $rootScope.username, $rootScope.agent.code).then(function (res) {
					getDataPersistencyListSuccess(res);
				});
		}

		getDataPersistencyListSuccess(AllPersistencyIndividu);
		$scope.getDataPersistencyListSuccess = getDataPersistencyListSuccess;

		function getDataPersistencyListSuccess(result) {
			if (result.invocationResult.isSuccessful) {
				var policyHolderNameTemp;
				$scope.showSpinner = false;
				if (result.invocationResult.array != null) {
					if (listIndividuAll.length == 0) {
						listIndividuAll = [];
						for (var i = 0; i < result.invocationResult.array.length; i++) {
							var dt = {};
							var policyHolderName1 = result.invocationResult.array[i].policyHolderName;

							if (policyHolderName1 == null) {
								policyHolderNameTemp = "";
							}
							else {
								policyHolderNameTemp = policyHolderName1;
							}

							dt.policyHolderName = policyHolderNameTemp;
							dt.policyNo = result.invocationResult.array[i].policyNo;
							dt.productCode = result.invocationResult.array[i].productCode;
							dt.policyStatus = result.invocationResult.array[i].policyStatus;
							dt.PruCodeEnd = (dt.productCode).substring(3, (dt.productCode).size);

							issuedAPI = Number(result.invocationResult.array[i].issuedAPI);
							dt.issuedAPI = issuedAPI.formatMoney(2, '.', ',');
							incrementAPI = Number(result.invocationResult.array[i].incrementAPI);
							dt.incrementAPI = incrementAPI.formatMoney(2, '.', ',');
							decrementAPI = Number(result.invocationResult.array[i].decrementAPI);
							dt.decrementAPI = decrementAPI.formatMoney(2, '.', ',');
							lapsedAPI = Number(result.invocationResult.array[i].lapsedAPI);
							dt.lapsedAPI = lapsedAPI.formatMoney(2, '.', ',');
							listIndividuAll[i] = dt;
							pageIndividu = 1;
							//						var latestPrsctyDetail = result.invocationResult.array[i].latestPrsctyDetail;
							//						
							//						var lastUpdate = moment(latestPrsctyDetail).format('LLLL');
							//						$scope.lastUpdate = lastUpdate;

							var latestPrsctyDetail = result.invocationResult.array[i].latestPrsctyDetail;
							latestPrsctyDetail = replaceMonthStringToNumber(latestPrsctyDetail);
							var lastUpdate = moment(latestPrsctyDetail).format('LLLL');
							$scope.lastUpdate = lastUpdate;
						}
					} else {
						for (var i = 0; i < result.invocationResult.array.length; i++) {
							var dt = {};
							var policyHolderName1 = result.invocationResult.array[i].policyHolderName;

							if (policyHolderName1 == null) {
								policyHolderNameTemp = "";
							} else {
								policyHolderNameTemp = policyHolderName1;
							}

							dt.policyHolderName = policyHolderNameTemp;
							dt.policyNumber = result.invocationResult.array[i].policyNo;
							dt.productCode = result.invocationResult.array[i].productCode;
							dt.policyStatus = result.invocationResult.array[i].policyStatus;
							dt.PruCodeEnd = (dt.productCode).substring(3, (dt.productCode).size);

							issuedAPI = Number(result.invocationResult.array[i].issuedAPI);
							dt.issuedAPI = issuedAPI.formatMoney(2, '.', ',');
							incrementAPI = Number(result.invocationResult.array[i].incrementAPI);
							dt.incrementAPI = incrementAPI.formatMoney(2, '.', ',');
							decrementAPI = Number(result.invocationResult.array[i].decrementAPI);
							dt.decrementAPI = decrementAPI.formatMoney(2, '.', ',');
							lapsedAPI = Number(result.invocationResult.array[i].lapsedAPI);
							dt.lapsedAPI = lapsedAPI.formatMoney(2, '.', ',');
							listIndividuAfterAdd[i] = dt;
							listIndividuAll.push(listIndividuAfterAdd[i]);
							$scope.numberOfItemsToDisplay += listIndividuAfterAdd.length;
							var latestPrsctyDetail = result.invocationResult.array[i].latestPrsctyDetail;
							latestPrsctyDetail = replaceMonthStringToNumber(latestPrsctyDetail);

							var lastUpdate = moment(latestPrsctyDetail).format('LLLL');
							$scope.lastUpdate = lastUpdate;
						}
					}
					var splitResult = (listIndividuAll[0].productCode).split(" ");
					$scope.CodePru = splitResult[0].substring(3, (splitResult[0].length));
					$scope.PruCodeEnd = (listIndividuAll[0].productCode).substring((splitResult[0].length), (listIndividuAll[0].productCode).size);
				}
				$scope.agentList = listIndividuAll;
				$ionicLoading.hide();
				$scope.noMoreItemsAvailable = false;
				if (result.invocationResult.statusCode == 500) {
					$ionicLoading.hide();
					$scope.noMoreItemsAvailable = true;
					AppsLog.log("No data found1. Please try again later!");
				}
			} else if (result.invocationResult.statusCode == 500) {
				$scope.showLoading = false;
				$ionicLoading.hide();
				$scope.noMoreItemsAvailable = true;
				AppsLog.log("No data found2. Please try again later!");
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}

		function getDataPersistencyListFailed(result) {
			$ionicLoading.hide();
			AppsLog.log("Data Individu Failed, Please Check Your Connection");
		}

		getListPolisStatusSuccess(IndividuPolisStatusPersistency);
		$scope.getListPolisStatusSuccess = getListPolisStatusSuccess;
		function getListPolisStatusSuccess(result) {
			if (result.invocationResult.isSuccessful) {
				if (result.invocationResult.array != null) {
					$scope.listPolisStatus = [];
					$scope.listPolisStatus.push($filter('translate')('SHOW_ALL'));
					for (var i = 0; i < result.invocationResult.array.length; i++) {
						$scope.listPolisStatus.push(result.invocationResult.array[i].value);
					}
					$scope.filterItem = {
						onRequest: $scope.listPolisStatus[0]
					}
				}
			} else if (result.invocationResult.statusCode == 500) {
				$ionicLoading.hide();
				AppsLog.log("No data found2. Please try again later!");
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}
		function getListPolisStatusFailed(result) {
			$ionicLoading.hide();
			AppsLog.log("Data Individu Failed, Please Check Your Connection");
		}
	    	$scope.changePage = function(id) {
	    		
	    		$state.go('inquiries_proposal_policy_details', {policyNumber: id, Type: "2", agentNumber: $state.params.agentNumber});
		}
	});