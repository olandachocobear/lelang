﻿angular.module('PruForce.controllers')
.controller('ContestHomeWidgetCtrl', function($translate, $sce, $scope, $state, $rootScope, $filter, $q, AllFavoriteContestOfflineService, AllMyContestOfflineService, $log) {
	AnalyticsLog.logPage("prudential.contest.home.all");
	$scope.loadingMyContest = true;
	$scope.loadingFavorite = true;

	$scope.initLoaded = false;

	$scope.successResult = true;
	$scope.successCall = true;
	
	$scope.size = 3;
	$rootScope.page = 1;

	var MyContestId = [];
	var MyFavContestId = [];

	$scope.constestWidgetUrl = 'components/contest/contest_home_widget.html';
	/*
	$scope.isNotMatchMyContest = function(entity)
	{
		var result = false;
		if ($scope.ListAllContestFavHomes != undefined || $scope.ListAllContestFavHomes != null){
			for (var i = 0; i < $scope.ListAllContestFavHomes.length; i++ ){
				result = ($scope.ListAllContestFavHomes[i].contestCode == entity);
				if (result) break;
			}
		}
		return result;
	}

	$scope.isNotMatchFavorite = function(entity)
	{
		
		var result = false;
		if ($scope.ListAllMyContests != undefined || $scope.ListAllMyContests != null){
			for (var i = 0; i < $scope.ListAllMyContests.length; i++ ){
				result = $scope.ListAllMyContests[i].contestCode.indexOf(entity) >= 0;
				if (result) break;
			}
		}
		return result;
		
	}
	*/

	$scope.isMyContest = function(contestCode)
	{
		return MyContestId.indexOf(contestCode) > -1;
	}

	$scope.isFavorite = function(contestCode)
	{
		return MyFavContestId.indexOf(contestCode) > -1;
	}

	function getDataMyContestFromService(callservice) {	
		return AllMyContestOfflineService.invoke($rootScope.username, $rootScope.agent.code, $rootScope.agent.agentType, $scope.size, $rootScope.page, callservice).then( function (res){
			getDataAllMyContestListSuccess(res);
		}, function (error){
			AppsLog.log(error);
		});
	}

	function getDataFavoriteContestFromService(callservice) {	
		return AllFavoriteContestOfflineService.invoke($rootScope.username, $rootScope.agent.code, $rootScope.agent.agentType, callservice).then( function (res){
			getDataAllFavoriteContestListSuccess(res);
		}, function (error){
			AppsLog.log(error);
		});
	}

	$scope.init = function(){
		$scope.loadingMyContest = true;
		$scope.loadingFavorite = true;
		$scope.successCall = true;
		
		var promises = [];
		var myContestPromise = getDataMyContestFromService(true);
		promises.push(myContestPromise);
		var favoriteContestPromise = getDataFavoriteContestFromService(true);
		promises.push(favoriteContestPromise);

		$q.all(promises).then(function(){
			$scope.successResult = true;
			$scope.initLoaded = true;
			$scope.loadingMyContest = false;
			$scope.loadingFavorite = false;
		}, function (error){
			$scope.successResult = false;
			$scope.initLoaded = true;
			$scope.loadingMyContest = false;
			$scope.loadingFavorite = false;
		});
	}
	
	collection = JsonStoreConfig['findAllMyContest'];
	$scope.$on(collection.JSONSTORE_NAME, function(event, args) {
		if(!$scope.initLoaded) return;
		$scope.successCall = (args.status == "success")?true:false;

		var myContestPromise = getDataMyContestFromService(false);
		
		$q.all([myContestPromise]).then(function(){
			$scope.loadingMyContest = false;
		}, function (error){
			$scope.loadingMyContest = false;
		});
	});
	
	collection = JsonStoreConfig['findAllFavoriteContest'];
	$scope.$on(collection.JSONSTORE_NAME, function(event, args) {
		if(!$scope.initLoaded) return;
		$scope.successCall = (args.status == "success")?true:false;

		var favoriteContestPromise = getDataFavoriteContestFromService(false);
		
		$q.all([favoriteContestPromise]).then(function(){
			$scope.loadingFavorite = false;
		}, function (error){
			$scope.loadingFavorite = false;
		});
	});
	
	function getDataAllMyContestListSuccess(result) {
		ListAllMyContest = [];
		MyContestId = [];
		var periodStartTemp, periodEndTemp;
		if(result.invocationResult != null){
			for (var i = 0; i < result.invocationResult.length; i++) {
				var dt = {};

				MyContestId.push(result.invocationResult[i].contestCode);
				dt.contestCode = result.invocationResult[i].contestCode;
				dt.contestName = result.invocationResult[i].contestName;
				dt.contestDescription = $sce.trustAsHtml(result.invocationResult[i].contestDescription);
				periodStartTemp = new Date(result.invocationResult[i].periodStart);
				dt.periodStart = moment(periodStartTemp).format('LL');
				periodEndTemp = new Date(result.invocationResult[i].periodEnd);
				dt.periodEnd = moment(periodEndTemp).format('LL');
				dt.extraCreditFlag = result.invocationResult[i].extraCreditFlag;
				dt.completedTask = result.invocationResult[i].completedTask;
				dt.totalTask = result.invocationResult[i].totalTask;
				dt.overall = result.invocationResult[i].overall;
				dt.allTask = $sce.trustAsHtml($translate.instant("CONTEST.HOME_FAVORITE_PROGRESS", dt));

				if (dt.overall == null)
				{
					dt.overall = {};
					dt.overall.lineStatus = "nothave";
					dt.overall.progress = (dt.completedTask/dt.totalTask)*100;
					dt.overall.spinner = $filter('formatNumber')(dt.overall.progress,0);
					dt.overall.contestName = dt.contestName;
				}
				else
				{
					dt.overall.spinner = $filter('formatNumber')(dt.overall.progress,0);
					dt.overall.lineStatus = "have";
				}
				dt.params = result.invocationResult[i].params;

				angular.forEach(dt.params, function(value, key)
				{	
					if (dt.params[key].percentage != undefined || dt.params[key].percentage != null)
					{
						dt.params[key].percentageRound = $filter('formatNumber')(dt.params[key].percentage,0);
						dt.params[key].percentage = $filter('formatNumber')(dt.params[key].percentage,0);
					}
				});
				ListAllMyContest[i] = dt;
			}
		}
		$scope.ListAllMyContests = ListAllMyContest;
	}
	
	//All contest home
	function getDataAllFavoriteContestListSuccess(result) {
		ListAllContestFavHome = [];
		MyFavContestId = [];

		angular.forEach(result.invocationResult, function(value, key)
		{
			var dtFav = {};

			MyFavContestId.push(value.contestCode);

			dtFav.completedTask = value.completedTask;
			dtFav.totalTask = value.totalTask;
			dtFav.contestCode = value.contestCode;
			dtFav.percentage = $filter('formatNumber')(value.percentage, 0);
			dtFav.contestName = value.contestName;
			dtFav.contestState = value.contestState;
			dtFav.description = $sce.trustAsHtml($translate.instant("CONTEST.HOME_FAVORITE_PROGRESS", dtFav));
			dtFav.status = value.status;
			dtFav.noBorder = true;

			if(key == 0){
				dtFav.status = "FAVORITETOP";
				dtFav.noBorder = false;
			}
			else if (key > 0 && key < (result.invocationResult.length-1)) 
			{
				dtFav.noBorder = false;
			}

			ListAllContestFavHome[key] = dtFav;
		});
		
		$scope.ListAllContestFavHomes = ListAllContestFavHome;	
		
		function FindAllContestHomeListFailed(result){
			AppsLog.log("Data Bank Failed, Please Check Your Connection");
		}
	}
	
	$scope.toContestTab = function(){
		$state.go('contest-tab');
	}

	$scope.changePageHomeContestDetail = function(id) {			
		$state.go('my_contest_detail', {contestCode: id});
	}
	
	$scope.changePageHomeFavContestDetail = function(id, contestState) {
		if (contestState == "notEligible")
		{
			$state.go('my_contest_detail_not_eligible', {contestCode: id});
		}
		else if (contestState == "myContest")
		{
			$state.go('my_contest_detail', {contestCode: id});
		}
		else if (contestState == "monitoring")
		{
			$state.go('contest_monitoring_detail', {contestCode: id});
		}
		else if (contestState == "completed")
		{
			$state.go('contest_completed_detail', {contestCode: id});
		}
	}

	$scope.init();
	
})