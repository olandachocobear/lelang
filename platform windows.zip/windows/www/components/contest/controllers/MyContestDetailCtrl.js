﻿angular.module('PruForce.controllers')
.controller('MyContestDetailCtrl', function($rootScope, $scope, $ionicLoading, $translate, $state, $stateParams, $interval, $http, $q, $filter, MyContestDetail, ContestLastUpdate, $ionicPopup, $sce, FiveRankingMyContestDetailService, CommonService) {
	AnalyticsLog.logPage("prudential.contest.mycontest.detail");
	
	$scope.goBackContest = function(){
		if($state.current.name == 'my_contest_detail' || $state.current.name == 'my_contest_detail_not_eligible'){
			$rootScope.goBack();
		}
	}

	updateLastUpdate(ContestLastUpdate);
	$scope.updateLastUpdate = updateLastUpdate;
	getDataMyContestDetailSuccess(MyContestDetail);

	$scope.getDataMyContestDetailSuccess = getDataMyContestDetailSuccess;
	$scope.showSpinnerImages = true;

	$scope.showRankingDetail = function() {	
		$ionicLoading.show();
		FiveRankingMyContestDetailService.invoke($rootScope.username, $rootScope.agent.code, $scope.MyContestDetails.contest.contestCode).then(function (res){
			$scope.fiveRanking = res;

			$scope.fiveRanking.invocationResult.thisAgent.nettApiStr = $filter('formatNumber')($scope.fiveRanking.invocationResult.thisAgent.nettApi, 2);
			angular.forEach($scope.fiveRanking.invocationResult.upperAgent, function(value, key)
			{	
				$scope.fiveRanking.invocationResult.upperAgent[key].nettApiStr =  $filter('formatNumber')($scope.fiveRanking.invocationResult.upperAgent[key].nettApi, 2);
			});

			angular.forEach($scope.fiveRanking.invocationResult.lowerAgent, function(value, key)
			{	
				$scope.fiveRanking.invocationResult.lowerAgent[key].nettApiStr =  $filter('formatNumber')($scope.fiveRanking.invocationResult.lowerAgent[key].nettApi , 2);
			});
			
			$ionicLoading.hide();
			var alertPopup = $ionicPopup.alert({	
				title: '<span class="text-initial">'+$filter('translate')('CONTEST.NOW_RANKING')+'<span class="big mLeft10">'+$scope.fiveRanking.invocationResult.thisAgent.ranking+'</span></span>',
				template: '<div class="container home inquiry-custom">'+
				'<div class="content font-size-12-8 pLeft10 pRight10 line-height-18-row" style="padding: 0px;">'+

				'<div class="row bBottom mTop0" style="border-bottom: solid 1px #000 !important;">'+
				'<div class="col col-55" style="font-weight:bold;">'+$filter('translate')('RANKING_CONTEST')+'</div><div class="col col-45 text-right"  style="font-weight:bold;">'+$filter('translate')('API')+'</div>'+
				'</div>'+

				'<div ng-if="'+$scope.fiveRanking.invocationResult.upperAgent.length+'>0" ng-model="fiveRanking" data-ng-repeat="upperAgentHtml in fiveRanking.invocationResult.upperAgent" class="row bBottom mTop0">'+
				'<div class="col col-55"> {{upperAgentHtml.ranking}}'+" "+'</div><div class="col col-45 text-right">'+'{{upperAgentHtml.nettApiStr}}'+'</div>'+
				'</div>'+
				'<div class="row mTop0 red-font red-border">'+
				'<div class="col col-55">'+$scope.fiveRanking.invocationResult.thisAgent.agentName+' </div><div class="col col-45 text-right">'+$scope.fiveRanking.invocationResult.thisAgent.nettApiStr+'</div>'+
				'</div>'+
				'<div ng-if="'+$scope.fiveRanking.invocationResult.lowerAgent.length+'>0" ng-model="fiveRanking" data-ng-repeat="lowerAgentHtml in fiveRanking.invocationResult.lowerAgent" class="row bBottom mTop0">'+
				'<div class="col col-55"> {{lowerAgentHtml.ranking}}'+" "+'</div><div class="col col-45 text-right">{{lowerAgentHtml.nettApiStr}}'+'</div>'+
				'</div>'+
				//'<button ng-repeat="button in buttons" ng-click="$buttonTapped(button, $event)" class="mTop10 list-info as-link btn-link button-block bg-red" ng-class="button.type || '+'button-assertive'+'" ng-bind-html="button.text" style="">Tutup</button>'+
				'</div>'+
				'</div>'+
				'</div>',
				scope:$scope,
				cssClass: 'v2 rank-detail',
				okText: $filter('translate')('CONTEST.CLOSE_BUTTON')
			});
		})
	};

	var options = {
		location: 'yes'
	};

	//Change page to Proposal List
	$scope.changePageProposalList = function(id) {			
		$state.go('contest_proposal_list', {contestCode: id});
	}
	
	$scope.openPdf = function(name, originalName){
		$ionicLoading.show();
		$state.go('common_pdfjs', {fileName: name, originalFileName: originalName, module: "contest", pageTitle: "CONDITIONS_CONTEST" , pageLogId: "prudential.contest.pdftermncondition"});
	}

	$scope.changePagePolicyList = function(id) {			
		$state.go('contest_policy_list', {contestCode: id});
	}
	
	//change to bonanza page
	$scope.changePageMyContestExtraCredit = function(id) {			
		$state.go('contest_extra_credit', {contestCode: id});
	}
	
	function resizeIframe(obj) {
		obj.style.height = obj.contentWindow.document.body.scrollHeight + 'px';
	}
	
	function getDataMyContestDetailSuccess(result) {
		
		MyContestDetail = [];
		var periodStartTemp, periodEndTemp;
		var progressSingle;
		var percentageChildTemp;

		if (result.invocationResult.isSuccessful) {
			var dt = {};

			dt.contest = result.invocationResult.contest;
			dt.rankingDetail = result.invocationResult.contest.rankingDetail;
			periodStartTemp = new Date(result.invocationResult.contest.periodStart);
			dt.contest.periodStart = moment(periodStartTemp).format('LL');
			periodEndTemp = new Date(result.invocationResult.contest.periodEnd);
			dt.contest.runTask = result.invocationResult.contest.totalTask - result.invocationResult.contest.completedTask;
			dt.contest.periodEnd = moment(periodEndTemp).format('LL');
			dt.contest.flyers = result.invocationResult.contest.flyers;
			var flyers = (dt.contest.flyers != null && dt.contest.flyers.indexOf("|")) ? dt.contest.flyers.split("|") : null;
			dt.contest.flyersName = flyers ? flyers[0] : "image"; 
			dt.contest.flyersFileName = flyers ? flyers[1] : ""; 

			CommonService.invokeFileBase64(dt.contest.flyersFileName, 'contest').then(
				function(response){
					if(response.invocationResult.isSuccessful){
						dt.contest.flyersBase64 = "data:image/jpeg;base64," + response.invocationResult.content;
					}
					$scope.showSpinnerImages = false;
				}, function(error){
					$scope.showSpinnerImages = false;
				});
			
			if (dt.contest.overall == null)
			{
				progressSingle = (dt.contest.completedTask/dt.contest.totalTask)*100;
				dt.contest.overall = {};
				dt.contest.overall.lineStatus = "nothave";
				dt.contest.overall.progress = $filter('formatNumber')(progressSingle, 1);
				dt.contest.overall.spinner = $filter('formatNumber')(progressSingle, 0);
			}
			else
			{
				dt.contest.overall.progress = $filter('formatNumber')(dt.contest.overall.progress, 1);
				dt.contest.overall.spinner = $filter('formatNumber')(dt.contest.overall.progress, 0);
				dt.contest.overall.lineStatus = "have";
			}

			dt.contest.params = angular.copy(result.invocationResult.contest.params);

			angular.forEach(dt.contest.params, function(value, key)
			{	
				if (dt.contest.params[key].percentage != undefined || dt.contest.params[key].percentage != null)
				{
					dt.contest.params[key].percentageRound = $filter('formatNumber')(dt.contest.params[key].percentage, 0);
					percentageChildTemp = dt.contest.params[key].percentage;
					dt.contest.params[key].percentage = $filter('formatNumber')(percentageChildTemp, 1);
				}

				dt.contest.params[key].subtitle = $sce.trustAsHtml($translate.instant(dt.contest.params[key].subtitle, dt.contest.params[key]));
			});

			dt.contestDescription = $sce.trustAsHtml(result.invocationResult.contest.contestDescription);
			dt.awardsDescription = $sce.trustAsHtml(result.invocationResult.awardsDescription);
			dt.termCondition = $sce.trustAsHtml(result.invocationResult.termCondition);
			
			var termConditionPdf = (result.invocationResult.termConditionPdf != null && result.invocationResult.termConditionPdf.indexOf("|")) ? result.invocationResult.termConditionPdf.split("|") : null;
			dt.termConditionPdfName = termConditionPdf ? termConditionPdf[0] : "image"; 
			dt.termConditionPdfFileName = termConditionPdf ? termConditionPdf[1] : ""; 

			dt.termConditionPdf = result.invocationResult.termConditionPdf;

			dt.isEligible = $stateParams.is_eligible ? $stateParams.is_eligible : false;

			$scope.MyContestDetails = dt;
		} else {
			AppsLog.log("No data found. Please try again later!");
		}
	}

	function updateLastUpdate(result){
		if (result.invocationResult.isSuccessful) {
			$scope.lastUpdate = '';
			if(result.invocationResult.lastUpdate != null){
				var lastUpdateDateTemp = new Date(result.invocationResult.lastUpdate);
				$scope.lastUpdate = moment(lastUpdateDateTemp).format('LL');
			}
		}
	}

	function getDataAllBigContestListFailed(result) {
		AppsLog.log("Load Data Failed, Please Check Your Connection");
	}
	

	$scope.accordionWidgetCollapse = function(e){
		var self = $(e.toElement);
		var accordion = self.parents(".widget-policy");
		var accordionBody = accordion.find(".list-info, .list-info-contest");

		if(accordion.hasClass("collapse1")){
			accordion.removeClass("collapse1");
			accordionBody.attr("style","margin-top: -"+(accordionBody.height()+ 15)+"px;");
		}else {
			accordion.addClass("collapse1");
			accordionBody.css("margin-top","0px");
			accordionBody.css("padding-top","12px");
		}
	}
	
	$scope.accordionWidgetCollapseDesc = function(e){
		var self = $(e.toElement);
		var accordion = self.parents(".widget-policy");
		var accordionBody = accordion.find(".list-info, .list-info-contest");

		if(accordion.hasClass("collapse1")){
			accordion.removeClass("collapse1");
			accordionBody.attr("style","margin-top: -"+(accordionBody.height()+ 15)+"px;");
		}else {
			accordion.addClass("collapse1");
			accordionBody.css("margin-top","0px");
			accordionBody.css("padding-top","45px");
		}
	}
	
	function init() {
		setTimeout(function(){
			for (var i = 0; i < $(".tab-item").length; i++) {
				$($(".tab-item")[i]).attr("data-position-left", ($($(".tab-item")[i]).position().left - 20));
			}
		}, 100)
	}
	
	$scope.accordionInit = function(){
		var accordions = $(".list-info-accordion");

		$.each(accordions, function( index, value ) {
			var accordionBody = $(value).find(".accordion-body");

			if(!$(value).hasClass("collapsed")){
				accordionBody.attr("style", "margin-top: -" + accordionBody.height() + "px;")
			}
		});
	}
	
	$scope.accordionWidgetInit = function(){
		var accordionsWidget = $(".widget-policy");

		$.each(accordionsWidget, function( index, value ) {
			var accordionBody = $(value).find(".list-info, .list-info-contest");

			if(!$(value).hasClass("collapse1")){
				accordionBody.attr("style", "margin-top: -" + (accordionBody.height() + 15) +"px;");
			}
		});
	}
	
	angular.element(document).ready(function() {
		init();
		$scope.accordionInit();
		$scope.accordionWidgetInit();
	});
})