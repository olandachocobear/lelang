﻿angular.module('PruForce.controllers')
	.controller('ContestPolicyListCtrl', function ($scope, $rootScope, $ionicLoading, $http, $state, $filter, $stateParams, AllPolicy, PolicyStatus, AllPolicyListContestService) {
		AnalyticsLog.logPage("prudential.contest.policy.list");

		$rootScope.page = 0;
		$rootScope.noMoreItemsAvailable = false;
		$rootScope.numberOfItemsToDisplay = $rootScope.size;
		$rootScope.inProgress = false;
		$ionicLoading.show();

		$rootScope.searchBy = '';
		$rootScope.orderBy = '';
		$rootScope.orderDirection = '';
		var policyStatus = '';
		var orderDirection = '';

		this.filterSearchString = '';
		$scope.listPolicyAll = [];
		$scope.error500 = false;

		getDataPolicyListSuccess(AllPolicy);
		$scope.getDataPolicyListSuccess = getDataPolicyListSuccess;

		$scope.filterPolicy = {
			"data": [
				{
					"id": "",
					"name": $filter('translate')('SHOW_ALL')
				}
			]
		};

		if (PolicyStatus.invocationResult.isSuccessful) {
			angular.forEach(PolicyStatus.invocationResult.array, function (value, key) {
				$scope.filterPolicy.data.push({
					'id': value['policyStatus'],
					'name': value['description']
				});
			})
		} else {
			AppsLog.log("No data found. Please try again later!");
		}

		$scope.sortItem = {
			onRequest: $scope.filterPolicy.data[0]
		};

		$rootScope.filterDirection = {
			data: [
				{
					"id": 0,
					"name": $filter('translate')('DEFAULT_SORT')
				}, {
					"id": 1,
					"name": $filter('translate')('POLICY_NAME')
				}, {
					"id": 2,
					"name": $filter('translate')('POLICY_NUMBER')
				}
			]
		};

		$scope.orderItem = {
			onRequest: $rootScope.filterDirection.data[0]
		};

		$scope.loadMore = function () {
			if (!$rootScope.inProgress) {
				$rootScope.inProgress = true;
				$rootScope.page += 1;
				$scope.showSpinner = true;
				getDataFromService();
			}
			$rootScope.noMoreItemsAvailable = false;
			$scope.$broadcast('scroll.infiniteScrollComplete');
		};

		$scope.moreItemsAvailable = function () {
			return !$scope.noMoreItemsAvailable;

		};

		$scope.GoSearching_GoFiltering = function () {
			$ionicLoading.show();
			//$scope.showSpinner = true;
			$rootScope.inProgress = true;
			$scope.listPolicyAll = [];
			$rootScope.page = 1;
			$rootScope.numberOfItemsToDisplay = 10;
			$rootScope.searchBy = this.filterSearchString;
			$rootScope.orderDirection = '';

			if ($scope.orderItem.onRequest.id == 1) {
				$rootScope.orderDirection = 'asc';
				$rootScope.orderBy = 'policyHolderName';
			} else if ($scope.orderItem.onRequest.id == 2) {
				$rootScope.orderDirection = 'asc';
				$rootScope.orderBy = 'policyNumber';
			}

			policyStatus = [];
			if ($scope.sortItem.onRequest.id) {
				policyStatus.push($scope.sortItem.onRequest.id);
			}
			if ($rootScope.searchBy == undefined) {
				$rootScope.searchBy = '';
			}

			$rootScope.noMoreItemsAvailable = false;
			getDataFromService();
		}

		function getDataFromService() {
			AllPolicyListContestService.invoke($rootScope.username, $rootScope.agent.code, $stateParams.contestCode, policyStatus, $rootScope.searchBy, $rootScope.orderBy, $rootScope.orderDirection, $rootScope.size, $rootScope.page).then(function (res) {
				getDataPolicyListSuccess(res);
			});
		}

		function getDataPolicyListSuccess(result) {
			var proposalReceivedDatetemp;
			$scope.showSpinner = false;

			if (result.invocationResult.isSuccessful) {
				if (result.invocationResult.array != null) {
					if (result.invocationResult.array.length > 0) {
						for (var i = 0; i < result.invocationResult.array.length; i++) {
							var dt = {};

							dt.policyStatusDesc = result.invocationResult.array[i].status;
							dt.policyNumber = result.invocationResult.array[i].policyNumber;
							dt.policyStatus = result.invocationResult.array[i].status;
							dt.policyHolderName = result.invocationResult.array[i].policyHolderName;
							dt.productName = result.invocationResult.array[i].productName;
							dt.productCode = result.invocationResult.array[i].productName;
							dt.PruCodeEnd = (dt.productCode).substring(3, (dt.productCode).size);
							proposalReceivedDateTemp = result.invocationResult.array[i].proposalReceivedDate;
							dt.proposalReceivedDate = moment(proposalReceivedDateTemp).format('LL');

							$scope.listPolicyAll.push(dt);

							var retrieveDate = result.invocationResult.retrieveDate;
							var lastUpdate = moment(retrieveDate).format('LLLL');
							$scope.lastUpdate = lastUpdate;
						}

						$rootScope.numberOfItemsToDisplay = $scope.listPolicyAll.length;

						if ($scope.listPolicyAll.length == 0) {
							$rootScope.noMoreItemsAvailable = true;
						}
					} else {
						$rootScope.noMoreItemsAvailable = true;
					}
				} else {
					$rootScope.noMoreItemsAvailable = true;
				}

				if (result.invocationResult.error == 500 || result.invocationResult.statusCode == 500) {
					$rootScope.noMoreItemsAvailable = true;
					AppsLog.log("No data found. Please try again later!");
					$scope.error500 = true;
				}

			} else {
				if (result.invocationResult.error == 500 || result.invocationResult.statusCode == 500) {
					$scope.showLoading = false;
					AppsLog.log("Load Data Failed, Please Check Your Connection");
					$scope.error500 = true;
				} else {
					AppsLog.log("No data found. Please try again later!");
				}
				$rootScope.noMoreItemsAvailable = true;
			}

			$rootScope.inProgress = false;
			$scope.showSpinner = false;
			$ionicLoading.hide();
		}

		function getDataPersistencyListFailed(result) {
			$ionicLoading.hide();
			AppsLog.log("Data Individu Failed, Please Check Your Connection");
		}

		$scope.changePage = function (id) {
			$state.go('inquiries_proposal_policy_details', { policyNumber: id, Type: 2, agentNumber: $rootScope.agent.code, PageType: "unit" });
		}
	})