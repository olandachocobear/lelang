﻿angular.module('PruForce.controllers')
	.controller('ContestCompletedCtrl', function ($scope, $rootScope, $ionicLoading, $sce, $translate, $state, $interval, $http, $filter, AllCompletedContestService, AllCompletedContestYearsService) {
		AnalyticsLog.logPage("prudential.contest.completed");

		$rootScope.page = 0;
		$rootScope.noMoreItemsAvailable = false;
		$rootScope.numberOfItemsToDisplay = $rootScope.size;
		$rootScope.inProgress = false;
		// $ionicLoading.show();

		$scope.ListAllCompletedContests = [];

		var completedYear = '';
		var searchBy2Individu = '';
		var orderBy = '';
		this.filterSearchString = '';
		var directionIndividu = 'asc';
		$scope.error500 = false;
		$rootScope.searchBy = '';
		$rootScope.orderDirection = '';
		$scope.transaction = [];

		$scope.refreshPage = function () {
			$scope.error500 = false;
		}

		$scope.loadMore = function () {
			if (!$rootScope.inProgress) {
				$rootScope.inProgress = true;
				$rootScope.page += 1;
				$scope.showSpinner = true;
				getDataFromService();
			}
			$rootScope.noMoreItemsAvailable = false;
			$scope.$broadcast('scroll.infiniteScrollComplete');
		};

		$scope.moreItemsAvailable = function () {
			return !$rootScope.noMoreItemsAvailable;
		};

		function getAllCompletedContestYearsFromService() {
			AllCompletedContestYearsService.invoke($rootScope.username, $rootScope.agent.code).then(function (res) {
				getDataAllCompletedContestYearsListSuccess(res);
			}, function (error) {
				AppsLog.log(error);
			});
		}

		getAllCompletedContestYearsFromService();
		function getDataFromService() {
			AllCompletedContestService.invoke($rootScope.username, $rootScope.agent.code, $rootScope.agent.agentType, $rootScope.size, $rootScope.page, completedYear, $rootScope.searchBy, $rootScope.orderDirection).then(function (res) {
				getDataAllCompletedContestListSuccess(res);
			}, function (error) {
				$scope.error500 = true;
				$rootScope.inProgress = false;
				$scope.showSpinner = false;
				$rootScope.page -= 1;
				AppsLog.log(error);
			});
		}

		$scope.completedYears = {
			data: [{
				id: 'null',
				name: $filter('translate')('CONTEST.SELECT_YEAR_COMPLETED')
			}]
		};

		$scope.yearsFilterItem = {
			onRequest: $scope.completedYears.data[0]
		};

		$scope.orderByItem = {
			data: [{
				id: 'null',
				name: $filter('translate')('CONTEST.SELECT_ORDER_COMPLETED')
			}, {
					id: 'recentYear',
					name: $filter('translate')('CONTEST.RECENT_YEARS_COMPLETED')
				},
				{
					id: 'longestYear',
					name: $filter('translate')('CONTEST.LONGEST_YEARS_COMPLETED')
				},
				{
					id: 'name',
					name: $filter('translate')('CONTEST.CONTEST_NAME_COMPLETED')
				}
			]
		};

		$scope.orderByItemFilter = {
			onRequest: $scope.orderByItem.data[0]
		};

		$scope.GoSearching_GoFiltering = function () {
			// $ionicLoading.show();
			$scope.showSpinner = true;
			$rootScope.inProgress = true;
			$rootScope.page = 1;
			$rootScope.numberOfItemsToDisplay = 10;

			$scope.ListAllCompletedContests = [];
			completedYear = angular.isUndefined($scope.yearsFilterItem.onRequest.id) ? "" : $scope.yearsFilterItem.onRequest.id;
			$rootScope.searchBy = angular.isUndefined(this.filterSearchString) ? "" : this.filterSearchString;
			$rootScope.orderDirection = '';
			$rootScope.orderDirection = $scope.orderByItemFilter.onRequest.id;

			if ($rootScope.orderDirection == 'null') {
				$rootScope.orderDirection = 'recentYear';
			}

			$rootScope.noMoreItemsAvailable = false;
			getDataFromService();
		}
		$scope.changePageCompletedContestDetail = function (id) {
			$state.go('contest_completed_detail', { contestCode: id });
		}

		function getDataAllCompletedContestListSuccess(result) {

			var completedDateTemp;
			var completedDateTemp2;

			var currentDate;

			if (result.invocationResult.isSuccessful) {
				var policyHolderNameTemp;
				var proposalReceivedDatetemp;
				var proposalReceivedDatetemp2;

				if (result.invocationResult.array != null) {
					if (result.invocationResult.array.length > 0) {
						for (var i = 0; i < result.invocationResult.array.length; i++) {
							var dt = {};

							dt.contestCode = result.invocationResult.array[i].contestCode;
							dt.contestName = result.invocationResult.array[i].contestName;
							completedDateTemp = new Date(result.invocationResult.array[i].completedDate);
							completedDateTemp2 = moment(completedDateTemp).format('LL');
							dt.completedDate = completedDateTemp2;
							dt.achieved = result.invocationResult.array[i].achieved;
							dt.status = result.invocationResult.array[i].currentContest;
							dt.orphan = result.invocationResult.array[i].orphan;
							dt.overall = result.invocationResult.array[i].overall;

							if (dt.overall == null) {

								progressSingle = (dt.completedTask / dt.totalTask) * 100;
								dt.overall = {};
								dt.overall.lineStatus = "nothave";
								dt.overall.progress = progressSingle;
								dt.overall.spinner = $filter('formatNumber')(progressSingle, 0);
								dt.overall.flagSingleContest = true;
							}
							else {
								dt.overall.spinner = $filter('formatNumber')(dt.overall.progress, 0);
								dt.overall.lineStatus = "have";
								dt.overall.flagSingleContest = false;
							}

							dt.params = angular.copy(result.invocationResult.array[i].params);

							angular.forEach(dt.params, function (value, key) {
								if (dt.params[key].percentage != undefined || dt.params[key].percentage != null) {
									dt.params[key].percentageRound = $filter('formatNumber')(dt.params[key].percentage, 0);
									dt.params[key].percentage = $filter('formatNumber')(dt.params[key].percentage, 1);
								}
								dt.params[key].subtitle = $sce.trustAsHtml($translate.instant(dt.params[key].subtitle, dt.params[key]));
							});

							$scope.ListAllCompletedContests.push(dt);
						}

						if ($scope.ListAllCompletedContests.length == 0) {
							$rootScope.noMoreItemsAvailable = true;
						}
					} else {
						$rootScope.noMoreItemsAvailable = true;
					}
				}

				$rootScope.numberOfItemsToDisplay = $scope.ListAllCompletedContests.length;

				if (result.invocationResult.error == 500 || result.invocationResult.statusCode == 500) {
					$rootScope.noMoreItemsAvailable = true;
					$scope.error500 = true;
					AppsLog.log("No data found. Please try again later!");
				}

			} else {
				if (result.invocationResult.error == 500 || result.invocationResult.statusCode == 500) {
					AppsLog.log("Load Data Failed, Please Check Your Connection");
					$scope.error500 = true;
				} else {
					AppsLog.log("No data found. Please try again later!");
				}
				$rootScope.noMoreItemsAvailable = true;
			}

			$ionicLoading.hide();
			$rootScope.inProgress = false;
			$scope.showSpinner = false;
		}

		function getDataAllBigContestListFailed(result) {
			AppsLog.log("Load Data Failed, Please Check Your Connection");
		}


		function getDataAllCompletedContestYearsListSuccess(result) {
			if (result.invocationResult.isSuccessful) {
				angular.forEach(result.invocationResult.array, function (value, key) {
					$scope.completedYears.data.push({
						'id': value,
						'name': value
					});
				})
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
			$ionicLoading.hide();
		}

		function getDataAllCompletedContestYearsListFailed(result) {
			AppsLog.log("Load Data Failed, Please Check Your Connection");
		}

		function changePageSize() {
			var tabList = document.getElementsByClassName('tabList');
			if (tabList[0]) {
				tabList[0].style.minHeight = (window.innerHeight - 100) + "px";
			}
		}

		angular.element(document).ready(function () {
			changePageSize();
		});

		$(window).resize(function () {
			changePageSize();
		});

	})