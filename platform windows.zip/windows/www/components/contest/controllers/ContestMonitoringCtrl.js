﻿angular.module('PruForce.controllers')
	.controller('ContestMonitoringCtrl', function ($sce, $translate, $scope, $rootScope, $ionicLoading, $state, $interval, $http, $filter, AllMonitoringContestService) {
		AnalyticsLog.logPage("prudential.contest.monitoring.all");

		$rootScope.page = 0;
		$rootScope.noMoreItemsAvailable = false;
		$rootScope.numberOfItemsToDisplay = $rootScope.size;
		$rootScope.inProgress = false;
		// $ionicLoading.show();

		$scope.ListAllMonitoringContests = [];
		$scope.showSpinner = true;
		$scope.error500 = false;

		var extraCreditFlag = 0;

		$scope.refreshPage = function () {
			$scope.error500 = false;
		}

		$scope.loadMore = function () {
			if (!$rootScope.inProgress) {
				$rootScope.inProgress = true;
				$rootScope.page += 1;
				$scope.showSpinner = true;
				getDataFromService();
			}
			$rootScope.noMoreItemsAvailable = false;
			$scope.$broadcast('scroll.infiniteScrollComplete');
		};

		$scope.MoreItemsAvailable = function () {
			return !$rootScope.noMoreItemsAvailable;
		};

		function getDataFromService() {
			AllMonitoringContestService.invoke($rootScope.username, $rootScope.agent.code, $rootScope.agent.agentType, $rootScope.size, $rootScope.page).then(function (res) {
				getDataAllMonitoringContestListSuccess(res);
			}, function (error) {
				$scope.error500 = true;
				$rootScope.inProgress = false;
				$scope.showSpinner = false;
				$rootScope.page -= 1;
				AppsLog.log(error);
			});
		}

		function getDataAllMonitoringContestListSuccess(result) {

			var dueDateTemp, dueDateTemp2;

			var currentDate;
			var timeDiff;
			var diffDays;

			var progressSingle;
			var apiColorTemp;
			var percentageChildTemp;

			if (result.invocationResult.isSuccessful) {
				var policyHolderNameTemp;
				var proposalReceivedDatetemp;
				var proposalReceivedDatetemp2;

				if (result.invocationResult.array != null) {
					if (result.invocationResult.array.length > 0) {
						for (var i = 0; i < result.invocationResult.array.length; i++) {
							var dt = {};

							dt.contestCode = result.invocationResult.array[i].contestCode;
							dt.contestName = result.invocationResult.array[i].contestName;
							dt.orphan = result.invocationResult.array[i].orphan;
							dueDateTemp = new Date(result.invocationResult.array[i].dueDate);
							dueDateTemp2 = moment(dueDateTemp).format('LL');

							currentDate = new Date();

							var diffDays = 0;
							if (!dueDateTemp.isSameDateAs(currentDate)) {
								var timeDiff = Math.abs(dueDateTemp.getTime() - currentDate.getTime());
								diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
							}

							if (diffDays == 0) {
								diffDays = $filter("translate")("CONTEST.TODAY");
							}
							else if (diffDays == 1) {
								diffDays = $filter("translate")("CONTEST.TOMORROW");
							}
							else {
								diffDays = dueDateTemp2;
							}

							dt.periodEndDiff = diffDays;
							dt.dueDate = dueDateTemp2;
							dt.daysLeft = result.invocationResult.array[i].daysLeft;

							dt.overall = result.invocationResult.array[i].overall;
							dt.completedTask = result.invocationResult.array[i].completedTask;
							dt.totalTask = result.invocationResult.array[i].totalTask;

							if (dt.overall == null) {

								progressSingle = (dt.completedTask / dt.totalTask) * 100;
								dt.overall = {};
								dt.overall.lineStatus = "nothave";
								dt.overall.progress = $filter('formatNumber')(progressSingle, 1);
								dt.overall.spinner = $filter('formatNumber')(progressSingle, 0);
							}
							else {
								dt.overall.spinner = $filter('formatNumber')(dt.overall.progress, 0);
								dt.overall.lineStatus = "have";
							}

							dt.status = result.invocationResult.array[i].status;
							dt.params = angular.copy(result.invocationResult.array[i].params);

							angular.forEach(dt.params, function (value, key) {

								if (dt.params[key].lapseZone == "0") {
									dt.params[key].progType = "prog-red prog-red";
								}
								else if (dt.params[key].lapseZone == "1") {
									dt.params[key].progType = "prog-gold prog-gold";
								}
								else {
									dt.params[key].progType = "prog";
								}

								if (dt.params[key].percentage != undefined || dt.params[key].percentage != null) {
									dt.params[key].percentageRound = $filter('formatNumber')(dt.params[key].percentage, 0);
									percentageChildTemp = dt.params[key].percentage;
									dt.params[key].percentage = $filter('formatNumber')(percentageChildTemp, 1);
								}

								dt.params[key].subtitle = $sce.trustAsHtml($translate.instant(dt.params[key].subtitle, dt.params[key]));
							});

							$scope.ListAllMonitoringContests.push(dt);
						}

						if ($scope.ListAllMonitoringContests.length == 0) {
							$rootScope.noMoreItemsAvailable = true;
						}
					} else {
						$rootScope.noMoreItemsAvailable = true;
					}
				}

				$rootScope.numberOfItemsToDisplay = $scope.ListAllMonitoringContests.length;

				if (result.invocationResult.error == 500 || result.invocationResult.statusCode == 500) {
					$rootScope.noMoreItemsAvailable = true;
					AppsLog.log("No data found. Please try again later!");
					$scope.error500 = true;
				}

			} else {
				if (result.invocationResult.error == 500 || result.invocationResult.statusCode == 500) {
					AppsLog.log("Load Data Failed, Please Check Your Connection");
					$scope.error500 = true;
				} else {
					AppsLog.log("No data found. Please try again later!");
				}
				$rootScope.noMoreItemsAvailable = true;
			}

			$ionicLoading.hide();
			$rootScope.inProgress = false;
			$scope.showSpinner = false;
		}

		function getDataAllBigContestListFailed(result) {
			AppsLog.log("Load Data Failed, Please Check Your Connection");
		}

		$scope.changePageContestMonitoringDetail = function (id) {
			$state.go('contest_monitoring_detail', { contestCode: id });
		}

		function changePageSize() {
			var tabList = document.getElementsByClassName('tabList');
			if (tabList[0]) {
				tabList[0].style.minHeight = (window.innerHeight - 100) + "px";
			}
		}

		angular.element(document).ready(function () {
			changePageSize();
		});

		$(window).resize(function () {
			changePageSize();
		});

	})