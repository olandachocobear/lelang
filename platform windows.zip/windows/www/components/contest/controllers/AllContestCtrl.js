﻿angular.module('PruForce.controllers')
.controller('AllContestCtrl',	function($scope, $rootScope, $ionicPopup, $window, $ionicLoading, $state,$interval, $http, $filter, $translate, $sce, AllContestService, AllBigContestService, SaveContestFavoriteService, DeleteContestFavoriteService, $ionicSlideBoxDelegate, CommonService) {
	AnalyticsLog.logPage("prudential.contest.allandbigcontest");
	
	$rootScope.page = 0;
	$rootScope.noMoreItemsAvailable = false;
	$rootScope.numberOfItemsToDisplay = $rootScope.size;
	$rootScope.inProgress = false;
	// $ionicLoading.show();

	$scope.listAllContestAll = [];
	$scope.ListAllBigContests = [];
	$scope.showSpinnerSlideBox = true;
	$scope.showSpinner= true;
	$scope.error500List = false;
	$scope.error500Big = false;
	var spinnerImage = [];

	$scope.data = {};
	$scope.data.sliderOption = {
        autoplay: 2500,
        autoplayDisableOnInteraction: false
	}
	$scope.data.activeIndex = 0;
	$scope.data.sliderDelegate = null;

	$scope.$broadcast('scroll.infiniteScrollComplete');
	// $ionicLoading.show();
	
	$scope.refreshPageList = function(){
		$scope.error500List = false;
	}

	$scope.refreshPageBig = function(){
		$scope.error500Big = false;
	}

	//********************************** Load More Page ************************//
	$scope.loadMore = function() {
		if (!$rootScope.inProgress) {
			$rootScope.inProgress = true;
			$rootScope.page += 1;
			$scope.showSpinner= true;
			getDataFromService();
			//getDataAllContestListSuccess(dummyAllBigContest);
		}
		$rootScope.noMoreItemsAvailable= false;
		$scope.$broadcast('scroll.infiniteScrollComplete');
		
	};

	$scope.MoreItemsAvailable = function() {
		return !$rootScope.noMoreItemsAvailable;
	};
	
	function getDataFromService() {	
		AllContestService.invoke($rootScope.username, $rootScope.agent.code, $rootScope.agent.agentType,  $rootScope.size, $rootScope.page).then( function (res){
			getDataAllContestListSuccess(res);
		}, function (error){
			AppsLog.log(error);
			$scope.error500List = true;
			$rootScope.inProgress = false;
			$scope.showSpinner = false;
			$rootScope.page -= 1;
		});
	}

	function getAllBigDataFromService() {	
		AllBigContestService.invoke($rootScope.username, $rootScope.agent.code, $rootScope.agent.agentType).then( function (res){	
			getDataAllBigContestListSuccess(res);
		}, function (error){
			AppsLog.log(error);
			$scope.error500Big = true;
			$scope.showSpinnerSlideBox = false;
		}); 
	}
	
	getAllBigDataFromService();

	//********************************** End of Load More Page *****************//

	//********************************** Start of Slider *****************//

	function init() {
		setTimeout(function(){
			for (var i = 0; i < $(".tab-item").length; i++) {
				$($(".tab-item")[i]).attr("data-position-left", ($($(".tab-item")[i]).position().left - 20));
			}
		}, 9000)
	}
	
	var resizeProccess = null;
	var onResize = false;

	$scope.refreshSize = function (pos){
		if(pos == $scope.data.sliderDelegate.activeIndex){
			if(!onResize){
				onResize = true;
				resizeProccess = setTimeout(function(){
					$scope.slideHasChanged(pos);
				},1000)
			}
		}
	}

	$scope.$on('selesaiLoadSlider', function (ngRepeatFinishedEvent) {
		$scope.showSpinnerSlideBox = false;
		$scope.refreshSize($scope.data.sliderDelegate.activeIndex);
	});

	angular.element($window).bind('resize', function() {
		$scope.refreshSize($scope.data.sliderDelegate.activeIndex);
	})


	$scope.$watch('data.sliderDelegate', function (newVal, oldVal) {
		if(newVal != null){
			$scope.data.sliderDelegate.on('slideChangeStart', function(){
				clearTimeout(resizeProccess);
				$scope.slideHasChanged($scope.data.sliderDelegate.activeIndex);
			})
		}
	});

	$scope.slideHasChanged = function(index){
		var bigContest = $(".big-contest");
		var currentSlideBig = $(bigContest.find(".swiper-slide")[index]);
		var imgWrapperBig = currentSlideBig.find(".image-wrapper").outerHeight();
		var contestInfoBig = $(currentSlideBig.find(".contest-info")[0]).outerHeight();
		var currentHeightBig = (imgWrapperBig + contestInfoBig + 15);

		$(".content-slider").height(currentHeightBig + "px");
		onResize = false;
	}


	function changePageSize(){
		var tabList = document.getElementsByClassName('tabList');
		if(tabList[0]){
			tabList[0].style.minHeight= (window.innerHeight - 100) + "px";			
		}
	}
	
	angular.element(document).ready(function() {
		init();
		changePageSize();
	});

	$( window ).resize(function() {
		changePageSize();
	});

	//********************************** End of Slider *****************//

	function getDataAllContestListSuccess(result) {

		if (result.invocationResult.isSuccessful) {
			if(result.invocationResult.array != null){
				if (result.invocationResult.array.length > 0) {
					for (var i = 0; i < result.invocationResult.array.length; i++){
						var dt = {};

						dt.contestCode = result.invocationResult.array[i].contestCode;
						dt.contestName = result.invocationResult.array[i].contestName;
						dt.contestState = result.invocationResult.array[i].contestState;
						dt.description = result.invocationResult.array[i].description;
						dt.topRank = 100; //result.invocationResult.array[i].topRank;
						dt.progressSts = result.invocationResult.array[i].progressSts;

						var progressSts = result.invocationResult.array[i].progressSts;

						dt.progressStsColor = "pull-right balanced";

						if (progressSts == "CLOSED"){
							dt.progressStsStatus = $filter('translate')('CONTEST.CLOSED');
							dt.progressStsColor = "pull-right assertive";	
						}
						else if (progressSts == "IN PROGRESS")
						{
							dt.progressStsStatus = $filter('translate')('CONTEST.IN_PROGRESS');
						}

						dt.favorite = result.invocationResult.array[i].favorite;

						$scope.listAllContestAll.push(dt);
					}

					if($scope.listAllContestAll.length == 0){
						$rootScope.noMoreItemsAvailable= true;
					}
				} else {
					$rootScope.noMoreItemsAvailable= true;
				}
			}

			$scope.numberOfItemsToDisplay = $scope.listAllContestAll.length;

			if(result.invocationResult.error==500 || result.invocationResult.statusCode == 500) {
				$rootScope.noMoreItemsAvailable= true;
				$scope.error500List = true;
				AppsLog.log("No data found. Please try again later!");
			}
		} else {
			if(result.invocationResult.error==500 || result.invocationResult.statusCode == 500) {
				$scope.showLoading = false;
				$scope.error500List = true;
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
			$rootScope.noMoreItemsAvailable= true;	
		}

		$ionicLoading.hide();
		$rootScope.inProgress = false;
		$scope.showSpinner= false;
	}

	function getDataAllContestListFailed(result) {
		AppsLog.log("Load Data Failed, Please Check Your Connection");
	}

	$scope.contestFav = function(e, contestCode, index){
		var self = $(e.toElement);
		$ionicLoading.show();
		self.blur();

		if(self.hasClass("contest-favorite")){
			DeleteContestFavoriteService.invoke($rootScope.username, $rootScope.agent.code, $rootScope.agent.agentType, contestCode).then(function(res){
				$ionicLoading.hide();
				self.removeClass("contest-favorite");
				$scope.listAllContestAll[index].favorite = false;
			}, function(error){
				$ionicLoading.hide();
				return $scope.showAlert($filter('translate')('CONTEST.ATTENTION_NOTELIGIBLE'), $filter('translate')('CONTEST.ERROR'));
			});
		}else{
			SaveContestFavoriteService.invoke($rootScope.username, $rootScope.agent.code, $rootScope.agent.agentType, contestCode).then(function (res){
				$ionicLoading.hide();
				if (res.invocationResult.message == "I001")
				{
					$scope.listAllContestAll[index].favorite = true;
					self.addClass("contest-favorite");
				}
				var message = $translate.instant(resolveMessage(res.invocationResult.message), $scope.listAllContestAll[index]);
				res.invocationResult.message = "";
				return $scope.showAlert($filter('translate')('CONTEST.ATTENTION_NOTELIGIBLE'), message);
			}, function(error){
				$ionicLoading.hide();
				return $scope.showAlert($filter('translate')('CONTEST.ATTENTION_NOTELIGIBLE'), $filter('translate')('CONTEST.ERROR'));
			});
		}
	}

	var resolveMessage = function(ECode){
		switch(ECode){
			case "E001":
				return 'CONTEST.NOT_FOUND';
			case "E002":
				return 'CONTEST.NOT_ELIGIBLE_CONTEST';
			case "E003":
				return 'CONTEST.NOT_IN_PERIOD';
			case "E004":
				return "CONTEST.MAX_FAVORITE_AMOUNT";
			case "E005":
				return "CONTEST.FAILED_SAVE_FAVORITE";
			case "E006":
				return "CONTEST.FAILED_DELETE_FAVORITE";
			case "I001":
				return "CONTEST.FAVORITE_SUCCESS";
			case "I002":
				return "CONTEST.FAVORITE_DELETE_SUCCESS";
		}
		/**
			E001 = Contest ${data.contestCode} is not found
			E002 = You are not eligible for this contest
			E003 = Contest ${data.contestCode} is not in period date range!
			E004 = You can choose maximum 3 active contest
			E005 = Failed to save contest favorite
			E006 = Data not found, failed to delete contest favorite
			I001 = Data Successfully Saved
			I002 = Data Successfully Deleted
		 */
	}

	//**************************** All Big Contest *******************************//
	$scope.changePageBigContestDetail = function(id, contestState) {			

		if (contestState == "notEligible")
		{
			$state.go('my_contest_detail_not_eligible', {contestCode: id});
		}
		else if (contestState == "myContest")
		{
			$state.go('my_contest_detail', {contestCode: id});
		}
		else if (contestState == "monitoring")
		{
			$state.go('contest_monitoring_detail', {contestCode: id});
		}
		else if (contestState == "completed")
		{
			$state.go('contest_completed_detail', {contestCode: id});
		}
	}

	$scope.changePageAllContestDetail = function(id, contestState) {	
		if (contestState == "notEligible")
		{
			$state.go('my_contest_detail_not_eligible', {contestCode: id});
		}
		else if (contestState == "myContest")
		{
			$state.go('my_contest_detail', {contestCode: id});
		}
		else if (contestState == "monitoring")
		{
			$state.go('contest_monitoring_detail', {contestCode: id});
		}
		else if (contestState == "completed")
		{
			$state.go('contest_completed_detail', {contestCode: id});
		}
	}

	$scope.hideSpinnerImages = function(index){
		return !(spinnerImage[index]);
	}

	function getDataAllBigContestListSuccess(result) {
		
		var progressSts2;
		var withChild;
		var paramCode;
		var flyerTemp;
		var periodStartTemp;
		var periodStartTemp2;
		var periodEndTemp;
		var periodEndTemp2;
		if(result.invocationResult != null){
			if (result.invocationResult.isSuccessful) {
				for (var i = 0; i < result.invocationResult.array.length; i++) {
					var dt = {};
					
					dt.contestCode = result.invocationResult.array[i].contestCode;
					dt.contestName = result.invocationResult.array[i].contestName;
					dt.contestState = result.invocationResult.array[i].contestState;				
					periodStartTemp = new Date(result.invocationResult.array[i].periodStart);
					periodStartTemp2 = moment(periodStartTemp).format('LL');
					dt.periodStart = periodStartTemp2;
					periodEndTemp = new Date(result.invocationResult.array[i].periodEnd);
					periodEndTemp2 = moment(periodEndTemp).format('LL');
					
					dt.periodEnd = periodEndTemp2;
					dt.flyers = result.invocationResult.array[i].flyers;
					var flyers = (dt.flyers != null && dt.flyers.indexOf("|")) ? dt.flyers.split("|") : null;
					dt.flyersName = flyers ? flyers[0] : "image"; 
					dt.flyersFileName = flyers ? flyers[1] : ""; 
					(function (filename, dt, pos) {
							spinnerImage[pos] = true;
							CommonService.invokeFileBase64(filename, 'contest').then(
								function (response) {
									if (response.invocationResult.isSuccessful) {
										dt.flyersBase64 = "data:image/jpeg;base64," + response.invocationResult.content;
									}
									spinnerImage[pos] = false;
								}, function (error) {
									spinnerImage[pos] = false;
								});
						})(dt.flyersFileName, dt, i);
					dt.description = $sce.trustAsHtml(result.invocationResult.array[i].description);
					dt.flagSingleContest = result.invocationResult.array[i].flagSingleContest;
					dt.listContestChildren = result.invocationResult.array[i].listContestChildren;
					
					var flagSingleContest2 = result.invocationResult.array[i].flagSingleContest;
					
					if (flagSingleContest2 == true){
						withChild = "content-of-progress";	
					}
					else
					{
						withChild = "content-of-progress with-child";
						angular.forEach(dt.listContestChildren, function(value, key)
						{
							dt.listContestChildren[key].paramCode = "PRM999";
						});

					}

					angular.forEach(dt.listContestChildren, function(value, key)
					{
						if(dt.flagSingleContest == true){
							dt.listContestChildren[key].percentageProgSpinner = $filter('formatNumber')(dt.listContestChildren[key].percentage,1);
							dt.listContestChildren[key].percentageProgRound = $filter('formatNumber')(dt.listContestChildren[key].percentage,0);
							dt.listContestChildren[key].percentage = $filter('formatNumber')(dt.listContestChildren[key].percentage, 1);
						} else if(dt.flagSingleContest == false){
							dt.listContestChildren[key].percentageProgSpinner = $filter('formatNumber')(dt.listContestChildren[key].totalPercentage,1);
							dt.listContestChildren[key].percentageProgRound = $filter('formatNumber')(dt.listContestChildren[key].totalPercentage,0);
							dt.listContestChildren[key].percentage = $filter('formatNumber')(dt.listContestChildren[key].totalPercentage, 1);
						}
					});
					
					dt.withChild = withChild;

					$scope.ListAllBigContests.push(dt);
				}
				
				//$rootScope.page += 1;
				//getDataFromService();
				if(result.invocationResult.error==500 || result.invocationResult.statusCode == 500) {
					$scope.error500Big = true;
					AppsLog.log("No data found. Please try again later!");
				}
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}

		$scope.showSpinnerSlideBox = false;

		$ionicLoading.hide();
		$ionicSlideBoxDelegate.update();
	}

	function getDataAllBigContestListFailed(result) {
		AppsLog.log("Load Data Failed, Please Check Your Connection");
	}

	//*****************************End of All Big Contest*********************************//

	$scope.showAlert = function(msg_title, msg_template) {
		var popUpButton3 = $(".popup-container .popup .popup-head h3");
		popUpButton3.css("line-height", "21px");
		popUpButton3.css("color", "#fff");
		popUpButton3.css("font-style", "italic");
		popUpButton3.css("font-size", "16px");

		var popUpButton4 = $(".popup-container .popup-buttons");
		popUpButton4.css("visibility", "hidden");
		popUpButton4.css("height", "0");
		popUpButton4.css("min-height", "0");

		var popUpButton5 = $(".popup-container .list-info");
		popUpButton5.css("border-bottom", "solid 1px #e5e5e5");

		var popUpButton6 = $(".popup-container .popup .popup-body");
		popUpButton6.css("overflow-y", "scroll");
		popUpButton6.css("overflow-x", "hidden");
		popUpButton6.css("-webkit-overflow-scrolling", "touch");

		var popUpButton7 = $(".popup-container .content p");
		popUpButton7.css("font-style", "normal");

		var alertPopup = $ionicPopup.alert({
			title: msg_title,
			template: msg_template
		});
		var popUpButton0 = $(".popup-container");
		popUpButton0.css("background-color", "rgba(0, 0, 0, 0.7)");
		popUpButton0.css("z-index", "2000");
		var popUpButton01 = $(".popup-container .popup");
		popUpButton01.css("width", "88vw");
		popUpButton01.css("margin-top", "86px");
		popUpButton01.css("margin-bottom", "56px");
		popUpButton01.css("background-color", "rgba(255, 255, 255, 1)");
		var popUpButton1 = $(".popup-container .popup .popup-head");
		
		popUpButton1.css("background-color", "#ff0000");
		var popUpButton = $(".popup-container .popup-buttons");
		popUpButton.css("visibility", "visible");
		popUpButton.css("min-height", "65px");
		var popUpButton2 = $(".popup-container .popup .popup-body");
		popUpButton2.css("padding", "5vw");
		popUpButton2.css("overflow", "auto");

		alertPopup.then(function(res) {
		});
	};

})