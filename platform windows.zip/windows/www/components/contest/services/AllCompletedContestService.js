﻿angular.module('PruForce.services')
	.service('AllCompletedContestService', function (DataFactory, $q) {
		function invoke(salesforceId, agentNumber, agentType, max, page, year, searchBy, orderBy) {

			var req = {
				adapter: "HTTPAdapterContest",
				procedure: "findAllCompletedContest",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + salesforceId + "','" + agentNumber + "','" + agentType + "'," + max + "," + page + "," + year + ",'" + searchBy + "','" + orderBy + "']" }
			};

			var deferred = $q.defer();

			DataFactory.invoke(req, true, false)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invoke: invoke
		}
	});

