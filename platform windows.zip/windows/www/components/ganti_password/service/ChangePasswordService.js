﻿angular.module('PruForce.services')

	.service('ChangePasswordService', function (AOBResources, $q) {

		function invoke(username, nPassword, cPassword) {

			var req = {
				adapter: "HTTPAdapterAuth",
				procedure: "ChangePasspruforceid",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + username + "','" + nPassword + "','" + cPassword + "']" }
			};

			var deferred = $q.defer();

			AOBResources.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invoke: invoke
		}
	});

