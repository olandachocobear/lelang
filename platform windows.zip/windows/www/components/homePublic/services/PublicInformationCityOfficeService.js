﻿angular.module('PruForce.services')

	.service('PublicInformationCityOfficeService', function (DataFactory, $q, $rootScope) {

		function invoke() {
			var req = {
				adapter: "HTTPAdapter3",
				procedure: "findPublicInformationCityOffice",
				method: WLResourceRequest.POST,
				parameters: { "params": "[]" }

			};

			var deferred = $q.defer();

			DataFactory.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
				}, function (error) {
					deferred.reject(error);
				});

			$rootScope.flagingAlwaysOnline = false;
			return deferred.promise;
		}

		return {
			invoke: invoke
		}
	});

