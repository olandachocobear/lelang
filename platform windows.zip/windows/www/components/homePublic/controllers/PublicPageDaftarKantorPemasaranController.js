﻿angular.module('PruForce.controllers')

	.controller('PublicPageDaftarKantorPemasaranController', function ($scope, $rootScope, $ionicLoading, $filter, $translate, DataOffice, CityOffice, PublicInformationOfficeService) {

		AppsLog.log("START >> PublicPageDaftarKantorPemasaranController " + new Date());
		AnalyticsLog.logPage("prudential.public.agencyoffice");
		var sizeOffice = 30;
		var pageOffice = 1;
		var filterSearch = "";
		var filterCityCode = "";
		$scope.transaction = [];
		var listOfficeAll = [];
		var listOfficeAfterAdd = [];
		$scope.noMoreItemsAvailable = false;
		$scope.numberOfItemsToDisplay = 30;

		$scope.loadMore = function () {
			pageOffice += 1;
			$scope.showSpinner = true;
			getDataFromService();
			$scope.noMoreItemsAvailable = false;
			$scope.$broadcast('scroll.infiniteScrollComplete');
		};

		$scope.GoSearching_GoFiltering = function () {
			$ionicLoading.show();
			listOfficeAll = [];
			sizeOffice = 30;
			pageOffice = 1;
			filterSearch = ($scope.transaction.searchString == undefined) ? "" : $scope.transaction.searchString.replace(/['|"|\\]/g, "\\$&");
			if ($scope.filterItem.onRequest == $filter('translate')('SHOW_ALL')) {
				filterCityCode = '';
			} else {
				filterCityCode = $scope.filterItem.onRequest;
			}

			if (filterSearch == undefined) {
				filterSearch = '';
			}

			$scope.noMoreItemsAvailable = false;
			getDataFromService();
		}

		function getDataFromService() {
			PublicInformationOfficeService.invoke(pageOffice, sizeOffice, filterCityCode, filterSearch).then(function (res) {
				getDataOfficeListSuccess(res);
			});
		}
		getDataOfficeListSuccess(DataOffice);
		$scope.getDataOfficeListSuccess = getDataOfficeListSuccess;
		function getDataOfficeListSuccess(result) {
			if (result.invocationResult.isSuccessful) {
				var policyHolderNameTemp;
				$scope.showSpinner = false;
				if (result.invocationResult.array != null) {
					if (listOfficeAll.length == 0) {
						listOfficeAll = [];
						for (var i = 0; i < result.invocationResult.array.length; i++) {
							var dt = {};
							dt.officeName = $filter('uppercase')(result.invocationResult.array[i].officeName);
							dt.officeAddr1 = $filter('uppercase')(result.invocationResult.array[i].officeAddr1);
							dt.officeAddr2 = $filter('uppercase')(result.invocationResult.array[i].officeAddr2);
							dt.officeAddr3 = $filter('uppercase')(result.invocationResult.array[i].officeAddr3);
							dt.officePhone = result.invocationResult.array[i].officePhone;
							listOfficeAll[i] = dt;
							pageOffice = 1;
						}
					} else {
						for (var i = 0; i < result.invocationResult.array.length; i++) {
							var dt = {};
							dt.officeName = $filter('uppercase')(result.invocationResult.array[i].officeName);
							dt.officeAddr1 = $filter('uppercase')(result.invocationResult.array[i].officeAddr1);
							dt.officeAddr2 = $filter('uppercase')(result.invocationResult.array[i].officeAddr2);
							dt.officeAddr3 = $filter('uppercase')(result.invocationResult.array[i].officeAddr3);
							dt.officePhone = result.invocationResult.array[i].officePhone;
							listOfficeAfterAdd[i] = dt;
							listOfficeAll.push(listOfficeAfterAdd[i]);
							$scope.numberOfItemsToDisplay += listOfficeAfterAdd.length;

						}


					}
				}

				$scope.agentList = listOfficeAll;
				$scope.noMoreItemsAvailable = false;
				$ionicLoading.hide();
				if (result.invocationResult.statusCode == 500) {
					$scope.noMoreItemsAvailable = true;
					$ionicLoading.hide();
					AppsLog.log("No data found1. Please try again later!");
				}

			} else if (result.invocationResult.statusCode == 500) {
				$scope.showLoading = false;
				$ionicLoading.hide();
				$scope.noMoreItemsAvailable = true;
				AppsLog.log("No data found2. Please try again later!");
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}

		getListCityOfficeSuccess(CityOffice);
		$scope.getListCityOfficeSuccess = getListCityOfficeSuccess;
		function getListCityOfficeSuccess(result) {
			AppsLog.log(" hasil json :" + JSON.stringify(result));
			if (result.invocationResult.isSuccessful) {
				if (result.invocationResult.array != null) {
					$scope.listCityOffice = [];
					$scope.listCityOffice.push($filter('translate')('SHOW_ALL'));
					for (var i = 0; i < result.invocationResult.array.length; i++) {
						$scope.listCityOffice.push(result.invocationResult.array[i].city_code);
					}
					$scope.filterItem = {
						onRequest: $scope.listCityOffice[0]
					}
				}
			} else if (result.invocationResult.statusCode == 500) {
				$ionicLoading.hide();
				AppsLog.log("PublicPageDaftarKantorPemasaranController - No data found. Please try again later!");
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}
		AppsLog.log("END >> PublicPageDaftarKantorPemasaranController " + new Date());
	});