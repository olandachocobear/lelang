﻿angular.module('PruForce.controllers')

	.controller('PublicPageHospitalController', function ($scope, $rootScope, $ionicLoading, $filter, $translate, DataHospital, CityHospital, PublicInformationHospitalService) {

		AppsLog.log("START >> PublicHospitalController " + new Date());
		AnalyticsLog.logPage("prudential.public.hospital");
		var sizeHospital = 30;
		var pageHospital = 1;
		var filterSearch = "";
		var filterCityCode = "";
		$scope.transaction = [];
		var listHospitalAll = [];
		var listHospitalAfterAdd = [];
		$scope.noMoreItemsAvailable = false;
		$scope.numberOfItemsToDisplay = 30;

		$scope.loadMore = function () {
			pageHospital += 1;
			$scope.showSpinner = true;
			getDataFromService();
			$scope.noMoreItemsAvailable = false;
			$scope.$broadcast('scroll.infiniteScrollComplete');
		};

		$scope.GoSearching_GoFiltering = function () {
			$ionicLoading.show();
			listHospitalAll = [];
			sizeHospital = 30;
			pageHospital = 1;
			filterSearch = ($scope.transaction.searchString == undefined) ? "" : $scope.transaction.searchString.replace(/['|"|\\]/g, "\\$&");
			if ($scope.filterItem.onRequest == $filter('translate')('SHOW_ALL')) {
				filterCityCode = '';
			} else {
				filterCityCode = $scope.filterItem.onRequest;
			}

			if (filterSearch == undefined) {
				filterSearch = '';
			}

			$scope.noMoreItemsAvailable = false;
			getDataFromService();
		}

		function getDataFromService() {
			PublicInformationHospitalService.invoke(pageHospital, sizeHospital, filterCityCode, filterSearch).then(function (res) {
				getDataHospitalListSuccess(res);
			});
		}
		getDataHospitalListSuccess(DataHospital);
		$scope.getDataHospitalListSuccess = getDataHospitalListSuccess;
		function getDataHospitalListSuccess(result) {
			if (result.invocationResult.isSuccessful) {
				var policyHolderNameTemp;
				$scope.showSpinner = false;
				if (result.invocationResult.array != null) {
					if (listHospitalAll.length == 0) {
						listHospitalAll = [];
						for (var i = 0; i < result.invocationResult.array.length; i++) {
							var dt = {};
							dt.hospitalName = $filter('uppercase')(result.invocationResult.array[i].hospitalName);
							dt.address1 = $filter('uppercase')(result.invocationResult.array[i].address1);
							dt.address2 = $filter('uppercase')(result.invocationResult.array[i].address2);
							dt.address3 = $filter('uppercase')(result.invocationResult.array[i].address3);
							dt.postCode = result.invocationResult.array[i].postCode;
							dt.phone1 = result.invocationResult.array[i].phone1;
							listHospitalAll[i] = dt;
							pageHospital = 1;
						}
					} else {
						for (var i = 0; i < result.invocationResult.array.length; i++) {
							var dt = {};
							dt.hospitalName = $filter('uppercase')(result.invocationResult.array[i].hospitalName);
							dt.address1 = $filter('uppercase')(result.invocationResult.array[i].address1);
							dt.address2 = $filter('uppercase')(result.invocationResult.array[i].address2);
							dt.address3 = $filter('uppercase')(result.invocationResult.array[i].address3);
							dt.postCode = result.invocationResult.array[i].postCode;
							dt.phone1 = result.invocationResult.array[i].phone1;
							listHospitalAfterAdd[i] = dt;
							listHospitalAll.push(listHospitalAfterAdd[i]);
							$scope.numberOfItemsToDisplay += listHospitalAfterAdd.length;

						}


					}
				}

				$scope.agentList = listHospitalAll;

				$ionicLoading.hide();
				$scope.noMoreItemsAvailable = false;
				if (result.invocationResult.statusCode == 500) {
					$ionicLoading.hide();
					$scope.noMoreItemsAvailable = true;
					AppsLog.log("No data found1. Please try again later!");
				}

			} else if (result.invocationResult.statusCode == 500) {
				$scope.showLoading = false;
				$ionicLoading.hide();
				$scope.noMoreItemsAvailable = true;
				AppsLog.log("No data found2. Please try again later!");
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}

		getListCityHospitalSuccess(CityHospital);
		$scope.getListCityHospitalSuccess = getListCityHospitalSuccess;
		function getListCityHospitalSuccess(result) {
			AppsLog.log(" hasil json :" + JSON.stringify(result));
			if (result.invocationResult.isSuccessful) {
				if (result.invocationResult.array != null) {
					$scope.listCityHospital = [];
					$scope.listCityHospital.push($filter('translate')('SHOW_ALL'));
					for (var i = 0; i < result.invocationResult.array.length; i++) {
						$scope.listCityHospital.push(result.invocationResult.array[i].city_code);
					}
					$scope.filterItem = {
						onRequest: $scope.listCityHospital[0]
					}
				}
			} else if (result.invocationResult.statusCode == 500) {
				$ionicLoading.hide();
				AppsLog.log("PublicHospitalController - No data found. Please try again later!");
			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}
		AppsLog.log("END >> PublicHospitalController " + new Date());
	});