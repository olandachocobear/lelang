﻿angular.module('PruForce.controllers')

	.controller('PublicPageDaftarInformasiCtrl', function ($scope, $rootScope, $filter) {
		$scope.openpdf = function (url) {
			$rootScope.openPDF($filter('translate')(url));
		}
        $scope.isRolePD = function(){
            return $rootScope.pd
        }
	});