﻿/**
 * 
 */
angular.module('PruForce.controllers')

	.controller('AgentForgetPRUForceIDCtrl', function ($scope, $ionicLoading, $translate, $filter, $rootScope, $state, $localStorage, $ionicPopup, AgentVerifyingDataService, CheckIDEmailService) {


		$scope.initModel = {};

		// this is used for agent forget PRUForceID
		$scope.flagShowPlaceHolder = true;
		$scope.removeClass = function ($event) {
			$scope.flagShowPlaceHolder = false;
		}
		$scope.checkDate = function ($event) {
			if ($scope.initModel.dob == undefined || $scope.initModel.dob == '') {
				$scope.flagShowPlaceHolder = true;
			}
		}
		$scope.VerifyAgentFID = function () {
			if ($scope.initModel.agentCode == undefined || $scope.initModel.idcardno == undefined || $scope.initModel.dob == undefined || $scope.initModel.phonenumber == undefined) {
				$rootScope.AlertDialog($filter('translate')('PRU_05'));
			} else {
				$ionicLoading.show();
				$rootScope.agent.code = $scope.initModel.agentCode;
				$rootScope.agent.idcardno = $scope.initModel.idcardno;
				$rootScope.agent.dob = $scope.initModel.dob;
				$rootScope.agent.phonenumber = $scope.initModel.phonenumber;
				var dateOfBirth = $filter('date')($scope.initModel.dob, 'yyyy-MM-dd');
				AgentVerifyingDataService.invoke($scope.initModel.agentCode, $scope.initModel.idcardno, dateOfBirth, $scope.initModel.phonenumber).then(function (res) {
					VerifyAgentFIDSuccess(res);
				});
			}
		}

		function VerifyAgentFIDSuccess(res) {
			if (res.invocationResult.respCode == 200) {
				CheckIDEmailDataAgent();
			} else {
				$ionicLoading.hide();
				$rootScope.AlertDialog($filter('translate')('PRU_25'));
			}
		}

		function CheckIDEmailDataAgent() {
			CheckIDEmailService.invoke($rootScope.agent.code, $rootScope.userType).then(function (res) {
				CheckIDEmailAgentDataSuccess(res);
			});
		}

		function CheckIDEmailAgentDataSuccess(res) {
			$ionicLoading.hide();
			if (res.invocationResult.statusCode == 200) {
				$rootScope.agent.email = res.invocationResult.email;
				$state.go("verifikasi-sms", { 'smsType': 'ForgetPRUForceID', 'userType': 'agent' });
			} else {
				$rootScope.AlertDialog($filter('translate')('PRU_39'));

			}
		}

	});