﻿/**
 * 
 */
angular.module('PruForce.controllers')

	.controller('CandidateForgetPRUForceIDCtrl', function ($scope, $translate, $filter, $rootScope, $ionicLoading, $state, $localStorage, $ionicPopup, CandidateVerifyingDataService) {


		$scope.initModel = {};

		$scope.VerifyCandidateFID = function () {
			if ($scope.initModel.npa == undefined || $scope.initModel.nama == undefined || $scope.initModel.idcardno == undefined) {
				$rootScope.AlertDialog($filter('translate')('PRU_05'));
			} else {
				$ionicLoading.show();
				$rootScope.candidate.npa = $scope.initModel.npa;
				$rootScope.candidate.name = $scope.initModel.nama;
				$rootScope.candidate.idcardno = $scope.initModel.idcardno;
				var checksalesforceidflag = "N";
				$rootScope.candidate.checksalesforceidflag = $scope.initModel.checksalesforceidflag;
				CandidateVerifyingDataService.invoke($scope.initModel.npa, $scope.initModel.nama, $scope.initModel.idcardno, checksalesforceidflag).then(function (res) {
					VerifyCandidateFIDSuccess(res);
				});
			}

		}

		function VerifyCandidateFIDSuccess(result) {
			$ionicLoading.hide();
			if (result.invocationResult.respCode == 200) {
				$state.go("verifikasi-sms", { 'smsType': 'ForgetPRUForceID', 'userType': 'candidate' });
			} else {
				$rootScope.AlertDialog($filter('translate')('PRU_24'));
			}

		}

	});