﻿angular.module('PruForce.services')

    .service('SendForgetPRUForceIDService', function (AOBResources, $q) {

        function invoke(agentcode, npa, email) {

            var req = {
                adapter: "HTTPAdapterAuth",
                procedure: "forIDpruforceid",
                method: WLResourceRequest.POST,
                parameters: { "params": "['" + agentcode + "','" + npa + "','" + email + "']" }
            };

            var deferred = $q.defer();

            AOBResources.invoke(req, true)
                .then(function (res) {
                    deferred.resolve(res);
                }, function (error) {
                    deferred.reject(error);
                });

            return deferred.promise;
        }

        return {
            invoke: invoke
        }
    });

