﻿angular.module('PruForce.services')
	.service('GetImageAgentProfileService', function (DataFactoryOffline, $q) {
		AppsLog.log("masuk service 1");

		function invoke(pruforceId, agentCode) {

			AppsLog.log("agentnumbernya apa: " + agentCode);
			var module = "agentProfile";
			var fileName = "Image_" + agentCode + ".jpg";

			var req = {
				adapter: "HTTPAdapterInquiry",
				procedure: "downloadImageAgentProfile",
				method: WLResourceRequest.POST,
				parameters: { "params": "['" + pruforceId + "','" + agentCode + "','" + fileName + "','" + module + "']" }
			};

			var deferred = $q.defer();

			DataFactoryOffline.invoke(req, true)
				.then(function (res) {
					deferred.resolve(res);
					AppsLog.log("hasil invoke dalam service");
					AppsLog.log(res);
				}, function (error) {
					deferred.reject(error);
				});

			return deferred.promise;
		}

		return {
			invoke: invoke
		}
	});

