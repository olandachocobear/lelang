﻿angular.module('PruForce.controllers')
	.controller('AgentProfileCtrl', function ($scope, $rootScope, $http, $jrCrop, $ionicActionSheet, AgentProfileData, PhotoUploaderService, UploadImageAgentProfileService, GetImageAgentProfileService, $ionicLoading, ProfileClientService) {
		AnalyticsLog.logPage("prudential.AgentProfile");
		$scope.triggerEmail = function (agentEmailAddress) {
			window.location.href = 'mailto:' + agentEmailAddress;
		}
	
		getDataAgentProfileSuccess(AgentProfileData);

		$scope.agent = {};
		if ($rootScope.getPhotoProfile != undefined || $rootScope.getPhotoProfile != null) {
			$scope.agent.imageProfile = $rootScope.getPhotoProfile;
		} else {
			$scope.agent.imageProfile = "img/avatar-img.png";
		}


		
		function getDataAgentProfileSuccess(result) {
			if (result.invocationResult.isSuccessful) {
				$scope.agentNumber = result.invocationResult.agentNumber;
				$scope.clientName = result.invocationResult.clientName;
				$scope.clientNumber = result.invocationResult.clientNumber;
				$scope.marriageStatus = result.invocationResult.marriageStatus;
				$scope.address1 = result.invocationResult.agentAddress1;
				$scope.address2 = result.invocationResult.agentAddress2;
				$scope.address3 = result.invocationResult.agentAddress3;
				$scope.address4 = result.invocationResult.agentAddress4;
				$scope.address5 = result.invocationResult.agentAddress5;
				$scope.agentEmailAddress = result.invocationResult.agentEmailAddress;
				$scope.agentType = result.invocationResult.agentType;
				$scope.idNumber = result.invocationResult.idNumber;

				$scope.mobilePhone = result.invocationResult.mobilePhone;
				$scope.homePhone = result.invocationResult.homePhone;
				$scope.officePhone = result.invocationResult.officePhone;

				$scope.oficeLocation = result.invocationResult.office;
				if (result.invocationResult.unitCode != null && result.invocationResult.unitCode != "")
					$scope.unitCode = result.invocationResult.unitCode;
				else
					$scope.unitCode = "-";
				if (result.invocationResult.unitName != null && result.invocationResult.unitName != "")
					$scope.unitName = result.invocationResult.unitName;
				else
					$scope.unitName = "-";

				$scope.licenceNumber = result.invocationResult.licenceNumber;

				$scope.overallSanction = result.invocationResult.overallSanction;
				$scope.currentYearSanction = result.invocationResult.currentYearSanction;

				var joinDate = result.invocationResult.joinDate;
				var joinDateConv = new Date(joinDate);
				var joinDates = moment(joinDateConv).format('LL');
				$scope.joinDates = joinDates;

				var licenceExpiryDate = result.invocationResult.licenceExpiryDate;
				var licenceExpiryDateConv = new Date(licenceExpiryDate);
				var licenceExpiryDates = moment(licenceExpiryDateConv).format('LL');
				$scope.licenceExpiryDates = licenceExpiryDates;

				var dateBirth = result.invocationResult.dateOfBirth;
				var dateBirthConv = new Date(dateBirth);
				var dateofBirth = moment(dateBirthConv).format('LL');
				$scope.dateofBirth = dateofBirth;

				//$rootScope.clientNumber = $scope.clientNumber;

			} else {
				AppsLog.log("No data found. Please try again later!");
			}
		}

		function getDataClientProfileSuccess(result) {
			
				$scope.idNumber = result.invocationResult.idNumber;
				$scope.nationality = result.invocationResult.nationality;
				$scope.religion = result.invocationResult.religion;
				
				$scope.maritalStatus = result.invocationResult.maritalStatus;
				$scope.gender = result.invocationResult.gender;

				//$rootScope.clientNumber = null;

	
		}

		function getDataAgentProfileFailed(result) {
			AppsLog.log("Load Data Failed, Please Check Your Connection");
		}

		$scope.changePhoto = function () {
			var hideSheet = $ionicActionSheet.show({
				buttons: [
					{ text: 'Upload Gambar' },
					{ text: 'Ambil Gambar' }
				],
				cancelText: 'Cancel',
				cancel: function () {
				},
				buttonClicked: function (index) {
					if (index === 0) {
						AppsLog.log(0);
						takeGallery();
						hideSheet();
					} else if (index === 1) {
						AppsLog.log(1);
						takeCamera();
						hideSheet();
					}
				}
			});
		};

		function takeGallery() {
			PhotoUploaderService.GetFromLibrary().then(
				function (result) {
					try {
						var uploadTo = 'agent.imageProfile';
						var width = 200;
						var height = 200;
						$scope.showCropper(result, uploadTo, width, height);
					} catch (error) {
						$ionicLoading.hide();
						AppsLog.log("errornya :" + error);
					}
				},
				function (error) {
					AppsLog.log(error);
				}
			);
		}

		function takeCamera() {
			PhotoUploaderService.TakePictureFromCamera().then(
				function (result) {
					try {
						var uploadTo = 'agent.imageProfile';
						var width = 200;
						var height = 200;
						$scope.showCropper(result, uploadTo, width, height);
					} catch (error) {
						$ionicLoading.hide();
						AppsLog.log("errornya :" + error);
					}
				},
				function (error) {
					AppsLog.log(error);
				}
			);
		}

		$scope.showCropper = function (image, uploadTo, widthCropper, heightCropper) {
			var dataModel = uploadTo.split(".");
			$jrCrop.crop({
				url: image,
				width: widthCropper,
				height: heightCropper,
				cancelText: 'Batal',
				chooseText: 'Crop',
				allowRotation: true,
				buttonLocation: 'footer',
				circle: true
			}).then(function (canvas) {
				var agentCode = $rootScope.agent.code;
				var fileName = "Image_" + agentCode + ".jpg";
				var imageData = canvas.toDataURL();
				var pruforceId = $rootScope.username;
				UploadImageAgentProfileService.invoke(agentCode, pruforceId, agentCode, fileName, imageData).then(function (res) {
					GetImageAgentProfileService.invoke($rootScope.username, $rootScope.agent.code).then(function (res) {
						$scope[dataModel[0]][dataModel[1]] = canvas.toDataURL();
					});
				});
			});
		};

	})